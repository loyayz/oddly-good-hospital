import importlib.util,json,pathlib,shutil,sys
root=pathlib.Path(__file__).resolve().parent
side=sys.argv[1];source=root/(side+'-project');target=root/(side+'-all-project')
assert not target.exists()
shutil.copytree(source,target)
path=source/'tools/performance/instrument_all_instances.py'
spec=importlib.util.spec_from_file_location('instrument',path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
extra={
 'public_areas':['_derive_floor','_script_region_components','_region_basis','_wait_door_view','_facility_environment','_environment_sample_indices','_environment_matches','_queue_fit_current','_queue_fit_basis','_queue_fit_clear','_actor_index_scope'],
 'point_navigation':['_source_quote','_prepare_route_subject','_connector_preparation','_connector_edges','ready_waiting_cost_field'],
 'navigation':['_envelope','_traversal_shape','_graph_key','_distance_destination','ready_structural_field'],
 'environment':['_prepare_facility_sources','_build_facility_sources','_prepare_actor_sources','_prepare_sample_sources','_sample_records','_has_sample','_wall_edge','_wall_between'],
 'clinic':['_facility_busy','_staff_busy','_gathering_visit'],
 'departments':['ensure','_track_phase','_update_cause_clocks'],
}
for group,methods in extra.items(): module.EXTRA.setdefault(group,[]).extend(methods)
result=module.instrument(target)
result['extra_methods']=extra
(target/'all-instance-profile-identity.json').write_bytes((json.dumps(result,indent=2)+'\n').encode('utf8'))
print(json.dumps(dict(side=side,files=len(result['files']),methods=result['actual_method_count'])))
