extends SceneTree
func _initialize() -> void:
	var part: String = String.chr(0)
	var id: String = "a"+part+"suffix"
	var codes: Array = []
	for i: int in id.length(): codes.append(id.unicode_at(i))
	var bytes: PackedByteArray = PackedByteArray([97,0,115,117,102,102,105,120])
	var second: String = bytes.get_string_from_utf8()
	var second_codes: Array = []
	for i: int in second.length(): second_codes.append(second.unicode_at(i))
	print(JSON.stringify({"chr_part_length":part.length(),"chr_codes":codes,"utf8_codes":second_codes,"utf8_length":second.length()}))
	quit()
