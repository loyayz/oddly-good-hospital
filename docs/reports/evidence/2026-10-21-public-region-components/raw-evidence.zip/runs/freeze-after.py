from pathlib import Path
import hashlib,json,shutil,subprocess,uuid
repo=Path.cwd();root=Path(__file__).resolve().parent;source=root/'before-project';target=root/'after-project'
identity=json.loads((source/'source-identity.json').read_text(encoding='utf-8-sig'))
assert not target.exists();shutil.copytree(source,target)
paths=[r['path'] for r in identity['source']]
for p in subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],text=True).splitlines():
 if p.startswith(('game/','content/','tools/performance/','tests/acceptance/')) and p not in paths: paths.append(p)
rows=[]
for p in paths:
 actual=repo/p
 if p.startswith(('game/','content/','tools/performance/','tests/acceptance/')):
  assert actual.is_file(),p
  output=target/p;output.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(actual,output)
 blob=(target/p).read_bytes();rows.append({'path':p,'sha256':hashlib.sha256(blob).hexdigest()})
profile='OddlyGoodHospital Performance '+uuid.uuid4().hex
p=target/'project.godot';p.write_bytes(p.read_text(encoding='utf-8-sig').replace(identity['profile'],profile).encode('utf8'))
identity.update(project=str(target),profile=profile,source=rows,working_tree_base='f0261120d72266d3dec63f3f492c5ac171b39de3',copied_from=str(source))
for name in ['oddly_good_platform.windows.x86_64.dll','libgmp-10.dll','libmpfr-6.dll','libgcc_s_seh-1.dll','libwinpthread-1.dll']:
 shutil.copy2(repo/'game/platform/windows/bin'/name,target/'game/platform/windows/bin'/name)
identity['native_sha256']=hashlib.sha256((target/'game/platform/windows/bin/oddly_good_platform.windows.x86_64.dll').read_bytes()).hexdigest().upper()
(target/'source-identity.json').write_bytes((json.dumps(identity,indent=2)+chr(10)).encode('utf8'))
print('frozen production',sum(p['path'].startswith(('game/','content/','tools/performance/')) for p in rows),'tests',sum(p['path'].startswith('tests/acceptance/') for p in rows),'native',identity['native_sha256'])
