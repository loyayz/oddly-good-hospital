"""Build this region-computation delivery from explicit frozen-source config.

This script never starts Godot, builds native code, or rewrites game/test files.
delivery-config.json is supplied by the coordinator after profiles and selected
regressions finish. Missing observations are never treated as observed zeroes.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
import pathlib
import statistics
import subprocess
import sys
import zipfile
from datetime import datetime

REPO = pathlib.Path(r"C:\code\loyayz\oddly-good-hospital")
ROOT = pathlib.Path(__file__).resolve().parent
OUT = REPO / "docs/reports/evidence/2026-10-21-public-region-components"
CONFIG = ROOT / "delivery-config.json"
BASE = "f0261120d72266d3dec63f3f492c5ac171b39de3"
PREFIXES = ("game/", "content/", "tools/performance/")
WINDOWS = {"public360": (360, "public-v6.input.bin"), "gp80": (80, "gp.input.bin"), "operations40": (40, "op.input.bin")}
INPUTS = REPO / ".cache/task-navigation-20261019"
BINARY_KEYS = ("engine_sha256", "native_sha256", "gmp_sha256", "mpfr_sha256", "runtime_sha256")
ALL_IDENTITY = "all-instance-profile-identity.json"
sys.dont_write_bytecode = True


def read(path):
    return json.loads(pathlib.Path(path).read_text(encoding="utf-8-sig"))


def resolve(path):
    value = pathlib.Path(path)
    return value if value.is_absolute() else REPO / value


def digest(data):
    return hashlib.sha256(data).hexdigest()


def sha(path):
    return digest(pathlib.Path(path).read_bytes())


def dump(name, value):
    # Keep the evidence bytes identical to Git's LF blobs on Windows.
    (OUT / name).write_bytes((json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf8"))


def git_output(*arguments, text=False, data=None):
    return subprocess.check_output(["git", *arguments], cwd=REPO, text=text, input=data)


def git_blobs(expressions):
    raw = git_output("cat-file", "--batch", data="".join(x + "\n" for x in expressions).encode())
    cursor = 0
    for expression in expressions:
        end = raw.index(b"\n", cursor)
        header = raw[cursor:end].split()
        assert len(header) == 3 and header[1] == b"blob", (expression, header)
        size = int(header[2])
        cursor = end + 1
        yield raw[cursor:cursor + size]
        cursor += size + 1
    assert cursor == len(raw)


def measured(directory, label, window, side, project):
    path = directory / f"{label}-{window}.json"
    data = read(path)
    launch = read(directory / f"{label}-{window}.launch.json")
    steps, input_name = WINDOWS[window]
    assert data["complete"] and data["qualified"] and not data["errors"], path
    assert data["formal_pass"] is False and data["formal_acceptance_paused"] is True
    assert data["requested_steps"] == len(data["samples"]) == data["metrics"]["count"] == steps
    assert all(data["qualification"].values()) and all(data.get("public_checks", {}).values())
    assert all(sample["complete"] and sample["present"] == 160 for sample in data["samples"])
    depths = [sample["route_query_depth"] for sample in data["samples"] if "route_query_depth" in sample]
    assert all(depth == 0 for depth in depths), path
    if "profile" in data:
        assert len(depths) == steps, (path, "selected runner must record per-step query depths")
    assert data["initial"]["validation"] == data["final"]["validation"] == ""
    assert data["initial"]["present"] == data["final"]["present"] == 160
    assert not data["public"]["errors"]
    assert sha(path.with_name(path.name + ".final.bin")) == data["final_binary_sha256"]
    assert sha(INPUTS / input_name) == data["source_input_sha256"]
    assert launch["exit_code"] == 0 and not launch["affinity_changed"] and not launch["priority_changed"]
    assert isinstance(data["sources"], dict)
    for source, expected in data["sources"].items():
        assert source.startswith("res://") and sha(project / source.removeprefix("res://")) == expected, (path, source)
    for suffix in ("stdout.log", "stderr.log"):
        log = (directory / f"{label}-{window}.{suffix}").read_text(encoding="utf-8-sig")
        assert "SCRIPT ERROR:" not in log and "ERROR:" not in log, (path, suffix)
    public_keys = ("actual_use_ticks", "queue_actor_ticks", "actual_exit_then_reuse_count", "actual_use_starts", "actual_use_completions", "area_arrivals", "fallback_starts")
    return {
        "run": f"{side}-{label}-{window}", "side": side,
        "source_result": str(path), "source_result_sha256": sha(path),
        "metrics": data["metrics"], "execution": data["execution"], "launch": launch,
        "qualification": data["qualification"], "final_hash": data["final_binary_sha256"],
        "input_sha256": data["source_input_sha256"], "work": data["final"]["work_ticks_by_kind"],
        "query_counts": data["public"]["query_counts"], "operations": data["operations"],
        "public_work": {key: data["public"][key] for key in public_keys},
        "all_steps_complete_with_160_actors": True,
        "query_scope_depth_evidence": {"recorded_sample_count": len(depths), "missing_sample_count": steps - len(depths), "all_recorded_zero": True if depths else None},
    }, data


def same_work(rows):
    fields = ("final_hash", "input_sha256", "work", "public_work", "operations")
    assert all(all(row[key] == rows[0][key] for key in fields) for row in rows), [row["run"] for row in rows]


def binary_proof(identity, project):
    directory = project / "game/platform/windows/bin"
    names = {"oddly_good_platform.windows.x86_64.dll": identity["native_sha256"], "libgmp-10.dll": identity["gmp_sha256"], "libmpfr-6.dll": identity["mpfr_sha256"], **identity["runtime_sha256"]}
    for name, expected in names.items():
        assert sha(directory / name) == expected.lower(), (project, name)


def wrapper_proof(profile, plain):
    directory = resolve(profile["wrapper_project"])
    identity = read(directory / ALL_IDENTITY)
    tool = directory / "tools/performance/instrument_all_instances.py"
    assert sha(tool) == identity["transformer_sha256"] and identity["original_method_bodies_preserved"]
    spec = importlib.util.spec_from_file_location("frozen_" + profile["side"], tool)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    checked = []
    for row in identity["files"]:
        original = (directory / ".cache/tail-profile-originals" / row["path"]).read_bytes()
        generated = (directory / row["path"]).read_bytes()
        assert digest(original) == row["original_sha256"] == row["reconstructed_original_sha256"]
        assert sha(plain / row["path"]) == digest(original)
        assert digest(generated) == row["generated_sha256"]
        methods = {method["method"] for method in row["methods"]}
        group = row["methods"][0]["operation"].split(".", 1)[0]
        regenerated, records = module.transform(original.decode("utf8"), group, methods, bool(identity["decision_ledger"]))
        assert regenerated.encode("utf8") == generated and records == row["methods"], row["path"]
        checked.append({"path": row["path"], "original_sha256": digest(original), "generated_sha256": digest(generated), "method_count": len(methods), "inverse_and_regeneration_byte_equal": True})
    assert len(checked) == identity["transformed_file_count"]
    assert sum(row["method_count"] for row in checked) == identity["actual_method_count"]
    return {"side": profile["side"], "parent_project": str(directory), "identity_sha256": sha(directory / ALL_IDENTITY), "transformed_file_count": len(checked), "actual_method_count": identity["actual_method_count"], "all_original_bodies_and_generated_wrappers_equal": True, "files": checked}


def segment_proof(profile):
    target, parent, proof = (resolve(profile[key]) for key in ("segment_project", "wrapper_project", "segment_proof"))
    identity_name = profile["segment_identity"]
    identity = read(target / identity_name)
    receipt = read(proof / "preparation-receipt.json")
    assert identity["inverse_byte_equal"] and identity["original_statement_order_preserved"]
    assert identity["new_wrappers"] == identity["original_lines_removed_or_rewritten"] == 0
    assert sha(target / identity_name) == receipt["manifest_sha256"]
    assert sha(target / ALL_IDENTITY) == receipt["all_instance_identity_sha256"]
    assert sha(parent / ALL_IDENTITY) == identity["parent_all_instance_identity_sha256"]
    assert sha(proof / "parent-all-instance-profile-identity.json") == identity["parent_all_instance_identity_sha256"]
    operations = []
    for key, value in identity.items():
        if key.endswith("_operations") and isinstance(value, list): operations.extend(value)
    assert len(operations) == len(set(operations)) == identity["new_local_operation_count"]
    checked = []
    for row in [identity, *identity.get("additional_sources", [])]:
        generated = (target / row["source_file"]).read_bytes()
        text = generated.decode("utf8")
        for insertion in reversed(row["insertions"]):
            chunk = insertion["chunk"]
            assert digest(chunk.encode()) == insertion["chunk_sha256"] and text.count(chunk) == 1
            text = text.replace(chunk, "", 1)
        original = (parent / row["source_file"]).read_bytes()
        stem = pathlib.PurePosixPath(row["source_file"]).stem
        assert text.encode("utf8") == original
        assert original == (proof / (stem + ".original-all-wrapper.gd.txt")).read_bytes()
        assert original == (proof / (stem + ".inverse-reconstructed.gd.txt")).read_bytes()
        assert digest(original) == row["original_complete_source_sha256"] == row["inverse_complete_source_sha256"]
        assert digest(generated) == row["generated_complete_source_sha256"]
        checked.append({"path": row["source_file"], "original_sha256": digest(original), "generated_sha256": digest(generated), "inverse_byte_equal": True})
    for row in read(target / ALL_IDENTITY)["files"]:
        assert sha(target / row["path"]) == row["generated_sha256"]
    return {"side": profile["side"], "identity_sha256": sha(target / identity_name), "all_identity_sha256": sha(target / ALL_IDENTITY), "operations": operations, "new_local_operation_count": len(operations), "complete_inverse_byte_equal": True, "modified_files": checked}


def import_failures(config):
    failures = []
    identifiers = set()
    executed = {entry["id"] for entry in config["acceptance_batches"]}
    for entry in config.get("import_failures", []):
        identifier = entry["id"]
        assert identifier not in identifiers and identifier not in executed and entry["note"]
        identifiers.add(identifier)
        directory = REPO / ".cache/acceptance" / identifier
        identity = read(directory / "source-identity.json")
        timing = read(directory / "timing-summary.json")
        log = directory / "import.log"
        assert timing["phase"] == "import_failed" and timing["completed"] is False
        assert "tests_ms" in timing and timing["tests_ms"] is None
        assert "SCRIPT ERROR:" in log.read_text(encoding="utf-8-sig")
        # These files do not exist because the runner never reached test
        # execution. Do not manufacture a failed case or an execution result.
        assert not (directory / "acceptance-results.json").exists()
        assert not (directory / "execution-status.json").exists()
        paths = entry["source_paths"]
        assert paths and len(paths) == len(set(paths))
        by_path = {row["path"]: row for row in identity["source"]}
        rows = []
        for path in paths:
            assert path in by_path
            row = by_path[path]
            assert sha(directory / path) == row["sha256"], (identifier, path)
            rows.append(row)
        failures.append({"batch": identifier, "status": "import_failed", "test_executed": False,
                         "acceptance_results_present": False, "execution_status_present": False,
                         "note": entry["note"], "timing": timing, "files": rows,
                         "source_identity_sha256": sha(directory / "source-identity.json"),
                         "import_log_sha256": sha(log), "timing_sha256": sha(directory / "timing-summary.json"),
                         "native_sha256": identity["native_sha256"],
                         "requested_test_arguments_not_executed": identity["test_arguments"]})
    return failures


def main():
    config = read(CONFIG)
    assert config["schema_version"] == 1 and config["baseline"] == BASE
    assert config["native_changed"] is True
    profiles_config = config["profiles"]
    assert {profile["side"] for profile in profiles_config} == {"before", "after"} and len(profiles_config) == 2
    before = read(ROOT / "before-project/source-identity.json")
    after = read(ROOT / "after-project/source-identity.json")
    baseline_rows = [row for row in before["source"] if row["path"].startswith(PREFIXES)]
    final_rows = [row for row in after["source"] if row["path"].startswith(PREFIXES)]
    assert baseline_rows and final_rows
    for row, blob in zip(baseline_rows, git_blobs([BASE + ":" + row["path"] for row in baseline_rows])):
        assert digest(blob) == row["sha256"] == sha(ROOT / "before-project" / row["path"]), row["path"]
    current = [{**row, "match": sha(REPO / row["path"]) == row["sha256"] == sha(ROOT / "after-project" / row["path"])} for row in final_rows]
    assert all(row["match"] for row in current)
    old = {row["path"]: row["sha256"] for row in baseline_rows}
    changed = [row for row in current if old.get(row["path"]) != row["sha256"]]
    equal_binary = {key: before[key] == after[key] for key in BINARY_KEYS}
    assert not equal_binary["native_sha256"] and all(value for key, value in equal_binary.items() if key != "native_sha256")
    assert before["native_sha256"].lower() == config["expected_native_before"].lower()
    assert after["native_sha256"].lower() == config["expected_native_after"].lower()
    for identity, project in ((before, ROOT / "before-project"), (after, ROOT / "after-project"), (after, REPO)):
        binary_proof(identity, project)
    console_engine = pathlib.Path(after["engine"])
    assert sha(console_engine) == after["engine_sha256"].lower()
    gui_engine = console_engine.with_name(console_engine.name.replace("_console", ""))
    windows, profiles, launches = [], [], []
    for window in WINDOWS:
        rows = []
        for label in ("a", "b", "c", "d"):
            side = "before" if label in {"a", "d"} else "after"
            row, _ = measured(ROOT, label, window, side, ROOT / (side + "-project"))
            rows.append(row)
            launches.append(row["launch"])
        same_work(rows)
        before_mean = statistics.mean(rows[index]["metrics"]["mean_us"] for index in (0, 3))
        after_mean = statistics.mean(rows[index]["metrics"]["mean_us"] for index in (1, 2))
        windows.append({"window": window, "runs": rows, "whole_world_equal": True, "before_mean_us": before_mean, "after_mean_us": after_mean, "mean_reduction_percent": (1 - after_mean / before_mean) * 100})
        for entry in profiles_config:
            row, data = measured(resolve(entry["root"]), entry["label"], window, entry["side"], resolve(entry["segment_project"]))
            same_work([rows[0], row])
            profile = data["profile"]
            assert not profile["errors"] and profile["step_records_complete"] and profile["incomplete_steps"] == 0
            assert data["all_instance_source_identity_sha256"] == sha(resolve(entry["segment_project"]) / ALL_IDENTITY)
            indices = {sample["tick"]: sample["index"] for sample in data["samples"]}
            steps = [{"index": indices[step["tick"]], "tick": step["tick"], "outer_us": step["outer_elapsed_us"], "observer_us": step["observer_handler_us"], "stages": step["stages"], "calls": step["calls"]} for step in profile["step_records"] if step["calls"]]
            assert steps
            profiles.append({**row, "steps": steps, "errors": profile["errors"], "raw_profile_retained": True})
            launches.append(row["launch"])
    engines = {launch["engine_executable_sha256"].lower() for launch in launches}
    assert engines == {sha(gui_engine)}

    batches, executed_tests, final_tests = [], [], []
    delivery_test_rows, delivery_batch = {}, None
    assert config["acceptance_batches"]
    assert len({entry["id"] for entry in config["acceptance_batches"]}) == len(config["acceptance_batches"])
    for entry in config["acceptance_batches"]:
        directory = REPO / ".cache/acceptance" / entry["id"]
        result, execution = read(directory / "acceptance-results.json"), read(directory / "execution-status.json")
        requested = set(entry["required_cases"])
        assert set(result["requested_cases"]) == set(result["results"]) == requested
        assert result["completed"] and result["checks"] == result["declared"] == len(requested)
        assert not execution["script_errors"] and execution["import_exit"] == 0
        assert result["failed"] == sum(not value["passed"] for value in result["results"].values())
        assert execution["test_exit"] == (1 if result["failed"] else 0)
        if entry.get("must_pass", True):
            assert result["failed"] == 0 and all(value["passed"] for value in result["results"].values())
            assert execution["import_exit"] == execution["test_exit"] == 0
        timing = read(directory / "timing-summary.json")
        assert timing["phase"] == "finished" and timing["completed"] and timing["tests_ms"] is not None
        batches.append({"batch": entry["id"], "result": result, "timing": timing, "execution": execution, "must_pass": entry.get("must_pass", True)})
        identity = read(directory / "source-identity.json")
        # Failed assertions may be retained beside a targeted successful
        # rerun. Every executed snapshot must still be this delivery's exact
        # production/native build; test source snapshots remain independent.
        assert all(after[key] == identity[key] for key in BINARY_KEYS)
        binary_proof(identity, directory)
        for row in identity["source"]:
            if row["path"].startswith(("game/", "content/")):
                assert sha(directory / row["path"]) == sha(REPO / row["path"]) == row["sha256"]
        rows = [row for row in identity["source"] if row["path"].startswith("tests/acceptance/")]
        for row in rows: assert sha(directory / row["path"]) == row["sha256"], row["path"]
        executed_tests.append({"batch": entry["id"], "source_identity_sha256": sha(directory / "source-identity.json"), "production_and_native_match_delivery": True, "files": rows})
        if entry.get("delivery_source", False):
            assert entry.get("must_pass", True)
            delivery_batch = entry["id"]
            delivery_test_rows = {row["path"]: row["sha256"] for row in rows}
            paths = set(config["delivery_test_paths"])
            final_tests = [row for row in rows if row["path"] in paths]
            assert {row["path"] for row in final_tests} == paths
            for row in final_tests: assert sha(REPO / row["path"]) == row["sha256"], row["path"]
    assert sum(bool(entry.get("delivery_source")) for entry in config["acceptance_batches"]) == 1
    latest, passed_union = {}, set()
    chronological = sorted(batches, key=lambda batch: datetime.fromisoformat(batch["timing"]["started_at_utc"]))
    assert chronological[-1]["batch"] == delivery_batch
    for batch in chronological:
        started = datetime.fromisoformat(batch["timing"]["started_at_utc"])
        finished = datetime.fromisoformat(batch["timing"]["ended_at_utc"])
        assert finished >= started
        for case, value in batch["result"]["results"].items():
            latest[case] = {"batch": batch["batch"], "passed": value["passed"], "completed_at_utc": batch["timing"]["ended_at_utc"]}
            if value["passed"]: passed_union.add(case)
    assert latest and all(value["passed"] for value in latest.values()), latest
    for snapshot in executed_tests:
        snapshot["test_source_differences_from_delivery"] = [{"path": row["path"], "executed_sha256": row["sha256"], "delivery_sha256": delivery_test_rows.get(row["path"])} for row in snapshot["files"] if row["sha256"] != delivery_test_rows.get(row["path"])]
    failed_imports = import_failures(config)
    wrapper_checks = [wrapper_proof(entry, ROOT / (entry["side"] + "-project")) for entry in profiles_config]
    segment_checks = [segment_proof(entry) for entry in profiles_config]
    pending = config["pending_work"]
    assert pending and all(entry["status"] == "not_executed" and entry["note"] for entry in pending)
    OUT.mkdir(parents=True, exist_ok=True)
    dump("quick-summary.json", {"baseline": BASE, "diagnostic_only": True, "formal_pass": False, "formal_acceptance_paused": True, "execution_order": ["a:before", "b:after", "c:after", "d:before"], "native_changed": True, "windows": windows, "retained_results": config.get("retained_results", []), "caution": "Independent plain fixed legal 160-person windows; percentiles are not pooled. Prior baseline selected profiles are retained with original provenance. This editor headless debug comparison is not formal Release acceptance."})
    dump("function-summary.json", {"baseline": BASE, "profiles": profiles, "transform_originals": wrapper_checks, "local_segment_inverses": segment_checks, "caution": "Method/segment counts come from actual frozen identities. Wrappers perturb timing; inclusive parent values overlap children. Only plain windows establish whole-step comparisons."})
    dump("functional-summary.json", {"batches": batches, "latest_case_results": latest, "passed_case_union": sorted(passed_union), "delivery_test_source_batch": delivery_batch, "import_failures": failed_imports, "formal_pass": False, "formal_acceptance_paused": True, "unexecuted_work": pending, "caution": "Per-case latest executed results must pass; passing cases may come from an earlier complete batch and a later targeted rerun on the identical production/native build. This does not claim the targeted rerun executed the earlier batch's other cases. Original failed assertions and distinct test snapshots remain retained. Import failures happened before test execution and are not failed-case results. Pending yield recovery source and its hook are not executed and are not represented as passing."})
    dump("source-check.json", {"baseline": BASE, "baseline_files": baseline_rows, "final_files": current, "changed_production_files": changed, "binary_equal": equal_binary, "native_changed": True, "before_native": before["native_sha256"], "after_native": after["native_sha256"], "actual_engine_path": str(gui_engine), "actual_engine_sha256": next(iter(engines)), "console_engine_sha256": sha(console_engine), "transform_originals": wrapper_checks, "local_segment_inverses": segment_checks, "executed_test_snapshots": executed_tests, "delivery_test_source_batch": delivery_batch, "import_failure_snapshots": failed_imports, "final_test_files": final_tests, "delivery_test_file_count": len(final_tests), "unexecuted_work": pending, "test_game_matches": True, "complete_executed_results_and_every_sample_validated": True})
    entries, archive_size = archive_evidence(config, changed, executed_tests, failed_imports)
    print(json.dumps({"archive_entries": len(entries), "archive_bytes": archive_size, "baseline_files": len(baseline_rows), "final_files": len(final_rows), "delivery_test_files": len(final_tests), "formal_acceptance_paused": True}))
    for window in windows: print(window["window"], window["before_mean_us"], window["after_mean_us"], window["mean_reduction_percent"])


def archive_evidence(config, changed, tests, failed_imports):
    files, notes = {}, {}

    def add(path, name):
        path = pathlib.Path(path)
        assert path.is_file(), path
        assert name not in files or files[name] == path, name
        files[name] = path

    def tree(directory, prefix):
        directory = pathlib.Path(directory)
        assert directory.is_dir(), directory
        for path in directory.rglob("*"):
            if path.is_file(): add(path, prefix + path.relative_to(directory).as_posix())

    def run_files(directory, prefix, label=None):
        for path in directory.iterdir():
            selected = label is None or path.name.startswith(label + "-")
            if not selected: continue
            if path.is_file() and path.suffix in {".json", ".bin", ".ndjson", ".log", ".py", ".ps1", ".txt", ".md", ".gd"}: add(path, prefix + path.name)
            elif path.is_dir() and path.name.endswith(".json.sources"): tree(path, prefix + path.name + "/")

    run_files(ROOT, "runs/")
    for side in ("before", "after"):
        directory = ROOT / (side + "-project")
        add(directory / "source-identity.json", "runs/" + side + "-project/source-identity.json")
        for path in directory.glob("*.log"): add(path, "runs/" + side + "-project/" + path.name)
    for profile in config["profiles"]:
        prefix = profile["side"] + "-instrumentation/"
        source = resolve(profile["wrapper_project"])
        run_files(resolve(profile["root"]), prefix + "original-runs/", profile["label"])
        for name in (ALL_IDENTITY, "source-identity.json"): add(source / name, prefix + "parent-all-project/" + name)
        for row in read(source / ALL_IDENTITY)["files"]:
            for relative in (row["path"], ".cache/tail-profile-originals/" + row["path"]): add(source / relative, prefix + "parent-all-project/" + relative)
        for path in source.glob("*.log"): add(path, prefix + "parent-all-project/" + path.name)
        tree(resolve(profile["segment_proof"]), prefix + "segments-proof/")
        segment = resolve(profile["segment_project"])
        for name in (ALL_IDENTITY, profile["segment_identity"], "source-identity.json"): add(segment / name, prefix + "segment-project/" + name)
        identity = read(segment / profile["segment_identity"])
        for row in [identity, *identity.get("additional_sources", [])]: add(segment / row["source_file"], prefix + "segment-project/" + row["source_file"])
        for path in segment.glob("*.log"): add(path, prefix + "segment-project/" + path.name)
        for index, path in enumerate(profile.get("preparation_scripts", [])): add(resolve(path), prefix + "scripts/" + str(index) + "-" + pathlib.Path(path).name)
    for snapshot in tests:
        directory = REPO / ".cache/acceptance" / snapshot["batch"]
        prefix = "acceptance/" + snapshot["batch"] + "/"
        for path in directory.iterdir():
            if path.is_file() and path.suffix in {".json", ".log"}: add(path, prefix + path.name)
        for row in snapshot["files"]: add(directory / row["path"], prefix + "executed-source/" + row["path"])
    for snapshot in failed_imports:
        directory = REPO / ".cache/acceptance" / snapshot["batch"]
        prefix = "import-failures/" + snapshot["batch"] + "/"
        for name in ("source-identity.json", "import.log", "timing-summary.json"):
            add(directory / name, prefix + name)
        for row in snapshot["files"]: add(directory / row["path"], prefix + "source/" + row["path"])
        notes[prefix + "NOT-EXECUTED.json"] = (json.dumps(snapshot, ensure_ascii=False, indent=2) + "\n").encode("utf8")
    for _, name in WINDOWS.values(): add(INPUTS / name, "inputs/" + name)
    for row in changed: add(REPO / row["path"], "final-source/" + row["path"])
    for index, entry in enumerate(config["pending_work"]):
        path = resolve(entry["path"])
        prefix = "unexecuted-pending/" + str(index) + "/"
        if path.is_dir(): tree(path, prefix + "source/")
        else: add(path, prefix + "source/" + path.name)
        notes[prefix + "NOT-EXECUTED.json"] = (json.dumps(entry, ensure_ascii=False, indent=2) + "\n").encode("utf8")
    for index, entry in enumerate(config.get("additional_evidence_paths", [])):
        path = resolve(entry["path"])
        prefix = "additional/" + str(index) + "/"
        if path.is_dir(): tree(path, prefix)
        else: add(path, prefix + path.name)
    archive, manifest = OUT / "raw-evidence.zip", []
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as container:
        for name, path in sorted(files.items()):
            blob = path.read_bytes()
            container.writestr(name, blob)
            manifest.append({"path": name, "sha256": digest(blob), "bytes": len(blob)})
        for name, blob in sorted(notes.items()):
            assert name not in files
            container.writestr(name, blob)
            manifest.append({"path": name, "sha256": digest(blob), "bytes": len(blob)})
    with zipfile.ZipFile(archive) as container:
        assert len(container.namelist()) == len(set(container.namelist())) == len(manifest)
        for row in manifest:
            blob = container.read(row["path"])
            assert digest(blob) == row["sha256"] and len(blob) == row["bytes"]
    dump("raw-manifest.json", {"archive": archive.name, "sha256": sha(archive), "bytes": archive.stat().st_size, "entries": manifest, "every_entry_sha256_verified": True})
    return manifest, archive.stat().st_size


if __name__ == "__main__":
    main()
