"""Verify this delivery after aggregation, report authoring and staging."""
from __future__ import annotations

import argparse
import hashlib
import json
import pathlib
import re
import subprocess
import zipfile
from datetime import datetime

REPO = pathlib.Path(r"C:\code\loyayz\oddly-good-hospital")
ROOT = pathlib.Path(__file__).resolve().parent
OUT = REPO / "docs/reports/evidence/2026-10-21-public-region-components"
CRLF_EXCEPTION = "tests/acceptance/zip_library_boundaries.gd"


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def digest(data):
    return hashlib.sha256(data).hexdigest()


def git_output(*arguments, text=False, data=None):
    return subprocess.check_output(["git", *arguments], cwd=REPO, text=text, input=data)


def main():
    config = read(ROOT / "delivery-config.json")
    default = pathlib.Path(config["report_path"])
    if not default.is_absolute(): default = REPO / default
    parser = argparse.ArgumentParser()
    parser.add_argument("--report", type=pathlib.Path, default=default)
    report = parser.parse_args().report.resolve()
    source = read(OUT / "source-check.json")
    rows = source["final_files"] + source["final_test_files"]
    raw = git_output("cat-file", "--batch", data="".join(":" + row["path"] + "\n" for row in rows).encode())
    cursor, exceptions = 0, []
    for row in rows:
        end = raw.index(b"\n", cursor)
        header = raw[cursor:end].split()
        assert len(header) == 3 and header[1] == b"blob", (row["path"], header)
        size = int(header[2])
        cursor = end + 1
        blob = raw[cursor:cursor + size]
        cursor += size + 1
        current = (REPO / row["path"]).read_bytes()
        assert digest(current) == row["sha256"], row["path"]
        if digest(blob) != row["sha256"]:
            assert row["path"] == CRLF_EXCEPTION, row["path"]
            assert blob.replace(b"\r\n", b"\n") == current.replace(b"\r\n", b"\n")
            assert not git_output("diff", "HEAD", "--", row["path"])
            exceptions.append(row["path"])
    assert cursor == len(raw)
    assert source["native_changed"] and source["before_native"] != source["after_native"]
    assert not source["binary_equal"]["native_sha256"]
    assert all(value for key, value in source["binary_equal"].items() if key != "native_sha256")
    assert source["delivery_test_file_count"] == len(source["final_test_files"])
    assert report.is_file()
    links = re.findall(r"\]\((evidence/[^)]+)\)", report.read_text(encoding="utf8"))
    assert links and all((report.parent / link).is_file() for link in links)
    required = {"quick-summary.json", "function-summary.json", "functional-summary.json", "source-check.json", "raw-manifest.json", "raw-evidence.zip"}
    assert required <= {pathlib.Path(link).name for link in links}
    for name in required - {"raw-evidence.zip"}:
        blob = (OUT / name).read_bytes()
        assert blob.endswith(b"\n") and b"\r" not in blob and not blob.startswith(b"\xef\xbb\xbf"), name
        blob.decode("utf8")
    quick, functions, functional = (read(OUT / name) for name in ("quick-summary.json", "function-summary.json", "functional-summary.json"))
    assert quick["formal_pass"] is False and quick["formal_acceptance_paused"] is True
    assert functional["formal_pass"] is False and functional["formal_acceptance_paused"] is True
    passed, latest = set(), {}
    chronological = sorted(functional["batches"], key=lambda batch: datetime.fromisoformat(batch["timing"]["started_at_utc"]))
    assert chronological[-1]["batch"] == functional["delivery_test_source_batch"] == source["delivery_test_source_batch"]
    configured_batches = {entry["id"]: entry for entry in config["acceptance_batches"]}
    assert len(configured_batches) == len(chronological) and set(configured_batches) == {batch["batch"] for batch in chronological}
    assert configured_batches[functional["delivery_test_source_batch"]]["delivery_source"]
    for batch in chronological:
        assert batch["result"]["completed"] and not batch["execution"]["script_errors"] and batch["execution"]["import_exit"] == 0
        assert batch["must_pass"] == configured_batches[batch["batch"]].get("must_pass", True)
        assert set(batch["result"]["results"]) == set(configured_batches[batch["batch"]]["required_cases"])
        assert batch["result"]["failed"] == sum(not value["passed"] for value in batch["result"]["results"].values())
        assert batch["execution"]["test_exit"] == (1 if batch["result"]["failed"] else 0)
        if batch["must_pass"]:
            assert batch["result"]["failed"] == 0 and batch["execution"]["test_exit"] == 0
        for case, value in batch["result"]["results"].items():
            latest[case] = {"batch": batch["batch"], "passed": value["passed"], "completed_at_utc": batch["timing"]["ended_at_utc"]}
            if value["passed"]: passed.add(case)
    assert latest == functional["latest_case_results"] and all(value["passed"] for value in latest.values())
    assert sorted(passed) == functional["passed_case_union"]
    assert all(snapshot["production_and_native_match_delivery"] for snapshot in source["executed_test_snapshots"])
    assert functional["unexecuted_work"] and all(item["status"] == "not_executed" for item in functional["unexecuted_work"])
    failures = functional["import_failures"]
    assert source["import_failure_snapshots"] == failures
    configured_failures = {entry["id"]: entry for entry in config.get("import_failures", [])}
    assert len(configured_failures) == len(failures) and {entry["batch"] for entry in failures} == set(configured_failures)
    assert not set(configured_failures).intersection(batch["batch"] for batch in functional["batches"])
    for failure in failures:
        assert failure["status"] == "import_failed" and failure["test_executed"] is False
        assert failure["acceptance_results_present"] is failure["execution_status_present"] is False
        assert failure["timing"]["phase"] == "import_failed" and failure["timing"]["completed"] is False
        assert failure["timing"]["tests_ms"] is None
        assert failure["note"] == configured_failures[failure["batch"]]["note"]
        assert {row["path"] for row in failure["files"]} == set(configured_failures[failure["batch"]]["source_paths"])
    for wrapper in functions["transform_originals"]: assert wrapper["all_original_bodies_and_generated_wrappers_equal"]
    for segment in functions["local_segment_inverses"]: assert segment["complete_inverse_byte_equal"]
    manifest = read(OUT / "raw-manifest.json")
    archive = OUT / manifest["archive"]
    assert digest(archive.read_bytes()) == manifest["sha256"] and archive.stat().st_size == manifest["bytes"]
    with zipfile.ZipFile(archive) as container:
        assert len(container.namelist()) == len(set(container.namelist())) == len(manifest["entries"])
        for row in manifest["entries"]:
            blob = container.read(row["path"])
            assert digest(blob) == row["sha256"] and len(blob) == row["bytes"]
        assert any(name.startswith("unexecuted-pending/") and name.endswith("NOT-EXECUTED.json") for name in container.namelist())
        for failure in failures:
            prefix = "import-failures/" + failure["batch"] + "/"
            assert json.loads(container.read(prefix + "NOT-EXECUTED.json")) == failure
            for name, key in (("source-identity.json", "source_identity_sha256"), ("import.log", "import_log_sha256"), ("timing-summary.json", "timing_sha256")):
                assert digest(container.read(prefix + name)) == failure[key]
            assert json.loads(container.read(prefix + "timing-summary.json")) == failure["timing"]
            for row in failure["files"]:
                assert digest(container.read(prefix + "source/" + row["path"])) == row["sha256"]
            assert prefix + "acceptance-results.json" not in container.namelist()
            assert prefix + "execution-status.json" not in container.namelist()
    staged = git_output("diff", "--cached", "--name-only", text=True).splitlines()
    assert staged and not any(path.lower().endswith(".dll") for path in staged)
    expected = {report.relative_to(REPO).as_posix()}
    expected.update((OUT / name).relative_to(REPO).as_posix() for name in required)
    expected.update(row["path"] for row in source["changed_production_files"] + source["final_test_files"])
    assert expected <= set(staged), sorted(expected - set(staged))
    for relative in staged:
        if relative.startswith("docs/reports/"): assert git_output("show", ":" + relative) == (REPO / relative).read_bytes(), relative
    assert not git_output("diff", "--check") and not git_output("diff", "--cached", "--check")
    print(json.dumps({"staged_files": len(staged), "verified_delivery_files": len(rows), "unchanged_crlf_exceptions": exceptions, "report_links": len(links), "raw_entries": len(manifest["entries"]), "selected_affected_cases_passed": len(passed), "import_failures_before_test_execution": len(failures), "pending_work_not_executed": True, "formal_acceptance_paused": True}))


if __name__ == "__main__":
    main()
