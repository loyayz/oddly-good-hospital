from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import zipfile

REPO = Path(__file__).resolve().parent.parent
ROOT = REPO / '.cache/floor-graph-936a7f1-20261023'
OUT = REPO / 'docs/reports/evidence/2026-10-23-floor-graph-worker-trial'
read = lambda path: json.loads(Path(path).read_text(encoding='utf-8-sig'))
digest = lambda data: hashlib.sha256(data).hexdigest()
sha = lambda path: digest(Path(path).read_bytes())
relative = lambda path: Path(path).relative_to(REPO).as_posix()
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip()
assert head.startswith('936a7f1'), head
assert subprocess.check_output(['git', 'branch', '--show-current'], cwd=REPO, text=True).strip() == 'dev'
subprocess.check_call(['git', 'diff', '--exit-code', '--', 'game', 'tests', 'project.godot'], cwd=REPO)
parent = REPO / 'docs/reports/evidence/2026-10-23-entry-route-costs/raw-evidence.zip'
assert sha(parent) == 'da69ed15f0847489a328ef229fc3450a87207f97f9ff3b2973cffbe3071bd326'
baseline = read(ROOT / 'baseline-identity.json')
baseline_rows = {row['path']: row['sha256'] for row in baseline['sources'] + baseline['tests']}
for row in baseline['sources'] + baseline['tests']:
    if row['path'] not in ['project.godot', 'export_presets.cfg']:
        assert sha(REPO / row['path']) == row['sha256'], row['path']
members = {}
aliases = []
identities = {}


def add(path, name=None):
    path = Path(path)
    name = name or relative(path)
    data = path.read_bytes()
    if name in members:
        assert members[name] == data, name
    members[name] = data


for path in sorted(ROOT.glob('*-identity.json')):
    if path.name.endswith('-initial-identity.json'):
        continue
    variant = path.name.removesuffix('-identity.json')
    identity = read(path)
    project = ROOT / (variant + '-project')
    for key in ['sources', 'tests']:
        for row in identity[key]:
            source = project / row['path']
            assert sha(source) == row['sha256'], source
            if baseline_rows.get(row['path']) != row['sha256']:
                member = 'source-blobs/' + row['sha256'] + source.suffix
                add(source, member)
                aliases.append(dict(path=relative(source), member=member, sha256=row['sha256']))
    identities[variant] = dict(sources=len(identity['sources']), tests=len(identity['tests']), all_files_verified=True,
                               measured=any(read(item)['variant'] == variant for item in ROOT.glob('*.source-check.json')))

runs = {}
intervals = []
for path in sorted(ROOT.glob('*.semantic-check.json')):
    label = path.name.removesuffix('.semantic-check.json')
    check = read(path)
    launch = read(ROOT / (label + '.launch.json'))
    source = read(ROOT / (label + '.source-check.json'))
    actual = read(ROOT / (label + '.json'))
    variant = source['variant']
    assert check['passed'] and all(check['checks'].values()), label
    assert launch['exit_code'] == 0 and not launch['errors'] and not launch['timed_out'], label
    assert sha(launch['engine']) == launch['engine_sha256']
    assert source['actual_sources'] == read(ROOT / (variant + '-identity.json'))['sources']
    assert actual['requested_steps'] == len(actual['samples']) == actual['metrics']['count'] == 80
    assert actual['complete'] and actual['qualified'] and not actual['errors']
    assert all(row['complete'] and row['present'] == 160 for row in actual['samples'])
    assert sha(ROOT / (label + '.json.final.bin')) == actual['final_binary_sha256']
    differences = check['query_count_differences']
    batch = actual.get('floor_graph_batch', {})
    if variant in ['baselineworker4v2', 'baselineserialv2']:
        extra = read(ROOT / (label + '.floor-batch-check-v2.json'))
        assert extra['passed'] and all(extra['checks'].values()), label
        assert set(differences) == {'floor_batch_graphs', 'floor_batch_consumed', 'door_candidates', 'reservation_candidate_queries'}
        for key in ['door_candidates', 'reservation_candidate_queries']:
            assert differences[key]['expected'] - differences[key]['actual'] == 16
        assert differences['floor_batch_graphs']['actual'] == differences['floor_batch_consumed']['actual'] == 4
        assert len(batch['records']) == 1
        record = batch['records'][0]
        assert record['actors'] == 112 and record['floors'] == [1, 2, 3, 4] and record['tick'] == 851
        assert record['charged'] == 39687424 and record['query_charged'] == 0 and record['target'] == 134217728
        assert all(job['points'] == 9216 for job in record['jobs'])
        if variant == 'baselineworker4v2':
            assert len({job['thread_id'] for job in record['jobs']}) == 4
            assert all(job['thread_id'] != record['main_thread_id'] for job in record['jobs'])
        else:
            assert all(job['thread_id'] == record['main_thread_id'] for job in record['jobs'])
    else:
        assert not differences
        assert not batch.get('records', [])
        extra = dict(no_batch_executed=True)
    intervals.append((launch['started_at_utc'], launch['ended_at_utc'], label))
    runs[label] = dict(variant=variant, metrics_us=actual['metrics'], tick851_us=next(row['elapsed_us'] for row in actual['samples'] if row['tick'] == 851),
                       input_sha256=actual['source_input_sha256'], final_binary_sha256=actual['final_binary_sha256'],
                       query_counts=actual['public']['query_counts'], query_count_differences=differences,
                       batch=batch, checks=check['checks'], additional_checks=extra,
                       process_cpu_ms=launch['child_cpu_ms'], process_wall_ms=launch['wall_ms'])
assert len(runs) == 7
intervals.sort()
for left, right in zip(intervals, intervals[1:]):
    assert left[1] <= right[0], (left, right)
initial_guard = read(ROOT / 'b2-gp80.floor-batch-check.json')
assert initial_guard['passed'] is False and initial_guard['checks']['all_semantic_checks']
assert initial_guard['checks']['only_batch_counters'] is False
for path in ROOT.iterdir():
    if path.is_file() and not path.name.endswith('.final.bin'):
        add(path)
for path in ROOT.glob('*.json.final.bin'):
    member = 'final-states/' + sha(path) + '.bin'
    add(path, member)
    aliases.append(dict(path=relative(path), member=member, sha256=sha(path)))
for name in ['floor_graph_round.py', 'floor_graph_batch.gd', 'worker_select_round.py']:
    add(REPO / '.cache' / name)
add(REPO / '.cache/wait-signature-031e1f7-20261022/run.py')
add(REPO / '.cache/task-navigation-20261019/gp.input.bin')
add(Path(__file__))
members['source-aliases.json'] = (json.dumps(aliases, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
OUT.mkdir(parents=True, exist_ok=True)
archive = OUT / 'raw-evidence.zip'
assert not archive.exists()
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as output:
    for name, data in sorted(members.items()):
        output.writestr(name, data)
with zipfile.ZipFile(archive) as output:
    assert set(output.namelist()) == set(members)
    for name, data in members.items():
        assert digest(output.read(name)) == digest(data), name
manifest = dict(schema_version=1, archive_sha256=sha(archive), archive_bytes=archive.stat().st_size,
                baseline_reference=dict(path=relative(parent), sha256=sha(parent)),
                members=[dict(path=name, bytes=len(data), sha256=digest(data)) for name, data in sorted(members.items())])
summary = dict(schema_version=1, generated_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               baseline_commit=head, production_commit='5712c6f7fbc7e222e2a483bc376201352fd5ffc2', diagnostic_only=True, formal_pass=False,
               fixed_load=dict(people=160, patients=120, staff=32, visitors=8, floors=4, rooms=64, facilities=1336, tick_seconds=0.1),
               engine_windows=7, qualified_measured_steps=560, actual_worker_group_windows=2, serial_group_control_windows=2,
               inactive_trial_windows=['b1-gp80'], all_recorded_engine_intervals_disjoint=True, engine_intervals=intervals,
               production_and_tests_unchanged=True, identities=identities, runs=runs, adoption=False,
               functional_engine_windows=0, selected_but_not_run_cases=['SPACE-46', 'SPACE-51', 'SPACE-55', 'STAFF-57', 'STAFF-61'],
               no_public_or_operations_followup=True, no_release_or_formal_acceptance=True,
               raw_archive=dict(path=relative(archive), sha256=sha(archive), bytes=archive.stat().st_size, members=len(members)),
               limitations=['No whole-window stable gain was established; group-only improvement is not formal or whole-step acceptance.',
                            'Worker b3 is already slow in the unchanged cold first step, before its sole group at tick851. Do not attribute all of its regression to parallelization.',
                            'b1 uses the endpoint-pair prototype and executes no group; its timing is not a parallel speedup.',
                            'The initial b2 count guard failed after the engine and semantic checks passed. Both old failed guard and corrected validation are retained.',
                            'Sandboxed Get-Process observes a restricted process namespace; ordered terminal sessions and recorded process intervals establish this batch ordering.',
                            'The host CPU and background process observations are post-run snapshots and do not prove the cause of timing variance.',
                            'No background processes, power plan, affinity, priority, input load, polling interval, warmup or cache allowance were changed.',
                            'No push was performed.'])
for name, value in [('raw-manifest.json', manifest), ('summary.json', summary)]:
    path = OUT / name
    assert not path.exists()
    path.write_bytes((json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
print(json.dumps(dict(archive_sha256=sha(archive), bytes=archive.stat().st_size, members=len(members), windows=7, steps=560)))
