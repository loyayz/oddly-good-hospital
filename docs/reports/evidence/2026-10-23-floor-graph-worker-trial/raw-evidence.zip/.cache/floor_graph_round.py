from pathlib import Path
from types import SimpleNamespace
import argparse
import importlib.util
import json
import shutil
import subprocess

REPO = Path(__file__).resolve().parent.parent
spec = importlib.util.spec_from_file_location('floor_trial', REPO / '.cache/worker_select_round.py')
trial = importlib.util.module_from_spec(spec)
spec.loader.exec_module(trial)
trial.ROOT = REPO / '.cache/floor-graph-936a7f1-20261023'

METHOD = '''# Source floors belong to this actual public scan's eligible actors.
# Every worker owns its graph; the cache and all live-source acquisition stay
# on main. Existing and stale resident graphs retain their original lazy path.
func prepare_scan_graphs(space: HospitalSpace, world: WorldState, actor_ids: Array) -> void:
\tvar started: int = Time.get_ticks_usec()
\tvar records: Array = []
\tvar keys: Dictionary = {}
\tvar allowance: int = _charged+_query_charged
\tvar target: int = int(space.content.balance.pathfinding.graph_cache_target_bytes)
\tfor actor_id: String in actor_ids:
\t\tvar actor: Dictionary = world.facts.actors[actor_id]
\t\tif actor.location.kind!="floor": continue
\t\tvar floor_id: int = int(actor.location.floor_id)
\t\tvar current: Dictionary = floor_source(space,world,floor_id)
\t\tvar key: String = _graph_key(space,world,floor_id,actor,[],{},current)
\t\tif _entries.has(key) or keys.has(key): continue
\t\tkeys[key] = true
\t\tvar source_record: Dictionary = _sources[str(world.get_instance_id())+":"+str(floor_id)]
\t\tvar source: Dictionary = source_record.static_source
\t\tvar source_charge: int = var_to_bytes(source).size()*8+16384+FloorNavigation.LIMIT
\t\t# Complete 96x96 capacity is a conservative admission check before any
\t\t# graph exists. Registration still uses the original actual point count.
\t\tallowance += FloorNavigation.LIMIT*1024+source_charge
\t\trecords.append({"floor_id":floor_id,"actor":actor,"key":key,"source":source,"source_record":source_record,"source_charge":source_charge})
\tif records.size()<2: return
\tif allowance>target or _query_charged>target/4:
\t\tspace.query_counts["floor_batch_budget_fallbacks"] = int(space.query_counts.get("floor_batch_budget_fallbacks",0))+1
\t\treturn
\tvar geometries: Array[RouteClearance] = []
\tfor record: Dictionary in records:
\t\tgeometries.append(RouteClearance.new(space,world,record.actor,int(record.floor_id),[],{},false,record.source))
\tvar preparation_us: int = Time.get_ticks_usec()-started
\tvar result: Dictionary = preload("res://tools/performance/floor_graph_batch.gd").new().build(geometries,floor_batch_mode)
\tif not result.get("ok",false):
\t\tspace.query_counts["floor_batch_failures"] = int(space.query_counts.get("floor_batch_failures",0))+1
\t\treturn
\tvar registration_started: int = Time.get_ticks_usec()
\tfor index: int in records.size():
\t\tvar record: Dictionary = records[index]
\t\tvar graph: FloorNavigation = result.graphs[index]
\t\tvar charge: int = graph.get_point_count()*1024+int(record.source_charge)
\t\t_entries[record.key] = {"graph":graph,"source":record.source,"used":_used,"charge":charge,"floor_id":record.floor_id,"floor_batch_pending":true}
\t\trecord.source_record.graphs[record.key] = graph.geometry.get_instance_id()
\t\t_charged += charge
\tspace.query_counts["floor_batch_graphs"] = int(space.query_counts.get("floor_batch_graphs",0))+records.size()
\t_trim(target,space.query_counts)
\tvar floors: Array = []
\tfor record: Dictionary in records: floors.append(record.floor_id)
\tfloor_batch_records.append({"tick":world.sim_tick+1,"actors":actor_ids.size(),"floors":floors,"preparation_us":preparation_us,"group_us":result.elapsed_us,"registration_us":Time.get_ticks_usec()-registration_started,"jobs":result.jobs,"main_thread_id":result.main_thread_id,"charged":_charged,"query_charged":_query_charged,"target":target})

'''


def prepare(variant):
    trial.prepare(SimpleNamespace(variant=variant, tasks=4))
    if variant == 'baseline':
        return
    assert variant in ['baselineworker4v2', 'baselineserialv2']
    mode = 'serial' if variant == 'baselineserialv2' else 'worker4'
    project = trial.ROOT / (variant + '-project')
    helper = project / 'tools/performance/floor_graph_batch.gd'
    shutil.copy2(REPO / '.cache/floor_graph_batch.gd', helper)
    changes = {
        'game/building/navigation_cache.gd': [
            ('var _entries: Dictionary = {}\n', 'var _entries: Dictionary = {}\nvar floor_batch_mode: String = "' + mode + '"\nvar floor_batch_records: Array = []\n'),
            ('func graph(space:', METHOD + 'func graph(space:'),
            ('\tentry.used = _used\n\t_entries.erase(key)\n\t_entries[key] = entry\n\tvar result: FloorNavigation',
             '\tif entry.get("floor_batch_pending",false):\n\t\tspace.query_counts["floor_batch_consumed"] = int(space.query_counts.get("floor_batch_consumed",0))+1\n\t\tentry.erase("floor_batch_pending")\n\tentry.used = _used\n\t_entries.erase(key)\n\t_entries[key] = entry\n\tvar result: FloorNavigation')],
        'game/life/waiting_life.gd': [
            ('\t\t\tspace.begin_dynamic_route_query(world,first_scan)\n\t\t\tvar area:',
             '\t\t\tspace.begin_dynamic_route_query(world,first_scan)\n\t\t\tif first_scan: space._navigation.prepare_scan_graphs(space,world,_floor_graph_scan_subjects(world))\n\t\t\tvar area:'),
            ('func advance(world: WorldState) -> void:', '''func _floor_graph_scan_subjects(world: WorldState) -> Array:
\tvar result: Array = []
\tfor visit_id: String in world.active_visit_ids():
\t\tif world.facts.waiting_life.needs.has(visit_id): continue
\t\tvar visit: Dictionary = world.facts.visits[visit_id]
\t\tif not _waiting(world,visit): continue
\t\tvar ticket: Dictionary = world.facts.tickets[visit.ticket_id]
\t\tif ticket.get("service_assigned",false) and int(ticket.get("called_tick",-1))>=0: continue
\t\tif world.sim_tick>=int(world.facts.waiting_life.clocks[visit_id].next_need_tick): continue
\t\tif not world.facts.waiting_life.seats.get(visit_id,{}).is_empty() or world.facts.moves.has(visit.actor_id): continue
\t\tresult.append(str(visit.actor_id))
\treturn result

func advance(world: WorldState) -> void:''')],
        'tools/performance/representative_worker.gd': [
            ('\treport.worker_sample = ', '\treport["floor_graph_batch"] = {"mode":clinical.simulation.space._navigation.floor_batch_mode,"records":clinical.simulation.space._navigation.floor_batch_records.duplicate(true)}\n\treport.worker_sample = ')]
    }
    patches = []
    for relative, replacements in changes.items():
        original = (project / relative).read_text(encoding='utf-8')
        generated = original
        for before, after in replacements:
            assert generated.count(before) == 1, (relative, before)
            generated = generated.replace(before, after, 1)
        restored = generated
        for before, after in reversed(replacements):
            restored = restored.replace(after, before, 1)
        assert restored == original
        (project / relative).write_bytes(generated.encode('utf-8'))
        patches.append(dict(path=relative, original=original, generated=generated, inverse_equal=True))
    path = trial.ROOT / (variant + '-identity.json')
    identity = trial.read(path)
    identity.update(patches=patches, execution_mode=mode, independent_astar_instances=True, graph_budget_unchanged=True)
    for row in identity['sources']:
        row['sha256'] = trial.sha(project / row['path'])
    identity['sources'].append(dict(path='tools/performance/floor_graph_batch.gd', sha256=trial.sha(helper)))
    path.rename(path.with_name(variant + '-initial-identity.json'))
    trial.write(path, identity)


def measure(args):
    subprocess.check_call(['pwsh', '-NoProfile', '-Command',
        "if (Get-Process -Name '*Godot*' -ErrorAction SilentlyContinue) { throw 'Another Godot process is running.' }"])
    trial.measure(args)
    validate(args)


def validate(args):
    prefix = trial.ROOT / (args.label + '-' + args.window)
    check = trial.read(prefix.with_suffix('.semantic-check.json'))
    report = trial.read(prefix.with_suffix('.json'))
    differences = check['query_count_differences']
    checks = dict(all_semantic_checks=check['passed'], only_expected_counters=all(key.startswith('floor_batch_') or key in ['door_candidates', 'reservation_candidate_queries'] for key in differences))
    reduced = {}
    for key in ['door_candidates', 'reservation_candidate_queries']:
        row = differences.get(key, dict(actual=0, expected=0))
        reduced[key] = row['expected']-row['actual']
    checks['matching_saved_candidate_queries'] = reduced['door_candidates'] == reduced['reservation_candidate_queries'] and reduced['door_candidates'] >= 0
    batch = report.get('floor_graph_batch', {})
    if args.variant != 'baseline':
        counts = report['public']['query_counts']
        checks['no_batch_failures'] = counts.get('floor_batch_failures', 0) == 0
        checks['all_prepared_graphs_consumed'] = counts.get('floor_batch_graphs', 0) == counts.get('floor_batch_consumed', 0)
        records = batch['records']
        checks['actual_work_performed'] = bool(records) if args.window == 'gp80' else True
        checks['within_original_budget'] = all(row['charged'] + row['query_charged'] <= row['target'] and row['query_charged'] <= row['target'] / 4 for row in records)
        if records:
            checks['expected_execution_threads'] = all(
                (job['thread_id'] != row['main_thread_id']) == args.variant.startswith('baselineworker')
                for row in records for job in row['jobs'])
            if args.variant.startswith('baselineworker'):
                checks['multiple_worker_threads'] = all(len({job['thread_id'] for job in row['jobs']}) > 1 for row in records)
    trial.write(prefix.with_suffix('.floor-batch-check-v2.json'), dict(passed=all(checks.values()), checks=checks, batch=batch, count_differences=differences))
    assert all(checks.values()), checks
    print(json.dumps(dict(batch=batch, checks=checks)))


def functional(args):
    project = trial.ROOT / (args.variant + '-project')
    identity = trial.read(trial.ROOT / (args.variant + '-identity.json'))
    for key in ['sources', 'tests']:
        for row in identity[key]:
            assert trial.sha(project / row['path']) == row['sha256'], row['path']
    launcher = trial.module(REPO / '.cache/wait-signature-031e1f7-20261022/run.py', 'floor_cases')
    launcher.ROOT = trial.ROOT
    prefix = trial.ROOT / args.label
    cases = ['SPACE-46', 'SPACE-51', 'SPACE-55', 'STAFF-57', 'STAFF-61']
    launcher.launch(['--headless', '--path', project, '--script', 'res://tests/acceptance/runner.gd', '--', 'space', 'staff',
                     *['--case=' + case for case in cases]], prefix)
    output = prefix.with_suffix('.acceptance-results.json')
    assert not output.exists()
    shutil.copy2(project / 'acceptance-results.json', output)
    result = trial.read(output)
    assert result['completed'] and result['checks'] == len(cases) and result['failed'] == 0
    assert sorted(result['results']) == sorted(cases)
    print(json.dumps(dict(passed=True, cases={key: dict(body_ms=value['body_ms'], setup_ms=value['setup_ms'])
                                              for key, value in result['results'].items()})))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['prepare', 'measure', 'functional', 'validate'])
    parser.add_argument('--variant', default='baselineworker4v2')
    parser.add_argument('--label', default='b1')
    parser.add_argument('--window', default='gp80')
    parser.add_argument('--profile', default='plain')
    args = parser.parse_args()
    if args.action == 'prepare':
        prepare(args.variant)
    elif args.action == 'measure':
        measure(args)
    elif args.action == 'validate':
        validate(args)
    else:
        functional(args)
