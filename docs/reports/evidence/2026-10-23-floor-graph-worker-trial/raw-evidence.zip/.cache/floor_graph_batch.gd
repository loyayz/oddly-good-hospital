extends RefCounted

class GraphJob extends RefCounted:
	var geometry: RouteClearance
	var graph: FloorNavigation
	var elapsed_us: int = 0
	var thread_id: int = 0
	func run() -> void:
		var started: int = Time.get_ticks_usec()
		graph = FloorNavigation.new(geometry)
		elapsed_us = Time.get_ticks_usec()-started
		thread_id = OS.get_thread_caller_id()

var jobs: Array[GraphJob] = []

func build(geometries: Array[RouteClearance], mode: String) -> Dictionary:
	jobs.clear()
	for geometry: RouteClearance in geometries:
		var job: GraphJob = GraphJob.new()
		job.geometry = geometry
		jobs.append(job)
	var main_thread: int = OS.get_thread_caller_id()
	var started: int = Time.get_ticks_usec()
	if mode=="serial":
		for job: GraphJob in jobs: job.run()
	else:
		var group: int = WorkerThreadPool.add_group_task(_run,jobs.size(),mini(4,jobs.size()),false,"Current scan floor graphs")
		WorkerThreadPool.wait_for_group_task_completion(group)
	var elapsed: int = Time.get_ticks_usec()-started
	var graphs: Array[FloorNavigation] = []
	var records: Array = []
	for job: GraphJob in jobs:
		if job.graph==null: return {"ok":false}
		graphs.append(job.graph)
		records.append({"thread_id":job.thread_id,"elapsed_us":job.elapsed_us,"points":job.graph.get_point_count()})
	jobs.clear()
	return {"ok":true,"graphs":graphs,"jobs":records,"elapsed_us":elapsed,"main_thread_id":main_thread}

func _run(index: int) -> void:
	jobs[index].run()
