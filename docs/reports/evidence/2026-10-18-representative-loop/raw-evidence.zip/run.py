from pathlib import Path
import subprocess,json,sys,time
root=Path(__file__).resolve().parents[2]
out=Path(__file__).resolve().parent
engine='C:/programs/godot/Godot_v4.7.2-stable_win64_console.exe'
project=Path(sys.argv[1]).resolve();name=sys.argv[2]
args=sys.argv[3:];timeout=55
command=[engine,'--headless','--path',str(project)]
if args and args[0]=='import': command+=['--editor','--import','--quit'];args=args[1:]
else: command+=['--script','res://tools/performance/representative.gd','--']
command+=args
log=out/(name+'.log');meta=out/(name+'.run.json')
if log.exists() or meta.exists(): raise SystemExit('Evidence output already exists')
started=time.perf_counter();timed_out=False;termination=None
with log.open('w',encoding='utf-8') as stream:
    process=subprocess.Popen(command,cwd=root,stdout=stream,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
    try: code=process.wait(timeout)
    except subprocess.TimeoutExpired:
        timed_out=True
        # The console launcher has a child engine process on Windows. Kill only
        # this owned launch tree, retaining the exact stop result as evidence.
        stopped=subprocess.run(['taskkill','/PID',str(process.pid),'/T','/F'],capture_output=True,text=True,encoding='utf-8',errors='replace')
        termination={'exit_code':stopped.returncode,'stdout':stopped.stdout,'stderr':stopped.stderr}
        code=process.wait(timeout=5)
text=log.read_text(encoding='utf-8',errors='replace')
errors=[line for line in text.splitlines() if any(x in line for x in ['SCRIPT ERROR:','ERROR:'])]
data={'command':command,'pid':process.pid,'elapsed_seconds':time.perf_counter()-started,'exit_code':code,'timed_out':timed_out,'termination':termination,'engine_errors':errors,'log':str(log)}
meta.write_text(json.dumps(data,indent=2),encoding='utf-8')
print(json.dumps(data,indent=2))
print('\n'.join(text.splitlines()[-8:]))
sys.exit(0 if code==0 and not timed_out and not errors else 1)
