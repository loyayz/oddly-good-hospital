extends "res://tests/acceptance/staff_fixtures.gd"

# The control disables only geometry inheritance. Fit, route, reservations and
# transport remain the production implementations, with independent captures.
class ObservedSpace extends HospitalSpace:
	var inherit_enabled: bool = true
	var inherit_calls: int = 0
	var sources_checked: int = 0
	var identical_source: bool = true
	var routes: Array = []
	func _init(database: HospitalContent) -> void:
		super(database)
	func inherit_navigation_geometry(source: WorldState, projection: WorldState) -> void:
		inherit_calls += 1
		if not inherit_enabled: return
		for entry: Dictionary in _navigation._sources.values():
			if entry.world.get_ref()!=source or int(entry.revision)!=source.geometry_revision: continue
			var captured: Dictionary = RouteClearance.capture_source(self,projection,int(entry.floor_id))
			identical_source = identical_source and captured==entry.source and captured==RouteClearance.capture_source(self,source,int(entry.floor_id))
			sources_checked += 1
		super.inherit_navigation_geometry(source,projection)
	func route(world: WorldState, actor_id: String, floor_id: int, target: Array, members: Array = [], offsets: Dictionary = {}, ignore_people: bool = false) -> Dictionary:
		var origin: Dictionary = world.facts.actors[actor_id].location.duplicate(true)
		var result: Dictionary = super.route(world,actor_id,floor_id,target,members,offsets,ignore_people)
		routes.append({"actor_id":actor_id,"origin":origin,"floor_id":floor_id,"target":target.duplicate(),"quote":result.duplicate(true)})
		return result

func run(t, database: HospitalContent) -> void:
	_content = database
	var rows: Array = []
	var valid: bool = true
	for kind: String in ["exact","expanded","reserved","using","cross_floor"]:
		var x: Dictionary = _input(kind)
		var row: Dictionary = _compare(x,kind)
		rows.append(row)
		valid = valid and row.ok
		if x.has("simulation"): x.simulation.dispose()
	var invalidation: Dictionary = _invalidation()
	var bounded: Dictionary = _bounded_sources()
	t.check("STAFF-43",valid and invalidation.ok and bounded.ok,{"round_trips":rows,"invalidation":invalidation,"bounded_sources":bounded})

func _input(kind: String) -> Dictionary:
	var x: Dictionary
	if kind=="cross_floor":
		var builder: RefCounted = load("res://tests/acceptance/space.gd").new()
		builder.content = _content
		var simulation: HospitalSimulation = builder._transit_fixture()
		x = _bind(simulation.world)
		x.simulation = simulation
		var built: CommandResult = builder._command(simulation,"build_facility",{"id":"water","definition_id":"FUR17","floor_id":2,"cell":[44,80]})
		x.setup_error = "" if built.accepted else built.reason
	else:
		x = _fixture()
		_facility(x,"water","FUR17",[44,74])
		x.setup_error = ""
	if kind=="using":
		var user: Dictionary = _visit(x,"user",x.space.facility_layout(x.world,"water").patient_cell)
		x.world.facts.sim_tick = 1800
		x.world.facts.waiting_life.clocks[user.id].next_purpose = "water"
		x.l._begin_need(x.world,user)
		for _tick: int in 16:
			if x.world.facts.waiting_life.needs.get(user.id,{}).get("phase","")=="using": break
			x.world.facts.sim_tick += 1
			x.space.advance(x.world)
			x.l.dispatch(x.world)
		x.using_started = x.world.facts.waiting_life.needs.get(user.id,{}).get("phase","")=="using"
	var visit: Dictionary = _visit(x,"request",[36,83] if kind=="expanded" else [38,82])
	if kind=="expanded":
		var binding: Dictionary = _content.definition("treatment_bindings","B_S08_D04_M04")
		var actor: Dictionary = x.world.facts.actors[visit.actor_id]
		actor.species_id = binding.species_id
		actor.body_binding_id = binding.id
		visit.binding_id = binding.id
		visit.disease_id = binding.disease_id
		visit.requested_plan_id = "P_"+str(binding.disease_id)+"_COMMON"
	if kind=="reserved":
		_facility(x,"other_seat","FUR06",[53,74])
		var other: Dictionary = _visit(x,"other",[55,82])
		x.reservation_error = x.l._reserve_seat(x.world,other,"other_seat")
	x.world.touch()
	return x

func _compare(x: Dictionary, kind: String) -> Dictionary:
	var world: WorldState = x.world
	var actor_id: String = world.facts.visits.request.actor_id
	var before: Dictionary = world.freeze()
	var validation: String = world.validate(_content)
	var inherited: ObservedSpace = ObservedSpace.new(_content)
	var fresh: ObservedSpace = ObservedSpace.new(_content)
	fresh.inherit_enabled = false
	var life: HospitalWaitingLife = HospitalWaitingLife.new(_content,inherited)
	var control: HospitalWaitingLife = HospitalWaitingLife.new(_content,fresh)
	var actual: Dictionary = life.facility_availability(world,actor_id,"water")
	var expected: Dictionary = control.facility_availability(world,actor_id,"water")
	var outward_and_back: Array = _actor_routes(inherited.routes,actor_id)
	var control_routes: Array = _actor_routes(fresh.routes,actor_id)
	var round_trip: bool = outward_and_back.size()==2
	if round_trip:
		round_trip = outward_and_back[0].quote.get("ok",false) and outward_and_back[1].quote.get("ok",false) \
			and outward_and_back[0].origin==before.actors[actor_id].location \
			and outward_and_back[1].origin.cell==actual.get("patient_cell",[]) \
			and outward_and_back[1].target==before.actors[actor_id].location.cell
	var specific: bool = true
	if kind in ["exact","expanded"]:
		var fit: Dictionary = x.space.facility_quote(world,"water",actor_id)
		specific = fit.get("ok",false)
		if kind=="exact": specific = specific and fit.get("footprint",[])==world.facts.facilities.water.footprint
		else: specific = specific and fit.get("footprint",[])!=world.facts.facilities.water.footprint and x.space.clearance(world.facts.actors[actor_id])>1
	if kind=="reserved": specific = str(x.get("reservation_error","missing")).is_empty() and world.facts.adaptations.has("other_seat")
	if kind=="using":
		specific = x.get("using_started",false) and world.facts.adaptations.water.actor_id==world.facts.visits.user.actor_id \
			and not x.l._facility_quote(world,{"actor_id":actor_id},"water").ok
	if kind=="cross_floor":
		specific = actual.get("floor_id",0)==2 and round_trip and _has_transit(outward_and_back[0].quote) and _has_transit(outward_and_back[1].quote)
	var readonly: bool = world.freeze()==before
	var same: bool = actual==expected and outward_and_back==control_routes
	var ok: bool = str(x.setup_error).is_empty() and validation.is_empty() and actual.get("ok",false) and same and round_trip and specific \
		and readonly and inherited.inherit_calls>0 and inherited.sources_checked>0 and inherited.identical_source
	return {"kind":kind,"ok":ok,"validation":validation,"setup_error":x.setup_error,"full_quotes_and_routes_equal":same,
		"independent_out_and_back":round_trip,"specific_rule":specific,"world_and_rng_readonly":readonly,"sources_equal":inherited.identical_source,
		"sources_checked":inherited.sources_checked,"quote":actual,"routes":outward_and_back}

func _actor_routes(rows: Array, actor_id: String) -> Array:
	return rows.filter(func(row: Dictionary) -> bool: return row.actor_id==actor_id)

func _has_transit(quote: Dictionary) -> bool:
	for part: Dictionary in quote.get("path",[]):
		if part.get("kind","")=="connector": return true
	return false

func _invalidation() -> Dictionary:
	var rows: Array = []
	var valid: bool = true
	for kind: String in ["blocked_geometry","new_reservation"]:
		var x: Dictionary = _input("exact")
		var world: WorldState = x.world
		_facility(x,"other_seat","FUR06",[53,74])
		var other: Dictionary = _visit(x,"other",[55,82])
		world.touch()
		var space: HospitalSpace = HospitalSpace.new(_content)
		var actor_id: String = world.facts.visits.request.actor_id
		var target: Array = space.facility_layout(world,"other_seat").patient_cell.duplicate()
		var initial: Dictionary = space.route(world,actor_id,1,target)
		var mutation_ok: bool = true
		if kind=="blocked_geometry":
			world.facts.floors.overrides["1"].blocked.append(target.duplicate())
			world.touch()
		else:
			mutation_ok = space.reserve_facility(world,"other_seat",other.actor_id,other.ticket_id).is_empty()
		var before: Dictionary = world.freeze()
		var projection: WorldState = WorldState.new(world.freeze())
		projection.facts.actors[actor_id].location.cell = [39,82]
		space.inherit_navigation_geometry(world,projection)
		var key: String = str(projection.get_instance_id())+":1"
		var stale_not_inherited: bool = not space._navigation._sources.has(key)
		var actual: Dictionary = space.route(projection,actor_id,1,target)
		var control: Dictionary = HospitalSpace.new(_content).route(projection,actor_id,1,target)
		var current_source: Dictionary = space._navigation.floor_source(space,projection,1)
		var validation: String = world.validate(_content)
		var ok: bool = initial.ok and mutation_ok and stale_not_inherited and not actual.ok and actual==control \
			and current_source==RouteClearance.capture_source(space,projection,1) and world.freeze()==before and validation.is_empty()
		valid = valid and ok
		rows.append({"kind":kind,"ok":ok,"mutation_ok":mutation_ok,"stale_binding_skipped":stale_not_inherited,
			"fresh_route_equal":actual==control,"current_source_equal":current_source==RouteClearance.capture_source(space,projection,1),
			"validation":validation,"route":actual})
	return {"ok":valid,"cases":rows}

func _bounded_sources() -> Dictionary:
	var x: Dictionary = _input("exact")
	var before: Dictionary = x.world.freeze()
	var space: HospitalSpace = HospitalSpace.new(_content)
	var actor_id: String = x.world.facts.visits.request.actor_id
	var warm: Dictionary = space.route(x.world,actor_id,1,[40,82])
	var maximum: int = 0
	var all_routes: bool = warm.ok
	var bindings_inherited: bool = true
	for _index: int in 48:
		# Inherit from the same warm source, so another new-world capture cannot
		# incidentally prune leaked projections and conceal an inheritance leak.
		var projection: WorldState = WorldState.new(x.world.freeze())
		projection.facts.actors[actor_id].location.cell = [39+_index%2,82]
		space.inherit_navigation_geometry(x.world,projection)
		bindings_inherited = bindings_inherited and space._navigation._sources.has(str(projection.get_instance_id())+":1")
		var result: Dictionary = space.route(projection,actor_id,1,[41,82])
		all_routes = all_routes and result.ok
		maximum = maxi(maximum,space._navigation._sources.size())
	return {"ok":all_routes and bindings_inherited and maximum<=8 and x.world.freeze()==before,"queries":48,"maximum_source_bindings":maximum,
		"all_sources_inherited_before_route":bindings_inherited,"final_source_bindings":space._navigation._sources.size(),
		"source_count_bounded":maximum<=8,"world_and_rng_readonly":x.world.freeze()==before}
