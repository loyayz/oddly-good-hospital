from pathlib import Path
import hashlib,json
out=Path(__file__).resolve().parent
root=out.parents[1]
source=(root/'tools/performance/step_profile.gd').read_text(encoding='utf8')
trace=source.replace('func root(name: String) -> void:\n','func root(name: String) -> void:\n\tprint("TRACE_ROOT="+JSON.stringify({"name":name,"at_us":Time.get_ticks_usec()}))\n',1)
for name in ['enter_call','exit_call']:
    trace=trace.replace(f'func {name}(operation: String) -> void:\n',f'func {name}(operation: String) -> void:\n\tif operation in ["environment._work_position","wellbeing._select_facility","wellbeing._tea_position"]: print("TRACE_{name.upper()}="+JSON.stringify({{"operation":operation,"at_us":Time.get_ticks_usec()}}))\n',1)
assert trace!=source
target=out/'correct-before-project/tools/performance/step_profile.gd'
assert target.read_bytes()==(root/'tools/performance/step_profile.gd').read_bytes()
(out/'trace_step_profile.gd').write_text(trace,encoding='utf8')
target.write_text(trace,encoding='utf8')
(out/'operations-stage-trace-identity.json').write_text(json.dumps({'diagnostic_only':True,'timing_usable_for_benefit':False,'reason':'Console trace inside the instrumented step; interrupted first-step location only','source_sha256':hashlib.sha256(trace.encode()).hexdigest(),'production_clinical_sha256':hashlib.sha256((out/'correct-before-project/game/clinic/clinical_runtime.gd').read_bytes()).hexdigest()},indent=2),encoding='utf8')
