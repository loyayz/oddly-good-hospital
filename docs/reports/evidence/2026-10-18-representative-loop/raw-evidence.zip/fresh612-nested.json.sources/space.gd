extends "res://game/building/hospital_space.gd"
var _step_profile_observer: RefCounted

func finish_boundary(world: WorldState) -> void:
	_step_profile_observer.enter_call("space.finish_boundary")
	super.finish_boundary(world)
	_step_profile_observer.exit_call("space.finish_boundary")

func route(world: WorldState, actor_id: String, floor_id: int, target: Array, members: Array = [], offsets: Dictionary = {}, ignore_people: bool = false) -> Dictionary:
	_step_profile_observer.enter_call("space.route")
	var _step_profile_result: Variant = super.route(world,actor_id,floor_id,target,members,offsets,ignore_people)
	_step_profile_observer.exit_call("space.route")
	return _step_profile_result

func travel_quote(world: WorldState, actor_id: String, floor_id: int, target: Array) -> Dictionary:
	_step_profile_observer.enter_call("space.travel_quote")
	var _step_profile_result: Variant = super.travel_quote(world,actor_id,floor_id,target)
	_step_profile_observer.exit_call("space.travel_quote")
	return _step_profile_result

func advance(world: WorldState, present_at_start: int = -1) -> void:
	_step_profile_observer.enter_call("space.advance")
	super.advance(world,present_at_start)
	_step_profile_observer.exit_call("space.advance")

func _floor_route(world: WorldState, actor: Dictionary, floor_id: int, start: Vector2i, goal: Vector2i, members: Array = [], offsets: Dictionary = {}, ignore_people: bool = false, navigation: Dictionary = {}) -> Dictionary:
	_step_profile_observer.enter_call("space._floor_route")
	var _step_profile_result: Variant = super._floor_route(world,actor,floor_id,start,goal,members,offsets,ignore_people,navigation)
	_step_profile_observer.exit_call("space._floor_route")
	return _step_profile_result

func _active_route_clear(world: WorldState, actor: Dictionary, movement: Dictionary, versions: Dictionary) -> bool:
	_step_profile_observer.enter_call("space._active_route_clear")
	var _step_profile_result: Variant = super._active_route_clear(world,actor,movement,versions)
	_step_profile_observer.exit_call("space._active_route_clear")
	return _step_profile_result

func _dispatch_routes(world: WorldState, present_at_start: int) -> void:
	_step_profile_observer.enter_call("space._dispatch_routes")
	super._dispatch_routes(world,present_at_start)
	_step_profile_observer.exit_call("space._dispatch_routes")

func _movement_clear(world: WorldState, actor_id: String, floor_id: int, broad: Rect2, sweeps: Array[BodyIndex.Record], members: Array) -> bool:
	_step_profile_observer.enter_call("space._movement_clear")
	var _step_profile_result: Variant = super._movement_clear(world,actor_id,floor_id,broad,sweeps,members)
	_step_profile_observer.exit_call("space._movement_clear")
	return _step_profile_result

func facility_quote(world: WorldState, facility_id: String, actor_id: String, staff_ids: Array = []) -> Dictionary:
	_step_profile_observer.enter_call("space.facility_quote")
	var _step_profile_result: Variant = super.facility_quote(world,facility_id,actor_id,staff_ids)
	_step_profile_observer.exit_call("space.facility_quote")
	return _step_profile_result

func _exit_witness(world: WorldState, actor: Dictionary, floor_id: int, start: Vector2i, exit: Vector2i) -> Dictionary:
	_step_profile_observer.enter_call("space._exit_witness")
	var _step_profile_result: Variant = super._exit_witness(world,actor,floor_id,start,exit)
	_step_profile_observer.exit_call("space._exit_witness")
	return _step_profile_result

func _reserve_doors(world: WorldState, actor: Dictionary, movement: Dictionary, swept: Rect2) -> bool:
	_step_profile_observer.enter_call("space._reserve_doors")
	var _step_profile_result: Variant = super._reserve_doors(world,actor,movement,swept)
	_step_profile_observer.exit_call("space._reserve_doors")
	return _step_profile_result

func _yield(world: WorldState, actor: Dictionary, movement: Dictionary, swept: Rect2) -> void:
	_step_profile_observer.enter_call("space._yield")
	super._yield(world,actor,movement,swept)
	_step_profile_observer.exit_call("space._yield")

func _yield_idle_staff(world: WorldState, actor: Dictionary, movement: Dictionary, swept: Rect2) -> bool:
	_step_profile_observer.enter_call("space._yield_idle_staff")
	var _step_profile_result: Variant = super._yield_idle_staff(world,actor,movement,swept)
	_step_profile_observer.exit_call("space._yield_idle_staff")
	return _step_profile_result
