extends "res://game/staff/staff_wellbeing.gd"
var _step_profile_observer: RefCounted

func dispatch(world: WorldState) -> void:
	_step_profile_observer.enter_call("wellbeing.dispatch")
	super.dispatch(world)
	_step_profile_observer.exit_call("wellbeing.dispatch")

func boundaries(world: WorldState) -> void:
	_step_profile_observer.enter_call("wellbeing.boundaries")
	super.boundaries(world)
	_step_profile_observer.exit_call("wellbeing.boundaries")

func advance(world: WorldState, worked: Dictionary = {}, before_movement: Dictionary = {}) -> void:
	_step_profile_observer.enter_call("wellbeing.advance")
	super.advance(world,worked,before_movement)
	_step_profile_observer.exit_call("wellbeing.advance")

func _dispatch_task(world: WorldState, staff_id: String) -> void:
	_step_profile_observer.enter_call("wellbeing._dispatch_task")
	super._dispatch_task(world,staff_id)
	_step_profile_observer.exit_call("wellbeing._dispatch_task")

func _select_facility(world: WorldState, staff_id: String, kind: String) -> Dictionary:
	_step_profile_observer.enter_call("wellbeing._select_facility")
	var _step_profile_result: Variant = super._select_facility(world,staff_id,kind)
	_step_profile_observer.exit_call("wellbeing._select_facility")
	return _step_profile_result

func _tea_position(world: WorldState, staff_id: String) -> Dictionary:
	_step_profile_observer.enter_call("wellbeing._tea_position")
	var _step_profile_result: Variant = super._tea_position(world,staff_id)
	_step_profile_observer.exit_call("wellbeing._tea_position")
	return _step_profile_result

func _dispatch_recreation(world: WorldState) -> void:
	_step_profile_observer.enter_call("wellbeing._dispatch_recreation")
	super._dispatch_recreation(world)
	_step_profile_observer.exit_call("wellbeing._dispatch_recreation")

func _adapted_candidate(world: WorldState, facility_id: String, fit: Dictionary, actor_id: String) -> WorldState:
	_step_profile_observer.enter_call("wellbeing._adapted_candidate")
	var _step_profile_result: Variant = super._adapted_candidate(world,facility_id,fit,actor_id)
	_step_profile_observer.exit_call("wellbeing._adapted_candidate")
	return _step_profile_result

func _tea_obstacles(world: WorldState, staff_id: String) -> Dictionary:
	_step_profile_observer.enter_call("wellbeing._tea_obstacles")
	var _step_profile_result: Variant = super._tea_obstacles(world,staff_id)
	_step_profile_observer.exit_call("wellbeing._tea_obstacles")
	return _step_profile_result
