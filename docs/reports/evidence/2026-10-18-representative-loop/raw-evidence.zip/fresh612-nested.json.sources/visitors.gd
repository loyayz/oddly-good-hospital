extends "res://game/clinic/hospital_visitors.gd"
var _step_profile_observer: RefCounted

func arrivals(world: WorldState) -> void:
	_step_profile_observer.enter_call("visitors.arrivals")
	super.arrivals(world)
	_step_profile_observer.exit_call("visitors.arrivals")

func dispatch(world: WorldState) -> void:
	_step_profile_observer.enter_call("visitors.dispatch")
	super.dispatch(world)
	_step_profile_observer.exit_call("visitors.dispatch")

func advance(world: WorldState) -> void:
	_step_profile_observer.enter_call("visitors.advance")
	super.advance(world)
	_step_profile_observer.exit_call("visitors.advance")

func _waiting_point(world: WorldState, actor_id: String, facility_ids: Variant = null) -> Dictionary:
	_step_profile_observer.enter_call("visitors._waiting_point")
	var _step_profile_result: Variant = super._waiting_point(world,actor_id,facility_ids)
	_step_profile_observer.exit_call("visitors._waiting_point")
	return _step_profile_result

func _waiting_point_in_query(world: WorldState, actor_id: String, facility_ids: Array) -> Dictionary:
	_step_profile_observer.enter_call("visitors._waiting_point_in_query")
	var _step_profile_result: Variant = super._waiting_point_in_query(world,actor_id,facility_ids)
	_step_profile_observer.exit_call("visitors._waiting_point_in_query")
	return _step_profile_result

func _bedside(world: WorldState, actor_id: String, stay: Dictionary) -> Dictionary:
	_step_profile_observer.enter_call("visitors._bedside")
	var _step_profile_result: Variant = super._bedside(world,actor_id,stay)
	_step_profile_observer.exit_call("visitors._bedside")
	return _step_profile_result

func _bedside_in_query(world: WorldState, actor_id: String, stay: Dictionary) -> Dictionary:
	_step_profile_observer.enter_call("visitors._bedside_in_query")
	var _step_profile_result: Variant = super._bedside_in_query(world,actor_id,stay)
	_step_profile_observer.exit_call("visitors._bedside_in_query")
	return _step_profile_result
