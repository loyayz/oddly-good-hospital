from pathlib import Path
import subprocess,sys,json,statistics,hashlib
root=Path(__file__).resolve().parents[2];out=Path(__file__).resolve().parent
scenes={
 'gp':(out/'clinical-corrected/clinical-corrected-r2-gp_work_handoff.input.bin',80),
 'operations':(out/'operations.input.bin',40),
}
all_results={}
for scene,(input_file,steps) in scenes.items():
    if len(sys.argv)>1 and scene not in sys.argv[1:]: continue
    results=[]
    for pair in range(3):
        order=['before','after'] if pair%2==0 else ['after','before']
        for side in order:
            project=out/('correct-before-project' if side=='before' else 'optimized-project')
            name=f'{scene}-{side}-plain-p{pair+1}'
            output=out/(name+'.json')
            args=[sys.executable,str(out/'run.py'),str(project),name,'--input='+str(input_file),'--output='+str(output),f'--steps={steps}','--profile=plain']
            status=subprocess.run(args,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf8',errors='replace')
            if status.returncode!=0:
                print(status.stdout,flush=True)
                raise SystemExit('A final same-input run failed; retain it and diagnose before continuing')
            value=json.loads(output.read_text(encoding='utf8'))
            assert value['qualified'] and value['complete'],name
            row={'pair':pair+1,'side':side,'name':name,'input_sha256':value['source_input_sha256'],'final_binary_sha256':value['final_binary_sha256'],'metrics':value['metrics'],
                 'spikes':{str(s['tick']):s['elapsed_us'] for s in value['samples'] if s['tick'] in [878,879]},'qualification':value['qualification']}
            results.append(row)
            print(json.dumps({'scene':scene,**row},ensure_ascii=False),flush=True)
    assert len({row['input_sha256'] for row in results})==1
    assert len({row['final_binary_sha256'] for row in results})==1
    medians={side:{metric:statistics.median(row['metrics'][metric] for row in results if row['side']==side) for metric in ['mean_us','p50_us','p95_us','p99_us','max_us','cold_first_us','following_mean_us','total_us']} for side in ['before','after']}
    all_results[scene]={'steps_per_window':steps,'pairs':3,'runs':results,'median_window_metrics':medians,
                        'mean_reduction':1-medians['after']['mean_us']/medians['before']['mean_us'],'all_full_facts_events_rng_binary_identical':True,
                        'input_sha256':results[0]['input_sha256'],'final_binary_sha256':results[0]['final_binary_sha256']}
    (out/'final-measurements.json').write_text(json.dumps({'diagnostic_only':True,'formal_pass':False,'formal_acceptance_paused':True,'scenes':all_results},indent=2),encoding='utf8')
print('FINAL_MEASUREMENTS_COMPLETE',flush=True)
