from pathlib import Path
import zipfile,shutil,hashlib,json,sys
root=Path(__file__).resolve().parents[2];out=Path(__file__).resolve().parent
name=sys.argv[1];project=out/name
if project.exists(): raise SystemExit('Project already exists')
with zipfile.ZipFile(out/'before-source.zip') as archive: archive.extractall(project)
for relative in ['game/platform/windows/bin','.godot/imported']:
    shutil.copytree(root/relative,project/relative,dirs_exist_ok=True)
production=['game/clinic/clinical_runtime.gd']
if name!='correct-before-project': production+=['game/building/navigation_cache.gd','game/building/hospital_space.gd','game/life/waiting_life.gd']
for relative in production: shutil.copy2(root/relative,project/relative)
for path in (root/'tools/performance').glob('representative*.gd'): shutil.copy2(path,project/'tools/performance'/path.name)
shutil.copy2(root/'tools/performance/step_profile.gd',project/'tools/performance/step_profile.gd')
p=project/'project.godot';text=p.read_text(encoding='utf8');p.write_text(text.replace('config/custom_user_dir_name="oddly-good-hospital"','config/custom_user_dir_name="OddlyGoodHospital Loop '+name+' 20261018"'),encoding='utf8')
sources=[]
for relative in ['game','content','tools/performance']:
    for path in sorted((project/relative).rglob('*')):
        if path.is_file() and path.suffix in ['.gd','.json','.csv','.dll']:
            sources.append({'path':path.relative_to(project).as_posix(),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
(project/'source-identity.json').write_text(json.dumps({'base':'dba8612cef21668cbd7b38560c19f9f40b0e3847','production_overlay':production,'sources':sources},indent=2),encoding='utf8')
print(project)
