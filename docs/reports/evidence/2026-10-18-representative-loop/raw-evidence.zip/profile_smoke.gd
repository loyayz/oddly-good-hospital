extends SceneTree

const StepProfile = preload("res://tools/performance/step_profile.gd")

func _initialize() -> void:
	call_deferred("_run")

func _events(result: TickResult) -> Array:
	var records: Array = []
	if result==null: return records
	for event: SimEvent in result.facts: records.append(event.to_record())
	return records

func _run() -> void:
	var content: HospitalContent = HospitalContent.new()
	var initial: WorldState = HospitalFactory.create("00000000-0000-4000-8000-000000000001","profile smoke",false,content)
	var initialized: HospitalSimulation = HospitalSimulation.new(initial,content)
	var input: Dictionary = initial.freeze()
	initialized.dispose()
	var plain: HospitalSimulation = HospitalSimulation.new(WorldState.new(input.duplicate(true)),content)
	var root_observer: RefCounted = StepProfile.new()
	root_observer.source_directory = "res://.cache/performance-loop-20261018/profile-smoke-root-sources"
	var root_only: HospitalSimulation = root_observer.create(WorldState.new(input.duplicate(true)),content,false)
	var nested_observer: RefCounted = StepProfile.new()
	nested_observer.source_directory = "res://.cache/performance-loop-20261018/profile-smoke-nested-sources"
	var nested: HospitalSimulation = nested_observer.create(WorldState.new(input.duplicate(true)),content,true)
	if root_only==null or nested==null:
		print("PROFILE_SMOKE="+JSON.stringify({"ok":false,"root_errors":root_observer.errors,"nested_errors":nested_observer.errors}))
		quit(2)
		return
	var ok: bool = true
	var steps: Array = []
	for index: int in 2:
		var expected: TickResult = plain.step()
		root_observer.begin_step()
		var started: int = Time.get_ticks_usec()
		var root_result: TickResult = root_only.step()
		var root_record: Dictionary = root_observer.end_step(root_result,Time.get_ticks_usec()-started)
		nested_observer.begin_step()
		started = Time.get_ticks_usec()
		var nested_result: TickResult = nested.step()
		var nested_record: Dictionary = nested_observer.end_step(nested_result,Time.get_ticks_usec()-started)
		var equal: bool = expected!=null and root_result!=null and nested_result!=null and plain.world.freeze()==root_only.world.freeze() and plain.world.freeze()==nested.world.freeze() and _events(expected)==_events(root_result) and _events(expected)==_events(nested_result)
		ok = ok and equal
		steps.append({"index":index,"equal_world_rng_events":equal,"root_record":root_record,"nested_record":nested_record})
	var root_report: Dictionary = root_observer.report()
	var nested_report: Dictionary = nested_observer.report()
	ok = ok and root_report.errors.is_empty() and nested_report.errors.is_empty() and int(root_report.partition_check_us)==0 and int(nested_report.partition_check_us)==0
	var report: Dictionary = {"ok":ok,"purpose":"Measurement plumbing smoke only; empty legal hospital is not the clinical performance workload.","steps":steps,"root_report":root_report,"nested_report":nested_report}
	var file: FileAccess = FileAccess.open("res://.cache/performance-loop-20261018/profile-smoke.json",FileAccess.WRITE)
	file.store_string(JSON.stringify(report,"\t"))
	plain.dispose()
	root_only.dispose()
	nested.dispose()
	print("PROFILE_SMOKE="+JSON.stringify({"ok":ok,"root_errors":root_report.errors,"nested_errors":nested_report.errors,"root_stages":root_report.root_stages.size(),"nested_calls":nested_report.nested_calls.size()}))
	quit(0 if ok else 1)
