from pathlib import Path
from types import SimpleNamespace
import argparse
import importlib.util
import json
import shutil

REPO = Path(__file__).resolve().parent.parent
spec = importlib.util.spec_from_file_location('borrow_trial', REPO / '.cache/worker_select_round.py')
trial = importlib.util.module_from_spec(spec)
spec.loader.exec_module(trial)
trial.ROOT = REPO / '.cache/static-geometry-c122dcc-20261023'

HELPER = '''# Borrow immutable arrays only while their existing owner is alive. The latest
# floor source owns one weak reference, without retaining another graph or body
# history. A new wrapper binds the caller's current source and body dimensions.
func _static_geometry(space: HospitalSpace, world: WorldState, floor_id: int, actor: Dictionary, members: Array, offsets: Dictionary, source: Dictionary) -> RouteClearance:
\tvar prepared: RouteClearance = null
\tvar record: Dictionary = {}
\tvar key: String = ""
\tif members.is_empty() and offsets.is_empty():
\t\trecord = _sources[str(world.get_instance_id())+":"+str(floor_id)]
\t\tkey = _graph_key(space,world,floor_id,actor,[],{},source)
\t\tif record.get("prepared_key","")==key:
\t\t\tprepared = record.prepared_geometry.get_ref() as RouteClearance
\tvar geometry: RouteClearance = RouteClearance.new(space,world,actor,floor_id,members,offsets,false,source,prepared)
\tvar counter: String = "structural_geometry_builds" if prepared==null else "structural_geometry_borrows"
\tspace.query_counts[counter] = int(space.query_counts.get(counter,0))+1
\tif not record.is_empty():
\t\trecord.prepared_key = key
\t\trecord.prepared_geometry = weakref(geometry)
\treturn geometry

'''


def prepare(variant):
    trial.prepare(SimpleNamespace(variant=variant, tasks=4))
    if variant == 'baseline':
        return
    assert variant == 'baselineborrow'
    project = trial.ROOT / (variant + '-project')
    changes = {
        'game/building/hospital_navigation.gd': [
            ('if query==null: query = RouteClearance.new(space,world,actor,floor_id,members,offsets,false,source)',
             'if query==null: query = space._navigation._static_geometry(space,world,floor_id,actor,members,offsets,source)')],
        'game/building/navigation_cache.gd': [
            ('\t\t\tif previous.has("facility_index") and previous.source.facilities==current.facilities: entry.facility_index = previous.facility_index',
             '\t\t\tif previous.get("static_version",-1)==identity.version and previous.has("prepared_geometry"):\n\t\t\t\tentry.prepared_key = previous.prepared_key\n\t\t\t\tentry.prepared_geometry = previous.prepared_geometry\n\t\t\tif previous.has("facility_index") and previous.source.facilities==current.facilities: entry.facility_index = previous.facility_index'),
            ('func _refresh_graph(space:', HELPER + 'func _refresh_graph(space:'),
            ('\tvar geometry: RouteClearance = RouteClearance.new(space,world,actor,floor_id,members,offsets,false,source)\n\tvar floor_graph: FloorNavigation',
             '\tvar geometry: RouteClearance = _static_geometry(space,world,floor_id,actor,members,offsets,source)\n\tvar floor_graph: FloorNavigation')]
    }
    patches = []
    for relative, replacements in changes.items():
        original = (project / relative).read_text(encoding='utf-8')
        generated = original
        for before, after in replacements:
            assert generated.count(before) == 1, (relative, before)
            generated = generated.replace(before, after, 1)
        restored = generated
        for before, after in reversed(replacements):
            restored = restored.replace(after, before, 1)
        assert restored == original
        (project / relative).write_bytes(generated.encode('utf-8'))
        patches.append(dict(path=relative, original=original, generated=generated, inverse_equal=True))
    path = trial.ROOT / (variant + '-identity.json')
    identity = trial.read(path)
    identity['patches'] = patches
    for row in identity['sources']:
        row['sha256'] = trial.sha(project / row['path'])
    path.rename(path.with_name(variant + '-initial-identity.json'))
    trial.write(path, identity)


def measure(args):
    trial.measure(args)
    validate(args)


def validate(args):
    result = trial.read(trial.ROOT / (args.label + '-' + args.window + '.semantic-check.json'))
    differences = result['query_count_differences']
    checks = dict(all_semantic_checks=result['passed'], only_expected_counts=set(differences) <= {
        'structural_geometry_builds', 'structural_geometry_borrows', 'door_candidates', 'reservation_candidate_queries'})
    if args.variant == 'baselineborrow':
        door = differences.get('door_candidates', dict(actual=0, expected=0))
        reservation = differences.get('reservation_candidate_queries', dict(actual=0, expected=0))
        checks['fewer_or_equal_door_quotes'] = door['actual'] <= door['expected']
        checks['matching_candidate_reductions'] = door['expected'] - door['actual'] == reservation['expected'] - reservation['actual']
    path = trial.ROOT / (args.label + '-' + args.window + '.borrow-count-check.json')
    trial.write(path, dict(passed=all(checks.values()), checks=checks, differences=differences))
    assert all(checks.values()), checks
    print(json.dumps(dict(geometry_counts=differences)))


def functional(args):
    project = trial.ROOT / (args.variant + '-project')
    identity = trial.read(trial.ROOT / (args.variant + '-identity.json'))
    for key in ['sources', 'tests']:
        for row in identity[key]:
            assert trial.sha(project / row['path']) == row['sha256'], row['path']
    launcher = trial.module(REPO / '.cache/wait-signature-031e1f7-20261022/run.py', 'borrow_cases')
    launcher.ROOT = trial.ROOT
    prefix = trial.ROOT / args.label
    cases = ['SPACE-46', 'SPACE-51', 'STAFF-57', 'STAFF-61']
    launcher.launch(['--headless', '--path', project, '--script', 'res://tests/acceptance/runner.gd', '--', 'space', 'staff',
                     *['--case=' + case for case in cases]], prefix)
    destination = prefix.with_suffix('.acceptance-results.json')
    assert not destination.exists()
    shutil.copy2(project / 'acceptance-results.json', destination)
    result = trial.read(destination)
    assert result['completed'] and result['checks'] == len(cases) and result['failed'] == 0
    assert sorted(result['results']) == sorted(cases)
    print(json.dumps(dict(passed=True, cases={key: dict(body_ms=value['body_ms'], setup_ms=value['setup_ms'])
                                              for key, value in result['results'].items()})))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['prepare', 'measure', 'functional', 'validate'])
    parser.add_argument('--variant', default='baselineborrow')
    parser.add_argument('--label', default='b1')
    parser.add_argument('--window', default='gp80')
    parser.add_argument('--profile', default='plain')
    args = parser.parse_args()
    if args.action == 'prepare':
        prepare(args.variant)
    elif args.action == 'measure':
        measure(args)
    elif args.action == 'validate':
        validate(args)
    else:
        functional(args)
