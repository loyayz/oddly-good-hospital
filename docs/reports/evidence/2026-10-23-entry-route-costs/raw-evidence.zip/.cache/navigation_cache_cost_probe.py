from pathlib import Path
import argparse
import importlib.util

spec = importlib.util.spec_from_file_location('navigation_cache_probe', Path(__file__).with_name('entry_route_cost_probe.py'))
probe = importlib.util.module_from_spec(spec)
spec.loader.exec_module(probe)
probe.VARIANT = 'baselinecacheprobe'
probe.METHODS = {
    'game/building/navigation_cache.gd': ['graph', '_refresh_graph', '_travel_distance', 'cached_floor_path', 'floor_source'],
    'game/building/route_clearance.gd': ['_build_static'],
}

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['prepare', 'measure'])
    parser.add_argument('--window', default='gp80')
    parser.add_argument('--label', default='cache01')
    args = parser.parse_args()
    if args.action == 'prepare':
        probe.prepare()
    else:
        probe.measure(args)
