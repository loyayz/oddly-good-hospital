from pathlib import Path
from types import SimpleNamespace
import argparse
import importlib.util
import json
import re
import subprocess

REPO = Path(__file__).resolve().parent.parent
spec = importlib.util.spec_from_file_location('entry_trial', REPO / '.cache/worker_select_round.py')
trial = importlib.util.module_from_spec(spec)
spec.loader.exec_module(trial)
trial.ROOT = REPO / '.cache/entry-route-c122dcc-20261023'
VARIANT = 'baselineentryprobe02'
TICKS = [823, 850, 866, 2623, 2650, 2655, 2759, 2763, 2842]
METHODS = {
    'game/life/public_areas.gd': ['_waiting_point', '_entry_landings', '_entry_geometry_view', '_entry_order', 'safe_wait', '_safe_wait_geometry'],
    'game/building/hospital_navigation.gd': ['_prepare_route_subject', '_point_route', '_connector_preparation', '_source_quote', '_connector_edges', '_floor_route'],
}


def mark(label, indent):
    return (indent + 'if _entry_probe_started>0:\n'
            + indent + '\tvar _entry_probe_us: int = Time.get_ticks_usec()-_entry_probe_started\n'
            + indent + '\tvar _entry_probe_key: String = "diag_entry/"+str(world.sim_tick+1)+"/"+' + json.dumps(label) + '\n'
            + indent + '\tspace.query_counts[_entry_probe_key+"/us"] = int(space.query_counts.get(_entry_probe_key+"/us",0))+_entry_probe_us\n'
            + indent + '\tspace.query_counts[_entry_probe_key+"/calls"] = int(space.query_counts.get(_entry_probe_key+"/calls",0))+1\n')


def instrument(source, name, label):
    start = source.index('func ' + name + '(')
    match = re.search(r'\n(?:static )?func ', source[start + 6:])
    end = start + 6 + match.start() + 1 if match else len(source)
    original = source[start:end]
    lines = original.splitlines(keepends=True)
    result = [lines[0], '\tvar _entry_probe_started: int = Time.get_ticks_usec() if world.sim_tick in ' + str(TICKS) + ' else 0\n']
    ordinal = 0
    lambda_indent = None
    for raw in lines[1:]:
        stripped = raw.lstrip('\t').rstrip('\r\n')
        indent = raw[:len(raw) - len(raw.lstrip('\t'))]
        if lambda_indent is not None:
            if not stripped or stripped.startswith('#') or len(indent) > lambda_indent:
                result.append(raw)
                continue
            lambda_indent = None
        if 'func(' in stripped and stripped.endswith(':'):
            lambda_indent = len(indent)
            result.append(raw)
            continue
        expression = None
        if stripped.startswith(('if ', 'elif ')) and ': return' in stripped:
            condition, expression = stripped.split(': return', 1)
            result.append(indent + condition + ':\n')
            indent += '\t'
        elif stripped == 'return':
            result.append(mark(label, indent))
            result.append(raw)
            continue
        elif stripped.startswith('return '):
            expression = stripped[len('return '):]
        else:
            result.append(raw)
            continue
        ordinal += 1
        if not expression.strip():
            result.append(mark(label, indent))
            result.append(indent + 'return\n')
            continue
        variable = '_entry_probe_return_' + str(ordinal)
        result.append(indent + 'var ' + variable + ': Variant = ' + expression.strip() + '\n')
        result.append(mark(label, indent))
        result.append(indent + 'return ' + variable + '\n')
    last = next(line.strip() for line in reversed(lines) if line.strip() and not line.lstrip().startswith('#'))
    if not last.startswith('return'):
        result.append(mark(label, '\t'))
    generated = ''.join(result)
    if name == '_waiting_point':
        generated = generated.replace(lines[0], lines[0] + '\t_entry_probe_tick = world.sim_tick\n', 1)
    if name == '_entry_order':
        generated = generated.replace('world.sim_tick', '_entry_probe_tick')
    assert generated != original, name
    return source[:start] + generated + source[end:], dict(method=name, original=original, generated=generated)


def prepare():
    trial.prepare(SimpleNamespace(variant=VARIANT, tasks=4))
    project = trial.ROOT / (VARIANT + '-project')
    patches = []
    for relative, names in METHODS.items():
        original = (project / relative).read_text(encoding='utf-8')
        generated = original
        if relative.endswith('public_areas.gd'):
            generated = generated.replace('var _space: WeakRef\n', 'var _space: WeakRef\nvar _entry_probe_tick: int = -1\n', 1)
        replacements = []
        for name in names:
            generated, patch = instrument(generated, name, relative.rsplit('/', 1)[-1] + '.' + name)
            replacements.append(patch)
        restored = generated
        for patch in reversed(replacements):
            assert restored.count(patch['generated']) == 1
            restored = restored.replace(patch['generated'], patch['original'], 1)
        restored = restored.replace('var _space: WeakRef\nvar _entry_probe_tick: int = -1\n', 'var _space: WeakRef\n', 1)
        assert restored == original
        (project / relative).write_bytes(generated.encode('utf-8'))
        patches.append(dict(path=relative, original=original, generated=generated, replacements=replacements, inverse_equal=True))
    relative = 'tools/performance/representative_worker.gd'
    original = (project / relative).read_text(encoding='utf-8')
    generated = original.replace('\t\tvar started: int = Time.get_ticks_usec()',
        '\t\tvar entry_query_before: Dictionary = clinical.simulation.space.query_counts.duplicate() if clinical.world.sim_tick in ' + str(TICKS) + ' else {}\n\t\tvar started: int = Time.get_ticks_usec()', 1)
    anchor = '\t\tif result==null:'
    generated = generated.replace(anchor, '''\t\tif not entry_query_before.is_empty():
\t\t\tvar entry_delta: Dictionary = {}
\t\t\tfor entry_key: String in clinical.simulation.space.query_counts:
\t\t\t\tif entry_key.begins_with("diag_entry/"): continue
\t\t\t\tvar entry_change: int = int(clinical.simulation.space.query_counts[entry_key])-int(entry_query_before.get(entry_key,0))
\t\t\t\tif entry_change!=0: entry_delta[entry_key] = entry_change
\t\t\tstep_record["query_delta"] = entry_delta
''' + anchor, 1)
    assert generated != original and generated.count('entry_query_before: Dictionary') == 1
    (project / relative).write_bytes(generated.encode('utf-8'))
    patches.append(dict(path=relative, original=original, generated=generated, query_snapshots_outside_measured_step=True))
    path = trial.ROOT / (VARIANT + '-identity.json')
    identity = trial.read(path)
    identity.update(patches=patches, selected_world_ticks=TICKS, return_expression_evaluated_before_clock_stop=True,
                    nested_lambdas_excluded_from_function_bookends=True)
    for row in identity['sources']:
        row['sha256'] = trial.sha(project / row['path'])
    path.rename(path.with_name(VARIANT + '-initial-identity.json'))
    trial.write(path, identity)


def measure(args):
    subprocess.check_call(['pwsh', '-NoProfile', '-Command',
        "if (Get-Process -Name '*Godot*' -ErrorAction SilentlyContinue) { throw 'Another Godot process is running; no measurement started.' }"])
    args.variant = VARIANT
    args.profile = 'root'
    trial.measure(args)
    result = trial.read(trial.ROOT / (args.label + '-' + args.window + '.semantic-check.json'))
    assert all(key.startswith('diag_entry/') for key in result['query_count_differences'])
    data = trial.read(trial.ROOT / (args.label + '-' + args.window + '.json'))
    counts = data['public']['query_counts']
    selected = {}
    for tick in TICKS:
        prefix = 'diag_entry/' + str(tick + 1) + '/'
        current = {key[len(prefix):]: value for key, value in counts.items() if key.startswith(prefix)}
        if current:
            selected[tick + 1] = current
    trial.write(trial.ROOT / (args.label + '-' + args.window + '.entry-costs.json'), selected)
    print(json.dumps(selected))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['prepare', 'measure'])
    parser.add_argument('--window', default='gp80')
    parser.add_argument('--label', default='probe01')
    args = parser.parse_args()
    if args.action == 'prepare':
        prepare()
    else:
        measure(args)
