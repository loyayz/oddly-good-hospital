from pathlib import Path
from types import SimpleNamespace
import argparse
import importlib.util
import json

REPO=Path(__file__).resolve().parent.parent
spec=importlib.util.spec_from_file_location('static_geometry_trial',REPO/'.cache/worker_select_round.py')
trial=importlib.util.module_from_spec(spec)
spec.loader.exec_module(trial)
trial.ROOT=REPO/'.cache/static-geometry-c122dcc-20261023'
TICKS='[823,850,866,2623,2758,2759,2763,2878]'

def prepare(variant):
    trial.prepare(SimpleNamespace(variant=variant,tasks=4))
    if variant=='baseline':return
    project=trial.ROOT/(variant+'-project')
    patches=[]
    transformations={
        'game/building/hospital_navigation.gd':[
            ('\tif query==null: query = RouteClearance.new(space,world,actor,floor_id,members,offsets,false,source)',
             '''\tif query==null:
\t\tvar _sg_started: int = Time.get_ticks_usec() if world.sim_tick in '''+TICKS+''' else 0
\t\tquery = RouteClearance.new(space,world,actor,floor_id,members,offsets,false,source)
\t\tif _sg_started>0:
\t\t\tvar _sg_elapsed: int = Time.get_ticks_usec()-_sg_started
\t\t\tvar _sg_label: String = "diag_static/"+str(world.sim_tick+1)+"/standalone"
\t\t\tspace.query_counts[_sg_label+"/calls"] = int(space.query_counts.get(_sg_label+"/calls",0))+1
\t\t\tspace.query_counts[_sg_label+"/us"] = int(space.query_counts.get(_sg_label+"/us",0))+_sg_elapsed
\t\t\tif members.is_empty() and offsets.is_empty() and space.in_dynamic_route_query(world):
\t\t\t\tvar _sg_key: String = space._navigation._graph_key(space,world,floor_id,actor,[],{},source)
\t\t\t\tvar _sg_views: Dictionary = space.read_view(world,"diagnostic_static_geometry",func()->Dictionary:return {})
\t\t\t\t_sg_views[_sg_key] = {"geometry":query,"elapsed_us":_sg_elapsed}
'''.rstrip('\n'))],
        'game/building/navigation_cache.gd':[
            ('\tvar geometry: RouteClearance = RouteClearance.new(space,world,actor,floor_id,members,offsets,false,source)\n\tvar floor_graph: FloorNavigation',
             '''\tvar _sg_started: int = Time.get_ticks_usec() if world.sim_tick in '''+TICKS+''' else 0
\tvar geometry: RouteClearance = RouteClearance.new(space,world,actor,floor_id,members,offsets,false,source)
\tif _sg_started>0:
\t\tvar _sg_elapsed: int = Time.get_ticks_usec()-_sg_started
\t\tvar _sg_label: String = "diag_static/"+str(world.sim_tick+1)+"/graph_geometry"
\t\tspace.query_counts[_sg_label+"/calls"] = int(space.query_counts.get(_sg_label+"/calls",0))+1
\t\tspace.query_counts[_sg_label+"/us"] = int(space.query_counts.get(_sg_label+"/us",0))+_sg_elapsed
\t\tif members.is_empty() and offsets.is_empty() and space.in_dynamic_route_query(world):
\t\t\tvar _sg_key: String = _graph_key(space,world,floor_id,actor,[],{},source)
\t\t\tvar _sg_views: Dictionary = space.read_view(world,"diagnostic_static_geometry",func()->Dictionary:return {})
\t\t\tvar _sg_previous: Dictionary = _sg_views.get(_sg_key,{})
\t\t\tif not _sg_previous.is_empty():
\t\t\t\tvar _sg_source: Dictionary = (_sg_previous.geometry as RouteClearance).source.duplicate()
\t\t\t\t_sg_source.erase("occupancy")
\t\t\t\tvar _sg_same: bool = _sg_source==source
\t\t\t\tvar _sg_match: String = "diag_static/"+str(world.sim_tick+1)+("/duplicate_equal" if _sg_same else "/different_source")
\t\t\t\tspace.query_counts[_sg_match+"/calls"] = int(space.query_counts.get(_sg_match+"/calls",0))+1
\t\t\t\tspace.query_counts[_sg_match+"/new_us"] = int(space.query_counts.get(_sg_match+"/new_us",0))+_sg_elapsed
\t\t\t\tspace.query_counts[_sg_match+"/old_us"] = int(space.query_counts.get(_sg_match+"/old_us",0))+int(_sg_previous.elapsed_us)
\tvar floor_graph: FloorNavigation''')]
    }
    for relative,changes in transformations.items():
        original=(project/relative).read_text(encoding='utf-8')
        generated=original
        for before,after in changes:
            assert generated.count(before)==1,(relative,before)
            generated=generated.replace(before,after,1)
        if variant=='baselineprobe2' and relative.endswith('hospital_navigation.gd'):
            anchor='\t\t\t\t_sg_views[_sg_key] = {"geometry":query,"elapsed_us":_sg_elapsed}'
            extra='''\t\t\t\tvar _sg_prior: Dictionary = _sg_views.get(_sg_key,{})
\t\t\t\tif not _sg_prior.is_empty():
\t\t\t\t\tvar _sg_old_source: Dictionary = (_sg_prior.geometry as RouteClearance).source.duplicate()
\t\t\t\t\tvar _sg_current_source: Dictionary = source.duplicate()
\t\t\t\t\t_sg_old_source.erase("occupancy")
\t\t\t\t\t_sg_current_source.erase("occupancy")
\t\t\t\t\tif _sg_old_source==_sg_current_source:
\t\t\t\t\t\tspace.query_counts[_sg_label+"/duplicate_calls"] = int(space.query_counts.get(_sg_label+"/duplicate_calls",0))+1
\t\t\t\t\t\tspace.query_counts[_sg_label+"/duplicate_us"] = int(space.query_counts.get(_sg_label+"/duplicate_us",0))+_sg_elapsed
'''+anchor
            assert generated.count(anchor)==1
            generated=generated.replace(anchor,extra,1)
            changes.append((anchor,extra))
        restored=generated
        for before,after in reversed(changes):restored=restored.replace(after,before,1)
        assert restored==original
        (project/relative).write_bytes(generated.encode('utf-8'))
        patches.append(dict(path=relative,original=original,generated=generated,inverse_equal=True))
    path=trial.ROOT/(variant+'-identity.json')
    identity=trial.read(path)
    identity['patches']=patches
    for row in identity['sources']:row['sha256']=trial.sha(project/row['path'])
    path.rename(path.with_name(variant+'-initial-identity.json'))
    trial.write(path,identity)

def measure(args):
    trial.measure(args)
    result=trial.read(trial.ROOT/(args.label+'-'+args.window+'.json'))
    reference=trial.read(REPO/'.cache/queue-signature-26bcc0f-20261023'/('e3-gp80.json' if args.window=='gp80' else 'e1-'+args.window+'.json'))
    counts=result['public']['query_counts']
    unchanged={k:v for k,v in counts.items() if not k.startswith('diag_static/')}
    assert unchanged==reference['public']['query_counts']
    print(json.dumps({k:v for k,v in counts.items() if k.startswith('diag_static/')}))

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('action',choices=['prepare','measure'])
    p.add_argument('--variant',default='baselineprobe')
    p.add_argument('--label',default='probe01')
    p.add_argument('--window',default='gp80')
    p.add_argument('--profile',default='root')
    args=p.parse_args()
    if args.action=='prepare':prepare(args.variant)
    else:measure(args)
