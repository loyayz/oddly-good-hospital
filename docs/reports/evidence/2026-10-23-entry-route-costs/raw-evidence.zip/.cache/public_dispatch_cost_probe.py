from pathlib import Path
import argparse
import importlib.util

spec = importlib.util.spec_from_file_location('public_dispatch_probe', Path(__file__).with_name('entry_route_cost_probe.py'))
probe = importlib.util.module_from_spec(spec)
spec.loader.exec_module(probe)
probe.VARIANT = 'baselineentryprobe03'
probe.METHODS = {
    'game/life/public_areas.gd': ['select', '_wait_constraints', '_wait_door_view', '_ensure', '_queue_fit_current', '_decision_signature'],
    'game/life/waiting_life.gd': ['_dispatch_public_seat', '_seat_candidates_in_query', '_facility_quote'],
}

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['prepare', 'measure'])
    parser.add_argument('--window', default='gp80')
    parser.add_argument('--label', default='probe03')
    args = parser.parse_args()
    if args.action == 'prepare':
        probe.prepare()
    else:
        probe.measure(args)
