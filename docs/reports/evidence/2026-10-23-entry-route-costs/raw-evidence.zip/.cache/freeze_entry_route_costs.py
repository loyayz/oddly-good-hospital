from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import zipfile

REPO = Path(__file__).resolve().parent.parent
ROOTS = [REPO / '.cache/static-geometry-c122dcc-20261023', REPO / '.cache/entry-route-c122dcc-20261023']
OUT = REPO / 'docs/reports/evidence/2026-10-23-entry-route-costs'
read = lambda path: json.loads(Path(path).read_text(encoding='utf-8-sig'))
digest = lambda data: hashlib.sha256(data).hexdigest()
sha = lambda path: digest(Path(path).read_bytes())
relative = lambda path: Path(path).relative_to(REPO).as_posix()
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip()
assert head == 'c122dcc75856592c68be4698b416ab9aad9f5b58', head
assert subprocess.check_output(['git', 'branch', '--show-current'], cwd=REPO, text=True).strip() == 'dev'
subprocess.check_call(['git', 'diff', '--exit-code', '--', 'game', 'tests', 'project.godot'], cwd=REPO)
baseline = read(ROOTS[0] / 'baseline-identity.json')
baseline_rows = {row['path']: row['sha256'] for row in baseline['sources'] + baseline['tests']}
for row in baseline['sources'] + baseline['tests']:
    if row['path'] not in ['project.godot', 'export_presets.cfg']:
        assert sha(REPO / row['path']) == row['sha256'], row['path']
parent = REPO / 'docs/reports/evidence/2026-10-23-movement-neighborhood-controls/raw-evidence.zip'
assert sha(parent) == '24862e116198337c709b253151082e501a911182b923bcb2c662085aeb678a80'
members = {}
aliases = []
identities = {}


def add(path, name=None):
    path = Path(path)
    name = name or relative(path)
    data = path.read_bytes()
    if name in members:
        assert members[name] == data, name
    members[name] = data


runs = {}
failed = {}
intervals = []
for root in ROOTS:
    for path in sorted(root.glob('*-identity.json')):
        if path.name.endswith('-initial-identity.json'):
            continue
        variant = path.name.removesuffix('-identity.json')
        identity = read(path)
        project = root / (variant + '-project')
        for key in ['sources', 'tests']:
            for row in identity[key]:
                source = project / row['path']
                assert sha(source) == row['sha256'], source
                if baseline_rows.get(row['path']) != row['sha256']:
                    member = 'source-blobs/' + row['sha256'] + source.suffix
                    add(source, member)
                    aliases.append(dict(path=relative(source), member=member, sha256=row['sha256']))
        identities[variant] = dict(sources=len(identity['sources']), tests=len(identity['tests']), all_files_verified=True)
    for path in sorted(root.glob('*.launch.json')):
        label = path.name.removesuffix('.launch.json')
        key = root.name + '/' + label
        launch = read(path)
        intervals.append((launch['started_at_utc'], launch['ended_at_utc'], key))
        assert sha(launch['engine']) == launch['engine_sha256']
        source = read(root / (label + '.source-check.json'))
        assert source['actual_sources'] == read(root / (source['variant'] + '-identity.json'))['sources']
        if launch['exit_code'] != 0 or launch['timed_out'] or launch['errors']:
            assert root == ROOTS[1] and label == 'probe01-gp80'
            assert any('Identifier "world" not declared' in message for message in launch['errors'])
            failed[key] = dict(exit_code=launch['exit_code'], errors=len(launch['errors']), timed_out=launch['timed_out'],
                               included_in_performance_comparison=False, reason='Instrumentation used world in _entry_order, which has no world argument.')
            continue
        check = read(root / (label + '.semantic-check.json'))
        assert check['passed'] and all(check['checks'].values()), key
        actual = read(root / (label + '.json'))
        assert actual['complete'] and actual['qualified'] and not actual['errors']
        assert len(actual['samples']) == actual['requested_steps'] == actual['metrics']['count']
        assert all(sample['complete'] and sample['present'] == 160 for sample in actual['samples'])
        assert sha(root / (label + '.json.final.bin')) == actual['final_binary_sha256']
        variant = source['variant']
        differences = check['query_count_differences']
        if variant == 'baselineborrow':
            assert set(differences) <= {'structural_geometry_builds', 'structural_geometry_borrows', 'door_candidates', 'reservation_candidate_queries'}
            assert differences['structural_geometry_borrows']['actual'] == 1
            for counter in ['door_candidates', 'reservation_candidate_queries']:
                assert differences[counter]['expected'] - differences[counter]['actual'] == 16
        elif variant == 'baseline':
            assert not differences
        elif variant.startswith('baselineprobe'):
            assert all(name.startswith('diag_static/') for name in differences)
        elif variant == 'baselineastarprobe':
            assert not differences
            assert actual['public']['query_counts'].get('cache_graph_evictions', 0) == 0
        else:
            assert all(name.startswith('diag_entry/') for name in differences)
        roots = []
        for line in (root / (label + '.json.steps.ndjson')).read_text().splitlines():
            row = json.loads(line)
            if row.get('kind') != 'complete' or not row.get('profile'):
                continue
            profile = row['profile']
            roots.append(dict(tick=row['sample']['tick'], elapsed_us=row['sample']['elapsed_us'],
                              stages_us={name: value['total_us'] for name, value in profile.get('stages', {}).items()},
                              query_delta=profile.get('query_delta', {}), astar_callback_probe=profile.get('astar_callback_probe', {})))
        runs[key] = dict(variant=variant, steps=actual['requested_steps'], metrics_us=actual['metrics'],
                         checks=check['checks'], query_counts=actual['public']['query_counts'], query_count_differences=differences,
                         root_steps=roots, input_sha256=actual['source_input_sha256'], final_binary_sha256=actual['final_binary_sha256'],
                         process_cpu_ms=launch['child_cpu_ms'], process_wall_ms=launch['wall_ms'])
    for path in root.iterdir():
        if path.is_file() and not path.name.endswith('.final.bin'):
            add(path)
    for path in root.glob('*.json.final.bin'):
        member = 'final-states/' + sha(path) + '.bin'
        add(path, member)
        aliases.append(dict(path=relative(path), member=member, sha256=sha(path)))

assert len(runs) == 17 and sum(run['steps'] for run in runs.values()) == 3600
assert len(failed) == 1
intervals.sort()
for left, right in zip(intervals, intervals[1:]):
    assert left[1] <= right[0], (left, right)
before = read(ROOTS[0] / 'b1-public360.launch.json')
after = read(ROOTS[0] / 'a2-public360.launch.json')
gap = (datetime.datetime.fromisoformat(after['started_at_utc']) - datetime.datetime.fromisoformat(before['ended_at_utc'])).total_seconds()
assert gap > 0
tooling_events = dict(
    borrow_first_count_guard=dict(run='b1-gp80', driver_exit_code=1, engine_exit_code=0, semantic_checks_passed=True,
                                 cause='Initial driver allowed only added geometry counters; a borrowed construction also removes 16 door and reservation candidate queries.',
                                 resolution='Retained the original measurement and validated matching candidate reductions without rerunning it.'),
    conservative_overlap_alarm=dict(actual_overlap=False, verified_gap_seconds=gap,
                                    resolution='Both receipts prove disjoint engine intervals. The earlier commentary alarm was corrected.'),
    environment_observation=dict(cim_error='无法从客户端中访问 CIM 资源。', performance_counter_error='在计算机上找不到指定的对象。',
                                 cpu_frequency_or_thermal_cause_established=False))
members['tooling-events.json'] = (json.dumps(tooling_events, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
members['source-aliases.json'] = (json.dumps(aliases, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
for name in ['static_geometry_round.py', 'static_geometry_borrow_round.py', 'entry_route_cost_probe.py',
             'public_dispatch_cost_probe.py', 'navigation_cache_cost_probe.py', 'astar_callback_probe.py', 'worker_select_round.py']:
    add(REPO / '.cache' / name)
add(REPO / '.cache/wait-signature-031e1f7-20261022/run.py')
add(Path(__file__))
for name in ['public-v6.input.bin', 'gp.input.bin']:
    add(REPO / '.cache/task-navigation-20261019' / name)
OUT.mkdir(parents=True, exist_ok=True)
archive = OUT / 'raw-evidence.zip'
assert not archive.exists()
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as output:
    for name, data in sorted(members.items()):
        output.writestr(name, data)
with zipfile.ZipFile(archive) as output:
    assert set(output.namelist()) == set(members)
    for name, data in members.items():
        assert digest(output.read(name)) == digest(data), name
manifest = dict(schema_version=1, archive_sha256=sha(archive), archive_bytes=archive.stat().st_size,
                baseline_reference=dict(path=relative(parent), sha256=sha(parent)),
                members=[dict(path=name, bytes=len(data), sha256=digest(data)) for name, data in sorted(members.items())])
summary = dict(schema_version=1, generated_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               baseline_commit=head, production_commit='5712c6f7fbc7e222e2a483bc376201352fd5ffc2', diagnostic_only=True, formal_pass=False,
               fixed_load=dict(people=160, patients=120, staff=32, visitors=8, floors=4, rooms=64, facilities=1336, tick_seconds=0.1),
               successful_performance_windows=len(runs), qualified_measured_steps=sum(run['steps'] for run in runs.values()),
               failed_engine_windows=failed, all_engine_intervals_disjoint=True, engine_intervals=intervals,
               production_and_tests_unchanged=True, functional_engine_windows=0,
               selected_but_not_run_cases=['SPACE-46', 'SPACE-51', 'STAFF-57', 'STAFF-61'],
               adoption=dict(weak_static_geometry_borrow=False, reason='Only one construction removed in each full window; no stable whole-step benefit.'),
               no_release_or_formal_acceptance=True, identities=identities, runs=runs, tooling_events=tooling_events,
               weekly_usage_at_round_boundary=dict(used_percent=38, window_minutes=10080, pause_threshold_strictly_above_percent=90),
               raw_archive=dict(path=relative(archive), sha256=sha(archive), bytes=archive.stat().st_size, members=len(members)),
               notes=['Nested function timings must not be added or directly subtracted across separate diagnostic runs.',
                      'The AStar call counter adds one script integer increment per heuristic call; search_us is observed search elapsed time, not heuristic self CPU.',
                      'The failed instrumentation run is retained and excluded even though it produced output and final state files.',
                      'Probe scripts evolved; each measured project identity and full original/generated source are archived.',
                      'No source-input prefix, business threshold, polling interval, cache warmup or total allowance was changed.',
                      'Local-only delivery; no push was performed.'])
for name, value in [('raw-manifest.json', manifest), ('summary.json', summary)]:
    path = OUT / name
    assert not path.exists()
    path.write_bytes((json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
print(json.dumps(dict(archive_sha256=sha(archive), bytes=archive.stat().st_size, members=len(members), windows=len(runs), steps=3600)))
