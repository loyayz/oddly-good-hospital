from pathlib import Path
from types import SimpleNamespace
import argparse
import importlib.util
import json
import subprocess

REPO = Path(__file__).resolve().parent.parent
spec = importlib.util.spec_from_file_location('astar_trial', REPO / '.cache/worker_select_round.py')
trial = importlib.util.module_from_spec(spec)
spec.loader.exec_module(trial)
trial.ROOT = REPO / '.cache/entry-route-c122dcc-20261023'
VARIANT = 'baselineastarprobe'
TICKS = [823, 850, 866, 2623, 2650, 2655, 2759, 2763, 2842]


def prepare():
    trial.prepare(SimpleNamespace(variant=VARIANT, tasks=4))
    project = trial.ROOT / (VARIANT + '-project')
    changes = {
        'game/building/floor_navigation.gd': [
            ('var geometry: RouteClearance\n', 'var geometry: RouteClearance\nvar _diagnostic_estimate_calls: int = 0\nvar _diagnostic_search_calls: int = 0\nvar _diagnostic_search_us: int = 0\n'),
            ('\tvar ids: PackedInt64Array = get_id_path(_id(start),_id(goal),partial)',
             '\tvar _diagnostic_started: int = Time.get_ticks_usec()\n\tvar ids: PackedInt64Array = get_id_path(_id(start),_id(goal),partial)\n\t_diagnostic_search_us += Time.get_ticks_usec()-_diagnostic_started\n\t_diagnostic_search_calls += 1'),
            ('func _estimate_cost(from_id: int, end_id: int) -> float:\n',
             'func _estimate_cost(from_id: int, end_id: int) -> float:\n\t_diagnostic_estimate_calls += 1\n')],
        'tools/performance/representative_worker.gd': [
            ('\t\tvar started: int = Time.get_ticks_usec()',
             '\t\tvar callback_selected: bool = clinical.world.sim_tick in ' + str(TICKS) + '\n\t\tvar callback_before: Dictionary = _callback_totals(clinical.simulation.space) if callback_selected else {}\n\t\tvar started: int = Time.get_ticks_usec()'),
            ('\t\tif result==null:',
             '\t\tif callback_selected:\n\t\t\tvar callback_after: Dictionary = _callback_totals(clinical.simulation.space)\n\t\t\tfor callback_key: String in callback_after: callback_after[callback_key] -= int(callback_before.get(callback_key,0))\n\t\t\tstep_record["astar_callback_probe"] = callback_after\n\t\tif result==null:')]
    }
    helper = '''
func _callback_totals(space: HospitalSpace) -> Dictionary:
\tvar result: Dictionary = {"estimate_calls":0,"search_calls":0,"search_us":0}
\tfor entry: Dictionary in space._navigation._entries.values():
\t\tvar graph: FloorNavigation = entry.graph
\t\tresult.estimate_calls += graph._diagnostic_estimate_calls
\t\tresult.search_calls += graph._diagnostic_search_calls
\t\tresult.search_us += graph._diagnostic_search_us
\treturn result
'''
    patches = []
    for relative, replacements in changes.items():
        original = (project / relative).read_text(encoding='utf-8')
        generated = original
        for before, after in replacements:
            assert generated.count(before) == 1, (relative, before)
            generated = generated.replace(before, after, 1)
        if relative.endswith('representative_worker.gd'):
            generated += helper
        restored = generated.removesuffix(helper) if relative.endswith('representative_worker.gd') else generated
        for before, after in reversed(replacements):
            restored = restored.replace(after, before, 1)
        assert restored == original
        (project / relative).write_bytes(generated.encode('utf-8'))
        patches.append(dict(path=relative, original=original, generated=generated, inverse_equal=True))
    path = trial.ROOT / (VARIANT + '-identity.json')
    identity = trial.read(path)
    identity.update(patches=patches, selected_world_ticks=TICKS, probe_adds_one_integer_increment_per_heuristic_call=True,
                    no_claim_of_unobserved_heuristic_self_time=True, counter_totals_require_no_graph_evictions=True)
    for row in identity['sources']:
        row['sha256'] = trial.sha(project / row['path'])
    path.rename(path.with_name(VARIANT + '-initial-identity.json'))
    trial.write(path, identity)


def measure(args):
    subprocess.check_call(['pwsh', '-NoProfile', '-Command',
        "if (Get-Process -Name '*Godot*' -ErrorAction SilentlyContinue) { throw 'Another Godot process is running.' }"])
    args.variant = VARIANT
    args.profile = 'root'
    trial.measure(args)
    check = trial.read(trial.ROOT / (args.label + '-' + args.window + '.semantic-check.json'))
    assert not check['query_count_differences']
    report = trial.read(trial.ROOT / (args.label + '-' + args.window + '.json'))
    assert report['public']['query_counts'].get('cache_graph_evictions', 0) == 0
    rows = [json.loads(line) for line in (trial.ROOT / (args.label + '-' + args.window + '.json.steps.ndjson')).read_text().splitlines()]
    selected = {row['sample']['tick']: dict(elapsed_us=row['sample']['elapsed_us'], **row['profile']['astar_callback_probe'])
                for row in rows if row.get('kind') == 'complete' and 'astar_callback_probe' in row['profile']}
    trial.write(trial.ROOT / (args.label + '-' + args.window + '.astar-costs.json'), selected)
    print(json.dumps(selected))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['prepare', 'measure'])
    parser.add_argument('--window', default='gp80')
    parser.add_argument('--label', default='astar01')
    args = parser.parse_args()
    if args.action == 'prepare':
        prepare()
    else:
        measure(args)
