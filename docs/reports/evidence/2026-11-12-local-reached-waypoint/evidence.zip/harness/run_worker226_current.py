from pathlib import Path
import sys,json,hashlib
base=Path('C:/Users/cong/dot-work/ogh-worker226-current-20261112');base.mkdir(exist_ok=False)
old=Path('C:/Users/cong/dot-work/ogh-fixed-boundary-20261112')
source=Path('C:/Users/cong/dot-work/ogh-recovery-full-20261112');project=base/'.cache/project'
repo=Path('C:/Users/cong/dot-work/oddly-good-hospital-handoff-20261112')
sys.path.insert(0,str(old/'tools/performance/current'))
import prepare_builtin_script_profile as guard
import prepare_transport_trace as overlay
import shutil
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
meta=json.loads((source/'identity-before.json').read_text())
for rel,digest in meta['source'].items():assert sha(source/'project'/rel)==digest,rel
for rel in meta['source']:
 if rel.startswith(('game/','content/','addons/')):assert sha(source/'project'/rel)==sha(repo/rel),rel
for name,h in meta['native'].items():assert sha(source/'project/game/platform/windows/bin'/name)==h,name
for name,h in meta['engine'].items():assert sha(Path(name))==h,name
shutil.copytree(source/'project',project)
meta['engine']=next(name for name in meta['engine'] if 'console' in name)
meta['current_repo_commit']='d0fc92b73a9e0eb4691127bd6bd9551ed4dfe788'
(base/'input-identity.json').write_text(json.dumps(meta,indent=2))
inp=source/'plain-r1/result.json.final.bin'
assert sha(inp)=='876e2502aa2f7b853f94aa50a9d0fe02a2bff68ce3cab6a4666ce3cef2ec6c58'
steps=8
command=lambda out:[meta['engine'],'--headless','--path',str(project),'--script','res://tools/performance/current/plain_v4.gd','--','--input='+str(inp),'--output='+str(out),'--steps='+str(steps),'--prefix-steps=0','--worker-tasks=4','--main-thread-policy=app']
print('Plain bounded 8 steps',flush=True)
guard.run_process(command(base/'plain8/result.json'),project,base/'plain8',180)
patches={
 'game/building/hospital_transit.gd':overlay.transit_patch(project/'game/building/hospital_transit.gd'),
 'game/building/hospital_movement.gd':overlay.movement_patch(project/'game/building/hospital_movement.gd'),
}
p=patches['game/building/hospital_transit.gd']
marker='\tvar at_entry: bool=_at_landing(space,world,connection,movement,segment)\n'
p.replace(marker,marker+'\tif actor.id in ["maintenance_contractor_00000226","maintenance_contractor_00000226"]: _TransportDiagnostic._record(world,"worker_begin",{"actor":_TransportDiagnostic._actor(world,actor.id),"at_entry":at_entry,"connection":_TransportDiagnostic._connection(connection)})\n')
marker='\tif not at_entry and not _landing_in_use(connection,int(segment.from)):\n\t\tspace.movement._queue_route(world,movement,true)\n'
p.replace(marker,'\tif not at_entry and not _landing_in_use(connection,int(segment.from)):\n\t\tif actor.id in ["maintenance_contractor_00000226","maintenance_contractor_00000226"]: _TransportDiagnostic._record(world,"worker_queue_landing_recovery",{"actor":_TransportDiagnostic._actor(world,actor.id)})\n\t\tspace.movement._queue_route(world,movement,true)\n')

p=patches['game/building/hospital_movement.gd']
for name,args,kind in [('_local_resume','world,actor,movement','bool'),('_local_collision','world,actor,movement,contact','void'),('_local_try_return','world,actor,movement,advance,blocked_motion','bool'),('_local_choose_options','world,actor,movement,motion,fixed','bool'),('_move_step','world,actor,movement,segment','MotionResult')]:
 before='\tvar _capture: bool=actor.id=="maintenance_contractor_00000226"\n\tvar _before: Dictionary=_TransportDiagnostic._actor(world,actor.id) if _capture else {}\n'
 details='{"function":"'+name+'","before":_before,"after":_TransportDiagnostic._actor(world,actor.id)'
 if kind=='bool':details+=',"result":_trace_value'
 if name=='_local_try_return':details+=',"advance":advance,"blocked_motion":[blocked_motion.x,blocked_motion.y]'
 if name in ['_move_step','_local_collision']:
  value='_trace_value' if name=='_move_step' else 'contact'
  details+=',"requested":['+value+'.requested_motion.x,'+value+'.requested_motion.y],"actual":['+value+'.actual_motion.x,'+value+'.actual_motion.y],"body_ids":'+value+'.blocker_actor_ids.duplicate(),"reservation_ids":'+value+'.reservation_ids.duplicate(),"static_reason":'+value+'.static_reason,"door_id":'+value+'.door_id'
 if name in ['_move_step','_local_collision']:
  details+=',"blocker_owners":'+value+'.blocker_actor_ids.map(func(id: String)->Dictionary:return _TransportDiagnostic._actor(world,id))'
 details+='}'
 after='\tif _capture: _TransportDiagnostic._record(world,"worker226_actual_call",'+details+')\n'
 p.wrap(name,args,before,after,kind)
p=overlay.Patch(project/'game/building/hospital_space.gd')
p.replace('class_name HospitalSpace\nextends RefCounted\n','class_name HospitalSpace\nextends RefCounted\n'+overlay.PREFIX)
import re
match=re.search(r'^func _dynamic_clear\([^\n]*\)[^\n]*:\n[\s\S]*?(?=^func |\Z)',p.text,re.M);body=match[0];new=body
for oldline,newline in [
 ('\t\tif rect.intersects(region.rect,false):\n\t\t\treturn false','\t\tif rect.intersects(region.rect,false):\n\t\t\tif actor_id=="bench_patient_0111": _TransportDiagnostic._record(world,"actual_dynamic_reject",{"branch":"reservation","reservation_id":region.reservation_id})\n\t\t\treturn false'),
 ('\t\tif _actor_index.intersects(floor_id,rect,actor_id,ignored):\n\t\t\treturn false','\t\tif _actor_index.intersects(floor_id,rect,actor_id,ignored):\n\t\t\tif actor_id=="bench_patient_0111": _TransportDiagnostic._record(world,"actual_dynamic_reject",{"branch":"current_body_index","rect":_TransportDiagnostic._raw_rect(rect)})\n\t\t\treturn false'),
 ('\tif movement._sweep_index.intersects(floor_id,rect,actor_id,members):\n\t\treturn false','\tif movement._sweep_index.intersects(floor_id,rect,actor_id,members):\n\t\tif actor_id=="bench_patient_0111": _TransportDiagnostic._record(world,"actual_dynamic_reject",{"branch":"accepted_sweep"})\n\t\treturn false')]:
 assert new.count(oldline)==1
 new=new.replace(oldline,newline)
p.replace(body,new)
patches['game/building/hospital_space.gd']=p

p=overlay.Patch(project/'tools/performance/current/plain_v4.gd')
p.replace('extends SceneTree\n','extends SceneTree\n'+overlay.PREFIX)
p.replace('\tvar initial: Dictionary = snapshot(world)\n','\t_TransportDiagnostic.prepare(world,content)\n\tvar initial: Dictionary = snapshot(world)\n')
p.replace('\tvar attribution: Dictionary = profiler.report() if profile_stages else {}\n','\t_TransportDiagnostic.finish(output+".transport.json",world)\n\twrite_json(output+".maintenance.json",world.facts.maintenance)\n\twrite_json(output+".moves.json",world.facts.moves)\n\tvar attribution: Dictionary = profiler.report() if profile_stages else {}\n')
patches['tools/performance/current/plain_v4.gd']=p
manifest={rel:p.checked() for rel,p in patches.items()}
(base/'overlay.json').write_text(json.dumps(manifest,indent=2))
try:
 for p in patches.values():p.path.write_bytes(p.text.encode())
 print('Observed bounded 8 steps',flush=True)
 guard.run_process(command(base/'trace8/result.json'),project,base/'trace8',180)
 a=json.loads((base/'plain8/result.json').read_text());b=json.loads((base/'trace8/result.json').read_text())
 assert a['complete'] and b['complete'] and a['all_completed_steps']==8 and a['final_sha256']==b['final_sha256']
 (base/'comparison.json').write_text(json.dumps({'complete_world_rng_ordered_events_equal':True,'final_sha256':a['final_sha256'],'input_sha256':sha(inp),'steps':steps},indent=2))
 print('World RNG ordered events equal',flush=True)
finally:
 for p in patches.values():p.path.write_bytes(p.original)
 for rel,digest in meta['source'].items():assert sha(project/rel)==digest,rel
 print('Production sources fully restored',flush=True)
