import hashlib,json,pathlib,statistics,subprocess,zipfile
REPO=pathlib.Path(r'C:\code\loyayz\oddly-good-hospital')
ROOT=pathlib.Path(__file__).resolve().parent
OUT=REPO/'docs/reports/evidence/2026-10-21-navigation-owner-cold-cost'
BASE='d8cb36d6b37da3c08a1ad89618ecb0bc2831ce26'
OUT.mkdir(parents=True,exist_ok=True)
def read(path): return json.loads(pathlib.Path(path).read_text(encoding='utf-8-sig'))
def sha(path): return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()
def dump(name,value): (OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def measured(name):
 d=read(ROOT/(name+'.json'))
 assert d['qualified'] and d['complete'] and not d['errors']
 assert all(d.get('public_checks',{}).values())
 return dict(run=name,metrics=d['metrics'],qualification=d['qualification'],public_checks=d.get('public_checks'),
  final_hash=d['final_binary_sha256'],input_sha256=d['source_input_sha256'],work=d['final']['work_ticks_by_kind'],query_counts=d['public']['query_counts'],
  public_work={k:d['public'][k] for k in ['actual_use_ticks','queue_actor_ticks','actual_exit_then_reuse_count']},
  starts=len(d['public']['actual_use_starts']),completions=len(d['public']['actual_use_completions']))
windows=[]
for window in ['public360','gp80','operations40']:
 groups={}
 for group,letters in [('intermediate','abcd'),('final',['fa','fb','fc','fd'])]:
  rows=[measured(letter+'-'+window) for letter in letters]
  assert len({r['final_hash'] for r in rows})==1
  assert len({r['input_sha256'] for r in rows})==1
  assert all(r['work']==rows[0]['work'] and r['public_work']==rows[0]['public_work'] for r in rows)
  groups[group]=dict(runs=rows,whole_world_equal=True,before_mean_of_window_means_us=statistics.mean(rows[i]['metrics']['mean_us'] for i in [0,3]),after_mean_of_window_means_us=statistics.mean(rows[i]['metrics']['mean_us'] for i in [1,2]))
 windows.append(dict(window=window,**groups))
dump('quick-summary.json',dict(baseline=BASE,formal_pass=False,formal_acceptance_paused=True,windows=windows,
 caution='All A/B/B/A windows retained. Intermediate code returned int rather than original float for a new same-floor shortcut; final code fixes the return contract. Per-window percentiles are never pooled formal percentiles.'))
profiles=[]
for side in ['before','final']:
 for window in ['public360','gp80','operations40']:
  name=side+'-all-'+window;d=read(ROOT/(name+'.json'));p=d['profile'];assert not p['errors']
  assert d['final_binary_sha256']==read(ROOT/('a-'+window+'.json'))['final_binary_sha256']
  indices={s['tick']:s['index'] for s in d['samples']}
  steps=[dict(index=indices[s['tick']],tick=s['tick'],outer_us=s['outer_elapsed_us'],observer_us=s['observer_handler_us'],stages=s['stages'],calls=s['calls']) for s in p['step_records'] if s['calls']]
  profiles.append(dict(run=name,hash=d['final_binary_sha256'],errors=p['errors'],steps=steps))
dump('function-summary.json',dict(profiles=profiles,caution='All-instance diagnostic timing includes observer perturbation; only plain windows measure complete-step gains. Inclusive contains children.'))
traces=[]
for name in ['before-ops-trace','before-ops-trace-v2','final-ops-trace']:
 d=read(ROOT/(name+'.json'));assert d['qualified'] and d['complete'] and not d['errors']
 assert d['final_binary_sha256']==read(ROOT/'a-operations40.json')['final_binary_sha256']
 rows=d['navigation_revision_trace'];world=max({r['world'] for r in rows},key=lambda w:sum(r['world']==w for r in rows))
 traces.append(dict(run=name,hash=d['final_binary_sha256'],real_world=world,executing_tick1190=[r for r in rows if r['world']==world and r['tick']==1190],all_rows=rows))
dump('navigation-owner-trace.json',dict(traces=traces,caution='Trace is diagnostic only. Executing1190 corresponds to completed output1191. Initial trace lacks explicit occupancy invalidation calls; v2 adds that probe.'))
batches=[]
for line in (ROOT/'batches.txt').read_text().splitlines():
 if not line.strip(): continue
 directory=REPO/'.cache/acceptance'/line.strip();d=read(directory/'acceptance-results.json')
 batches.append(dict(batch=line.strip(),cases=d['requested_cases'],checks=d['checks'],failed=d['failed'],completed=d['completed'],timing=read(directory/'timing-summary.json')))
assert batches[0]['failed']==2
assert all(b['failed']==0 and b['completed'] for b in batches[1:])
dump('functional-summary.json',dict(batches=batches,initial_failures=['OPS-13: ledger refund independently touches geometry','SPACE-51: new shortcut changed walking_distance float to int'],formal_pass=False))
before=read(ROOT/'before-project/source-identity.json');after=read(ROOT/'final-project/source-identity.json')
rows=[r for r in before['source'] if r['path'].startswith(('game/','content/','tools/performance/'))]
raw=subprocess.run(['git','cat-file','--batch'],input=''.join(BASE+':'+r['path']+'\n' for r in rows).encode(),cwd=REPO,check=True,stdout=subprocess.PIPE).stdout
cursor=0;baseline=[]
for r in rows:
 end=raw.index(b'\n',cursor);size=int(raw[cursor:end].split()[-1]);cursor=end+1;blob=raw[cursor:cursor+size];cursor+=size+1
 assert hashlib.sha256(blob).hexdigest()==r['sha256'],r['path']
 baseline.append(r)
current=[dict(**r,match=sha(REPO/r['path'])==r['sha256']) for r in after['source'] if r['path'].startswith(('game/','content/','tools/performance/'))]
assert all(r['match'] for r in current)
binary={k:before[k]==after[k] for k in ['engine_sha256','native_sha256','gmp_sha256','mpfr_sha256','runtime_sha256']};assert all(binary.values())
transforms=[]
for side in ['before','final']:
 directory=ROOT/(side+'-all-project');identity=read(directory/'all-instance-profile-identity.json');plain=ROOT/(side+'-project')
 for r in identity['files']:
  assert sha(plain/r['path'])==r['original_sha256']
  assert sha(directory/'.cache/tail-profile-originals'/r['path'])==r['original_sha256']
 transforms.append(dict(side=side,files=identity['transformed_file_count'],methods=identity['actual_method_count'],all_originals_match=True))
trace_checks=[]
for side in ['before','final']:
 directory=ROOT/(side+'-trace-project');identity=read(directory/'revision-trace-identity.json')
 for r in identity['patches']:
  generated=(directory/r['path']).read_bytes();assert hashlib.sha256(generated).hexdigest()==r['generated_sha256']
  original=generated.decode('utf8')
  for old,new in reversed(r.get('replacements',[(r.get('old'),r.get('new'))])):
   assert original.count(new)==1;original=original.replace(new,old)
  assert hashlib.sha256(original.encode()).hexdigest()==r['original_sha256']
  assert sha(ROOT/(side+'-project')/r['path'])==r['original_sha256']
 trace_checks.append(dict(side=side,patches=len(identity['patches']),inverse_matches_plain=True))
test_identity=read(REPO/'.cache/acceptance'/batches[-1]['batch']/'source-identity.json')
test_rows=[r for r in test_identity['source'] if r['path'].startswith('tests/acceptance/')]
assert test_rows and all(sha(REPO/r['path'])==r['sha256'] for r in test_rows)
dump('source-check.json',dict(baseline=BASE,baseline_files=baseline,final_files=current,binary_equal=binary,transform_originals=transforms,trace_inverse=trace_checks,final_test_files=test_rows))
files=[]
files.append(ROOT/'ledger-owner-audit.md')
for path in ROOT.iterdir():
 if path.is_file() and path.suffix in ['.json','.bin','.ndjson','.log','.py','.ps1','.txt']: files.append(path)
 if path.is_dir() and path.name.endswith('.sources'): files.extend(p for p in path.rglob('*') if p.is_file())
for side in ['before','after','final']:
 directory=ROOT/(side+'-project')
 for name in ['source-identity.json','import.log']:
  if (directory/name).exists(): files.append(directory/name)
for side in ['before','final']:
 directory=ROOT/(side+'-all-project');files.append(directory/'all-instance-profile-identity.json')
 for r in read(directory/'all-instance-profile-identity.json')['files']:
  files.extend([directory/r['path'],directory/'.cache/tail-profile-originals'/r['path']])
for side in ['before','final']:
 directory=ROOT/(side+'-trace-project');identity=read(directory/'revision-trace-identity.json');files.append(directory/'revision-trace-identity.json')
 for r in identity['patches']: files.append(directory/r['path'])
archive=OUT/'raw-evidence.zip';manifest=[]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for path in sorted(set(files)):
  name=path.relative_to(ROOT).as_posix();z.write(path,'runs/'+name);manifest.append(dict(path='runs/'+name,sha256=sha(path),bytes=path.stat().st_size))
 for name in ['public-v6.input.bin','gp.input.bin','op.input.bin']:
  path=REPO/'.cache/task-navigation-20261019'/name;name='inputs/'+name
  z.write(path,name);manifest.append(dict(path=name,sha256=sha(path),bytes=path.stat().st_size))
 for batch in batches:
  directory=REPO/'.cache/acceptance'/batch['batch']
  for name in ['acceptance-results.json','execution.log','source-identity.json','timing-summary.json','import.log']:
   path=directory/name
   if not path.exists(): continue
   name='acceptance/'+batch['batch']+'/'+name;z.write(path,name);manifest.append(dict(path=name,sha256=sha(path),bytes=path.stat().st_size))
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(manifest)
 for row in manifest: assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256']
dump('raw-manifest.json',dict(archive='raw-evidence.zip',sha256=sha(archive),bytes=archive.stat().st_size,entries=manifest))
print(json.dumps(dict(archive_entries=len(manifest),archive_bytes=archive.stat().st_size,baseline_files=len(baseline),final_files=len(current),test_files=len(test_rows))))
