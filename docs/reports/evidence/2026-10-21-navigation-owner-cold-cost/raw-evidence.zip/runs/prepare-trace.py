import hashlib,json,pathlib,shutil,sys
root=pathlib.Path(__file__).resolve().parent
side=sys.argv[1]
source=root/(side+'-project');target=root/(side+'-trace-project')
assert not target.exists()
shutil.copytree(source,target)
key='oddly_navigation_revision_trace_20261021'
edits={
 'game/building/navigation_cache.gd':('func invalidate(world: WorldState, floor_id: int) -> void:\n',f'''func invalidate(world: WorldState, floor_id: int) -> void:
\tif Engine.has_meta("{key}"):
\t\tEngine.get_meta("{key}").append({{"kind":"explicit_invalidate","world":world.get_instance_id(),"tick":world.sim_tick,"revision":world.geometry_revision,"floor":floor_id,"stack":get_stack()}})
'''),
 'game/sim/world_state.gd':('func invalidate_geometry() -> void:\n',f'''func invalidate_geometry() -> void:
\tif Engine.has_meta("{key}"):
\t\tEngine.get_meta("{key}").append({{"kind":"invalidate","world":get_instance_id(),"tick":sim_tick,"revision":geometry_revision,"stack":get_stack()}})
'''),
 'game/building/route_clearance.gd':('static func capture_source(space: HospitalSpace, world: WorldState, floor_id: int) -> Dictionary:\n',f'''static func capture_source(space: HospitalSpace, world: WorldState, floor_id: int) -> Dictionary:
\tif Engine.has_meta("{key}"):
\t\tEngine.get_meta("{key}").append({{"kind":"capture","world":world.get_instance_id(),"tick":world.sim_tick,"revision":world.geometry_revision,"floor":floor_id,"stack":get_stack()}})
'''),
}
manifest=[]
for relative,(old,new) in edits.items():
 path=target/relative;original=path.read_bytes();text=original.decode('utf8');assert text.count(old)==1
 transformed=text.replace(old,new)
 assert transformed.replace(new,old).encode()==original
 backup=target/'.cache/revision-originals'/relative;backup.parent.mkdir(parents=True,exist_ok=True);backup.write_bytes(original)
 path.write_text(transformed,encoding='utf8',newline='\n')
 manifest.append(dict(path=relative,original_sha256=hashlib.sha256(original).hexdigest(),generated_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),old=old,new=new))
path=target/'tools/performance/representative.gd';original=path.read_bytes();text=original.decode('utf8')
replacements=[('\tfor index: int in int(options.steps):',f'\tEngine.set_meta("{key}",[])\n\tfor index: int in int(options.steps):'),
 ('\t_write(str(options.output),report)',f'\treport.navigation_revision_trace = Engine.get_meta("{key}")\n\tEngine.remove_meta("{key}")\n\t_write(str(options.output),report)')]
for old,new in replacements: assert text.count(old)==1;text=text.replace(old,new)
inverse=text
for old,new in reversed(replacements): inverse=inverse.replace(new,old)
assert inverse.encode()==original
path.write_text(text,encoding='utf8',newline='\n')
manifest.append(dict(path='tools/performance/representative.gd',original_sha256=hashlib.sha256(original).hexdigest(),generated_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),replacements=replacements))
(target/'revision-trace-identity.json').write_text(json.dumps(dict(diagnostic_only=True,patches=manifest),indent=2)+'\n',encoding='utf8')
print(target)
