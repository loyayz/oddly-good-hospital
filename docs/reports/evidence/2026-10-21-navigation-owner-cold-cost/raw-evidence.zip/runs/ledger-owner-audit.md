# 记账与硬几何失效归属核对

核对日期：2026-10-21。源码基线为 `dev d8cb36d`，包含当前工作区将已结算记账通知改为 `touch(false)` 的调整。行号对应本文件生成时的工作区。

## 结论与口径

`game/**/*.gd` 共33处 `HospitalLedger.post` 生产调用点，分布在15个文件。其中6处临床收入原本使用 `settled=false`，本次不改变该分支。其余27处使用默认即时结算。

没有发现运行中的硬几何所有者仅依赖记账的 `world.touch()` 使导航失效。四个布局事务提交入口通过自己的 `world.facts` 替换提交几何；真实楼板完工另有明确的 `invalidate_geometry()`。初始化直接写入房间和设施属于尚未建立空间缓存的新世界构造，不依赖账目通知。

`HospitalLedger.post` 的职责是唯一凭据、金额冲突与资金核验、账目写入和账目派生索引更新。已结算分支的 `world.touch(false)` 仍增加 `facts.world_revision`，不改变金额、结算时机、零金额凭据、失败原子性或重复提交语义。源码依据：`game/economy/ledger.gd:7–21`；账目索引仅维护账目引用及金额，见 `game/sim/world_state.gd:88–100`。

本文件是源码归属核对，不记录用例通过或性能达标。功能回归与固定160人性能对照由各自原始执行证据提供。

## 全部调用点

“硬几何”指实际房间、墙门、设施主体占地、连接声明、土地或已完工楼板；金额、材料表现、等级、设备状态、科室专注、库存数量和普通人物位置不冒充硬几何。

| 序号 | 调用位置 | 记账内容 | 同次业务变化及失效归属 |
|---|---|---|---|
| 1 | `game/building/build_service.gd:60` | construction / construction_refund | 房间、设施、墙门、土地、移除或撤销；自己的 `candidate.touch():70` 及 `world.facts` 提交`:71` 保留硬几何通知。 |
| 2 | `game/building/connector_service.gd:118` | construction | 连接建造、扩站或拆除；自己的 `world.facts` 提交`:120` 保留硬几何通知。 |
| 3 | `game/building/blueprint_service.gd:251` | construction | 蓝图房间及设施放置；自己的 `world.facts` 提交`:253` 保留硬几何通知。 |
| 4 | `game/building/remodel_service.gd:92` | remodel | 既有房间及设施的搬移、旋转、重建和材料随迁；自己的 `world.facts` 提交`:97` 保留硬几何通知。 |
| 5 | `game/building/floor_service.gd:67` | floor_refund | 取消已付工单及退还未完成部分，不撤掉已完工楼板；不产生硬几何变化。 |
| 6 | `game/building/floor_service.gd:81` | floor_purchase | 普通模式只创建待工作单；创作模式调用同一真实 `_complete`。真实楼板几何由`:184–185`提交。 |
| 7 | `game/clinic/clinical_runtime.gd:1627` | consultation | 诊费收入，原本为 `settled=false`；不改布局。 |
| 8 | `game/clinic/clinical_runtime.gd:1628` | 当前 session.kind 对应设施费 | 诊疗设施收入，原本为 `settled=false`；不改布局。 |
| 9 | `game/clinic/clinical_runtime.gd:1669` | outpatient | 门诊收入，原本为 `settled=false`；不改布局。 |
| 10 | `game/clinic/clinical_runtime.gd:1683` | surgery | 手术设施收入，原本为 `settled=false`；不改布局。 |
| 11 | `game/clinic/clinical_runtime.gd:1700` | ward | 病床费用，原本为 `settled=false`；实际床位和展开预约继续由原临床／空间所有者提交。 |
| 12 | `game/clinic/clinical_runtime.gd:1878` | cure | 治愈收入，原本为 `settled=false`；不改布局。 |
| 13 | `game/community/research_service.gd:107` | research_refund | 研究任务取消及退款；不建造或改变研究桌。 |
| 14 | `game/community/research_service.gd:165` | research | 创建已付研究任务及排队请求；不改房间或桌体。 |
| 15 | `game/economy/finance_service.gd:127` | pay_necessary 的原 component | 必要工资、运营、离职工资及维护支付；只更新账目与支付来源。 |
| 16 | `game/economy/finance_service.gd:158` | subsidy_* | 定期补助及其周期凭据；不改土地或楼板。 |
| 17 | `game/operations/department_service.gd:600` | focus:* | 科室配置、房间归属及专业过渡；不改真实 Room 几何。原结果入口`:924–928`提交 `department_changed`。 |
| 18 | `game/operations/department_service.gd:616` | focus:* | 专业切换及过渡记录；不改真实 Room 几何。原结果入口仍通知科室派生记录。 |
| 19 | `game/operations/environment_service.gd:287` | renovation_material | 创建已付装修单元；当前表面和硬几何均未改变。命令 owner 另有原事实通知。 |
| 20 | `game/operations/environment_service.gd:317` | renovation_cancel_refund | 取消未开工单元并退款；已开工部分仍在主动恢复后真实收尾，不改墙边或楼板。 |
| 21 | `game/operations/environment_service.gd:493` | surface_replacement_refund | 真正表面完工时退还旧材款；安装的是 `environment.surfaces` 材料，不是导航墙门。环境 owner 在材料和单元状态提交后调用 `public_areas.changed(world)`。 |
| 22 | `game/operations/maintenance_service.gd:269` | upgrade_material | 已付升级工单及设备停诊状态；不改变设备主体尺寸。owner 在`:285`另有原事实通知。 |
| 23 | `game/operations/maintenance_service.gd:305` | upgrade_cancel_refund | 未开始阶段退款、任务释放及升级阻止状态；不改变设备布局。owner 在`:316`另有原事实通知。 |
| 24 | `game/operations/maintenance_service.gd:602` | _pay 的维护／维修原 component | 材料或维修差额及原支付分项；实际设备条件、故障状态、进度和外部人员由维护服务提交，不改设施主体占地。 |
| 25 | `game/operations/supply_service.gd:134` | supply_purchase | 耗材数量、采购单、直接资助次数；不改医院布局，owner 在`:149`另有原事实通知。 |
| 26 | `game/sim/hospital_factory.gd:27` | starter_supplies | 新世界的初始耗材及初始采购账目；首次向外返回前构造，无现有空间缓存。 |
| 27 | `game/sim/hospital_factory.gd:41` | starter_build_* | 预设医院初始房间及设施对应的采购凭据；直接布局写入发生于首次返回之前，见初始化边界。 |
| 28 | `game/sim/hospital_factory.gd:55` | hire | 预设医生初始化及聘用费用；没有既有空间缓存，不改变已经运行医院的硬几何。 |
| 29 | `game/sim/hospital_factory.gd:62` | hire | 预设其他员工初始化及聘用费用；同上。 |
| 30 | `game/staff/clinical_development.gd:65` | training | 创建已付培养任务及原员工培养引用；不创建／改变桌体或房间。 |
| 31 | `game/staff/clinical_development.gd:763` | training_refund | 培养取消或已实操掌握后的剩余课程退款及任务释放；不改硬几何。 |
| 32 | `game/staff/recruitment_service.gd:335` | search | 搜索付款、候选生成及原随机流提交；不改布局。 |
| 33 | `game/staff/recruitment_service.gd:387` | recruitment | 实际录用及新增人物；不是静态几何。`:411`同步真实人物索引，`:412`保留 owner 原事实通知。 |

## 四个运行中布局事务的提交证明

`WorldState.facts` setter 位于 `game/sim/world_state.gd:8–29`。它清除相关派生索引，并在`:29`无条件调用 `invalidate_geometry()`；`invalidate_geometry()`在`:220–222`增加 `geometry_revision`。因此事务最后替换事实后，原运行世界必然观察到新的硬几何，与账目是否增加该修订无关。

1. **BuildService**：`:47–54`取得完整候选，`:60`记账；`:70`调用候选自身的 `touch()`，`:71`替换运行世界事实。复合布局调用的 `_plan(..., owns_world=true)`另在`:126`使候选几何失效。金额为0、不调用 ledger 的正常建造也走相同提交，所以该路径本来就不能依赖记账通知。
2. **HospitalConnectors**：候选在`:16`从当前事实构造；建造`:38`、扩站`:52`、拆除`:61`改变候选连接事实。`:118`付款后，`:120`替换原运行世界事实。原世界的 facts setter 是真实提交边界。
3. **HospitalBlueprints**：`:170`创建独立候选，`:186`及`:205`通过原建造 owner 写入房间与设施；`:251`付款后，`:253`替换原运行世界事实。材料工单不提前代替真实表面完工。
4. **HospitalRemodel**：`:105`创建独立候选，`:120–132`经原建造／变换逻辑构造真实布局，`:139`检查最终几何；`:92`在应用阶段付款，`:97`替换原运行世界事实。候选状态和资金核验失败仍不提交原医院。

## 楼板及初始化特殊边界

**楼板**：`game/building/floor_service.gd:81–85`的购买先创建冻结成本与工作余量的订单。真实工作在`:171–181`验证当班、工具、原点和实际到场后推进。完工调用 `_complete`，`:184`写入本 plot 的 `completed_top_floor`，`:185`显式调用 `world.invalidate_geometry()`，`:190`才发布环境类完成凭据。创作模式的即时交付在`:86–87`复用同一个 `_complete`，所以同样保留硬几何通知。取消`:65–71`不撤回已经存在的楼板。

**初始化**：`game/sim/hospital_factory.gd:create`从`:4`开始，`:15`构造全新 `WorldState`；初始耗材在`:27`记账，空地模式在`:30`首次返回。预设模式在`:31–35`直接构造初始房间和设施，helper 分别位于`:72`和`:99`，随后登记初始采购和员工，最终在`:63`首次返回。整个构造入口没有创建 `HospitalSpace`、查询导航或向其他运行对象发布中间世界。初始几何因此由首次观察冷建；不能把“初始化 helper 没有逐项 touch”误判为运行中缓存依赖 ledger。

## OPS-13 原失败与修复边界

首次铺材的旧 `paid_cost` 默认为0，`surface_replacement_refund`金额为0，但仍需保留唯一原账目。旧 `HospitalLedger.post`对即时结算无条件调用 `touch()`，使 OPS-13 的完成边界从 geometry100变为101；材料完工并没有改变导航 source。旧 source 对象被保留不等于没有重采集：`NavigationCache.floor_source`可能先完整采集、判定内容相等，再返回旧对象。

将 ledger 改为 `touch(false)`消除的是这个账目 owner 错误提交的几何变化，不能采用以下替代：省略零金额凭据、把退款改为延迟结算、回减几何修订，或由装修服务复制账目内部逻辑。首次失败证据继续保留。

## 仍未由本修复实现的契约

`docs/design/04-technical.md:396、422–424`的局部导航／占用修订及真实软绕行范围、边权更新是完整目标契约。阶段规格 `docs/specs/26-10/2026-10-14-stage02-stage03-simulation-kernel.md:69、87`明确当前单位层内成本和缺少软代价生产者；实际 `FloorNavigation`、`RouteClearance`及数据也没有清扫正权重或范围。记账增加全局几何修订从来不能代替该机制，本次不新增半径或权重，也不宣称软代价玩法完成。

原 plain tick1191 的7次 source 采集中，最早1次由实际预约释放经 `release_adaptations → NavigationCache.invalidate`触发，属于必须保留的 occupancy 更新。之后3次 `environment._arrive`及3次 `waiting_life`设施报价中的无 source 变化重采集，才是清扫完成凭据伪几何通知导致的重复。全实例探针中最后3次表现为 department.sample，不能替代原 plain 的真实调用阶段。修复后的采集次数和整步收益以同一合法160人对照为准。

相关核验入口为 CORE-13、CORE-45（记账与结算契约）、CORE-02（预设世界初始化）、OPS-13（原失败边界）和 SPACE-16（真实楼板 owner）；本文件不预填执行结果。
