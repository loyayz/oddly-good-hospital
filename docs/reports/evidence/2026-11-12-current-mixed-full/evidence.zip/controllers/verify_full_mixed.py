from pathlib import Path
import sys,json,math
repo=Path(r'C:\Users\cong\dot-work\oddly-good-hospital-handoff-20261112'); root=Path(r'C:\Users\cong\dot-work\ogh-full-mixed-20261112'); project=root/'project'
sys.path.insert(0,str(repo/'tools/performance/current'))
from prepare_builtin_script_profile import digest,write,read,native_identity,engine_identity
from campaign160 import target_checks
identity=read(root/'identity-before.json'); result=root/'plain-r1/result.json'; data=read(result); c=data['sample_business']['comprehensive']
checks={}
checks['source_unchanged']={p:digest(project/p) for p in identity['source']}==identity['source']
checks['native_unchanged']=native_identity(project)==identity['native']
checks['engines_unchanged']=engine_identity(Path(next(iter(identity['engine']))))==identity['engine']
checks['input_unchanged']=digest(root/'mixed160.input.bin')==identity['input_sha256']==data['source_input_sha256']
checks['final_binary']=digest(Path(str(result)+'.final.bin'))==data['final_sha256']
rows=[json.loads(line) for line in Path(str(result)+'.steps.ndjson').read_text().splitlines()]
a=[r['sample'] for r in rows if r['kind']=='complete']; b=[r for r in rows if r['kind']=='enter']
checks['complete_records']=len(a)==len(b)==data['all_completed_steps']==7000 and [r['index'] for r in a]==[r['index'] for r in b]==list(range(7000))
checks['ticks']=[r['tick'] for r in a]==list(range(634,7634)) and [r['tick'] for r in b]==list(range(633,7633))
ordered=sorted(r['elapsed_us'] for r in a[1000:])
checks['percentiles']=data['metrics']['p95_us']==ordered[5699] and data['metrics']['p99_us']==ordered[5939] and data['metrics']['max_us']==max(ordered)
checks['density']=all(r['present']>=144 for r in a[1000:])
execution=read(Path(str(result)+'.execution.json'))
checks['execution_policy']=execution['main_thread_policy']['applied'] and execution['worker_tasks']==4 and not execution['profile_stages'] and not execution['worker_samples']['diagnostics_enabled']
checks['coverage_rows']=all(v['covered']==(v['actual']>=v['lower_bound']) for v in c['coverage'].values()) and set(c['uncovered'])=={k for k,v in c['coverage'].items() if not v['covered']}
assert all(checks.values()),checks
summary={'checks':checks,'execution_complete':True,'acceptance_pass':False,'coverage_pass':c['coverage_pass'],'invariant_failure_counts':c['invariant_failure_counts'],'observer_errors':c['errors'],'uncovered':c['uncovered'],'metrics':data['metrics'],'prefix_wall_us':data['prefix_wall_us'],'all_wall_us':data['all_wall_us'],'process':read(root/'plain-r1/process.json'),'cpu_checks':target_checks(data['metrics'],read(project/'docs/data/balance.json')['performance_targets']['metrics']),'sample_work':c['sample']['work'],'sample_events':c['sample']['events'],'coverage':c['coverage'],'final_sha256':data['final_sha256'],'source_identity_sha256':digest(root/'identity-before.json'),'strict_old_diagnostic_validator':'REJECTED as designed: business invariant failure is not coverage insufficiency; this report preserves the invariant failure and does not qualify acceptance.'}
write(root/'plain-r1-summary.json',summary)
print(json.dumps({k:summary[k] for k in ['checks','invariant_failure_counts','observer_errors','prefix_wall_us','all_wall_us']},ensure_ascii=False,indent=2))
# Only isolated diagnostic expected-witness constants are rebound. Shared tools untouched.
old='0daf82b82da618af8818aed962d5ef2bf9bad1b00be01c4f5a7ce71efb52662e'; new=data['final_sha256']; patches={}
for name in ['business_fact_probe.gd','business_fact_contract.py']:
    p=project/'tools/performance/current'/name; before=p.read_bytes(); assert before.count(old.encode())==1
    after=before.replace(old.encode(),new.encode()); p.write_bytes(after)
    assert after.replace(new.encode(),old.encode())==before
    patches[name]={'before_sha256':__import__('hashlib').sha256(before).hexdigest(),'after_sha256':digest(p),'exact_single_expected_witness_constant_replacement':True}
write(root/'diagnostic-binding.json',{'plain_result':str(result),'plain_result_sha256':digest(result),'expected_complete_world_rng_ordered_events':new,'patches':patches,'scope':'Expected witness binding only. No production, plain driver, load, observations or threshold changes. Plain invariant failures remain failures.'})
