from pathlib import Path
import os,sys
root=Path(r'C:\Users\cong\dot-work\ogh-full-mixed-20261112');project=root/'project';sys.path.insert(0,str(project/'tools/performance/current'))
from prepare_builtin_script_profile import run_process
kind=sys.argv[1];os.environ['OGH_DUMP_SOURCE']=str(root/(kind+'-bins'));os.environ['OGH_DUMP_OUTPUT']=str(root/(kind+'-dump.json'))
run_process([r'C:\programs\Godot\Godot_v4.7.2-stable_win64_console.exe','--headless','--path',str(project),'--script','res://tools/performance/current/capture_dump.gd'],project,root/(kind+'-dump-process'),120)
print('DUMP READ-ONLY OK')
