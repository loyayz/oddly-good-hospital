from pathlib import Path
import sys,json
root=Path(r'C:\Users\cong\dot-work\ogh-full-mixed-20261112'); project=root/'project'
sys.path.insert(0,str(project/'tools/performance/current'))
from prepare_builtin_script_profile import run_process,read,write,digest,native_identity,engine_identity
from business_fact_contract import validate_rows
plain=read(root/'plain-r1/result.json'); identity=read(root/'identity-before.json'); binding=read(root/'diagnostic-binding.json')
source={p:digest(project/p) for p in identity['source']}; write(root/'diagnostic-source-identity.json',source)
for p,sha in identity['source'].items():
    assert source[p]==sha or p in ['tools/performance/current/business_fact_probe.gd','tools/performance/current/business_fact_contract.py'],p
engine=Path(next(iter(identity['engine']))); out=root/'history-r1'; result=out/'result.json'
print('START FULL OWNER HISTORY',flush=True)
record=run_process([str(engine),'--headless','--path',str(project),'--script','res://tools/performance/current/business_fact_probe.gd','--',f'--input={root / "mixed160.input.bin"}',f'--output={result}'],project,out,2400,(0,1))
print('END FULL OWNER HISTORY',flush=True)
d=read(result); checks={}
checks['complete_world_rng_ordered_events']=d['final_sha256']==plain['final_sha256']==digest(Path(str(result)+'.final.bin'))
checks['exact_original_window']=d['requested_prefix_steps']==1000 and d['requested_sample_steps']==6000 and d['all_completed_steps']==7000 and d['metrics']['count']==6000
checks['world_valid']=d['world_validation']==''
checks['identical_observer_report']=d['sample_business']['comprehensive']==plain['sample_business']['comprehensive']
checks['same_explicit_failure']=d['errors']==plain['errors'] and d['complete']==plain['complete']==False
checks['input_unchanged']=digest(root/'mixed160.input.bin')==identity['input_sha256']==d['source_input_sha256']
checks['source_unchanged']={p:digest(project/p) for p in source}==source
checks['runtime_unchanged']=native_identity(project)==identity['native'] and engine_identity(engine)==identity['engine']
with Path(str(result)+'.business.ndjson').open(encoding='utf-8') as stream: contract=validate_rows(json.loads(line) for line in stream)
checks['owner_field_chain']=contract['ok'] and contract['prefix_steps']==1000 and contract['sample_steps']==6000
assert all(checks.values()),checks
write(root/'history-r1-summary.json',{'checks':checks,'contract':contract,'process':record,'coverage_pass':False,'invariant_failure_counts':d['sample_business']['comprehensive']['invariant_failure_counts'],'final_sha256':d['final_sha256'],'acceptance_pass':False,'scope':'Diagnostic equality against complete failing plain execution, NOT a coverage-qualified or invariant-passing witness. Original acceptance failure preserved exactly.'})
print(json.dumps({'checks':checks,'contract':contract,'process_wall_seconds':record['process_wall_seconds']},ensure_ascii=False),flush=True)
