extends SceneTree
func _initialize() -> void:
	var source: String = OS.get_environment("OGH_DUMP_SOURCE")
	var output: String = OS.get_environment("OGH_DUMP_OUTPUT")
	var rows: Dictionary = {}
	for name: String in DirAccess.get_files_at(source):
		if not name.ends_with(".bin"): continue
		var f: FileAccess = FileAccess.open(source+"/"+name,FileAccess.READ)
		var d: Dictionary = f.get_var(false)
		f.close()
		if d.has("before"):
			d["complete_facts_rng_unchanged"] = d.before==d.after
			if not d.complete_facts_rng_unchanged: quit(1);return
			d.erase("after")
		rows[name] = d
	var file: FileAccess = FileAccess.open(output,FileAccess.WRITE)
	file.store_string(JSON.stringify(rows,"\t"));file.close()
	quit(0)
