from pathlib import Path
import json,collections
r=Path(r'C:\Users\cong\dot-work\ogh-full-mixed-20261112'); changes=[]; states={}; special=[]; worker=[]; wards=[]; visitors=[]; exams=[]; target='maintenance_contractor_00000226'
with (r/'history-r2/result.json.business.ndjson').open(encoding='utf-8') as f:
 for line in f:
  d=json.loads(line)
  if d['kind']!='change': continue
  key=d['key']; old=states.get(key,{}).copy(); state=old.copy()
  for k,v in d['fields'].items():
   if v['after_present']: state[k]=v['after']
   else: state.pop(k,None)
  if d['operation']=='remove': states.pop(key,None)
  else: states[key]=state
  base={'tick':d['tick'],'index':d['index'],'key':key,'operation':d['operation'],'fields':d['fields']}
  if d['collection'].startswith('maintenance.'):
   special.append(base)
  if d['collection']=='ward_stays':
   selected={k:v for k,v in d['fields'].items() if k in ['phase','visit_id','visitor_intent','visitor_day','companion_intent','bed_id'] or 'visit' in k or 'companion' in k}
   if selected or d['operation']!='update': wards.append({**base,'fields':selected})
  if d['collection'].startswith('visitors.'): visitors.append(base)
  if d['collection']=='visits':
   selected={k:v for k,v in d['fields'].items() if k in ['phase','final_result','diagnosis','visitor_consent']}
   if selected: exams.append({**base,'fields':selected})
  if key=='moves/'+target or key=='actors/'+target:
   worker.append({'tick':d['tick'],'key':key,'state':state.copy(),'context':d.get('context',{}),'fields':d['fields']})
summary={'maintenance_changes':special,'ward_lifecycle':wards,'visitor_lifecycle':visitors,'visit_transitions':exams,'worker_changes':worker}
(r/'history-lifecycle.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
print('counts', {k:len(v) for k,v in summary.items()})
for d in special: print('MAINT',d['tick'],d['key'],{k:v['after'] for k,v in d['fields'].items() if k in ['phase','worker_id','completed_milli','remaining_milli','reason','work_cell']})
for d in wards: print('WARD',d['tick'],d['key'],d['operation'],{k:v['after'] for k,v in d['fields'].items()})
for d in visitors:
 if d['operation']!='update' or any(k in d['fields'] for k in ['phase','purpose','remaining_ticks']): print('VISITOR',d['tick'],d['key'],d['operation'],{k:v['after'] for k,v in d['fields'].items() if k in ['phase','purpose','remaining_ticks','visit_id','window']})
print('WORKER',len(worker),'first',worker[0] if worker else None,'last',worker[-1] if worker else None)
