from pathlib import Path
import sys,json
root=Path(r'C:\Users\cong\dot-work\ogh-full-mixed-20261112'); project=root/'project'
sys.path.insert(0,str(project/'tools/performance/current'))
from prepare_builtin_script_profile import run_process,read,write

engine=r'C:\programs\Godot\Godot_v4.7.2-stable_win64_console.exe'
out=root/'inspect-new-final'; result=out/'result.json'
record=run_process([engine,'--headless','--path',str(project),'--script','res://tools/performance/current/business_fact_probe.gd','--','--inspect',f'--input={root / "plain-r1/result.json.final.bin"}',f'--output={result}'],project,out,120)
d=read(result); assert d['complete'] and d['complete_facts_and_rng_unchanged'] and d['world_validation']==''; print('INSPECT COMPLETE',flush=True)
