from pathlib import Path
import sys,json,math
repo=Path(r'C:\Users\cong\dot-work\oddly-good-hospital-handoff-20261112')
root=Path(r'C:\Users\cong\dot-work\ogh-full-mixed-20261112')
project=root/'project'
sys.path.insert(0,str(repo/'tools/performance/current'))
from prepare_builtin_script_profile import digest,write,read,run_process,validate_diagnostic_witness,native_identity,engine_identity
from campaign160 import target_checks
identity=read(root/'identity-before.json')
engine=Path(next(iter(identity['engine'])))
assert {p:digest(project/p) for p in identity['source']}==identity['source']
assert native_identity(project)==identity['native']
assert engine_identity(engine)==identity['engine']
out=root/'plain-r1'
result=out/'result.json'
cmd=[str(engine),'--headless','--path',str(project),'--script','res://tools/performance/current/plain_v4.gd','--',f'--input={root / "mixed160.input.bin"}',f'--output={result}','--prefix-steps=1000','--steps=6000','--observed-floor=1','--main-thread-policy=app','--worker-tasks=4','--expected-scenario=mixed160-clinical-ops-v1','--require-coverage']
print('START FULL PLAIN WINDOW',flush=True)
record=run_process(cmd,project,out,2400,(0,1))
print('END FULL PLAIN WINDOW',flush=True)
data=read(result)
verification=validate_diagnostic_witness(result,identity['input_sha256'])
assert {p:digest(project/p) for p in identity['source']}==identity['source']
assert native_identity(project)==identity['native'] and engine_identity(engine)==identity['engine']
assert digest(root/'mixed160.input.bin')==identity['input_sha256']
rows=[json.loads(line) for line in Path(str(result)+'.steps.ndjson').read_text().splitlines()]
completed=[r['sample'] for r in rows if r['kind']=='complete']
entered=[r for r in rows if r['kind']=='enter']
assert len(completed)==len(entered)==7000
assert [r['index'] for r in entered]==list(range(7000))
assert [r['index'] for r in completed]==list(range(7000))
measured=completed[1000:];ordered=sorted(r['elapsed_us'] for r in measured)
for pct,key in [(0.95,'p95_us'),(0.99,'p99_us')]: assert data['metrics'][key]==ordered[math.ceil(6000*pct)-1]
assert data['metrics']['max_us']==max(ordered)
execution=read(Path(str(result)+'.execution.json'))
assert execution['main_thread_policy']['applied'] and execution['worker_tasks']==4 and not execution['profile_stages']
targets=read(project/'docs/data/balance.json')['performance_targets']['metrics']
summary={'validation':verification,'source_identity_unchanged':True,'runtime_unchanged':True,'full_step_records_verified':True,'percentiles_recomputed':True,'process':record,'metrics':data['metrics'],'cpu_checks':target_checks(data['metrics'],targets),'business':data['sample_business'],'final':data['final'],'final_sha256':data['final_sha256'],'execution':execution}
write(root/'plain-r1-summary.json',summary)
print(json.dumps(summary,ensure_ascii=False),flush=True)
