from pathlib import Path
import json,hashlib
r=Path(r'C:\Users\cong\dot-work\ogh-full-mixed-20261112');p=r/'project'; patches=json.loads((r/'upgrade-capture-patches.json').read_text()); restored={}
for rel,d in patches.items():
 f=p/rel;a=f.read_bytes();assert hashlib.sha256(a).hexdigest()==d['after_sha256']
 for c in reversed(d['changes']): a=a.replace(c['after'].encode(),c['before'].encode())
 assert hashlib.sha256(a).hexdigest()==d['before_sha256'];f.write_bytes(a);restored[rel]=hashlib.sha256(a).hexdigest()
# Restore expected-witness binding too; isolated traces remain in archived source diffs.
b=json.loads((r/'diagnostic-binding.json').read_text()); new=b['expected_complete_world_rng_ordered_events'].encode();old=b'0daf82b82da618af8818aed962d5ef2bf9bad1b00be01c4f5a7ce71efb52662e'
for name,v in b['patches'].items():
 f=p/'tools/performance/current'/name;a=f.read_bytes();assert hashlib.sha256(a).hexdigest()==v['after_sha256'];a=a.replace(new,old);assert hashlib.sha256(a).hexdigest()==v['before_sha256'];f.write_bytes(a);restored[name]=v['before_sha256']
identity=json.loads((r/'identity-before.json').read_text());assert all(hashlib.sha256((p/x).read_bytes()).hexdigest()==h for x,h in identity['source'].items())
(r/'restoration.json').write_text(json.dumps({'all_2403_original_tracked_sources_restored':True,'restored':restored,'no_shared_production_or_tool_edits':True},indent=2),encoding='utf-8')
print('RESTORED all original tracked source bytes')
