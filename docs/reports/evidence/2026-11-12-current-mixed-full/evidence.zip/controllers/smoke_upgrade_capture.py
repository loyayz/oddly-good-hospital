from pathlib import Path
import sys,json,os
root=Path(r'C:\Users\cong\dot-work\ogh-full-mixed-20261112');project=root/'project';sys.path.insert(0,str(project/'tools/performance/current'))
from prepare_builtin_script_profile import run_process,read,write,digest
from business_fact_contract import validate_result
out=root/'capture-smoke'; capture=root/'capture-smoke-bins';capture.mkdir(exist_ok=False);os.environ['OGH_UPGRADE_CAPTURE']=str(capture)
result=out/'result.json'
r=run_process([r'C:\programs\Godot\Godot_v4.7.2-stable_win64_console.exe','--headless','--path',str(project),'--script','res://tools/performance/current/business_fact_probe.gd','--','--smoke',f'--input={root / "mixed160.input.bin"}',f'--output={result}'],project,out,120,(0,1))
d=read(result); print(json.dumps({'complete':d['complete'],'errors':d['errors'],'final_sha256':d['final_sha256'],'captures':[p.name for p in capture.glob('*.bin')]},ensure_ascii=False))
if d['complete']: write(root/'capture-smoke-contract.json',validate_result(result))
