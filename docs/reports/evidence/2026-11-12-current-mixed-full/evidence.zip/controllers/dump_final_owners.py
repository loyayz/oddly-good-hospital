from pathlib import Path
import sys,os
r=Path(r'C:\Users\cong\dot-work\ogh-full-mixed-20261112');p=r/'project';sys.path.insert(0,str(p/'tools/performance/current'))
from prepare_builtin_script_profile import run_process
os.environ['OGH_FINAL_INPUT']=str(r/'plain-r1/result.json.final.bin');os.environ['OGH_FINAL_OUTPUT']=str(r/'final-owners-events.json')
run_process([r'C:\programs\Godot\Godot_v4.7.2-stable_win64_console.exe','--headless','--path',str(p),'--script','res://tools/performance/current/final_owner_dump.gd'],p,r/'final-owner-dump-process',120)
