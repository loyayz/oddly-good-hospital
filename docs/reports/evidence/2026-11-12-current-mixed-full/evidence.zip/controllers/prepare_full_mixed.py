from pathlib import Path
import json,sys,shutil,subprocess,hashlib,time
repo=Path(r'C:\Users\cong\dot-work\oddly-good-hospital-handoff-20261112')
base=Path(r'C:\Users\cong\dot-work\ogh-fixed-boundary-20261112')
root=Path(r'C:\Users\cong\dot-work\ogh-full-mixed-20261112')
assert root.is_dir()
project=root/'project'
reuse=base/'.cache/boundary-project'
assert project.is_dir()
sys.path.insert(0,str(repo/'tools/performance/current'))
from prepare_builtin_script_profile import digest,write,run_process,validate_diagnostic_witness,native_identity,engine_identity
from campaign160 import target_checks
paths=subprocess.check_output(['git','-C',str(repo),'ls-files'],text=True).splitlines()
different=[]
for p in paths:
    if p.startswith(('game/','content/','addons/')) or p=='project.godot':
        assert (project/p).is_file(),p
        if digest(repo/p)!=digest(project/p): different.append(p)
assert different==['project.godot'],different
assert digest(project/'game/building/hospital_movement.gd')=='fd9d720d6c7688eff475bb15968c64a3e4fcdeb0a2acb8878c00619e1e556ca4'
for p in paths:
    target=project/p
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(repo/p,target)
source={p:digest(project/p) for p in paths}
engine=Path(r'C:\programs\Godot\Godot_v4.7.2-stable_win64_console.exe')
original=Path(r'C:\code\loyayz\oddly-good-hospital\.cache\performance160-mixed-20261112-toolqualification01\mixed-input01\mixed160.input.bin')
input_path=root/'mixed160.input.bin'
shutil.copy2(original,input_path)
assert digest(input_path)=='75f5e1d922f39f12382c0ceb74806bda0293251189f68a1ac158842f65fa78ca'
identity={'source':source,'native':native_identity(project),'engine':engine_identity(engine),'input_sha256':digest(input_path),'commit':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'runtime_reused_from':str(reuse),'production_source_comparison':different}
write(root/'identity-before.json',identity)
write(root/'project/source-inventory.json',paths)
print('PREPARED',str(root),len(paths),flush=True)
