from pathlib import Path
import json,hashlib
root=Path(r'C:\Users\cong\dot-work\ogh-full-mixed-20261112'); project=root/'project'; patches={}
def edit(rel,changes):
 p=project/rel; b=p.read_bytes(); a=b
 for old,new in changes:
  old,new=old.encode(),new.encode(); assert a.count(old)==1,(rel,old); a=a.replace(old,new)
 p.write_bytes(a); (root/(p.name+'.original')).write_bytes(b)
 patches[rel]={'before_sha256':hashlib.sha256(b).hexdigest(),'after_sha256':hashlib.sha256(a).hexdigest(),'changes':[{'before':x,'after':y} for x,y in changes]}
old='\treturn not target.is_empty() and space.static_reason(world,actor,int(item.floor_id),Vector2i(int(target[0]),int(target[1]))).is_empty()'
new='''\tvar _capture: bool = not OS.get_environment("OGH_UPGRADE_CAPTURE").is_empty()
\tvar _before: Dictionary = world.freeze() if _capture else {}
\tvar _reason: String = ""
\tif not target.is_empty():
\t\t_reason = space.static_reason(world,actor,int(item.floor_id),Vector2i(int(target[0]),int(target[1])))
\tif _capture:
\t\tvar _file: FileAccess = FileAccess.open(OS.get_environment("OGH_UPGRADE_CAPTURE")+"/decision-"+str(world.sim_tick)+"-"+str(item.id)+".bin",FileAccess.WRITE)
\t\t_file.store_var({"tick":world.sim_tick,"item":item.duplicate(true),"actor":actor.duplicate(true),"raw_target":target.duplicate(),"static_reason":_reason,"result":not target.is_empty() and _reason.is_empty(),"before":_before,"after":world.freeze()})
\t\t_file.close()
\treturn not target.is_empty() and _reason.is_empty()'''
edit('game/operations/maintenance_service.gd',[(old,new)])
edit('game/building/route_clearance.gd',[
('var _size: int','var _diagnostic_upgrade_preview: bool = false\nvar _size: int'),
('\t_indexed_static = not include_reservations','\t_diagnostic_upgrade_preview = actor.id=="upgrade_preview"\n\t_indexed_static = not include_reservations'),
('func reason(origin: Vector2i) -> String:\n','''func reason(origin: Vector2i) -> String:
\tif _diagnostic_upgrade_preview and not OS.get_environment("OGH_UPGRADE_CAPTURE").is_empty():
\t\tvar _file: FileAccess = FileAccess.open(OS.get_environment("OGH_UPGRADE_CAPTURE")+"/geometry-"+str(get_instance_id())+".bin",FileAccess.WRITE)
\t\t_file.store_var({"origin":origin,"size":_size,"height_m":_height_m,"source":source,"plots":_plots,"blocked":_blocked,"doors":_doors,"facilities":_facilities,"connectors":_connectors,"reservations":_reservations,"walls":_walls,"indexed_static":_indexed_static,"facility_cells":_facility_cells,"connector_cells":_connector_cells,"open_door_cells":_open_door_cells,"closed_door_cells":_closed_door_cells})
\t\t_file.close()
''')])
(root/'upgrade-capture-patches.json').write_text(json.dumps(patches,ensure_ascii=False,indent=2),encoding='utf-8')
print('REVERSIBLE CAPTURE READY')
