extends SceneTree
func _initialize() -> void:
	var a:=OS.get_cmdline_user_args();var out: String=a[1]
	var f:=FileAccess.open(a[2],FileAccess.READ);var facts: Dictionary=f.get_var(false);f.close()
	var lift: Dictionary=facts.connectors.benchmark_lift
	var actors: Dictionary={};var moves: Dictionary={};var tickets: Dictionary={}
	for id: String in facts.actors:
		var actor: Dictionary=facts.actors[id];var location: Dictionary=actor.location;var move: Dictionary=facts.moves.get(id,{})
		if move.has("transit_ticket"):tickets[id]=move.transit_ticket
		var near: bool=location.kind=="floor" and int(location.floor_id)==1 and float(location.cell[0])>=78 and float(location.cell[0])<=94 and float(location.cell[1])>=38 and float(location.cell[1])<=50
		if id=="maintenance_contractor_00000226" or id in lift.riders or move.has("transit_ticket") or near:
			actors[id]=actor;moves[id]=move
	f=FileAccess.open(out+"/decoded.json",FileAccess.WRITE);f.store_string(JSON.stringify({"tick":facts.sim_tick,"lift":lift,"actors":actors,"moves":moves,"ticket_facts":tickets,"maintenance":facts.maintenance,"rng":facts.rng},"\t"));f.close();quit(0)
