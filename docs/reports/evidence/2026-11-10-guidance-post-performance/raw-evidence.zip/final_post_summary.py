"""Collect completed, audited triples. Run only after the serial engines finish."""
import hashlib
import json
from pathlib import Path
import statistics

base = Path(__file__).resolve().parent


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


groups = ["performance-merged", "performance-single-46001aa", "performance-effective-4a79a6b",
          "performance-goal-8d50cac", "performance-post-5c0689b", "performance-post-plain-5c0689b"]
rows = []
for group in groups:
    directory = base / group
    audit, protocol = read(directory / "raw-audit.json"), read(directory / "protocol.json")
    assert audit["verified"] and audit["current_source_rechecked"]
    row = {key: audit[key] for key in ["commit", "samples", "source_count", "pooled_mean_us", "pooled_p95_us", "pooled_p99_us"]}
    row["group"] = group
    row["profile_stages"] = protocol["profile_stages"]
    row["initialization_ms"] = [run["initialization_us"] / 1000 for run in audit["runs"]]
    row["prefix_ms"] = [run["prefix_wall_us"] / 1000 for run in audit["runs"]]
    row["per_repeat"] = [{key: run["metrics"][key] for key in ["mean_step_us", "p95_us", "p99_us", "max_us"]} for run in audit["runs"]]
    row["business"] = audit["runs"][0]["business"]
    row["initial"] = audit["runs"][0]["initial"]
    row["sample_start"] = audit["runs"][0]["sample_start"]
    row["final"] = audit["runs"][0]["final"]
    row["final_sha256"] = audit["runs"][0]["final_sha256"]
    if protocol["profile_stages"]:
        row["root_stage_mean_ms"] = {stage["name"]: statistics.mean(next(item["mean_us"] for item in run["stages"] if item["name"] == stage["name"]) for run in audit["runs"]) / 1000 for stage in audit["runs"][0]["stages"]}
    if group.startswith("performance-post-"):
        samples = []
        for repeat in range(1, 4):
            for line in (directory / f"r{repeat}.json.steps.ndjson").read_text(encoding="utf-8").splitlines():
                item = json.loads(line)
                if item["kind"] == "complete" and item["sample"]["index"] >= 1000:
                    samples.append(item["sample"])
        row["sample_population_min_max"] = [min(item["present"] for item in samples), max(item["present"] for item in samples)]
        row["active_moves_min_mean_max"] = [min(item["moves"] for item in samples), statistics.mean(item["moves"] for item in samples), max(item["moves"] for item in samples)]
        row["sessions_min_mean_max"] = [min(item["sessions"] for item in samples), statistics.mean(item["sessions"] for item in samples), max(item["sessions"] for item in samples)]
        result = read(directory / "r1.json")
        row["final_guidance"] = result["final"]["guidance"]
        worker = read(directory / "r1.json.execution.json")["worker_samples"]
        row["worker_counts"] = {key: worker[key] for key in ["batches", "jobs", "processed", "consumed", "main_empty_observations", "failed_batches", "coverage_distinct_lookups", "coverage_native_calls", "coverage_fallback_calls"]}
        row["inline_job_count"] = worker["threads"].get("1", 0)
        row["background_job_count"] = worker["jobs"] - row["inline_job_count"]
    rows.append(row)
with (base / "final-post-comparison.json").open("x", encoding="utf-8") as stream:
    json.dump(rows, stream, ensure_ascii=False, indent=2)
for row in rows:
    print(json.dumps({key: value for key, value in row.items() if key not in ["root_stage_mean_ms", "final_guidance"]}, ensure_ascii=False))
