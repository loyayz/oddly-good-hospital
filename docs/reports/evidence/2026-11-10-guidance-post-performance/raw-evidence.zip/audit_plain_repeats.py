"""Audit the plain triple and exact terminal parity against the profiled triple."""
import hashlib
import json
import math
from pathlib import Path
import statistics
import subprocess
import sys

PROJECT = Path(__file__).resolve().parents[2]
RUNS, REFERENCE = (Path(arg).resolve() for arg in sys.argv[1:])


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


protocol = read(RUNS / "protocol.json")
reference = read(REFERENCE / "protocol.json")
assert read(RUNS / "status.json")["state"] == "complete"
assert read(REFERENCE / "raw-audit.json")["verified"]
assert not protocol["profile_stages"] and reference["profile_stages"]
for key in ["commit", "tree", "tracked_diff", "input_sha256", "engine_sha256", "native",
            "runner_sha256", "prefix_steps", "sample_steps", "repeats", "main_thread_policy",
            "worker_tasks", "OMP_NUM_THREADS"]:
    assert protocol[key] == reference[key], key
assert protocol["prefix_steps"] == 1000 and protocol["sample_steps"] == 2000 and protocol["repeats"] == 3
assert protocol["tracked_diff"] == "" and protocol["main_thread_policy"] == "app"
assert sha(Path(protocol["input"])) == protocol["input_sha256"] == "ce56591c43fe1704abf76348dd5e67b0eae2a599143c03e045a780439a1bc15c"
assert sha(Path(protocol["engine"])) == protocol["engine_sha256"]
assert all(sha(PROJECT / "game/platform/windows/bin" / name) == value for name, value in protocol["native"].items())
source = read(RUNS / "source-identity.json")
assert source == read(REFERENCE / "source-identity.json")
assert subprocess.check_output(["git", "-C", str(PROJECT), "rev-parse", "HEAD"], text=True).strip() == protocol["commit"]
assert subprocess.run(["git", "-C", str(PROJECT), "diff", "--quiet", "HEAD", "--"]).returncode == 0
assert all(sha(PROJECT / name) == value for name, value in source.items())

rows, all_values = [], []
for number in range(1, 4):
    stem = RUNS / f"r{number}.json"
    result, ref = read(stem), read(REFERENCE / stem.name)
    assert result["complete"] and not result["errors"] and result["all_completed_steps"] == 3000
    assert result["source_input_sha256"] == protocol["input_sha256"]
    assert result["final_sha256"] == ref["final_sha256"] == sha(Path(str(stem) + ".final.bin"))
    assert Path(str(stem) + ".final.bin").read_bytes() == (REFERENCE / (stem.name + ".final.bin")).read_bytes()
    for key in ["initial", "final", "business", "prefix_business", "sample_business", "sample_start_population"]:
        assert result[key] == ref[key], key
    raw = [json.loads(line) for line in Path(str(stem) + ".steps.ndjson").read_text(encoding="utf-8").splitlines()]
    assert len(raw) == 6000
    values = []
    for index in range(3000):
        enter, complete = raw[index * 2:index * 2 + 2]
        assert enter["kind"] == "enter" and enter["index"] == index
        assert complete["kind"] == "complete" and complete["sample"]["index"] == index
        sample = complete["sample"]
        assert enter["tick"] + 1 == sample["tick"] == result["initial"]["tick"] + index + 1
        if index >= 1000:
            values.append(sample["elapsed_us"])
    ordered, metrics = sorted(values), result["metrics"]
    assert len(values) == metrics["count"] == 2000
    assert sum(values) == metrics["sum_step_us"] and statistics.mean(values) == metrics["mean_step_us"]
    assert ordered[-1] == metrics["max_us"]
    for percentile in [50, 95, 99]:
        assert ordered[math.ceil(len(values) * percentile / 100) - 1] == metrics[f"p{percentile}_us"]
    assert metrics["real_window_us_including_observation"] - sum(values) == metrics["observation_logging_and_loop_wall_us"] >= 0
    execution = read(Path(str(stem) + ".execution.json"))
    assert not execution["profile_stages"] and execution["worker_tasks"] == 4
    assert not Path(str(stem) + ".stages.json").exists()
    policy = execution["main_thread_policy"]
    assert policy["applied"] and policy["reason"] == "performance_cores" and policy["error"] == 0
    assert policy["hybrid"] and policy["group"] == 0 and policy["mask_hex"] == "fc03"
    worker = execution["worker_samples"]
    ref_worker = read(REFERENCE / (stem.name + ".execution.json"))["worker_samples"]
    for key in ["batches", "jobs", "processed", "consumed", "main_empty_observations", "failed_batches",
                "coverage_distinct_lookups", "coverage_native_calls", "coverage_fallback_calls"]:
        assert worker[key] == ref_worker[key], key
    assert worker["batches"] == 3000 and 0 <= worker["jobs"] <= 12000 and worker["failed_batches"] == 0
    assert worker["processed"] == worker["consumed"] and worker["coverage_fallback_calls"] == 0
    assert 0 <= worker["main_empty_observations"] <= worker["processed"]
    assert sum(worker["threads"].values()) == worker["jobs"]
    last = worker["last_batch"]
    assert last["ok"] and last["all_results_consumed"]
    assert last["requested"] == last["processed"] == last["consumed"]
    pending = last["requested"] - last["main_empty_observations"]
    assert len(last["jobs"]) == min(4, pending) and sum(job["processed"] for job in last["jobs"]) == pending
    assert all(job["processed"] == job["requested"] for job in last["jobs"])
    if len(last["jobs"]) > 1:
        assert all(job["thread_id"] != last["main_thread_id"] for job in last["jobs"])
    elif last["jobs"]:
        assert last["jobs"][0]["thread_id"] == last["main_thread_id"]
    assert not read(RUNS / f"r{number}.processes-before.json")
    log = (RUNS / f"r{number}.log").read_text(encoding="utf-8")
    assert "SCRIPT ERROR:" not in log and not any(line.startswith("ERROR:") for line in log.splitlines())
    all_values.extend(values)
    rows.append({"repeat": number, "metrics": metrics, "initialization_us": result["initialization_us"],
                 "prefix_wall_us": result["prefix_wall_us"], "initial": result["initial"]["population"],
                 "sample_start": result["sample_start_population"], "final": result["final"]["population"],
                 "business": result["sample_business"], "final_sha256": result["final_sha256"],
                 "main_thread_policy": policy, "workers": {key: worker[key] for key in ["batches", "jobs", "processed", "consumed", "main_empty_observations", "failed_batches"]},
                 "worker_thread_ids": sorted(worker["threads"], key=int)})
all_values.sort()
output = {"verified": True, "commit": protocol["commit"], "source_count": len(source),
          "current_source_rechecked": True, "controller_source_freeze_complete": True,
          "raw_steps": 9000, "samples": 6000, "profiled_reference": str(REFERENCE),
          "all_three_final_binary_bytes_match_profiled": True,
          "engine_input_native_rechecked": True, "pooled_mean_us": statistics.mean(all_values),
          "pooled_p95_us": all_values[math.ceil(len(all_values) * .95) - 1],
          "pooled_p99_us": all_values[math.ceil(len(all_values) * .99) - 1], "runs": rows}
with (RUNS / "raw-audit.json").open("x", encoding="utf-8") as stream:
    json.dump(output, stream, ensure_ascii=False, indent=2)
print(json.dumps({key: value for key, value in output.items() if key != "runs"}, ensure_ascii=False))
