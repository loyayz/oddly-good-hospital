"""Preserve audited final measurement evidence; refuses to overwrite a bundle."""
import hashlib
import json
from pathlib import Path
import zipfile

root = Path.cwd()
base = root / ".cache/return-merge-20261110"
output = root / "docs/reports/evidence/2026-11-10-guidance-post-performance"
profile = base / "performance-post-5c0689b"
plain = base / "performance-post-plain-5c0689b"
for directory in [profile, plain]:
    assert json.loads((directory / "status.json").read_text())["state"] == "complete"
    audit = json.loads((directory / "raw-audit.json").read_text())
    assert audit["verified"] and audit["current_source_rechecked"]
output.mkdir(exist_ok=False)
groups = [profile, plain, base / "metrics-post-5c0689b"]
files = [(path, path.relative_to(base).as_posix()) for directory in groups
         for path in sorted(directory.iterdir()) if path.is_file()]
helpers = ["audit_current_repeats.py", "audit_plain_repeats.py", "final_post_summary.py",
           "archive_final_post.py", "final-post-comparison.json", "terminal_metrics.gd", "run_selected.py"]
files.extend((base / name, name) for name in helpers)
input_path = root / "perf-work/codex-performance-20261110/.cache/performance160-20261110/input.bin"
files.append((input_path, "input.bin"))
records = []
with zipfile.ZipFile(output / "raw-evidence.zip", "x", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for path, key in files:
        data = path.read_bytes()
        records.append({"path": key, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
        archive.writestr(key, data)
with zipfile.ZipFile(output / "raw-evidence.zip") as archive:
    assert archive.testzip() is None and len(archive.namelist()) == len(records)
    assert all(hashlib.sha256(archive.read(item["path"])).hexdigest() == item["sha256"] for item in records)
manifest = {"scope": "5c0689b: three serial profiled and three serial plain 160-person processes; 1000 real prefix and 2000 sampled steps each; 1809-file source freeze. Raw 18000 completed steps and 12000 samples audited before source/report edits; full terminal bytes match across all six. App main-thread policy records success, max-four environment tasks with source-free observations completed on main. Zero-step terminal metrics only. No renderer/FPS or default-affinity/worker-count speedup control.",
            "files": records, "archive_bytes": (output / "raw-evidence.zip").stat().st_size,
            "archive_sha256": hashlib.sha256((output / "raw-evidence.zip").read_bytes()).hexdigest()}
(output / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps({key: value for key, value in manifest.items() if key != "files"}, ensure_ascii=False))
print("verified files", len(records))
