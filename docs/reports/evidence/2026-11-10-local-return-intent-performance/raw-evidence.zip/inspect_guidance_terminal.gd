extends SceneTree

func _initialize() -> void:
	var args: PackedStringArray = OS.get_cmdline_user_args()
	var records: Array = []
	for input: String in args.slice(1):
		var handle: FileAccess = FileAccess.open(input,FileAccess.READ)
		var envelope: Dictionary = handle.get_var(false)
		handle.close()
		var facts: Dictionary = envelope.facts
		var rows: Array = []
		var counts: Dictionary = {}
		for visit_id: String in facts.floor_guidance.visits:
			var guide: Dictionary = facts.floor_guidance.visits[visit_id]
			var visit: Dictionary = facts.visits[visit_id]
			var actor_id: String = str(visit.get("patient_id",visit.get("actor_id","")))
			var actor: Dictionary = facts.actors.get(actor_id,{})
			var move: Dictionary = facts.moves.get(actor_id,{})
			var row: Dictionary = {"visit_id":visit_id,"actor_id":actor_id,"phase":guide.phase,"initial_done":guide.get("initial_done",false),"reason":guide.get("reason",""),"location":actor.get("location",{}),"local_move":move.get("local_move",{}),"waiting_reason":move.get("waiting_reason",""),"request":move.get("request_key",""),"target_cell":move.get("target_cell",[]),"cursor":move.get("cursor",-1),"path_size":move.get("path",[]).size(),"travelled_tail":move.get("travelled",[]).slice(-8)}
			if not move.is_empty():
				var key: String = str(move.get("waiting_reason",""))
				counts[key]=int(counts.get(key,0))+1
			rows.append(row)
		records.append({"input":input,"tick":facts.get("sim_tick",-1),"guidance_waiting_reason_counts":counts,"rows":rows})
	var output: FileAccess = FileAccess.open(args[0],FileAccess.WRITE)
	output.store_string(JSON.stringify({"scope":"Read retained binary terminal facts only; no simulation steps, cache setup, movement or mutation","records":records},"\t"))
	output.close()
	quit()
