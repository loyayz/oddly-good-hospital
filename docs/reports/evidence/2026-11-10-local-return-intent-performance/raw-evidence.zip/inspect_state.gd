extends SceneTree
func _initialize() -> void:
	var envelope: Dictionary=FileAccess.open(OS.get_cmdline_user_args()[0],FileAccess.READ).get_var(false)
	var facts: Dictionary=envelope.facts
	var invalid: Array=[]
	for id: String in facts.moves:
		var movement: Dictionary=facts.moves[id]
		if not movement.has("local_move"): continue
		var actor: Dictionary=facts.actors[id]
		var origin: Vector2=ConvoyTrail.point(actor.location.cell)
		var target: Vector2=ConvoyTrail.point(movement.local_move.target.cell)
		if origin.x!=target.x and origin.y!=target.y:
			invalid.append({"id":id,"actor":actor,"local":movement.local_move,"cursor":movement.cursor,"goal":movement.target_cell,"path":movement.path,"travelled_tail":movement.travelled.slice(-12)})
	print(JSON.stringify({"invalid":invalid,"validation":WorldState.new(facts).validate(HospitalContent.new())}))
	quit()
