"""Compare retained guidance records without executing simulation steps."""
import argparse
from collections import Counter
import json
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('before', type=Path)
parser.add_argument('after', type=Path)
parser.add_argument('output', type=Path)
args = parser.parse_args()
result = {}
for label, path in [('before', args.before), ('after', args.after)]:
    document = json.loads(path.read_text(encoding='utf-8-sig'))
    visits = document['final']['guidance']['visits']
    receipts = [receipt for visit in visits.values() for receipt in visit.get('receipts', [])]
    result[label] = {
        'receipts_retained_in_final': len(receipts),
        'sample_receipts_retained_in_final': sum(receipt['completed_tick'] > 1000 for receipt in receipts),
        'initial_done_retained_in_final': sum(visit.get('initial_done', False) for visit in visits.values()),
        'phase_counts': dict(Counter(visit['phase'] for visit in visits.values())),
        'reason_counts': dict(Counter(visit.get('reason', '') for visit in visits.values())),
        'receipt_counts_by_desk': dict(Counter(receipt['desk_id'] for receipt in receipts)),
    }
args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
