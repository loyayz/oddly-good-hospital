import argparse
import json
import os
from pathlib import Path
import subprocess
import time

parser = argparse.ArgumentParser()
parser.add_argument('output')
parser.add_argument('--script', default='res://tools/performance/current/movement_regression.gd')
parser.add_argument('--acceptance', action='store_true')
parser.add_argument('cases', nargs='*')
args, extra = parser.parse_known_args()
args.cases += extra
root = Path.cwd()
out = (root / '.cache/return-intent-20261110' / args.output).resolve()
out.mkdir(parents=True, exist_ok=False)
environment = dict(os.environ)
for key, name in [('APPDATA', 'roaming'), ('LOCALAPPDATA', 'local')]:
    environment[key] = str(out / 'runtime' / name)
    Path(environment[key]).mkdir(parents=True)
engine = r'C:\code\loyayz\oddly-good-hospital\.cache\ordinary-tail-2d65f93-20261022\engine\Godot_v4.7.2-stable_win64_console.exe'
result = root / 'acceptance-results.json' if args.acceptance else out / 'results.json'
assert not result.exists()
command = [engine, '--headless', '--path', str(root), '--script', args.script, '--']
command += args.cases if args.acceptance else [str(result), *args.cases]
(out / 'source.patch').write_bytes(subprocess.check_output(['git', 'diff', 'HEAD', '--']))
started = time.perf_counter()
reason = ''
with (out / 'run.log').open('w', encoding='utf-8') as log:
    process = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT,
                               env=environment, creationflags=subprocess.CREATE_NO_WINDOW)
    try:
        while process.poll() is None:
            time.sleep(1)
            messages = (out / 'run.log').read_text(encoding='utf-8')
            if 'SCRIPT ERROR:' in messages or any(l.startswith('ERROR:') for l in messages.splitlines()):
                reason = 'script/engine error'
                process.terminate()
                break
            if time.perf_counter() - started > 300:
                reason = 'timeout'
                process.terminate()
                break
        process.wait(timeout=10)
    finally:
        if process.poll() is None:
            process.kill()
if args.acceptance and result.exists():
    result.rename(out / 'results.json')
status = {'command': command, 'returncode': process.returncode,
          'seconds': time.perf_counter() - started, 'reason': reason}
(out / 'status.json').write_text(json.dumps(status, indent=2), encoding='utf-8')
print(json.dumps(status))
print((out / 'run.log').read_text(encoding='utf-8')[-2000:])
