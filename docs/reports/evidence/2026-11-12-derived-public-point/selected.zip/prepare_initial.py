from pathlib import Path
import hashlib,json
root=Path('/workspace/scratch/6962cc21ddf3');r=root/'oddly-good-hospital-cloud-recovery-20261112';b=root/'derived-public-point-20261112';b.mkdir(exist_ok=False)
p=r/'game/building/room_use.gd';(b/'room_use.before.gd').write_bytes(p.read_bytes())
uid={str(x.relative_to(r)):hashlib.sha256(x.read_bytes()).hexdigest() for x in r.rglob('*.uid')};(b/'uid-before.json').write_text(json.dumps(uid,indent=2))
(r/'docs/reports/2026-11-12-derived-public-point.md').write_text('''# 派生空层公共点产权修复\n\n## 变更前规则与交接\n- design/04 第157行：实完连续高度授予产权，FloorState 仅保存布局差异；空层拓扑按需派生。stage25-stage28 第27行：最多九条高度，不生成逐层格/对象/任务。floor_service._complete 更新高度并 invalidate_geometry。\n- 本批只修 HospitalRoomUse._plots 查询索引，首次 public_point 访问该层时使用既有 floor_plots；不补 override、不写 World、不更改排序或安全/到场/80 tick 契约。沿用 weak World、facts 实例和 geometry_revision 失效。\n- 选例：合法无 override 完工层全 1024 点与实际 safe/reach；未完层/未购相邻 plot/越界拒绝；同服务高度变化并真实 geometry invalidation、facts 替换、World 恢复；已有 override 公共/私有房间；高层只派生查询层；既有 STAFF-74 门/连接安全撤离、存取恢复与真实 0.1s 步进/80 tick。公共点直接消费者只验证许可/拒绝边界，不扩临床/导航全主题。\n- 完工高度在纯查询合法边界输入中声明，不将此作为施工实际完成证据；实际移动另由流程选例执行。保存本轮完整 preWorld 原始 bin。前次 derived03 无原始 bin，不追补冒称。\n- 不运行微测/历史/完整性能窗，不修改 waypoint 未确认边界。\n''')
s=p.read_text();old='\tfor floor_key: String in world.facts.floors.overrides:\n\t\tvar owned: Dictionary={}\n\t\tfor plot: Array in HospitalSpace.floor_plots(world,int(floor_key)): owned[Vector2i(int(plot[0]),int(plot[1]))]=true\n\t\t_plots[int(floor_key)]=owned\n';assert old in s;s=s.replace(old,'')
old='\tif point.x<0 or point.y<0 or point.x>=96 or point.y>=96 or not _plots.get(floor_id,{}).has(Vector2i(point.x/32,point.y/32)): return false'
new='''\tif point.x<0 or point.y<0 or point.x>=96 or point.y>=96: return false
\tif not _plots.has(floor_id):
\t\tvar owned: Dictionary={}
\t\tfor plot: Array in HospitalSpace.floor_plots(world,floor_id): owned[Vector2i(int(plot[0]),int(plot[1]))]=true
\t\t_plots[floor_id]=owned
\tif not _plots[floor_id].has(Vector2i(point.x/32,point.y/32)): return false''';assert old in s;s=s.replace(old,new);p.write_bytes(s.encode())
run=(root/'floor-wait-order-selected-20261112/run_case.py').read_text().replace("'game/life/public_areas.gd'","'game/building/room_use.gd'").replace('run_floor_wait_order.gd','run_derived_public_point.gd');(b/'run_case.py').write_text(run)
