import importlib.util,json,os,subprocess,time
from pathlib import Path

root=Path(__file__).resolve().parent;project=root/'project';out=root/'functional';out.mkdir(exist_ok=False)
spec=importlib.util.spec_from_file_location('campaign',project/'tools/performance/current/campaign160.py');campaign=importlib.util.module_from_spec(spec);spec.loader.exec_module(campaign)
engine=Path('C:/programs/Godot/Godot_v4.7.2-stable_win64_console.exe')
environment=dict(os.environ,OMP_NUM_THREADS='1',APPDATA=str(root/'runtime-functional/Roaming'),LOCALAPPDATA=str(root/'runtime-functional/Local'))
for name in ['APPDATA','LOCALAPPDATA']:Path(environment[name]).mkdir(parents=True,exist_ok=True)
jobs=[('index','res://tests/acceptance/bed_destination_index_runner.gd',[str(out/'index.json'),'BED-INDEX-COUNT','BED-INDEX-LIFECYCLE','BED-INDEX-OWNER','BED-INDEX-ORACLE','BED-INDEX-STOPS']),('room14','res://tests/acceptance/rooms_areas_guidance_runner.gd',['--case=ROOM-14','--output='+str(out/'room14.json')]),('bed-regressions','res://tests/acceptance/bed_passage_runner.gd',[str(out/'bed-regressions.json'),'BED-CLAIM','BED-LOCAL','BED-GROUP','BED-TRANSIT','BED-FACING','BED-RESTORE'])]
results=[]
for name,script,args in jobs:
 assert not campaign.processes(),'Another engine/compiler is active'
 command=[str(engine),'--headless','--path',str(project),'--script',script,'--',*args]
 log_path=out/(name+'.log');started=time.perf_counter();row={'name':name,'command':command}
 with log_path.open('w',encoding='utf-8') as log:
  process=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,env=environment,creationflags=subprocess.CREATE_NO_WINDOW)
  row['engine_launcher_pid']=process.pid;(out/'status.json').write_text(json.dumps(row),encoding='utf-8')
  try:
   while process.poll() is None:
    time.sleep(.25);text=log_path.read_text(encoding='utf-8')
    if 'SCRIPT ERROR:' in text or any(line.startswith('ERROR:') for line in text.splitlines()):row['failure']='Godot error';break
    if time.perf_counter()-started>180:row['failure']='Test exceeded 180 seconds';break
  finally:campaign.stop_owned_process_tree(process)
 row.update(returncode=process.returncode,elapsed_seconds=time.perf_counter()-started)
 path=out/(name+'.json');data=json.loads(path.read_text(encoding='utf-8')) if path.exists() else {}
 row['ok']=data.get('ok',False);results.append(row)
 (out/'execution.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
 print(json.dumps({k:v for k,v in row.items() if k!='command'}),flush=True)
 assert process.returncode==0 and row['ok'] and 'failure' not in row,(row,log_path)
