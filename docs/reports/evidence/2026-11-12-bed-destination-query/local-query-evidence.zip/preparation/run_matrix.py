import importlib.util,json,os,subprocess,sys,time
from pathlib import Path

out=Path(__file__).resolve().parent;project=out/'project';repo=out.parents[1];overlay=repo/'.cache/bed-destination-query-20261112-overlay01'
identity=json.loads((overlay/'identity.json').read_text(encoding='utf-8'))
matrix=out/'matrix';matrix.mkdir(exist_ok=False)
spec=importlib.util.spec_from_file_location('campaign',project/'tools/performance/current/campaign160.py');campaign=importlib.util.module_from_spec(spec);spec.loader.exec_module(campaign)
engine=Path('C:/programs/Godot/Godot_v4.7.2-stable_win64_console.exe')
assert campaign.engine_identity(engine)==identity['engine_executables']
jobs=[('a1','a','plain'),('b1','b','plain'),('b2','b','plain'),('a2','a','plain'),('a3','a','plain'),('b3','b','plain'),('a-counted','a_counted','counted'),('b-counted','b_counted','counted')]
results=[];business=None;facts=None;queries=None
for name,variant,mode in jobs:
 assert not campaign.processes(),'Another engine/compiler is active'
 install=out/'installations'/(name+'.json')
 command=[sys.executable,'-X','utf8','-B',str(repo/'tools/performance/current/prepare_bed_destination_probe.py'),'install','--overlay',str(overlay),'--project',str(project),'--variant',variant,'--record',str(install)]
 subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True)
 assert campaign.engine_identity(engine)==identity['engine_executables']
 assert campaign.native_identity(project)==identity['native']
 environment=dict(os.environ,OMP_NUM_THREADS='1',APPDATA=str(out/'runtime-matrix'/name/'Roaming'),LOCALAPPDATA=str(out/'runtime-matrix'/name/'Local'))
 for key in ['APPDATA','LOCALAPPDATA']:Path(environment[key]).mkdir(parents=True,exist_ok=True)
 target=matrix/(name+'.json');log_path=matrix/(name+'.log');assert not target.exists()
 command=[str(engine),'--headless','--path',str(project),'--script','res://tools/performance/current/bed_destination_probe.gd','--','--input='+identity['input'],'--output='+str(target),'--mode='+mode,'--iterations=1000']
 row={'name':name,'variant':variant,'mode':mode,'command':command,'install_record':str(install),'environment':{k:environment[k] for k in ['OMP_NUM_THREADS','APPDATA','LOCALAPPDATA']}}
 started=time.perf_counter()
 with log_path.open('w',encoding='utf-8') as log:
  process=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,env=environment,creationflags=subprocess.CREATE_NO_WINDOW)
  row['engine_launcher_pid']=process.pid;(matrix/'status.json').write_text(json.dumps(row),encoding='utf-8')
  try:
   while process.poll() is None:
    time.sleep(.25);text=log_path.read_text(encoding='utf-8')
    if 'SCRIPT ERROR:' in text or any(line.startswith('ERROR:') for line in text.splitlines()):row['failure']='Godot error';break
    if time.perf_counter()-started>180:row['failure']='Microbenchmark exceeded 180 seconds';break
  finally:campaign.stop_owned_process_tree(process)
 row.update(returncode=process.returncode,controller_process_window_seconds=time.perf_counter()-started)
 data=json.loads(target.read_text(encoding='utf-8')) if target.exists() else {}
 row.update(ok=data.get('ok',False),measurements=data.get('measurements'),population=data.get('population'))
 results.append(row);(matrix/'execution.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
 print(json.dumps({k:v for k,v in row.items() if k not in ['command','environment','install_record']}),flush=True)
 assert row['ok'] and process.returncode==0 and 'failure' not in row,(row,log_path)
 assert data['all_world_facts_unchanged'] and data['input_sha256']==identity['input_sha256'] and not data['errors']
 assert data['main_thread_policy']['applied'] and data['OMP_NUM_THREADS']=='1'
 assert data['source_sha256']['space']==identity['variants'][variant]['game/building/hospital_space.gd']['sha256']
 assert data['source_sha256']['movement']==identity['variants'][variant]['game/building/hospital_movement.gd']['sha256']
 for measurement in data['measurements'].values():assert (measurement['elapsed_us'] is None)==(mode=='counted') and measurement['calls']>0
 current=(data['oracle_results_sha256'],data['world_facts_sha256'],data['queries'])
 assert data['actual_results_sha256']==current[0]
 if business is None:business,facts,queries=current
 else:assert current==(business,facts,queries),'Input/query/business witness changed'
 assert campaign.engine_identity(engine)==identity['engine_executables'] and campaign.native_identity(project)==identity['native']
 installed=json.loads(install.read_text(encoding='utf-8'))
 assert all(campaign.digest(project/n)==v for n,v in installed['source'].items()),'Source changed during the process'
 print('GATED '+name,flush=True)
