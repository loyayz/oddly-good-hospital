from pathlib import Path
import datetime
import hashlib
import json
import zipfile

REPO=Path(__file__).resolve().parent.parent
ROOT=REPO/'.cache/queue-view-5712c6f-20261023'
OUT=REPO/'docs/reports/evidence/2026-10-23-queue-value-view-trial'
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
digest=lambda b:hashlib.sha256(b).hexdigest()
sha=lambda p:digest(Path(p).read_bytes())
rel=lambda p:str(Path(p).relative_to(REPO)).replace('\\','/')
def write(path,value):Path(path).write_bytes((json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
assert not OUT.exists()
prior=REPO/'docs/reports/evidence/2026-10-23-occupied-seat-dependencies/raw-evidence.zip'
assert sha(prior)=='9bbe62d8cc7c156656727fa41c312f7b6d5c08eef21be641731e2942f0f5e9eb'
base=read(ROOT/'baseline-identity.json')
trial=read(ROOT/'final-identity.json')
for row in base['sources']:
    assert sha(ROOT/'baseline-project'/row['path'])==row['sha256'],row['path']
    if row['path'] not in ['project.godot','export_presets.cfg']:assert sha(REPO/row['path'])==row['sha256'],row['path']
for row in base['tests']:assert sha(REPO/row['path'])==row['sha256'],row['path']
for row in trial['sources']+trial['tests']:assert sha(ROOT/'final-project'/row['path'])==row['sha256'],row['path']
runs={}
intervals=[]
for path in sorted(ROOT.glob('*.launch.json')):
    launch=read(path)
    name=path.name.removesuffix('.launch.json')
    intervals.append((launch['started_at_utc'],launch['ended_at_utc'],name))
    assert launch['exit_code']==0 and not launch['timed_out'] and not launch['errors'],name
    output=ROOT/(name+'.json')
    if not output.exists():continue
    result=read(output)
    if 'metrics' not in result:continue
    check=read(ROOT/(name+'.semantic-check.json'))
    assert check['passed'] and all(check['checks'].values()),name
    assert result['complete'] and result['qualified'] and not result['errors'],name
    assert len(result['samples'])==result['requested_steps'] and all(x['present']==160 and x['complete'] for x in result['samples']),name
    window=next(x for x in ['gp80','public360','operations40'] if name.endswith(x))
    expected_path=REPO/'.cache/queue-signature-26bcc0f-20261023'/(( 'e3-' if window=='gp80' else 'e1-')+window+'.json')
    expected=read(expected_path)
    for key in ['source_input_sha256','initial','final','qualification','operations','event_records','final_binary_sha256']:
        assert result.get(key)==expected.get(key),(name,key)
    assert [{k:v for k,v in s.items() if k!='elapsed_us'} for s in result['samples']]==[{k:v for k,v in s.items() if k!='elapsed_us'} for s in expected['samples']],name
    ap,bp=result['public'].copy(),expected['public'].copy()
    ac,bc=ap.pop('query_counts'),bp.pop('query_counts')
    assert ap==bp,name
    delta={k:dict(actual=ac.get(k),baseline=bc.get(k)) for k in ac.keys()|bc.keys() if ac.get(k)!=bc.get(k)}
    assert all(k.startswith(('public_wait_queue_view_','diag_wait/')) for k in delta),name
    assert sha(ROOT/(name+'.json.final.bin'))==result['final_binary_sha256'],name
    source_check=read(ROOT/(name+'.source-check.json'))
    project=Path(launch['arguments'][launch['arguments'].index('--path')+1])
    variant=project.name.removesuffix('-project')
    identity=read(ROOT/(variant+'-identity.json'))
    assert identity['sources']==source_check['actual_sources'],name
    for row in identity['sources']:assert sha(project/row['path'])==row['sha256'],(name,row['path'])
    if result.get('profile'):
        p=result['profile']
        assert p['steps']==result['requested_steps'] and p['step_records_complete'] and not p['errors'],name
    runs[name]=dict(variant=variant,metrics_us=result['metrics'],steps=len(result['samples']),
        all_original_query_counts_business_events_rng_non_time_samples_equal=True,
        new_counts=check['new_counts'],probes=check.get('probes',{}),query_count_differences=delta,
        process_cpu_ms=launch['child_cpu_ms'],launch_wall_ms=launch['wall_ms'],
        input_sha256=result['source_input_sha256'],final_binary_sha256=result['final_binary_sha256'])
intervals.sort()
for a,b in zip(intervals,intervals[1:]):assert a[1]<=b[0],(a,b)
cases=read(ROOT/'functional01.acceptance-results.json')
assert cases['completed'] and cases['checks']==6 and cases['failed']==0
assert sorted(cases['results'])==['STAFF-48','STAFF-49','STAFF-57','STAFF-69','STAFF-70','STAFF-71']
lifecycle=cases['results']['STAFF-69']['details']['occupied_seat_queue_dependencies']['shared_queue_view_lifecycle']
assert lifecycle['ok'] and all(lifecycle['checks'].values())

members={}
def add(path,name=None):
    path=Path(path)
    if not path.is_file():return
    name=name or rel(path)
    data=path.read_bytes()
    if name in members:assert members[name]==data,name
    members[name]=data
for path in ROOT.iterdir():
    if path.is_file() and not path.name.endswith('.final.bin'):add(path)
for path in ROOT.glob('*.sources/*.gd'):add(path)
aliases=[]
for project in sorted(ROOT.glob('*-project')):
    for source in ['game/life/public_areas.gd','game/clinic/hospital_visitors.gd','tests/acceptance/public_phase_use.gd']:
        path=project/source
        member='source-blobs/'+sha(path)+'.gd'
        add(path,member)
        aliases.append(dict(original=rel(path),member=member,sha256=sha(path)))
for path in ROOT.glob('*.json.final.bin'):
    member='final-states/'+sha(path)+'.bin'
    add(path,member)
    aliases.append(dict(original=rel(path),member=member,sha256=sha(path)))
for source in ['queue_view_round.py','queue_view_final_measure.py','queue_view_probe.py','occupied_queue_probe.py']:
    add(REPO/'.cache'/source)
add(REPO/'.cache/wait-signature-031e1f7-20261022/run.py')
add(Path(__file__))
for name in ['public-v6.input.bin','gp.input.bin','op.input.bin']:add(REPO/'.cache/task-navigation-20261019'/name)
add(ROOT/'baseline-project/tools/performance/representative_worker.gd','runner-source/representative_worker.gd')
OUT.mkdir(parents=True)
archive=OUT/'raw-evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=7) as target:
    for name,data in sorted(members.items()):target.writestr(name,data)
rows=[dict(path=n,size=len(b),sha256=digest(b)) for n,b in sorted(members.items())]
with zipfile.ZipFile(archive) as target:
    assert sorted(target.namelist())==[x['path'] for x in rows]
    for row in rows:
        data=target.read(row['path'])
        assert len(data)==row['size'] and digest(data)==row['sha256']
manifest=dict(schema_version=1,archive=rel(archive),sha256=sha(archive),size=archive.stat().st_size,members=rows,aliases=aliases,
    baseline_identity=base,rejected_trial_identity=trial,external_baseline=dict(path=rel(prior),sha256=sha(prior),verified=True),
    restored_production_and_tests_verified=True,engine_intervals=intervals,no_engine_overlap=True)
write(OUT/'raw-manifest.json',manifest)
summary=dict(schema_version=1,generated_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    baseline_commit=base['workspace_head'],adopted=False,production_and_test_source_restored=True,
    diagnostic_only=True,formal_pass=False,successful_engine_windows=len(runs),measured_steps=sum(x['steps'] for x in runs.values()),
    fixed_load=dict(actors=160,patients=120,staff=32,visitors=8,floors=4,rooms=64,facilities=1336,tick_seconds=0.1),
    runs=runs,functional=dict(checks=6,failed=0,cases={k:dict(passed=v['passed'],body_ms=v['body_ms'],setup_ms=v['setup_ms']) for k,v in cases['results'].items()},lifecycle=lifecycle),
    raw_archive=dict(path=rel(archive),sha256=sha(archive),size=archive.stat().st_size,members=len(rows)),
    notes=['Shared queue snapshot trial rejected: no established whole-step benefit and public regression.',
        'All original query counts and business results equal; new view counters measure preparation, not fewer people or queries.',
        'View function timing includes equality, current actor collection, necessary rebuilding and bookkeeping; not isolated native equality CPU.',
        'Operations never entered the new view branch, yet its mean changed significantly. Its improvement cannot be credited to this patch.',
        'Source unchanged after rollback. Trial functional passes do not mean a new production implementation was accepted.'])
write(OUT/'summary.json',summary)
print(json.dumps(dict(windows=len(runs),steps=summary['measured_steps'],archive=summary['raw_archive'],cases=summary['functional']['cases'])),flush=True)
