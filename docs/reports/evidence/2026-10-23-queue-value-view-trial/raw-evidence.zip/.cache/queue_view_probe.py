from pathlib import Path
import importlib.util
import json
import re
import shutil
from types import SimpleNamespace

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('queue_view_probe_round',HERE/'queue_view_round.py')
round=importlib.util.module_from_spec(spec)
spec.loader.exec_module(round)
source=(HERE/'occupied_queue_probe.py').read_text(encoding='utf-8')
definitions=source[source.index('def mark('):source.index('\nfor variant,parent')]
definitions=definitions.replace("if name=='_decision_signature':",'if False:')
scope=dict(json=json,re=re,TICKS=[850,866,2759,2763,2878])
exec(definitions,scope)
instrument,mark=scope['instrument'],scope['mark']
ROOT=round.ROOT
for variant,parent in [('beforeprobe','baseline'),('afterprobe','final')]:
    project=ROOT/(variant+'-project')
    assert not project.exists()
    shutil.copytree(ROOT/(parent+'-project'),project)
    patches=[]
    methods={'game/life/public_areas.gd':['_decision_signature']+(['_queue_signature_view'] if parent=='final' else []),
        'game/clinic/hospital_visitors.gd':['dispatch']}
    for relative,names in methods.items():
        original=(project/relative).read_bytes().decode('utf-8')
        generated=original
        replacements=[]
        for name in names:
            generated,patch=instrument(generated,name,relative.rsplit('/',1)[-1]+'.'+name)
            if name=='_decision_signature':
                replacement=patch['generated']
                start='\tvar queue: Array = []'
                finish='\tvar sorted_ids: Array = other_ids.keys()'
                assert replacement.count(start)==replacement.count(finish)==1
                replacement=replacement.replace(start,'\tvar _queue_probe_started: int = Time.get_ticks_usec() if _waiting_probe_started>0 else 0\n'+start,1)
                replacement=replacement.replace(finish,mark('signature.queue').replace('_waiting_probe_started','_queue_probe_started')+finish,1)
                generated=generated.replace(patch['generated'],replacement,1)
                patch['generated']=replacement
            replacements.append(patch)
        restored=generated
        for patch in reversed(replacements):restored=restored.replace(patch['generated'],patch['original'],1)
        assert restored==original
        (project/relative).write_bytes(generated.encode('utf-8'))
        patches.append(dict(path=relative,replacements=replacements,inverse_equal=True))
    rows=[dict(path=x['path'],sha256=round.sha(project/x['path'])) for x in round.read(ROOT/(parent+'-identity.json'))['sources']]
    round.write(ROOT/(variant+'-identity.json'),dict(sources=rows,patches=patches,diagnostic_only=True,formal_pass=False))
    print(json.dumps(dict(prepared=variant)),flush=True)
for variant,label in [('beforeprobe','beforeprobe01'),('afterprobe','afterprobe01')]:
    round.measure(SimpleNamespace(variant=variant,label=label,window='gp80'))
