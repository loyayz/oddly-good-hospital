from pathlib import Path
import importlib.util
from types import SimpleNamespace
path=Path(__file__).with_name('queue_view_round.py')
spec=importlib.util.spec_from_file_location('queue_view_final',path)
round=importlib.util.module_from_spec(spec)
spec.loader.exec_module(round)
for variant,label,window in [
    ('final','b2','gp80'),('baseline','a3','gp80'),
    ('baseline','a1','public360'),('final','b1','public360'),('baseline','a2','public360'),
    ('baseline','a1','operations40'),('final','b1','operations40'),
]:round.measure(SimpleNamespace(variant=variant,label=label,window=window))
