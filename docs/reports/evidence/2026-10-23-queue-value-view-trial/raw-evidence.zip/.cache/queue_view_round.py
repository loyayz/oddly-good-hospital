from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import shutil
import subprocess
import sys
import time

sys.dont_write_bytecode=True
REPO=Path(__file__).resolve().parent.parent
ROOT=REPO/'.cache/queue-view-5712c6f-20261023'
PRIOR=REPO/'.cache/queue-signature-26bcc0f-20261023'
BASE=ROOT/'baseline-project'
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(path,value):
    path=Path(path)
    assert not path.exists(),path
    path.write_bytes((json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
def module(path,name):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod
def prepare(variant):
    started=time.perf_counter()
    ROOT.mkdir(exist_ok=True)
    target=ROOT/(variant+'-project')
    assert not target.exists()
    original=PRIOR/'occupiedfinal-project' if variant=='baseline' else BASE
    shutil.copytree(original,target)
    previous=read(PRIOR/'occupiedfinal-identity.json') if variant=='baseline' else read(ROOT/'baseline-identity.json')
    sources=[]
    changes=[]
    for row in previous['sources']:
        path=row['path']
        assert sha(original/path)==row['sha256'],path
        if path not in ['project.godot','export_presets.cfg']:
            if variant=='baseline':assert sha(REPO/path)==row['sha256'],path
            if sha(REPO/path)!=row['sha256']:changes.append(path)
            shutil.copy2(REPO/path,target/path)
        sources.append(dict(path=path,sha256=sha(target/path)))
    tests=[]
    for path in subprocess.check_output(['git','ls-files','tests'],cwd=REPO,text=True).splitlines():
        if (REPO/path).is_file():
            shutil.copy2(REPO/path,target/path)
            tests.append(dict(path=path,sha256=sha(target/path)))
    write(ROOT/(variant+'-identity.json'),dict(sources=sources,tests=tests,changes=changes,
        workspace_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip(),
        preparation_wall_ms=(time.perf_counter()-started)*1000,diagnostic_only=True,formal_pass=False,runtime_caches_restored=False))
    print(json.dumps(dict(prepared=variant,sources=len(sources),tests=len(tests),changes=changes)),flush=True)
def measure(args):
    project=ROOT/(args.variant+'-project')
    identity=read(ROOT/(args.variant+'-identity.json'))
    for row in identity['sources']:assert sha(project/row['path'])==row['sha256'],row['path']
    launch=module(REPO/'.cache/wait-signature-031e1f7-20261022/run.py','queue_view_launcher')
    launch.ROOT=ROOT
    if args.window=='functional':
        for row in identity['tests']:assert sha(project/row['path'])==row['sha256'],row['path']
        prefix=ROOT/args.label
        launch.launch(['--headless','--path',project,'--script','res://tests/acceptance/runner.gd','--','staff',
            '--case=STAFF-48','--case=STAFF-49','--case=STAFF-57','--case=STAFF-69','--case=STAFF-70','--case=STAFF-71'],prefix)
        actual=read(project/'acceptance-results.json')
        write(ROOT/(args.label+'.acceptance-results.json'),actual)
        print(json.dumps(dict(checks=actual['checks'],failed=actual['failed'],cases={k:dict(passed=v['passed'],body_ms=v['body_ms'],setup_ms=v['setup_ms']) for k,v in actual['results'].items()})),flush=True)
        assert actual['completed'] and actual['checks']==6 and actual['failed']==0
        return
    filename,steps=launch.WINDOWS[args.window]
    source_input=REPO/'.cache/task-navigation-20261019'/filename
    output=ROOT/(args.label+'-'+args.window+'.json')
    profile='root' if args.variant.endswith('probe') else 'plain'
    write(output.with_suffix('.source-check.json'),dict(actual_sources=identity['sources'],input_sha256=sha(source_input),variant=args.variant,
        runner_sha256=sha(project/'tools/performance/representative_worker.gd'),diagnostic_only=True,formal_pass=False,runtime_caches_restored=False,profile=profile))
    launch.launch(['--headless','--path',project,'--script','res://tools/performance/representative_worker.gd','--','--input='+str(source_input),
        '--output='+str(output),'--steps='+str(steps),'--profile='+profile],output)
    actual=read(output)
    expected=read(PRIOR/(('e3-' if args.window=='gp80' else 'e1-')+args.window+'.json'))
    checks=dict(complete=actual['complete'],qualified=actual['qualified'],errors_empty=not actual['errors'])
    for key in ['source_input_sha256','initial','final','qualification','operations','event_records','final_binary_sha256']:
        checks[key]=actual.get(key)==expected.get(key)
    ap,bp=actual['public'].copy(),expected['public'].copy()
    ac,bc=ap.pop('query_counts'),bp.pop('query_counts')
    checks['public_business']=ap==bp
    differences={k:dict(actual=ac.get(k),expected=bc.get(k)) for k in ac.keys()|bc.keys() if ac.get(k)!=bc.get(k)}
    checks['all_original_counts_equal']=all(k.startswith(('public_wait_queue_view_','diag_wait/')) for k in differences)
    checks['non_timing_samples']=[{k:v for k,v in x.items() if k!='elapsed_us'} for x in actual['samples']]==[{k:v for k,v in x.items() if k!='elapsed_us'} for x in expected['samples']]
    worker=actual['worker_sample']
    checks['workers_complete']=worker['batches']==steps and worker['processed']==worker['consumed'] and worker['failed_batches']==0
    if profile=='root':checks['all_stage_records']=actual['profile']['steps']==steps and actual['profile']['step_records_complete'] and not actual['profile']['errors']
    summary=dict(passed=all(checks.values()),checks=checks,metrics=actual['metrics'],new_counts={k:v for k,v in ac.items() if k.startswith('public_wait_queue_view_')},
        probes={k:v for k,v in ac.items() if k.startswith('diag_wait/')},all_query_count_differences=differences)
    write(output.with_suffix('.semantic-check.json'),summary)
    print(json.dumps(summary),flush=True)
    assert all(checks.values())
if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('action',choices=['prepare','measure'])
    parser.add_argument('--variant',default='baseline')
    parser.add_argument('--label',default='a1')
    parser.add_argument('--window',default='gp80')
    args=parser.parse_args()
    if args.action=='prepare':prepare(args.variant)
    else:measure(args)
