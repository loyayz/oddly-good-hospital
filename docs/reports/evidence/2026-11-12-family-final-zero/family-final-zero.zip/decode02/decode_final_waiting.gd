extends SceneTree
func _initialize() -> void:
	var args:=OS.get_cmdline_user_args()
	var input: Dictionary=FileAccess.open(args[2],FileAccess.READ).get_var(false)
	var original: Dictionary=input
	input=original.get("facts",{})
	var exported: Dictionary={"source_top_keys":original.keys(),"visitor_ids":original.get("visitor_ids",[])}
	for key: String in ["sim_tick","rng","ward_stays","visitors","visits","actors","moves","sessions"]:
		exported[key]=input.get(key,{})
	# Complete original dictionaries preserve empty final state and referenced
	# records. No simulation, ensure, query, random draw, or inferred history.
	FileAccess.open(args[1]+"/decoded.json",FileAccess.WRITE).store_string(JSON.stringify(exported,"  "))
	FileAccess.open(args[1]+"/keys.json",FileAccess.WRITE).store_string(JSON.stringify(input.keys()))
	quit(0)
