"""Fixed candidate03 plain batch. --check-only is entirely read-only; no engine/import."""
import argparse
import hashlib
import importlib
import json
from pathlib import Path
import sys
import threading
import time
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / ".cache/performance160-clinical-family-20261112-candidate03"
PROJECT = BASE / "project"
COMMIT = "9368fc68cb67760dd8200c60edb0fcacbee395c6"
MAP_SHA = "530a8e452cbaef51cb0071d6c5e0f459c9b3fee735ae4b9ce3fdd5c30218de3a"
IDENTITY_SHA = "5ccadf9a7b02aaf4adb47c3e94cdb8d75e1cc070a0b30a809c85cf989d4a0a3f"
AUTHORITY_SHA = "d6a5c5537beecc979cc5cfb6a3e33b045704956875140807ba5c790a15731653"
V3_INPUT_SHA = "752924c562f275804cee40cbd2a8760f8f0780cab3276a04330db63a2866e780"
MIXED_INPUT_SHA = "75f5e1d922f39f12382c0ceb74806bda0293251189f68a1ac158842f65fa78ca"
FULL_SHA = "0daf82b82da618af8818aed962d5ef2bf9bad1b00be01c4f5a7ce71efb52662e"
KNOWN_UNCOVERED = ["examination", "maintenance", "upgrade", "effective_ward_visit", "completed_examination"]
EXPECTED_TARGETS = {"sim_step_p95_ms": 10, "sim_step_p99_ms": 15,
                    "sim_step_ordinary_max_ms": 30, "sim_speed_ratio_min": 0.99}
sys.dont_write_bytecode = True


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def write(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def preflight(output):
    """Validate the actual standard freeze schema and every fixed source byte."""
    assert output.is_relative_to(ROOT / ".cache") and not output.exists(), "Use a new .cache output directory"
    freeze = read(BASE / "freeze.json")
    identity = read(PROJECT / "source-identity.json")
    authority = read(BASE / "profiler-authority.json")
    assert freeze["commit"] == identity["head"] == authority["head"] == COMMIT
    assert Path(freeze["project"]).resolve() == PROJECT == Path(authority["production_stage"]).resolve()
    assert Path(identity["project"]).resolve() == PROJECT
    assert freeze["all_git_blobs_verified"] is True and freeze["overlays"] == {}
    source = freeze["source"]
    assert len(source) == freeze["source_count"] == 2350
    assert len({path.casefold() for path in source}) == len(source), "Case-colliding source inventory"
    assert read(PROJECT / "source-inventory.json") == list(source)
    assert digest(PROJECT / "source-inventory.json") == freeze["source_inventory_file_sha256"]
    assert {row["path"]: row["sha256"] for row in identity["source"]} == source
    assert len(identity["source"]) == len(source)
    source_map_sha = hashlib.sha256(json.dumps(source, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    assert source_map_sha == freeze["source_map_sha256"] == identity["source_map_sha256"] == authority["source_map_sha256"] == MAP_SHA
    assert digest(PROJECT / "source-identity.json") == freeze["stage_identity_sha256"] == authority["stage_identity_sha256"] == IDENTITY_SHA
    assert digest(BASE / "profiler-authority.json") == freeze["authority_sha256"] == AUTHORITY_SHA
    for name, expected in source.items():
        path = (PROJECT / name).resolve()
        assert path.is_relative_to(PROJECT) and path.is_file() and digest(path) == expected, f"Frozen source changed: {name}"
    assert all(source[name] == value for name, value in authority["production_source"].items())
    assert (PROJECT / ".godot/global_script_class_cache.cfg").is_file(), "Validated class cache missing; do not silently import"
    assert all((PROJECT / path).is_file() and digest(PROJECT / path) == value for path, value in freeze["cache_source_files"].items()), "Prepared resource cache changed"
    assert Path(freeze["original_input"]).resolve() == Path(authority["input"]).resolve()
    assert freeze["original_input_sha256"] == authority["input_sha256"] == MIXED_INPUT_SHA
    assert freeze["reference_v3_input_sha256"] == authority["reference_v3_input_sha256"] == V3_INPUT_SHA
    assert Path(freeze["reference_v3_input"]).resolve() == Path(authority["reference_v3_input"]).resolve()
    assert freeze["primary_scenario"] == authority["scenario"] == "mixed160-clinical-ops-v1"
    for name, expected in (("original_input", MIXED_INPUT_SHA), ("reference_v3_input", V3_INPUT_SHA)):
        assert digest(Path(freeze[name])) == expected, f"Fixed input changed: {name}"
    native = {path.name: digest(path) for path in (PROJECT / "game/platform/windows/bin").glob("*.dll")}
    assert len(native) == 5 and native == freeze["native"] == identity["native"] == authority["native"]
    assert native["oddly_good_platform.windows.x86_64.dll"] == "89d4e1db54ca8a52ee2ed7da5b5fdcc1917c0667d172ab89d2fe683bc1767af2"
    engine = Path(authority["engine"])
    actual = engine.with_name(engine.stem.removesuffix("_console") + engine.suffix)
    executables = {str(path): digest(path) for path in (engine, actual)}
    assert len(executables) == 2 and executables == freeze["engine_executables"] == identity["engine_executables"] == authority["engine_executables"]
    assert digest(engine) == identity["engine_sha256"] and str(engine) == identity["engine"]
    targets = read(PROJECT / "docs/data/balance.json")["performance_targets"]["metrics"]
    assert {key: targets[key] for key in EXPECTED_TARGETS} == EXPECTED_TARGETS
    # Import only already-hash-validated frozen helpers, never the changing parent checkout.
    sys.path.insert(0, str(PROJECT / "tools/performance/current"))
    campaign = importlib.import_module("campaign160")
    guard = importlib.import_module("prepare_builtin_script_profile")
    assert Path(campaign.__file__).resolve().is_relative_to(PROJECT)
    assert Path(guard.__file__).resolve().is_relative_to(PROJECT)
    assert campaign.native_identity(PROJECT) == native and campaign.engine_identity(engine) == executables
    assert campaign.source_identity(PROJECT) == {name: value for name, value in source.items() if not name.endswith(".gd.uid")}
    return freeze, campaign, guard, targets


def plan(freeze, campaign, output):
    tasks = [
        ("smoke-v3", "comprehensive160-clinical-family-v3", "reference_v3_input", V3_INPUT_SHA,
         "f332ee5b20de51ece182f79866f5780d4792652bdb8169e0b3d9900e5af091d7", True),
        ("smoke-mixed", "mixed160-clinical-ops-v1", "original_input", MIXED_INPUT_SHA,
         "21aff2546935022312333b67605680c491292575aaa845b07733db993a415a51", True),
    ] + [(f"mixed-r{repeat}", "mixed160-clinical-ops-v1", "original_input", MIXED_INPUT_SHA, FULL_SHA, False)
         for repeat in (1, 2, 3)]
    engine = Path(read(BASE / "profiler-authority.json")["engine"])
    rows = []
    for name, scenario, input_key, input_sha, expected, smoke in tasks:
        directory, prefix, steps = output / name, 0 if smoke else 1000, 2 if smoke else 6000
        result = directory / "r1.json"
        args = SimpleNamespace(main_thread_policy="app", worker_tasks=4, scenario=scenario,
                               profile_stages=False, require_coverage=not smoke, smoke=smoke)
        command = campaign.build_engine_command(PROJECT, engine, Path(freeze[input_key]), result, prefix, steps, args)
        assert not any("profile" in item or "diagnostic" in item for item in command), "A plain command has an active probe"
        assert command.count("--require-coverage") == int(not smoke)
        rows.append({"name": name, "scenario": scenario, "input": freeze[input_key], "input_sha256": input_sha,
                     "expected_final_sha256": expected, "smoke": smoke, "prefix_steps": prefix,
                     "sample_steps": steps, "directory": str(directory), "result": str(result),
                     "timeout_seconds": 120 if smoke else 1800, "command": command})
    return rows


def latest_complete(path):
    if not path.is_file():
        return None
    with path.open("rb") as stream:
        stream.seek(max(0, path.stat().st_size - 16384))
        tail = stream.read(16384)
    for line in reversed(tail.splitlines()):
        try:
            row = json.loads(line)
            if row.get("kind") == "complete":
                return row["sample"]
        except (ValueError, KeyError):
            pass
    return None


def heartbeat(stop, task):
    started = time.monotonic()
    while not stop.wait(30):
        sample = latest_complete(Path(task["result"] + ".steps.ndjson"))
        print(json.dumps({"heartbeat": task["name"], "elapsed_seconds": round(time.monotonic() - started, 1),
                          "latest_complete": sample}), flush=True)


def validate_steps(result, data, total):
    completed, entered = 0, 0
    with Path(str(result) + ".steps.ndjson").open(encoding="utf-8-sig") as stream:
        for line in stream:
            row = json.loads(line)
            if row["kind"] == "enter":
                assert row["index"] == entered and row["tick"] == data["initial"]["tick"] + entered
                entered += 1
            else:
                assert row["kind"] == "complete" and row["sample"]["index"] == completed
                assert row["sample"]["tick"] == data["initial"]["tick"] + completed + 1
                completed += 1
    assert entered == completed == total, "Actual step stream incomplete"
    return {"entered": entered, "completed": completed, "sha256": digest(Path(str(result) + ".steps.ndjson"))}


def execute_task(task, guard, campaign, freeze, targets):
    directory, result = Path(task["directory"]), Path(task["result"])
    stop = threading.Event()
    watcher = threading.Thread(target=heartbeat, args=(stop, task), daemon=True)
    watcher.start()
    try:
        process = guard.run_process(task["command"], PROJECT, directory, task["timeout_seconds"], (0,) if task["smoke"] else (0, 1))
    finally:
        stop.set()
        watcher.join(timeout=2)
    data, execution = read(result), read(Path(str(result) + ".execution.json"))
    assert data["source_input_sha256"] == task["input_sha256"]
    assert data["requested_prefix_steps"] == task["prefix_steps"] and data["requested_sample_steps"] == task["sample_steps"]
    assert data["all_completed_steps"] == task["prefix_steps"] + task["sample_steps"] and data["metrics"]["count"] == task["sample_steps"]
    assert data["final"]["tick"] - data["initial"]["tick"] == data["all_completed_steps"]
    assert digest(Path(str(result) + ".final.bin")) == data["final_sha256"] == task["expected_final_sha256"], "Full World/ordered events changed"
    assert data["initial"]["population"]["present"] == 160
    assert data["initial"]["population"]["patients"] == 128 and data["initial"]["population"]["staff"] == 32
    comprehensive = data["sample_business"]["comprehensive"]
    assert comprehensive["scenario"] == task["scenario"] and comprehensive["invariant_failure_counts"] == {}
    assert execution["main_thread_policy"]["requested"] == "app" and execution["main_thread_policy"]["applied"]
    assert execution["worker_tasks"] == 4 and execution["profile_stages"] is False
    assert execution["worker_samples"]["diagnostics_enabled"] is False
    assert not list(directory.glob("*.stages.json")) and not list(directory.glob("*.builtin-profile.json"))
    step_stream = validate_steps(result, data, task["prefix_steps"] + task["sample_steps"])
    validation = None
    if task["smoke"]:
        assert data["complete"] is True and data["errors"] == [] and process["returncode"] == 0
        cpu, dense_checks = None, []
    else:
        validation = guard.validate_diagnostic_witness(result, task["input_sha256"])
        assert validation["uncovered"] == KNOWN_UNCOVERED and validation["coverage_pass"] is False, "Different coverage result"
        assert data["errors"] == [guard.COVERAGE_FAILURE] and process["returncode"] == 1
        dense = data["metrics"]["dense_intervals"]
        assert dense["threshold_present"] == 144 and dense["minimum_qualified_samples"] == 1000
        assert dense["has_qualified_segment"] is True and any(row["sample_count_qualified"] for row in dense["segments"])
        dense_checks = []
        for interval in dense["segments"]:
            assert interval["sample_count_qualified"] == (interval["metrics"]["count"] >= 1000)
            assert interval["metrics"]["count"] == interval["last_index"] - interval["first_index"] + 1
            assert interval["metrics"]["present_population"]["minimum"] >= 144
            dense_checks.append({"first_index": interval["first_index"], "last_index": interval["last_index"],
                                 "count": interval["metrics"]["count"], "sample_count_qualified": interval["sample_count_qualified"],
                                 "checks": campaign.target_checks(interval["metrics"], targets)})
        cpu = campaign.target_checks(data["metrics"], targets)
        cpu["dense_interval_samples"] = dense["has_qualified_segment"]
        cpu["dense_interval_targets"] = bool(dense_checks) and all(all(row["checks"].values()) for row in dense_checks)
    # Source comparison is independent of the driver's complete/coverage flags.
    for name, expected in freeze["source"].items():
        assert digest(PROJECT / name) == expected, f"Source changed after {task['name']}: {name}"
    assert campaign.native_identity(PROJECT) == freeze["native"]
    assert campaign.engine_identity(Path(task["command"][0])) == freeze["engine_executables"]
    assert digest(Path(task["input"])) == task["input_sha256"]
    row = {"name": task["name"], "smoke": task["smoke"], "process": process,
           "requested_prefix_steps": task["prefix_steps"], "requested_sample_steps": task["sample_steps"],
           "step_stream": step_stream, "input_sha256": task["input_sha256"],
           "final_sha256": data["final_sha256"], "result_sha256": digest(result),
           "source_native_engine_input_post_unchanged": True, "metrics": data["metrics"],
           "wall_us": {key: data[key] for key in ("prefix_wall_us", "all_wall_us", "initialization_us")},
           "execution": execution, "errors": data["errors"], "diagnostic_witness": validation,
           "cpu_targets": {"checks": cpu, "pass": all(cpu.values()) if cpu else None, "dense": dense_checks},
           "business_coverage": {"pass": comprehensive["coverage_pass"], "uncovered": comprehensive["uncovered"],
                                 "coverage": comprehensive["coverage"], "invariant_failure_counts": comprehensive["invariant_failure_counts"],
                                 "sample": comprehensive["sample"], "prefix": comprehensive["prefix"]},
           "qualified": False, "scope": "Smoke has no performance claim. Full CPU measurements retain the known original business coverage failure."}
    write(directory / "checked-result.json", row)
    return row


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check-only", action="store_true")
    parser.add_argument("--output", type=Path, default=BASE / "plain-batch01")
    args = parser.parse_args()
    output = args.output.resolve()
    freeze, campaign, guard, targets = preflight(output)
    tasks = plan(freeze, campaign, output)
    protocol = {"controller_sha256": digest(Path(__file__)), "commit": COMMIT, "project": str(PROJECT),
                "source_count": len(freeze["source"]), "source_map_sha256": MAP_SHA,
                "freeze_sha256": digest(BASE / "freeze.json"), "source_identity_sha256": IDENTITY_SHA,
                "authority_sha256": AUTHORITY_SHA, "source": freeze["source"], "native": freeze["native"],
                "engine_executables": freeze["engine_executables"], "cpu_targets": EXPECTED_TARGETS,
                "main_thread_policy": "app", "worker_tasks": 4, "OMP_NUM_THREADS": "1", "profile_stages": False,
                "fresh_processes": True, "os_caches_retained": True, "source_transforms": [], "tasks": tasks}
    if args.check_only:
        print(json.dumps({"check_only": True, "ok": True, "created_output": False, "engine_started": False,
                          "controller_sha256": protocol["controller_sha256"], "source_count": len(freeze["source"]),
                          "source_map_sha256": MAP_SHA, "output": str(output), "tasks": tasks}, ensure_ascii=False, indent=2))
        return
    assert not campaign.processes(), "Engine/build slot is occupied"
    output.mkdir(parents=True, exist_ok=False)
    write(output / "protocol.json", protocol)
    results = []
    try:
        for task in tasks:
            write(output / "status.json", {"state": "running", "task": task["name"], "completed": len(results)})
            print(json.dumps({"start": task["name"], "command": task["command"]}), flush=True)
            row = execute_task(task, guard, campaign, freeze, targets)
            results.append(row)
            write(output / "summary.json", {"completed_tasks": results, "qualified": False, "complete_batch": False})
            print(json.dumps({"finished": row["name"], "process_wall_seconds": row["process"]["process_wall_seconds"],
                              "cpu_targets": row["cpu_targets"]["checks"], "business_coverage": row["business_coverage"]["pass"],
                              "uncovered": row["business_coverage"]["uncovered"], "final_sha256": row["final_sha256"]}), flush=True)
        measurements = [row for row in results if not row["smoke"]]
        assert len(measurements) == 3
        summary = {"complete_batch": True, "qualified": False, "completed_tasks": results,
                   "three_round_cpu_targets_pass": all(row["cpu_targets"]["pass"] for row in measurements),
                   "three_round_business_coverage_pass": False,
                   "scope": "Three same-input CPU measurements; known coverage failure is retained. Different scenarios are not compared for optimization benefit."}
        write(output / "summary.json", summary)
        write(output / "status.json", {"state": "complete", "completed": len(results), "qualified": False})
    except BaseException as error:
        write(output / "status.json", {"state": "stopped_on_new_error", "completed": len(results),
                                       "error_type": type(error).__name__, "error": str(error)})
        raise


if __name__ == "__main__":
    main()
