"""Archive completed candidate03 plain evidence; no runtime or source mutation."""
import hashlib
import json
from pathlib import Path
import statistics
import zipfile
import zlib

ROOT = Path(__file__).resolve().parent.parent
BASE = ROOT / ".cache/performance160-clinical-family-20261112-candidate03"
BATCH = BASE / "plain-batch01"
EVIDENCE = ROOT / "docs/reports/evidence/2026-11-12-clinical-performance"
SUMMARY = EVIDENCE / "mixed-b03-summary.json"
ARCHIVE = EVIDENCE / "mixed-b03-unqualified.zip"
MANIFEST = EVIDENCE / "mixed-b03-manifest.json"
COMMIT = "9368fc68cb67760dd8200c60edb0fcacbee395c6"
INPUT_SHA = "75f5e1d922f39f12382c0ceb74806bda0293251189f68a1ac158842f65fa78ca"
FINAL_SHA = "0daf82b82da618af8818aed962d5ef2bf9bad1b00be01c4f5a7ce71efb52662e"
UNCOVERED = ["examination", "maintenance", "upgrade", "effective_ward_visit", "completed_examination"]


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def encoded(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def member_reference(archive, member, expected_sha, archive_sha=None):
    identity = sha(archive)
    if archive_sha:
        assert identity == archive_sha
    with zipfile.ZipFile(archive) as package:
        item = package.getinfo(member)
        data = package.read(member)
        assert hashlib.sha256(data).hexdigest() == expected_sha
        assert zlib.crc32(data) == item.CRC
    return {"archive": archive.relative_to(ROOT).as_posix(), "archive_sha256": identity, "member": member,
            "member_sha256": expected_sha, "member_bytes": item.file_size, "member_crc32": f"{item.CRC:08x}"}


def main():
    assert all(not path.exists() for path in (SUMMARY, ARCHIVE, MANIFEST)), "Never rewrite an archived result"
    freeze, identity, protocol = read(BASE / "freeze.json"), read(BASE / "project/source-identity.json"), read(BATCH / "protocol.json")
    batch, status = read(BATCH / "summary.json"), read(BATCH / "status.json")
    assert freeze["commit"] == identity["head"] == protocol["commit"] == COMMIT
    assert freeze["source_count"] == protocol["source_count"] == len(freeze["source"]) == 2350
    assert freeze["source"] == protocol["source"] == {row["path"]: row["sha256"] for row in identity["source"]}
    assert freeze["overlays"] == {} and freeze["all_git_blobs_verified"] and protocol["source_transforms"] == []
    assert freeze["native"] == identity["native"] == protocol["native"]
    assert freeze["native"]["oddly_good_platform.windows.x86_64.dll"] == "89d4e1db54ca8a52ee2ed7da5b5fdcc1917c0667d172ab89d2fe683bc1767af2"
    assert freeze["engine_executables"] == identity["engine_executables"] == protocol["engine_executables"]
    assert sha(BASE / "freeze.json") == protocol["freeze_sha256"]
    assert sha(BASE / "project/source-identity.json") == protocol["source_identity_sha256"] == freeze["stage_identity_sha256"]
    assert sha(BASE / "profiler-authority.json") == protocol["authority_sha256"] == freeze["authority_sha256"]
    assert sha(ROOT / ".cache/run_candidate03_plain_batch.py") == protocol["controller_sha256"]
    assert batch["complete_batch"] and batch["qualified"] is False and status == {"state": "complete", "completed": 5, "qualified": False}
    assert not batch["three_round_cpu_targets_pass"] and not batch["three_round_business_coverage_pass"]
    final_reference = member_reference(EVIDENCE / "mixed-b01-unqualified.zip", "run/r1.json.final.bin", FINAL_SHA,
                                       "4990bead51f8614dfcdf3d08d8deef5ddda477ae8d90dbc9af7ad15597c7ed0a")
    input_reference = member_reference(EVIDENCE / "mixed-toolqualification.zip", "qualification/mixed-input01/mixed160.input.bin", INPUT_SHA)
    v3_input_reference = member_reference(EVIDENCE / "mixed-toolqualification.zip", "inputs/original-v3-752924c5.input.bin", freeze["reference_v3_input_sha256"])
    smoke_references = {
        "smoke-v3": member_reference(EVIDENCE / "mixed-toolqualification.zip", "qualification/v3-smoke01/r1.json.final.bin", "f332ee5b20de51ece182f79866f5780d4792652bdb8169e0b3d9900e5af091d7"),
        "smoke-mixed": member_reference(EVIDENCE / "mixed-toolqualification.zip", "qualification/mixed-smoke01/r1.json.final.bin", "21aff2546935022312333b67605680c491292575aaa845b07733db993a415a51"),
    }
    tasks = batch["completed_tasks"]
    assert [task["name"] for task in tasks] == ["smoke-v3", "smoke-mixed", "mixed-r1", "mixed-r2", "mixed-r3"]
    rounds, smokes = [], []
    common_business = None
    for task in tasks:
        directory = BATCH / task["name"]
        raw, checked, process = read(directory / "r1.json"), read(directory / "checked-result.json"), read(directory / "process.json")
        assert checked == task and checked["result_sha256"] == sha(directory / "r1.json")
        assert sha(directory / "r1.json.steps.ndjson") == task["step_stream"]["sha256"]
        assert sha(directory / "engine.log") == process["log_sha256"]
        assert checked["source_native_engine_input_post_unchanged"] is True and checked["qualified"] is False
        assert checked["execution"]["profile_stages"] is False and checked["execution"]["worker_samples"]["diagnostics_enabled"] is False
        assert checked["execution"]["main_thread_policy"]["requested"] == "app" and checked["execution"]["main_thread_policy"]["applied"]
        assert checked["execution"]["worker_tasks"] == 4 and process["environment_overrides"]["OMP_NUM_THREADS"] == "1"
        assert raw["sample_business"]["comprehensive"]["invariant_failure_counts"] == {}
        assert raw["metrics"] == checked["metrics"]
        expected_final = smoke_references[task["name"]]["member_sha256"] if task["smoke"] else FINAL_SHA
        assert sha(directory / "r1.json.final.bin") == raw["final_sha256"] == checked["final_sha256"] == expected_final
        if task["smoke"]:
            assert raw["complete"] and raw["errors"] == [] and process["returncode"] == 0
            assert raw["all_completed_steps"] == raw["metrics"]["count"] == 2 and raw["requested_prefix_steps"] == 0
            smokes.append({"name": task["name"], "prefix_steps": 0, "sample_steps": 2, "process_wall_seconds": process["process_wall_seconds"],
                           "returncode": 0, "complete": True, "errors": [], "input_sha256": raw["source_input_sha256"],
                           "final_sha256": expected_final, "final_reference": smoke_references[task["name"]], "scope": "Entry/result equivalence only; no CPU or complete business-coverage claim."})
            continue
        comp = raw["sample_business"]["comprehensive"]
        metrics = raw["metrics"]
        assert raw["source_input_sha256"] == INPUT_SHA and raw["all_completed_steps"] == 7000 and metrics["count"] == 6000
        assert raw["requested_prefix_steps"] == 1000 and raw["requested_sample_steps"] == 6000
        assert task["step_stream"]["entered"] == task["step_stream"]["completed"] == 7000
        assert raw["complete"] is False and process["returncode"] == 1 and raw["errors"] == ["Comprehensive workload did not satisfy its business coverage contract"]
        assert comp["uncovered"] == UNCOVERED and comp["coverage_pass"] is False
        checks = checked["cpu_targets"]["checks"]
        assert checks["p95"] is False and checks["p99"] is False and checks["ordinary_maximum"] is False and checks["speed_1x_including_observation"] is True
        assert metrics["dense_intervals"]["dense_sample_count"] == 6000 and metrics["present_population"] == {"minimum":165,"maximum":171,"median":166}
        assert raw["prefix_wall_us"] + metrics["real_window_us_including_observation"] == raw["all_wall_us"]
        sample = comp["sample"]
        business = {"coverage": comp["coverage"], "covered_count": sum(value["covered"] for value in comp["coverage"].values()),
                    "coverage_count": len(comp["coverage"]), "uncovered": comp["uncovered"], "coverage_pass": False,
                    "invariant_failure_counts": {}, "sample_work": sample["work"],
                    "sample_completed_services": {key: value for key, value in sample["events"].items() if key.startswith("service_completed:")},
                    "new_attempts": sample["new_attempts"], "consumed_units": sample["consumed_units"], "purchased_units": sample["purchased_units"],
                    "purchase_receipts": sample["ledger"].get("supply_purchase",{}), "sample_events": sample["events"]}
        if common_business is None:
            common_business = business
        assert business == common_business
        rounds.append({"name": task["name"], "initial_tick": raw["initial"]["tick"], "final_tick": raw["final"]["tick"],
                       "prefix_steps": 1000, "sample_steps": 6000, "completed_steps": 7000, "raw_complete": False, "returncode": 1,
                       "qualified": False, "errors": raw["errors"], "metrics": metrics, "cpu_checks": checks,
                       "prefix_wall_us": raw["prefix_wall_us"], "sample_wall_us": metrics["real_window_us_including_observation"],
                       "all_wall_us": raw["all_wall_us"], "initialization_us": raw["initialization_us"], "process_wall_seconds": process["process_wall_seconds"],
                       "final_sha256": expected_final, "result_sha256": sha(directory / "r1.json"), "checked_result_sha256": sha(directory / "checked-result.json")})
    baseline = read(EVIDENCE / "mixed-b01-summary.json")
    assert baseline["source_input_sha256"] == INPUT_SHA and baseline["native"] == freeze["native"] and baseline["final_world_and_ordered_events_sha256"] == FINAL_SHA
    with zipfile.ZipFile(EVIDENCE / "mixed-b01-unqualified.zip") as package:
        baseline_bytes = package.read("run/r1.json")
        assert hashlib.sha256(baseline_bytes).hexdigest() == baseline["result_sha256"]
        baseline_raw = json.loads(baseline_bytes)
    baseline_metrics = baseline["metrics"]
    comparison = {"baseline": "mixed B01, one plain measurement", "baseline_summary_sha256": sha(EVIDENCE / "mixed-b01-summary.json"),
                  "baseline_source_commit": baseline["source_commit"], "baseline_mean_step_us": baseline_metrics["mean_step_us"],
                  "baseline_sample_wall_us": baseline_metrics["real_window_us_including_observation"], "baseline_p95_us": baseline_metrics["p95_us"],
                  "baseline_p99_us": baseline_metrics["p99_us"], "baseline_max_us": baseline_metrics["max_us"],
                  "baseline_prefix_wall_us": baseline_raw["prefix_wall_us"], "baseline_raw_result_sha256": baseline["result_sha256"],
                  "mean_step_change_percent": [(row["metrics"]["mean_step_us"] / baseline_metrics["mean_step_us"] - 1) * 100 for row in rounds],
                  "sample_wall_change_percent": [(row["sample_wall_us"] / baseline_metrics["real_window_us_including_observation"] - 1) * 100 for row in rounds],
                  "three_run_mean_step_us": statistics.mean(row["metrics"]["mean_step_us"] for row in rounds),
                  "three_run_mean_sample_wall_us": statistics.mean(row["sample_wall_us"] for row in rounds),
                  "scope": "Same mixed input and final World/events, same native/engine/settings. Combined implementation and run variation only; no per-patch attribution, no comparison with the different v3 workload."}
    summary = {"source_commit": COMMIT, "source_count": 2350, "source_map_sha256": freeze["source_map_sha256"],
               "stage_identity_sha256": freeze["stage_identity_sha256"], "freeze_sha256": sha(BASE / "freeze.json"), "authority_sha256": sha(BASE / "profiler-authority.json"),
               "source_transforms": [], "native": freeze["native"], "engine_executables": freeze["engine_executables"],
               "input_reference": input_reference, "reference_v3_input": v3_input_reference, "final_reference": final_reference,
               "scenario": "mixed160-clinical-ops-v1", "main_thread_policy": "app", "worker_tasks": 4, "OMP_NUM_THREADS": "1",
               "profile_stages": False, "fresh_processes": True, "os_caches_retained": True, "complete_cpu_measurements": 3,
               "qualified_repeats": 0, "qualified": False, "three_round_cpu_targets_pass": False, "three_round_coverage_pass": False,
               "cpu_targets": protocol["cpu_targets"], "rounds": rounds, "common_sample_business": common_business,
               "comparison": comparison, "smoke": smokes, "raw_batch": str(BATCH), "archive": ARCHIVE.name,
               "scope": "Three complete 1000+6000-step plain CPU measurements; each preserves original exit 1, five coverage failures and failed latency targets. Not qualified repetitions, full regression, renderer/GPU or Release acceptance. Current dirty sources and later optimizations are excluded."}
    SUMMARY.write_bytes(encoded(summary))
    files = {"summary.json": SUMMARY, "controller/run_candidate03_plain_batch.py": ROOT / ".cache/run_candidate03_plain_batch.py"}
    files["packaging/initial-schema-error.json"] = ROOT / ".cache/archive_mixed_b03_schema01_error.json"
    files["packaging/initial-archive-script.py"] = ROOT / ".cache/archive_mixed_b03_schema01.py"
    files["packaging/baseline-path-error.json"] = ROOT / ".cache/archive_mixed_b03_schema02_error.json"
    files["packaging/baseline-path-archive-script.py"] = ROOT / ".cache/archive_mixed_b03_schema02.py"
    files["packaging/archive-script.py"] = Path(__file__)
    for name in ("protocol.json", "status.json", "summary.json"):
        files["batch/" + name] = BATCH / name
    for name, source in {"freeze.json":BASE / "freeze.json", "profiler-authority.json":BASE / "profiler-authority.json", "source-identity.json":BASE / "project/source-identity.json", "source-inventory.json":BASE / "project/source-inventory.json", "freeze.py":BASE / "freeze.py"}.items():
        files["freeze/" + name] = source
    for name in ("campaign160.py", "plain_v4.gd", "comprehensive_observer.gd", "comprehensive_operations.gd", "prepare_builtin_script_profile.py", "parse_builtin_script_profile.py"):
        relative = "tools/performance/current/" + name
        source = BASE / "project" / relative
        assert sha(source) == freeze["source"][relative]
        files["frozen-tools/" + name] = source
    for task in tasks:
        for name in ("checked-result.json", "r1.json", "r1.json.execution.json", "r1.json.initial.json", "engine.log", "process.json", "r1.json.steps.ndjson"):
            files["tasks/" + task["name"] + "/" + name] = BATCH / task["name"] / name
    metadata = {}
    with zipfile.ZipFile(ARCHIVE, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=1) as package:
        for member, source in sorted(files.items()):
            data = source.read_bytes()
            metadata[member] = {"bytes":len(data), "sha256":hashlib.sha256(data).hexdigest(), "crc32":f"{zlib.crc32(data):08x}", "source":source.relative_to(ROOT).as_posix()}
            package.writestr(member, data)
        internal = encoded({"members":metadata, "input_reference":input_reference, "reference_v3_input":v3_input_reference, "final_reference":final_reference, "smoke_final_references":smoke_references, "scope":summary["scope"]})
        metadata["manifest.json"] = {"bytes":len(internal), "sha256":hashlib.sha256(internal).hexdigest(), "crc32":f"{zlib.crc32(internal):08x}", "source":"generated archive manifest"}
        package.writestr("manifest.json", internal)
    with zipfile.ZipFile(ARCHIVE) as package:
        assert package.testzip() is None
        assert set(package.namelist()) == set(metadata)
        for member, expected in metadata.items():
            data = package.read(member)
            assert len(data) == expected["bytes"] and hashlib.sha256(data).hexdigest() == expected["sha256"]
            assert f"{zlib.crc32(data):08x}" == expected["crc32"] == f"{package.getinfo(member).CRC:08x}"
    manifest = {"archive":ARCHIVE.name, "archive_sha256":sha(ARCHIVE), "archive_bytes":ARCHIVE.stat().st_size, "member_count":len(metadata),
                "summary":SUMMARY.name, "summary_sha256":sha(SUMMARY), "members":metadata, "references":{"input":input_reference,"v3_input":v3_input_reference,"final":final_reference,"smokes":smoke_references},
                "verification":{"all_members_sha256_readback":True,"all_members_crc32_readback":True,"zip_crc_test":True}, "scope":summary["scope"]}
    MANIFEST.write_bytes(encoded(manifest))
    print(json.dumps({"summary_sha256":sha(SUMMARY),"manifest_sha256":sha(MANIFEST),"archive_sha256":sha(ARCHIVE),"archive_bytes":ARCHIVE.stat().st_size,"members":len(metadata),"comparison":comparison}, ensure_ascii=False))


if __name__ == "__main__":
    main()
