"""Offline, commit-only freeze for the next complete 160-person run."""
import argparse
import datetime
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import tarfile
import time


ROOT = Path(__file__).resolve().parent.parent
OUTPUT = ROOT / ".cache/performance160-clinical-family-20261112-candidate03"
PROJECT = OUTPUT / "project"
NATIVE_RECORD = ROOT / ".cache/resident-mask-final-identity.json"
ENGINE_RECORD = ROOT / ".cache/performance160-clinical-family-20261112-v3-candidate01/freeze.json"
CACHE_SOURCE = ROOT / ".cache/acceptance/bb1771bfc7d040ff831b35c3606d13f6"
INPUT = ROOT / ".cache/performance160-mixed-20261112-toolqualification01/mixed-input01/mixed160.input.bin"
INPUT_SHA256 = "75f5e1d922f39f12382c0ceb74806bda0293251189f68a1ac158842f65fa78ca"
REFERENCE_INPUT = ROOT / ".cache/performance160-clinical-family-20261112-v3-prep01/input01/comprehensive160.input.bin"
REFERENCE_INPUT_SHA256 = "752924c562f275804cee40cbd2a8760f8f0780cab3276a04330db63a2866e780"
NATIVE_SOURCE_COMMIT = "5ad873947669632819d9af2bcc3108f865269e50"
NATIVE_SHA256 = {
    "libgcc_s_seh-1.dll": "791ebf66e99c7c1b4ed3666468cec45a0172b4c8942ac6c84c3e9cab3e1b5270",
    "libgmp-10.dll": "c2567ccf3f410c3411ba7cd4b7ba14f393a0e70a1d0c0593297df6706b5fba96",
    "libmpfr-6.dll": "b881beb5ed7e3413283ab94f24ab25cd47ed27127774867ae105642ff2fc2e47",
    "libwinpthread-1.dll": "e765ee6109a0080a7c42848911f4349099b3c15aa734d845cb0e438f6f5a91b5",
    "oddly_good_platform.windows.x86_64.dll": "89d4e1db54ca8a52ee2ed7da5b5fdcc1917c0667d172ab89d2fe683bc1767af2",
}


def digest(path):
    with path.open("rb") as source:
        return hashlib.file_digest(source, "sha256").hexdigest()


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def git(*args):
    return subprocess.check_output(["git", "-C", str(ROOT), *args])


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def freeze(commit_argument):
    started = time.perf_counter()
    commit = git("rev-parse", "--verify", commit_argument + "^{commit}").decode().strip()
    assert re.fullmatch(r"[0-9a-f]{40,64}", commit)
    assert not OUTPUT.exists(), "A freeze/evidence directory is never overwritten"
    native = read(NATIVE_RECORD)
    assert native["native"] == NATIVE_SHA256, "Approved five-DLL authority changed"
    for name, expected in NATIVE_SHA256.items():
        assert digest(Path(native["native_directory"]) / name) == expected, name
    engines = read(ENGINE_RECORD)["engine_executables"]
    assert len(engines) == 2
    for name, expected in engines.items():
        assert digest(Path(name)) == expected, name
    engine = next(name for name in engines if Path(name).stem.endswith("_console"))
    assert digest(INPUT) == INPUT_SHA256, "Fixed complete input changed"
    assert digest(REFERENCE_INPUT) == REFERENCE_INPUT_SHA256, "Fixed original v3 reference changed"
    native_sources = {name: value for name, value in native["production_source"].items() if name.endswith((".cpp", ".h"))}
    assert len(native_sources) == 2
    assert not git("diff", "--name-only", NATIVE_SOURCE_COMMIT, commit, "--", "game/platform/windows/*.cpp", "game/platform/windows/*.h"), "Native C++ sources changed after the approved 89d build"
    assert (CACHE_SOURCE / ".godot/imported").is_dir()
    OUTPUT.mkdir()
    write(OUTPUT / "freeze-started.json", {"commit": commit, "started_utc": utc(), "engine_started": False})
    try:
        PROJECT.mkdir()
        archive_started = time.perf_counter()
        process = subprocess.Popen(["git", "-C", str(ROOT), "archive", "--format=tar", commit], stdout=subprocess.PIPE)
        try:
            with tarfile.open(fileobj=process.stdout, mode="r|") as archive:
                for member in archive:
                    target = (PROJECT / member.name).resolve()
                    assert target.is_relative_to(PROJECT), member.name
                    assert member.isdir() or member.isfile(), "No links or external archive members"
                    if member.isdir():
                        target.mkdir(parents=True, exist_ok=True)
                    else:
                        assert not target.exists(), member.name
                        target.parent.mkdir(parents=True, exist_ok=True)
                        with archive.extractfile(member) as source, target.open("wb") as destination:
                            shutil.copyfileobj(source, destination)
            assert process.wait() == 0, "git archive failed"
        except BaseException:
            if process.poll() is None:
                process.kill()
            process.wait()
            raise
        archive_seconds = time.perf_counter() - archive_started

        verification_started = time.perf_counter()
        algorithm = git("rev-parse", "--show-object-format").decode().strip()
        source, blobs = {}, {}
        for entry in git("ls-tree", "-r", "-z", commit).split(b"\0"):
            if not entry:
                continue
            header, raw_name = entry.split(b"\t", 1)
            mode, kind, oid = header.split()
            assert kind == b"blob" and mode in (b"100644", b"100755"), entry
            name = raw_name.decode("utf-8")
            path = (PROJECT / name).resolve()
            assert path.is_relative_to(PROJECT) and path.is_file(), name
            data = path.read_bytes()
            actual_blob = hashlib.new(algorithm, b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
            assert actual_blob == oid.decode(), "Commit blob mismatch: " + name
            source[name] = hashlib.sha256(data).hexdigest()
            blobs[name] = oid.decode()
        assert set(source) == {p.relative_to(PROJECT).as_posix() for p in PROJECT.rglob("*") if p.is_file()}
        assert "source-inventory.json" not in source and "source-identity.json" not in source
        for name, expected in native_sources.items():
            assert source[name] == expected, "Commit does not contain the exact approved native source: " + name
        verification_seconds = time.perf_counter() - verification_started

        cache_started = time.perf_counter()
        # A copied import cache is not a source overlay or a world/service cache.
        # Its resource inputs/settings must still equal this committed tree.
        asset_inputs = {}
        for name, expected in source.items():
            if name.startswith("assets/") or name.endswith(".import"):
                assert digest(CACHE_SOURCE / name) == expected, "Imported resource input changed: " + name
                asset_inputs[name] = expected
        shutil.copytree(CACHE_SOURCE / ".godot/imported", PROJECT / ".godot/imported")
        for name in ("global_script_class_cache.cfg", "extension_list.cfg"):
            shutil.copy2(CACHE_SOURCE / ".godot" / name, PROJECT / ".godot" / name)
        cache_source_files = {p.relative_to(CACHE_SOURCE).as_posix(): digest(p) for p in (CACHE_SOURCE / ".godot/imported").rglob("*") if p.is_file()}
        for name in ("global_script_class_cache.cfg", "extension_list.cfg"):
            relative = ".godot/" + name
            cache_source_files[relative] = digest(CACHE_SOURCE / relative)
        assert all(digest(PROJECT / name) == expected for name, expected in cache_source_files.items())
        extensions = (PROJECT / ".godot/extension_list.cfg").read_text(encoding="utf-8").splitlines()
        assert extensions
        for path in extensions:
            assert path.startswith("res://") and path[6:] in source, path
        cache_seconds = time.perf_counter() - cache_started

        destination = PROJECT / "game/platform/windows/bin"
        assert not destination.exists(), "Native binaries must not be silently overlaid on committed files"
        destination.mkdir(parents=True)
        for name, expected in NATIVE_SHA256.items():
            shutil.copy2(Path(native["native_directory"]) / name, destination / name)
            assert digest(destination / name) == expected, name
        assert all(digest(PROJECT / name) == expected for name, expected in source.items()), "A committed source changed after archive validation"
        inventory = sorted(source)
        write(PROJECT / "source-inventory.json", inventory)
        source_map_sha256 = hashlib.sha256(json.dumps(source, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode()).hexdigest()
        standard = {"head": commit, "project": str(PROJECT), "engine": engine, "engine_sha256": engines[engine],
                    "engine_executables": engines, "source": [{"path": name, "sha256": source[name]} for name in inventory],
                    "native": NATIVE_SHA256, "source_map_sha256": source_map_sha256, "scope": "Every source byte from the named Git commit; no production/tool overlays. Separate verified import cache and five native DLLs."}
        write(PROJECT / "source-identity.json", standard)
        authority = {"head": commit, "production_stage": str(PROJECT), "stage_identity_sha256": digest(PROJECT / "source-identity.json"),
                     "production_source": {name: source[name] for name in inventory if name.startswith("game/") and not name.endswith(".uid")},
                     "native": NATIVE_SHA256, "native_directory": str(destination), "engine": engine, "engine_executables": engines,
                     "input": str(INPUT), "input_sha256": INPUT_SHA256, "scenario": "mixed160-clinical-ops-v1", "reference_v3_input": str(REFERENCE_INPUT), "reference_v3_input_sha256": REFERENCE_INPUT_SHA256, "source_map_sha256": source_map_sha256,
                     "scope": "Profiler authority over this commit-only production stage; complete game source identities include the four native-source changes and all movement/navigation implementations."}
        assert all(authority["production_source"][name] == expected for name, expected in native_sources.items())
        assert "game/building/hospital_movement.gd" in authority["production_source"]
        write(OUTPUT / "profiler-authority.json", authority)
        record = {"commit": commit, "tree": git("rev-parse", commit + "^{tree}").decode().strip(), "project": str(PROJECT),
                  "source": source, "git_blobs": blobs, "git_object_algorithm": algorithm, "all_git_blobs_verified": True, "overlays": {},
                  "source_count": len(source), "source_map_sha256": source_map_sha256,
                  "source_inventory_file_sha256": digest(PROJECT / "source-inventory.json"),
                  "stage_identity_sha256": digest(PROJECT / "source-identity.json"), "authority": str(OUTPUT / "profiler-authority.json"),
                  "authority_sha256": digest(OUTPUT / "profiler-authority.json"), "native": NATIVE_SHA256,
                  "native_record": str(NATIVE_RECORD), "native_record_sha256": digest(NATIVE_RECORD), "engine_executables": engines,
                  "original_input": str(INPUT), "original_input_sha256": INPUT_SHA256,
                  "primary_scenario": "mixed160-clinical-ops-v1", "reference_v3_input": str(REFERENCE_INPUT), "reference_v3_input_sha256": REFERENCE_INPUT_SHA256,
                  "native_compiled_source_reference_commit": NATIVE_SOURCE_COMMIT, "native_compiled_sources_unchanged": True, "native_changed_header_and_registrar_sha256": native_sources,
                  "cache_source": str(CACHE_SOURCE), "cache_source_files": cache_source_files, "cache_source_files_count": len(cache_source_files),
                  "cache_asset_inputs": asset_inputs, "cache_scope": "Reuse specified completed bb1771 acceptance import: only imported resource outputs, class lookup and extension list; no editor/script-bytecode/world/service caches. Imported asset input SHA matched; no unrelated historical global class audit.",
                  "prepared_utc": utc(), "archive_seconds": archive_seconds, "git_blob_verification_seconds": verification_seconds,
                  "cache_seconds": cache_seconds, "freeze_seconds": time.perf_counter() - started, "engine_started": False, "compiled": False,
                  "freeze_script_sha256": digest(Path(__file__)), "scope": standard["scope"]}
        write(OUTPUT / "freeze.json", record)
        shutil.copy2(Path(__file__), OUTPUT / "freeze.py")
        print(json.dumps({key: record[key] for key in ("commit", "project", "source_count", "source_map_sha256", "stage_identity_sha256", "authority", "authority_sha256", "freeze_seconds", "engine_started")}), flush=True)
    except BaseException as error:
        write(OUTPUT / "freeze-failed.json", {"commit": commit, "failed_utc": utc(), "error_type": type(error).__name__, "error": str(error), "engine_started": False, "scope": "Incomplete offline freeze; preserved for diagnosis and never usable as a completed measurement source."})
        raise


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--commit", required=True, help="Exact final committed source; no working-tree overlay")
    freeze(parser.parse_args().commit)
