"""Read all evidence even when the campaign stops at its coverage assertion."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import statistics

DIRECTORY = Path(__file__).resolve().parent


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def metrics_match(rows, reported):
    if not rows:
        return reported.get("count") == 0
    values = sorted(int(row["elapsed_us"]) for row in rows)
    expected = {"count":len(rows),"sum_step_us":sum(values),"p50_us":values[math.ceil(.50*len(values))-1],"p95_us":values[math.ceil(.95*len(values))-1],"p99_us":values[math.ceil(.99*len(values))-1],"max_us":values[-1]}
    return all(reported.get(key) == value for key, value in expected.items())


def target_checks(metrics, targets):
    return {"p95":metrics["p95_us"]<=targets["sim_step_p95_ms"]*1000,"p99":metrics["p99_us"]<=targets["sim_step_p99_ms"]*1000,"ordinary_maximum":metrics["max_us"]<=targets["sim_step_ordinary_max_ms"]*1000,"speed_1x_including_observation":metrics["simulation_seconds_per_wall_second"]>=targets["sim_speed_ratio_min"]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--smoke", action="store_true")
    parser.add_argument("--repeat-number", type=int, choices=[1,2,3], default=1)
    args = parser.parse_args()
    output = args.output.resolve();destination = output / "independent-verification.json"
    assert not destination.exists(), "Preserve previous verification evidence"
    frozen = read(DIRECTORY / "freeze.json");project = Path(frozen["project"])
    prefix, count = (0,2) if args.smoke else (1000,6000)
    checks = {
        "all_frozen_source_including_uid_unchanged":all((project/name).is_file() and sha(project/name)==value for name,value in frozen["source"].items()),
        "inventory_json_unchanged":sha(project/"source-inventory.json")==frozen["source_inventory_json_file_sha256"],
        "input_unchanged":sha(Path(frozen["input"]))==frozen["input_sha256"],
        "both_engine_executables_unchanged":all(sha(Path(name))==value for name,value in frozen["engine_executables"].items()),
        "all_native_dlls_unchanged":{path.name:sha(path) for path in (project/"game/platform/windows/bin").glob("*.dll")}==frozen["native"],
    }
    required = ["protocol.json","source-identity.json","r1.json","r1.json.execution.json","r1.json.steps.ndjson","r1.json.final.bin","world-validation.json","r1.log"]
    missing = [name for name in required if not (output/name).is_file()]
    checks["all_required_result_files_present"] = not missing
    record = {"pinned_commit":frozen["commit"],"pinned_tree":frozen["tree"],"canonical_source_map_fingerprint":frozen["canonical_source_map_fingerprint"],"checks":checks,"missing":missing,"smoke_only":args.smoke,"scope":"Readonly evidence verification, separate from game execution. Evidence integrity, business qualification and performance compliance are reported separately. New candidate output is not required to match the retired old-A outcome after correctness fixes."}
    if missing:
        record.update(evidence_integrity_pass=False,business_qualification_pass=False,performance_targets_pass=False)
        write(destination, record);print(json.dumps(record));raise SystemExit(1)
    protocol = read(output/"protocol.json");source = read(output/"source-identity.json")
    data = read(output/"r1.json");execution = read(output/"r1.json.execution.json")
    world = read(output/"world-validation.json")
    text = (output/"r1.log").read_text(encoding="utf-8")
    rows, enters, parse_errors = [], [], []
    with (output/"r1.json.steps.ndjson").open(encoding="utf-8") as stream:
        for number,line in enumerate(stream,1):
            try:
                row = json.loads(line)
            except json.JSONDecodeError:
                parse_errors.append(number);continue
            if row.get("kind") == "complete": rows.append(row["sample"])
            elif row.get("kind") == "enter": enters.append(row)
    samples = rows[prefix:]
    initial = data.get("initial",{})
    targets = protocol["cpu_targets"]
    initial_tick = int(initial.get("tick",-1))
    sample_wall_us = int(data.get("all_wall_us",0))-int(data.get("prefix_wall_us",0))
    metrics = data.get("metrics",{})
    kernel_errors = [error for error in data.get("errors",[]) if error != "Comprehensive workload did not satisfy its business coverage contract"]
    checks.update({
        "measured_source_matches_exact_frozen_map":source=={name:value for name,value in frozen["source"].items() if not name.endswith(".gd.uid")},
        "protocol_identity_matches_frozen_source":protocol["source_inventory_sha256"]==frozen["source_inventory_json_file_sha256"] and protocol["runner_sha256"]==frozen["source"]["tools/performance/current/plain_v4.gd"] and protocol["engine_executables"]==frozen["engine_executables"] and protocol["native"]==frozen["native"] and protocol["input_sha256"]==data.get("source_input_sha256")==frozen["input_sha256"],
        "plain_policy_and_fixed_window_retained":protocol["prefix_steps"]==data.get("requested_prefix_steps")==prefix and protocol["sample_steps"]==data.get("requested_sample_steps")==count and protocol["repeats"]==1 and not protocol["profile_stages"] and protocol["main_thread_policy"]=="app" and protocol["worker_tasks"]==4 and protocol["OMP_NUM_THREADS"]=="1" and protocol["require_coverage"]==bool(not args.smoke) and protocol.get("outcome_reference") is None and (args.smoke or protocol["paired_repeat"]==args.repeat_number),
        "no_active_a2_hooks":not frozen["active_a2_hooks"] and not (output/"r1.json.hotpath.json").exists() and not (output/"r1.json.stages.json").exists(),
        "complete_raw_step_and_tick_sequence":not parse_errors and len(rows)==len(enters)==prefix+count and data.get("all_completed_steps")==prefix+count and [row["index"] for row in rows]==list(range(prefix+count)) and all(row["tick"]==initial_tick+row["index"]+1 for row in rows) and initial_tick==633 and data.get("final",{}).get("tick")==633+prefix+count,
        "complete_enter_sequence_matches_real_steps":[row["index"] for row in enters]==list(range(prefix+count)) and all(row["tick"]==initial_tick+row["index"] for row in enters),
        "complete_6000_or_smoke2_statistics_match_raw":len(samples)==count and metrics_match(samples,metrics),
        "initial_160_complete_boundary_retained":initial.get("population",{}).get("present")==160 and initial.get("population",{}).get("patients")==128 and initial.get("population",{}).get("staff")==32 and initial.get("population",{}).get("visitors")==0 and not initial.get("population",{}).get("unclassified_actor_ids",[]) and initial.get("rooms")==64 and initial.get("facilities")==1361 and initial.get("beds")==24 and initial.get("props")==1200 and len(initial.get("desks",[]))==8,
        "app_thread_policy_worker4_and_plain_execution":execution["main_thread_policy"].get("applied",False) and execution["main_thread_policy"]["requested"]=="app" and execution["worker_tasks"]==4 and not execution["profile_stages"] and not execution["worker_samples"]["diagnostics_enabled"],
        "reported_kernel_world_validation_and_no_fatal":not kernel_errors and "SCRIPT ERROR:" not in text and not any(line.startswith("ERROR:") for line in text.splitlines()),
        "independent_final_world_readonly_validation":world["passed"] and world["complete_facts_unchanged"] and not world["validation"] and world["content_fingerprint_matches"] and world["tick"]==633+prefix+count and world["input_sha256"]==sha(output/"r1.json.final.bin")==data.get("final_sha256"),
        "sample_wall_clock_scope_exact":sample_wall_us>0 and metrics.get("real_window_us_including_observation")==sample_wall_us,
        "sample_speed_ratio_matches_fixed_tick":sample_wall_us>0 and abs(float(metrics.get("simulation_seconds_per_wall_second",-1))-count*.1*1e6/sample_wall_us)<1e-9 and metrics.get("simulated_seconds")==count*.1,
    })
    expected_targets = {"sim_step_p95_ms":10,"sim_step_p99_ms":15,"sim_step_ordinary_max_ms":30,"sim_speed_ratio_min":.99}
    checks["project_cpu_targets_unchanged"] = targets == expected_targets
    if samples:
        population = [row["present"] for row in samples]
        checks["sample_population_matches_raw"] = metrics.get("present_population")=={"minimum":min(population),"maximum":max(population),"median":statistics.median(population)}
    threshold = math.ceil(int(initial.get("population",{}).get("present",160))*.9)
    dense_rows, current = [], []
    for row in samples:
        if int(row["present"])>=threshold: current.append(row)
        elif current: dense_rows.append(current);current=[]
    if current: dense_rows.append(current)
    dense = metrics.get("dense_intervals",{})
    segments = dense.get("segments",[])
    checks["every_dense_interval_boundary_and_statistics_match_raw"] = dense.get("threshold_present")==threshold and len(segments)==len(dense_rows) and all(segment["first_index"]==group[0]["index"] and segment["last_index"]==group[-1]["index"] and segment["first_tick"]==group[0]["tick"] and segment["last_tick"]==group[-1]["tick"] and segment["sample_count_qualified"]==(len(group)>=1000) and metrics_match(group,segment["metrics"]) for segment,group in zip(segments,dense_rows))
    comprehensive = data.get("sample_business",{}).get("comprehensive",{})
    missing_coverage = comprehensive.get("uncovered",[])
    coverage_pass = bool(comprehensive.get("coverage_pass",False))
    record.update({"enclosing_checkout_commit":protocol["commit"],"git_metadata_scope":protocol["git_metadata_scope"],"evidence_integrity_pass":all(checks.values()),"business_qualification_pass":bool(data.get("complete") and not data.get("errors") and coverage_pass) if not args.smoke else None,"coverage_pass":coverage_pass if not args.smoke else None,"coverage_missing":missing_coverage,"coverage_errors":comprehensive.get("errors",[]),"kernel_errors":kernel_errors,"result_errors":data.get("errors",[]),"initial":initial,"final":data.get("final",{}),"metrics":metrics,"full_cpu_target_checks":target_checks(metrics,targets) if samples else {},"dense_cpu_target_checks":[{"first_tick":segment["first_tick"],"last_tick":segment["last_tick"],"count":segment["metrics"]["count"],"sample_count_qualified":segment["sample_count_qualified"],"checks":target_checks(segment["metrics"],targets)} for segment in segments],"has_qualified_dense_segment":any(len(group)>=1000 for group in dense_rows),"complete_world_and_ordered_events_file_sha256":data.get("final_sha256"),"world_validation":world,"source_input_sha256":frozen["input_sha256"]})
    record["performance_targets_pass"] = bool(not args.smoke and record["business_qualification_pass"] and all(record["full_cpu_target_checks"].values()) and record["has_qualified_dense_segment"] and segments and all(all(row["checks"].values()) for row in record["dense_cpu_target_checks"]))
    write(destination,record)
    print(json.dumps({"report":str(destination),"checks":checks,"evidence_integrity_pass":record["evidence_integrity_pass"],"business_qualification_pass":record["business_qualification_pass"],"performance_targets_pass":record["performance_targets_pass"],"coverage_missing":missing_coverage}))
    raise SystemExit(0 if record["evidence_integrity_pass"] else 1)


if __name__ == "__main__":
    main()
