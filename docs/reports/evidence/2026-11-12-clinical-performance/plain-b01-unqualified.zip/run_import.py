import datetime
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import time

directory = Path(__file__).resolve().parent
project = directory / "project"
engine = Path("C:/programs/Godot/Godot_v4.7.2-stable_win64_console.exe")
spec = importlib.util.spec_from_file_location("frozen_campaign", project / "tools/performance/current/campaign160.py")
campaign = importlib.util.module_from_spec(spec)
spec.loader.exec_module(campaign)
assert not campaign.processes(), "Another engine or compiler is active"
environment = dict(os.environ, OMP_NUM_THREADS="1", APPDATA=str(directory / "runtime/Roaming"), LOCALAPPDATA=str(directory / "runtime/Local"))
for key in ["APPDATA", "LOCALAPPDATA"]:
    Path(environment[key]).mkdir(parents=True, exist_ok=True)
command = [str(engine), "--headless", "--path", str(project), "--editor", "--import"]
log_path, result_path = directory / "import.log", directory / "import-result.json"
assert not log_path.exists() and not result_path.exists()
started = time.perf_counter()
result = {"command": command, "environment": {key: environment[key] for key in ["OMP_NUM_THREADS", "APPDATA", "LOCALAPPDATA"]}, "started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(), "engine_executables": campaign.engine_identity(engine)}
with log_path.open("w", encoding="utf-8") as log:
    process = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT, env=environment, creationflags=subprocess.CREATE_NO_WINDOW)
    result["engine_launcher_pid"] = process.pid
    result_path.write_text(json.dumps(result, indent=2), encoding="utf-8")
    try:
        while process.poll() is None:
            time.sleep(0.25)
            text = log_path.read_text(encoding="utf-8")
            if "SCRIPT ERROR:" in text or any(line.startswith("ERROR:") for line in text.splitlines()):
                result["failure"] = "Godot import reported an error"
                break
            if time.perf_counter() - started > 180:
                result["failure"] = "Import exceeded 180 seconds"
                break
    finally:
        campaign.stop_owned_process_tree(process)
        result.update({"returncode": process.returncode, "elapsed_seconds": time.perf_counter() - started, "state": "engine_exited"})
        result_path.write_text(json.dumps(result, indent=2), encoding="utf-8")
print(json.dumps(result))
assert process.returncode == 0 and "failure" not in result
