extends SceneTree

func _initialize() -> void: call_deferred("run")

func _hash(value: Variant) -> String:
	var digest:=HashingContext.new();digest.start(HashingContext.HASH_SHA256)
	digest.update(var_to_bytes(value));return digest.finish().hex_encode()

func run() -> void:
	var input: String="";var output: String=""
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--input="): input=arg.trim_prefix("--input=")
		if arg.begins_with("--output="): output=arg.trim_prefix("--output=")
	if input.is_empty() or output.is_empty() or FileAccess.file_exists(output): quit(2);return
	var started: int=Time.get_ticks_usec();var content:=HospitalContent.new()
	var file: FileAccess=FileAccess.open(input,FileAccess.READ);var envelope: Dictionary=file.get_var(false);file.close()
	var world:=WorldState.new(envelope.facts);var before: Dictionary=world.freeze()
	var validation: String=world.validate(content)
	var unchanged: bool=world.freeze()==before
	var result: Dictionary={"passed":validation.is_empty() and unchanged and envelope.content_fingerprint==content.content_fingerprint,"input_sha256":FileAccess.get_sha256(input),"content_fingerprint_matches":envelope.content_fingerprint==content.content_fingerprint,"validation":validation,"complete_facts_unchanged":unchanged,"facts_variant_sha256":_hash(before),"rng_variant_sha256":_hash(before.rng),"tick":world.sim_tick,"actor_records":before.actors.size(),"present":world.present_actor_count(),"rooms":before.rooms.size(),"facilities":before.facilities.size(),"ordered_event_records":envelope.get("events",[]).size(),"elapsed_us":Time.get_ticks_usec()-started,"scope":"Readonly final-envelope validation. WorldState and content only; no HospitalSimulation, quote, movement, reservation, random draw or step is executed. Facts encoding and complete envelope file hashes have distinct scopes."}
	FileAccess.open(output,FileAccess.WRITE).store_string(JSON.stringify(result,"\t"))
	print(JSON.stringify(result));quit(0 if result.passed else 1)
