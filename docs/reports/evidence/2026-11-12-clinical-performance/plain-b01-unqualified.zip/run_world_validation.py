import argparse,hashlib,importlib.util,json,os,subprocess,time
from pathlib import Path

parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
directory=Path(__file__).resolve().parent;output=args.output.resolve();project=directory/'project'
spec=importlib.util.spec_from_file_location('campaign',project/'tools/performance/current/campaign160.py');campaign=importlib.util.module_from_spec(spec);spec.loader.exec_module(campaign)
assert not campaign.processes()
result_path=output/'world-validation.json';log_path=output/'world-validation.log';execution=output/'world-validation.execution.json'
assert not result_path.exists() and not log_path.exists() and not execution.exists()
engine=Path('C:/programs/Godot/Godot_v4.7.2-stable_win64_console.exe')
command=[str(engine),'--headless','--path',str(project),'--script',str(directory/'verify_world.gd'),'--','--input='+str(output/'r1.json.final.bin'),'--output='+str(result_path)]
environment=dict(os.environ,OMP_NUM_THREADS='1',APPDATA=str(directory/'runtime-validation/Roaming'),LOCALAPPDATA=str(directory/'runtime-validation/Local'))
for key in ['APPDATA','LOCALAPPDATA']:Path(environment[key]).mkdir(parents=True,exist_ok=True)
record={'command':command,'reader_sha256':hashlib.sha256((directory/'verify_world.gd').read_bytes()).hexdigest()};started=time.perf_counter()
with log_path.open('w',encoding='utf-8') as log:
 process=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,env=environment,creationflags=subprocess.CREATE_NO_WINDOW)
 record['engine_launcher_pid']=process.pid;execution.write_text(json.dumps(record),encoding='utf-8')
 try:
  while process.poll() is None:
   time.sleep(.25);text=log_path.read_text(encoding='utf-8')
   if 'SCRIPT ERROR:' in text or any(row.startswith('ERROR:') for row in text.splitlines()):record['failure']='Godot validation error';break
   if time.perf_counter()-started>60:record['failure']='Readonly validation exceeded 60 seconds';break
 finally:campaign.stop_owned_process_tree(process)
record.update(returncode=process.returncode,elapsed_seconds=time.perf_counter()-started)
execution.write_text(json.dumps(record,indent=2),encoding='utf-8');print(json.dumps(record))
assert process.returncode==0 and 'failure' not in record and json.loads(result_path.read_text(encoding='utf-8'))['passed']
