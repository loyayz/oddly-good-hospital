"""Freeze an explicitly pinned Git commit; no engine or simulation runs here."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import tarfile
import time

DIRECTORY = Path(__file__).resolve().parent
ROOT = DIRECTORY.parents[1]
PROJECT = DIRECTORY / "project"
OLD = ROOT / ".cache/performance160-clinical-family-20261112-v3-qualified01"
INPUT = ROOT / ".cache/performance160-clinical-family-20261112-v3-prep01/input01/comprehensive160.input.bin"
INPUT_SHA = "752924c562f275804cee40cbd2a8760f8f0780cab3276a04330db63a2866e780"
ACTIVE_HOOKS = ["_HotpathTimer", "ClinicalDiagnostic", "_TransportDiagnostic", "_PerformanceProbe", "_MovementProfile160", "# queue-shortcut-counter"]


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def git(*args):
    return subprocess.check_output(["git", "-C", str(ROOT), *args])


def native(directory):
    return {path.name: sha(path) for path in (directory / "game/platform/windows/bin").glob("*.dll")}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--commit", required=True)
    args = parser.parse_args()
    assert re.fullmatch(r"[a-f0-9]{40}", args.commit), "Use the exact final forty-character commit"
    commit = git("rev-parse", args.commit + "^{commit}").decode().strip()
    assert commit == args.commit and not PROJECT.exists() and not (DIRECTORY / "freeze.json").exists()
    protocol = read(OLD / "qualification-r1/protocol.json")
    assert sha(INPUT) == INPUT_SHA
    assert native(OLD / "project") == protocol["native"]
    assert all(sha(Path(path)) == value for path, value in protocol["engine_executables"].items())
    changes = git("diff", "--name-only", "8cfc3cc1b0ad5aa85954b8744efae9ac03fdfb43", commit, "--", "game/platform/windows").decode().splitlines()
    code_changes = [name for name in changes if Path(name).suffix in [".cpp", ".c", ".h", ".hpp", ".cmake", ".gdextension"] or Path(name).name == "CMakeLists.txt"]
    assert not code_changes, ("Need a matching native-build identity for changed native sources", code_changes)
    started = time.perf_counter()
    PROJECT.mkdir(parents=True, exist_ok=False)
    process = subprocess.Popen(["git", "-C", str(ROOT), "archive", "--format=tar", commit], stdout=subprocess.PIPE)
    with tarfile.open(fileobj=process.stdout, mode="r|") as archive:
        for member in archive:
            destination = (PROJECT / member.name).resolve()
            assert destination.is_relative_to(PROJECT) and (member.isdir() or member.isfile()), member.name
            if member.isdir():
                destination.mkdir(parents=True, exist_ok=True)
            else:
                destination.parent.mkdir(parents=True, exist_ok=True)
                with archive.extractfile(member) as source, destination.open("wb") as target:
                    shutil.copyfileobj(source, target)
    assert process.wait() == 0
    object_format = git("rev-parse", "--show-object-format").decode().strip()
    source, blobs = {}, {}
    for entry in git("ls-tree", "-r", "-z", commit).split(b"\0"):
        if not entry:
            continue
        header, name = entry.split(b"\t", 1)
        _, kind, oid = header.split()
        relative = name.decode("utf-8");assert kind == b"blob"
        data = (PROJECT / relative).read_bytes()
        assert hashlib.new(object_format, b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest() == oid.decode(), relative
        source[relative] = hashlib.sha256(data).hexdigest();blobs[relative] = oid.decode()
    active = []
    for relative in source:
        if relative.endswith(".gd") and (relative.startswith("game/") or relative in ["tools/performance/current/plain_v4.gd", "tools/performance/current/comprehensive_observer.gd", "tools/performance/current/comprehensive_operations.gd"]):
            text = (PROJECT / relative).read_text(encoding="utf-8")
            active.extend({"path":relative,"marker":marker} for marker in ACTIVE_HOOKS if marker in text)
    assert not active, active
    for name in [".godot/imported", "game/platform/windows/bin"]:
        shutil.copytree(OLD / "project" / name, PROJECT / name, dirs_exist_ok=True)
    for name in [".godot/global_script_class_cache.cfg", ".godot/extension_list.cfg"]:
        shutil.copy2(OLD / "project" / name, PROJECT / name)
    assert native(PROJECT) == protocol["native"]
    inventory = sorted(source)
    write(PROJECT / "source-inventory.json", inventory)
    record = {"commit":commit,"tree":git("rev-parse",commit+"^{tree}").decode().strip(),"project":str(PROJECT),"source":source,"git_blobs":blobs,"git_object_format":object_format,"source_files":len(source),"canonical_source_map_fingerprint":{"sha256":hashlib.sha256(json.dumps(source,sort_keys=True,separators=(',',':'),ensure_ascii=True).encode()).hexdigest(),"algorithm":"SHA256(UTF8(json.dumps(path_to_sha256_map,sort_keys=True,separators=(',',':'),ensure_ascii=True))) without trailing newline"},"source_inventory_json_file_sha256":sha(PROJECT/"source-inventory.json"),"input":str(INPUT),"input_sha256":INPUT_SHA,"engine_executables":protocol["engine_executables"],"native":protocol["native"],"native_source_changes_since_old_a":code_changes,"active_a2_hooks":active,"cache_source":str(OLD/"project"),"freeze_seconds":time.perf_counter()-started,"scope":"Exact committed Git tree only; uncommitted/untracked files excluded. Imported assets, class lookup and identical native libraries are copied separately; no runtime service cache, world, simulation step or A2 hook is copied. Enclosing checkout metadata is distinct from this pinned source authority."}
    write(DIRECTORY / "freeze.json", record)
    print(json.dumps({key:record[key] for key in ["commit","tree","project","source_files","canonical_source_map_fingerprint","input_sha256","freeze_seconds"]}))


if __name__ == "__main__":
    main()
