extends SceneTree

func _initialize() -> void:
	var input: String="";var output: String=""
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--input="): input=arg.trim_prefix("--input=")
		if arg.begins_with("--output="): output=arg.trim_prefix("--output=")
	if input.is_empty() or output.is_empty() or FileAccess.file_exists(output): quit(2);return
	var file: FileAccess=FileAccess.open(input,FileAccess.READ);var saved: Dictionary=file.get_var(false);file.close()
	var facts_bytes: PackedByteArray=var_to_bytes(saved.facts)
	saved.erase("scenario")
	file=FileAccess.open(output,FileAccess.WRITE);file.store_var(saved);file.close()
	file=FileAccess.open(output,FileAccess.READ);var restored: Dictionary=file.get_var(false);file.close()
	var same: bool=var_to_bytes(restored.facts)==facts_bytes and not restored.has("scenario")
	print(JSON.stringify({"passed":same,"input":input,"generic_input":output,"facts_unchanged":same,"scope":"Only remove the optional scenario header in a separate complete file for generic argv compatibility. No simulation step, business fact or RNG mutation."}))
	quit(0 if same else 1)
