import datetime,hashlib,importlib.util,json,os,subprocess,sys,time
from pathlib import Path

HERE=Path(__file__).resolve().parent;PROJECT=HERE/'project';engine=Path('C:/programs/Godot/Godot_v4.7.2-stable_win64_console.exe')
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
identity_path=HERE/'source-after-contract-oracle.json' if (HERE/'source-after-contract-oracle.json').exists() else HERE/'freeze.json'
identity=read(identity_path);spec=importlib.util.spec_from_file_location('frozen_campaign',PROJECT/'tools/performance/current/campaign160.py');campaign=importlib.util.module_from_spec(spec);spec.loader.exec_module(campaign)
stage=sys.argv[1];v3=HERE/'v3-input01/comprehensive160.input.bin';mixed=HERE/'mixed-input01/mixed160.input.bin';generic=HERE/'generic.input.bin'
base=[str(engine),'--headless','--path',str(PROJECT)]
def godot(script,*args):return base+['--script',script,'--',*args]
def smoke(input_path,name,scenario=None):
 command=[sys.executable,'-X','utf8','-B',str(PROJECT/'tools/performance/current/campaign160.py'),'--engine',str(engine),'--input',str(input_path),'--output',str(HERE/name),'--smoke']
 if scenario is not None:command+=['--scenario',scenario]
 return command
commands={
 'import':base+['--editor','--import'],
 'v3_prepare':godot('res://tools/performance/current/comprehensive_prepare.gd','--output-dir='+str(v3.parent)),
 'mixed_prepare':godot('res://tools/performance/current/mixed_prepare.gd','--output-dir='+str(mixed.parent)),
 'contract':godot('res://tools/performance/current/mixed_input_contract_test.gd','--input='+str(mixed),'--v3-reference='+identity['original_input'],'--v3-generated='+str(v3),'--output='+str(HERE/'input-contract.json')),
 'contract02':godot('res://tools/performance/current/mixed_input_contract_test.gd','--input='+str(mixed),'--v3-reference='+identity['original_input'],'--v3-generated='+str(v3),'--output='+str(HERE/'input-contract02.json')),
 'generic_input':godot(str(HERE/'generic_input.gd'),'--input='+str(v3),'--output='+str(generic)),
 'generic_smoke':smoke(generic,'generic-smoke01'),
 'v3_smoke':smoke(v3,'v3-smoke01','comprehensive160-clinical-family-v3'),
 'mixed_smoke':smoke(mixed,'mixed-smoke01','mixed160-clinical-ops-v1'),
 'wrong_scenario':godot('res://tools/performance/current/plain_v4.gd','--input='+str(mixed),'--output='+str(HERE/'wrong-scenario.json'),'--expected-scenario=comprehensive160-clinical-family-v3','--prefix-steps=0','--steps=2','--main-thread-policy=app','--worker-tasks=4'),
}
assert stage in commands and not campaign.processes(),'Engine/compiler slot is not empty'
log_path=HERE/(stage+'.log');result_path=HERE/(stage+'.execution.json');assert not log_path.exists() and not result_path.exists()
before={n:sha(PROJECT/n) for n in identity['source']};assert before==identity['source']
assert campaign.native_identity(PROJECT)==identity['native'] and campaign.engine_identity(engine)==identity['engine_executables']
assert sha(Path(identity['original_input']))==identity['original_input_sha256']
environment=dict(os.environ,OMP_NUM_THREADS='1',APPDATA=str(HERE/'runtime'/stage/'Roaming'),LOCALAPPDATA=str(HERE/'runtime'/stage/'Local'))
for key in ['APPDATA','LOCALAPPDATA']:Path(environment[key]).mkdir(parents=True,exist_ok=True)
result={'stage':stage,'command':commands[stage],'cwd':str(PROJECT),'environment':{key:environment[key] for key in ['OMP_NUM_THREADS','APPDATA','LOCALAPPDATA']},'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_inventory_count':len(before),'source_map_sha256':identity['source_map_sha256'],'engine_executables':identity['engine_executables'],'native':identity['native'],'runner_sha256':sha(Path(__file__)),'generic_converter_sha256':sha(HERE/'generic_input.gd')}
expected=2 if stage=='wrong_scenario' else 0;started=time.perf_counter();last_progress=started
with log_path.open('w',encoding='utf-8') as log:
 process=subprocess.Popen(commands[stage],stdout=log,stderr=subprocess.STDOUT,cwd=PROJECT,env=environment,creationflags=subprocess.CREATE_NO_WINDOW)
 result['launcher_pid']=process.pid;result_path.write_text(json.dumps(result,indent=2),encoding='utf-8')
 try:
  while process.poll() is None:
   time.sleep(.25);content=log_path.read_text(encoding='utf-8')
   if 'SCRIPT ERROR:' in content or any(line.startswith('ERROR:') for line in content.splitlines()):result['failure']='Godot script error';break
   if time.perf_counter()-started>1800:result['failure']='Qualification watchdog reached';break
   if time.perf_counter()-last_progress>25:
    print(json.dumps({'stage':stage,'elapsed_seconds':time.perf_counter()-started,'tail':content.splitlines()[-2:]}),flush=True);last_progress=time.perf_counter()
 finally:campaign.stop_owned_process_tree(process)
result.update(returncode=process.returncode,expected_returncode=expected,elapsed_seconds=time.perf_counter()-started,state='engine_exited',ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
after={n:sha(PROJECT/n) for n in identity['source']};result['changed_source']=[n for n in after if after[n]!=before[n]]
result['source_unchanged']=after==before;result['native_unchanged']=campaign.native_identity(PROJECT)==identity['native'];result['executed_engine_unchanged']=campaign.engine_identity(engine)==identity['engine_executables'];result['original_input_unchanged']=sha(Path(identity['original_input']))==identity['original_input_sha256'];result['remaining_processes']=campaign.processes()
if stage=='wrong_scenario' and process.returncode==expected:
 rejection=read(HERE/'wrong-scenario.json');result['expected_rejection']=rejection.get('reason')=='scenario mismatch' and rejection.get('actual_scenario')=='mixed160-clinical-ops-v1' and not (HERE/'wrong-scenario.json.steps.ndjson').exists() and not (HERE/'wrong-scenario.json.final.bin').exists()
result_path.write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result),flush=True)
assert process.returncode==expected and 'failure' not in result and not result['changed_source'] and result['native_unchanged'] and result['executed_engine_unchanged'] and result['original_input_unchanged'] and not result['remaining_processes'],(stage,result_path)
if stage=='wrong_scenario':assert result['expected_rejection']
