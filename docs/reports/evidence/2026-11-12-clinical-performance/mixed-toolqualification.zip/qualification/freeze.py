import hashlib,json,shutil,subprocess,tarfile,time
from pathlib import Path

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1];PROJECT=HERE/'project'
COMMIT='5df40cda22e0903de22761cf75d2fc62bb74a4ab'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
def write(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')
def git(*args):return subprocess.check_output(['git','-C',str(ROOT),*args])
tools=['README.md','campaign160.py','comprehensive_observer.gd','comprehensive_prepare.gd','paired160.py','plain_v4.gd','mixed160.md','mixed_clinical_inputs.gd','mixed_input_contract_test.gd','mixed_prepare.gd','scenario_cli_contract_test.py']
native_record=ROOT/'.cache/resident-mask-final-identity.json';native=read(native_record)
assert not PROJECT.exists() and not (HERE/'freeze.json').exists()
assert git('rev-parse',COMMIT+'^{commit}').decode().strip()==COMMIT
assert native['native']['oddly_good_platform.windows.x86_64.dll']=='89d4e1db54ca8a52ee2ed7da5b5fdcc1917c0667d172ab89d2fe683bc1767af2'
for name,value in native['production_source'].items():assert sha(ROOT/name)==value==sha(Path(native['production_stage'])/name)
for name,value in native['native'].items():assert sha(Path(native['native_directory'])/name)==value
started=time.perf_counter();PROJECT.mkdir()
process=subprocess.Popen(['git','-C',str(ROOT),'archive','--format=tar',COMMIT],stdout=subprocess.PIPE)
with tarfile.open(fileobj=process.stdout,mode='r|') as archive:
 for member in archive:
  target=(PROJECT/member.name).resolve();assert target.is_relative_to(PROJECT) and (member.isdir() or member.isfile())
  if member.isdir():target.mkdir(parents=True,exist_ok=True)
  else:
   target.parent.mkdir(parents=True,exist_ok=True)
   with archive.extractfile(member) as source,target.open('wb') as destination:shutil.copyfileobj(source,destination)
assert process.wait()==0
base={};blobs={};algorithm=git('rev-parse','--show-object-format').decode().strip()
for entry in git('ls-tree','-r','-z',COMMIT).split(b'\0'):
 if not entry:continue
 header,name=entry.split(b'\t',1);_,kind,oid=header.split();assert kind==b'blob';name=name.decode('utf-8');data=(PROJECT/name).read_bytes()
 assert hashlib.new(algorithm,b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==oid.decode(),name
 base[name]=sha(PROJECT/name);blobs[name]=oid.decode()
overlays={}
for name in list(native['production_source'])+['tools/performance/current/'+n for n in tools]:
 overlays[name]={'before_sha256':base.get(name),'after_sha256':sha(ROOT/name),'source':str(ROOT/name)}
 (PROJECT/name).parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/name,PROJECT/name)
cache=ROOT/'.cache/performance160-clinical-family-20261112-v3-candidate01/project'
shutil.copytree(cache/'.godot/imported',PROJECT/'.godot/imported',dirs_exist_ok=True)
for name in ['global_script_class_cache.cfg','extension_list.cfg']:shutil.copy2(cache/'.godot'/name,PROJECT/'.godot'/name)
destination=PROJECT/'game/platform/windows/bin';destination.mkdir(parents=True,exist_ok=True)
for name,value in native['native'].items():shutil.copy2(Path(native['native_directory'])/name,destination/name);assert sha(destination/name)==value
source={name:sha(PROJECT/name) for name in sorted(set(base)|set(overlays))}
for name in source:
 if name.startswith('game/') and name.endswith('.gd') or name in ['tools/performance/current/plain_v4.gd','tools/performance/current/comprehensive_observer.gd','tools/performance/current/comprehensive_operations.gd']:
  content=(PROJECT/name).read_text(encoding='utf-8');assert not any(marker in content for marker in ['_HotpathTimer','ClinicalDiagnostic','_TransportDiagnostic','_PerformanceProbe','_MovementProfile160','# queue-shortcut-counter']),name
input_path=ROOT/'.cache/performance160-clinical-family-20261112-v3-prep01/input01/comprehensive160.input.bin'
assert sha(input_path)=='752924c562f275804cee40cbd2a8760f8f0780cab3276a04330db63a2866e780'
engine=read(ROOT/'.cache/performance160-clinical-family-20261112-v3-candidate01/freeze.json')['engine_executables']
assert all(sha(Path(name))==value for name,value in engine.items())
write(PROJECT/'source-inventory.json',sorted(source))
record={'commit':COMMIT,'tree':git('rev-parse',COMMIT+'^{tree}').decode().strip(),'project':str(PROJECT),'base_source':base,'git_blobs':blobs,'source':source,'overlays':overlays,'native':native['native'],'native_record':str(native_record),'native_record_sha256':sha(native_record),'engine_executables':engine,'original_input':str(input_path),'original_input_sha256':sha(input_path),'cache_source':str(cache),'source_count':len(source),'source_map_sha256':hashlib.sha256(json.dumps(source,sort_keys=True,separators=(',',':'),ensure_ascii=True).encode()).hexdigest(),'source_inventory_file_sha256':sha(PROJECT/'source-inventory.json'),'freeze_seconds':time.perf_counter()-started,'scope':'Pinned committed 5df tree plus exactly four verified production native source overlays and eleven reviewed current tools. All other uncommitted/untracked source excluded. Separate imported assets/class lookup and verified five DLLs; no runtime world or service cache. Fixed source inventory excludes generated outputs. No probe hooks.'}
write(HERE/'freeze.json',record);print(json.dumps({key:record[key] for key in ['commit','project','source_count','source_map_sha256','freeze_seconds']}),flush=True)
