import datetime,hashlib,importlib.util,json,os,subprocess,sys,time
from pathlib import Path

HERE=Path(__file__).resolve().parent;PROJECT=HERE/'project';OUTPUT=HERE/'qualification-r1'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
frozen=read(HERE/'freeze.json');spec=importlib.util.spec_from_file_location('campaign',PROJECT/'tools/performance/current/campaign160.py');campaign=importlib.util.module_from_spec(spec);spec.loader.exec_module(campaign)
engine=Path('C:/programs/Godot/Godot_v4.7.2-stable_win64_console.exe');reference=HERE.parent/'performance160-clinical-family-20261112-v3-candidate01/qualification-r1'
checks={'pinned_commit':frozen['commit']=='7b2a7352f9e0c5af54024521a106a307e97fbd22','pure_git_source':frozen['all_git_blobs_verified'] and not frozen['overlays'],'all_source':all(sha(PROJECT/n)==v for n,v in frozen['source'].items()),'inventory':sha(PROJECT/'source-inventory.json')==frozen['source_inventory_file_sha256'],'stage_identity':sha(PROJECT/'source-identity.json')==frozen['stage_identity_sha256'],'authority':sha(Path(frozen['authority']))==frozen['authority_sha256'],'both_executables':campaign.engine_identity(engine)==frozen['engine_executables'],'five_native_libraries':campaign.native_identity(PROJECT)==frozen['native'] and frozen['native']['oddly_good_platform.windows.x86_64.dll']=='89d4e1db54ca8a52ee2ed7da5b5fdcc1917c0667d172ab89d2fe683bc1767af2','original_input':sha(Path(frozen['original_input']))==frozen['original_input_sha256']=='752924c562f275804cee40cbd2a8760f8f0780cab3276a04330db63a2866e780','b01_reference':sha(reference/'r1.json.final.bin')=='0afa344f973e4ce8b12ce46a034f3dc754f43e42e446938e94f4ed47163aaf74','engine_slot_empty':not campaign.processes()}
source_identity=read(PROJECT/'source-identity.json');checks['stage_exact_source_map']={row['path']:row['sha256'] for row in source_identity['source']}==frozen['source'];checks['inventory_exact_paths']=sorted(read(PROJECT/'source-inventory.json'))==sorted(frozen['source'])
active=[]
for name in frozen['source']:
 if name.startswith('game/') and name.endswith('.gd') or name in ['tools/performance/current/plain_v4.gd','tools/performance/current/comprehensive_observer.gd','tools/performance/current/comprehensive_operations.gd']:
  content=(PROJECT/name).read_text(encoding='utf-8')
  active += [{'path':name,'marker':marker} for marker in ['_HotpathTimer','ClinicalDiagnostic','_TransportDiagnostic','_PerformanceProbe','_MovementProfile160','# queue-shortcut-counter'] if marker in content]
checks['plain_without_active_hooks']=not active
preflight={'passed':all(checks.values()),'checks':checks,'active_hooks':active,'source_map_sha256':frozen['source_map_sha256'],'freeze_file_sha256':sha(HERE/'freeze.json'),'stage_identity_sha256':frozen['stage_identity_sha256'],'input_sha256':frozen['original_input_sha256'],'engine_executables':frozen['engine_executables'],'native':frozen['native']}
assert not (HERE/'campaign-preflight.json').exists() and not OUTPUT.exists()
(HERE/'campaign-preflight.json').write_text(json.dumps(preflight,indent=2),encoding='utf-8');assert all(checks.values()),checks
environment=dict(os.environ,OMP_NUM_THREADS='1',APPDATA=str(HERE/'runtime-r1/Roaming'),LOCALAPPDATA=str(HERE/'runtime-r1/Local'))
for key in ['APPDATA','LOCALAPPDATA']:Path(environment[key]).mkdir(parents=True,exist_ok=True)
command=[sys.executable,'-X','utf8','-B',str(PROJECT/'tools/performance/current/campaign160.py'),'--engine',str(engine),'--input',frozen['original_input'],'--output',str(OUTPUT),'--scenario','comprehensive160-clinical-family-v3','--prefix-steps','1000','--sample-steps','6000','--repeat-number','1','--require-coverage','--outcome-reference',str(reference)]
record={'command':command,'cwd':str(PROJECT),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'environment':{key:environment[key] for key in ['APPDATA','LOCALAPPDATA','OMP_NUM_THREADS']},'preflight_file_sha256':sha(HERE/'campaign-preflight.json'),'controller_sha256':sha(Path(__file__)),'scope':'One complete plain original-v3 repeat only. Campaign coverage failure is preserved; independent verification runs after full completion.'}
def latest():
 path=OUTPUT/'r1.json.steps.ndjson'
 if not path.exists():return {}
 with path.open('rb') as stream:
  stream.seek(0,2);stream.seek(max(0,stream.tell()-16384));lines=stream.read().decode('utf-8').splitlines()
 for line in reversed(lines):
  try:row=json.loads(line)
  except json.JSONDecodeError:continue
  if row.get('kind')=='complete':return row['sample']
 return {}
started=time.perf_counter();last=started
with (HERE/'campaign-control.log').open('w',encoding='utf-8') as log:
 process=subprocess.Popen(command,cwd=PROJECT,stdout=log,stderr=subprocess.STDOUT,env=environment,creationflags=subprocess.CREATE_NO_WINDOW)
 record['campaign_launcher_pid']=process.pid;(HERE/'campaign-control.json').write_text(json.dumps(record,indent=2),encoding='utf-8');print(json.dumps({'state':'started','campaign_launcher_pid':process.pid,'output':str(OUTPUT),'preflight':checks}),flush=True)
 try:
  while process.poll() is None:
   time.sleep(.5)
   if time.perf_counter()-last>=30:
    progress={'state':'running','elapsed_seconds':time.perf_counter()-started,'latest_real_step':latest()};(HERE/'campaign-progress.json').write_text(json.dumps(progress,indent=2),encoding='utf-8');print(json.dumps(progress),flush=True);last=time.perf_counter()
   if time.perf_counter()-started>1900:record['failure']='Bounded campaign controller exceeded1900s';break
 finally:campaign.stop_owned_process_tree(process)
record.update(returncode=process.returncode,elapsed_seconds=time.perf_counter()-started,state='campaign_exited',ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),latest_real_step=latest(),remaining_processes=campaign.processes())
record['all_source_unchanged']=all(sha(PROJECT/n)==v for n,v in frozen['source'].items());record['native_unchanged']=campaign.native_identity(PROJECT)==frozen['native'];record['both_executables_unchanged']=campaign.engine_identity(engine)==frozen['engine_executables'];record['original_input_unchanged']=sha(Path(frozen['original_input']))==frozen['original_input_sha256']
if (OUTPUT/'r1.json').exists():
 data=read(OUTPUT/'r1.json');record['complete_real_step_count']=data.get('all_completed_steps');record['coverage_pass']=data.get('sample_business',{}).get('comprehensive',{}).get('coverage_pass');record['result_errors']=data.get('errors');record['full_final_world_and_events_sha256']=data.get('final_sha256');record['b01_witness_equal']=sha(OUTPUT/'r1.json.final.bin')=='0afa344f973e4ce8b12ce46a034f3dc754f43e42e446938e94f4ed47163aaf74'
(HERE/'campaign-control.json').write_text(json.dumps(record,indent=2),encoding='utf-8');print(json.dumps(record),flush=True)
assert not record['remaining_processes'] and record['all_source_unchanged'] and record['native_unchanged'] and record['both_executables_unchanged'] and record['original_input_unchanged']
assert 'failure' not in record and record.get('complete_real_step_count')==7000,record
