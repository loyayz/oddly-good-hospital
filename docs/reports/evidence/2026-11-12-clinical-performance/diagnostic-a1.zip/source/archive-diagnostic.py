"""Archive captured diagnostic evidence without rerunning the simulation."""
import hashlib
import json
from pathlib import Path
import time
import zipfile


ROOT = Path(__file__).resolve().parents[2]
RUN = Path(__file__).resolve().parent
PROJECT = RUN / "project"
RESULT = RUN / "full-diagnostic-r1"
DESTINATION = ROOT / "docs/reports/evidence/2026-11-12-clinical-performance/diagnostic-a1.zip"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


started = time.perf_counter()
assert not DESTINATION.exists(), "Preserve the existing archive"
combined = read(PROJECT / "combined-diagnostic-identity.json")
clinical = read(PROJECT / "clinical-diagnostic-layer-identity.json")
transport = read(PROJECT / "transport-diagnostic-identity.json")
shortcut = read(PROJECT / "queue-shortcut-overlay-proof.json")
base = Path(combined["base_project"])
originals = clinical["original_source"]
assert len(originals) == 2220 and len(combined["source"]) == 2227
assert all(sha((PROJECT / name).read_bytes()) == expected for name, expected in combined["source"].items())
changed = combined["instrumented_original_file_sha256"]
restored = {name: (PROJECT / name).read_text(encoding="utf-8") for name in changed}


def reverse_pairs(layer):
    for name, entry in layer["reversible_hooks"].items():
        text = restored[name]
        assert sha(text.encode()) == entry["instrumented_sha256"], name
        for replacement in reversed(entry["replacements"]):
            before, after = replacement["original"], replacement["instrumented"]
            if before:
                assert text.count(after) == 1, name
                text = text.replace(after, before, 1)
            else:
                assert text.endswith(after), name
                text = text[:-len(after)]
        assert sha(text.encode()) == entry["original_sha256"], name
        restored[name] = text


reverse_pairs(transport)
for name, entry in shortcut["source"].items():
    assert sha(restored[name].encode()) == entry["after_sha256"], name
    lines = restored[name].splitlines(keepends=True)
    for insertion in reversed(entry["insertions"]):
        start = insertion["after_line0"]
        count = len(insertion["lines"])
        assert lines[start:start + count] == insertion["lines"], name
        del lines[start:start + count]
    restored[name] = "".join(lines)
    assert sha(restored[name].encode()) == entry["before_sha256"], name
reverse_pairs(clinical)
for name, expected in originals.items():
    before = (base / name).read_bytes()
    after = restored[name].encode() if name in restored else (PROJECT / name).read_bytes()
    assert sha(before) == expected and before == after, name

entries = {}
sources = {}


def add(path, name):
    assert name not in entries and path.is_file()
    entries[name] = path.read_bytes()
    sources[name] = str(path.relative_to(ROOT))


for path in sorted(RESULT.iterdir()):
    if path.is_file() and not path.name.endswith(".final.bin"):
        add(path, "run/" + path.name)
for name in ["diagnostic-summary.json", "final-preparation-checks.json", "full-pre-run.json"]:
    add(RUN / name, "capture/" + name)
for name in ["clinical-diagnostic-layer-identity.json", "clinical-diagnostic-identity.json", "combined-diagnostic-identity.json", "queue-shortcut-counter-identity.json", "queue-shortcut-overlay-proof.json", "transport-diagnostic-identity.json", "source-inventory.json"]:
    add(PROJECT / name, "source/" + name)
for name in changed:
    add(base / name, "source/original/" + name)
    add(PROJECT / name, "source/instrumented/" + name)
for name in sorted(set(combined["source"]) - set(originals)):
    add(PROJECT / name, "source/added/" + name)
add(PROJECT / "tools/performance/current/campaign160.py", "source/frozen-runner/campaign160.py")
add(Path(__file__), "source/archive-diagnostic.py")
reference_archive = DESTINATION.with_name("r1-unqualified.zip")
result = read(RESULT / "r1.json")
assert result["source_input_sha256"] == "752924c562f275804cee40cbd2a8760f8f0780cab3276a04330db63a2866e780"
assert sha((RESULT / "r1.json.final.bin").read_bytes()) == result["final_sha256"]
manifest = {
    "schema": 1,
    "diagnostic_only": True,
    "business_qualified": False,
    "fixed_window": {"prefix_steps": 1000, "sample_steps": 6000, "completed_steps": 7000},
    "reference_archive": {"path": reference_archive.name, "sha256": sha(reference_archive.read_bytes()), "scope": "Existing archive contains the identical frozen input and complete world/ordered-event final binary; these large files are not duplicated here."},
    "input_sha256": result["source_input_sha256"],
    "complete_world_and_ordered_events_bin_sha256": result["final_sha256"],
    "source_authority": {"base_original_files": 2220, "diagnostic_files": 2227, "canonical_source_map_fingerprint": combined["canonical_source_map_fingerprint"], "reverse_order": ["transport", "queue_shortcut", "clinical"], "modified_original_files": list(changed), "all_original_bytes_restored_and_compared": True, "archived_original_and_instrumented_files": len(changed), "complete_source_tree_not_duplicated": True},
    "timing_scope": "Raw stage and function/branch hooks include diagnostic overhead. Inclusive hooks can overlap, cover prefix plus sample, and cannot be subtracted from the sampled root stages as exclusive CPU. This archive does not establish a speedup or performance compliance.",
    "captured_status_scope": "The frozen old runner left status.json as running after its final coverage assertion. Complete r1 result, 7000 real steps, process return, and independent equivalence verification establish completion. Historical status is retained unchanged.",
    "files": {name: {"bytes": len(data), "sha256": sha(data), "captured_from": sources[name]} for name, data in sorted(entries.items())},
}
entries["manifest.json"] = (json.dumps(manifest, ensure_ascii=False, indent=2) + "\n").encode()
with zipfile.ZipFile(DESTINATION, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, data in sorted(entries.items()):
        archive.writestr(name, data)
with zipfile.ZipFile(DESTINATION) as archive:
    assert archive.testzip() is None
    for name, row in manifest["files"].items():
        data = archive.read(name)
        assert len(data) == row["bytes"] and sha(data) == row["sha256"], name
checks = {"archive": str(DESTINATION), "archive_bytes": DESTINATION.stat().st_size, "sha256": sha(DESTINATION.read_bytes()), "entries": len(entries), "all_archived_file_bytes_verified": True, "all_2220_original_source_bytes_restore_exactly": True, "input_and_final_deduplicated_via_r1_archive": True, "elapsed_seconds": time.perf_counter() - started}
(RUN / "archive-checks.json").write_text(json.dumps(checks, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps(checks))
