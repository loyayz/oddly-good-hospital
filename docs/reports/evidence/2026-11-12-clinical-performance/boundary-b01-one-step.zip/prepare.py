import hashlib,importlib.util,json,re,shutil
from pathlib import Path

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
BASE=ROOT/'.cache/performance160-clinical-family-20261112-v3-candidate01/project'
PROJECT=HERE/'project';HELPER='tools/performance/current/boundary_step_trace.gd';DRIVER='tools/performance/current/boundary_step_driver.gd'
PREFIX='const _BoundaryProbe=preload("res://'+HELPER+'")\n'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda data:hashlib.sha256(data).hexdigest()
spec=importlib.util.spec_from_file_location('probe_arguments',BASE/'tools/performance/current/function_probe.py');arguments_module=importlib.util.module_from_spec(spec);spec.loader.exec_module(arguments_module)

def inverse(text,changes):
 for old,new in reversed(changes):
  if old:
   assert text.count(new)==1; text=text.replace(new,old,1)
  else:
   assert text.endswith(new);text=text[:-len(new)]
 return text

class Patch:
 def __init__(self,name):
  self.name=name;self.original=(BASE/name).read_bytes();self.text=self.original.decode('utf-8');self.changes=[]
  assert '\r' not in self.text and '_BoundaryProbe' not in self.text
  match=re.search(r'^extends RefCounted\n',self.text,re.M);assert match
  header=self.text[:match.end()];self.replace(header,header+PREFIX)
 def replace(self,old,new):
  assert self.text.count(old)==1,(self.name,old);self.text=self.text.replace(old,new,1);self.changes.append((old,new))
 def wrap(self,name,world='world',actor='actor.id',space='space',kind='value',extra='{}',after=''):
  matches=list(re.finditer(r'^(?:static )?func '+re.escape(name)+r'\((.*)\)\s*->\s*([^:\n]+):$',self.text,re.M));assert len(matches)==1,(self.name,name)
  m=matches[0];header=m[0];result=m[2].strip();renamed=header.replace('func '+name+'(','func _boundary_original_'+name+'(',1);self.replace(header,renamed)
  call='_boundary_original_'+name+'('+arguments_module.arguments(m[1])+')'
  body=header+'\n\tvar _boundary_context: Dictionary=_BoundaryProbe.enter("'+name+'",'+space+','+world+','+actor+','+extra+')\n'
  body+='\t'+('var _boundary_result: '+result+'=' if result!='void' else '')+call+'\n'
  if after:body+='\t'+after+'\n'
  body+='\t_BoundaryProbe.leave(_boundary_context,'+space+','+world+','+('_boundary_result' if result!='void' else 'null')+',"'+kind+'")\n'
  if result!='void':body+='\treturn _boundary_result\n'
  suffix='\n# Generated one-step boundary wrapper: '+name+'\n'+body;self.text+=suffix;self.changes.append(('',suffix))
 def contact(self):
  name='_movement_contacts';match=re.search(r'^func '+name+r'\((.*)\) -> void:$',self.text,re.M);assert match
  header=match[0];self.replace(header,header.replace('func '+name+'(','func _boundary_original_'+name+'(',1))
  body=header+'\n\tvar _boundary_parent: Array=_BoundaryProbe.contact_enter()\n\t_boundary_original_'+name+'('+arguments_module.arguments(match[1])+')\n\t_BoundaryProbe.contact_leave(_boundary_parent,space,world,actor_id,broad,result)\n'
  suffix='\n# Generated one-step contact observer\n'+body;self.text+=suffix;self.changes.append(('',suffix))
 def proof(self):
  restored=inverse(self.text,self.changes).encode('utf-8');assert restored==self.original,self.name
  return {'original_sha256':sha(self.original),'instrumented_sha256':sha(self.text.encode()),'full_file_and_bodies_restore_exactly':True,'replacements':[{'original':a,'instrumented':b} for a,b in self.changes]}

assert not PROJECT.exists() and not (HERE/'identity.json').exists()
base_record=read(BASE.parent/'freeze.json');assert base_record['commit']=='9e3a1e0faeb2f2425ee1d6d5821c96b019cfb57d'
assert all(sha((BASE/n).read_bytes())==v for n,v in base_record['source'].items())
source_input=BASE.parent/'qualification-r1/r1.json.final.bin';assert sha(source_input.read_bytes())=='0afa344f973e4ce8b12ce46a034f3dc754f43e42e446938e94f4ed47163aaf74'
movement=Patch('game/building/hospital_movement.gd')
anchor='\t\tvar actor: Dictionary = world.facts.actors[actor_id]\n\t\tif movement.get("replan_after_transit",false)'
movement.replace(anchor,'\t\tvar actor: Dictionary = world.facts.actors[actor_id]\n\t\t_BoundaryProbe.actor_turn(space,world,actor,movement)\n\t\tif movement.get("replan_after_transit",false)')
movement.wrap('advance',actor='""')
for name in ['_move_step','_convoy_turn_contact']:movement.wrap(name,kind='motion')
for name in ['_bed_goal_blocker','_bed_local_path_blocker','_active_route_clear','_local_resume','_local_collision','_local_try_return','_local_goal_occupied','_local_path_clear']:movement.wrap(name)
movement.wrap('_local_movable',world='_world')
movement.wrap('queue_waypoint',actor='str(movement.actor_id)',extra='{"requested_floor":floor_id,"requested_cell":cell.duplicate()}')
movement.contact()
transit=Patch('game/building/hospital_transit.gd')
transit.wrap('_alight',actor='str(connection.get("primary_actor_id",connection.riders[0]))',extra='{"connection_before":connection.duplicate(true)}',after='if not _boundary_context.is_empty(): _boundary_context.extra.connection_after=connection.duplicate(true)')
transit.wrap('egress_clear',actor='actor_id',extra='{"connection_before":connection.duplicate(true),"destination_floor":floor_id,"members":members.duplicate()}',after='if not _boundary_context.is_empty(): _boundary_context.extra.connection_after=connection.duplicate(true)')
patches=[movement,transit];proof={p.name:p.proof() for p in patches}
PROJECT.mkdir(parents=True,exist_ok=False)
for name in base_record['source']:
 target=PROJECT/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(BASE/name,target)
for name in ['.godot/imported','game/platform/windows/bin']:shutil.copytree(BASE/name,PROJECT/name,dirs_exist_ok=True)
for name in ['.godot/global_script_class_cache.cfg','.godot/extension_list.cfg']:shutil.copy2(BASE/name,PROJECT/name)
for original,relative in [('driver.gd',DRIVER),('trace.gd',HELPER)]:shutil.copy2(HERE/original,PROJECT/relative)
inventory=sorted([*base_record['source'],DRIVER,HELPER]);(PROJECT/'source-inventory.json').write_text(json.dumps(inventory,indent=2),encoding='utf-8')
plain={n:sha((PROJECT/n).read_bytes()) for n in inventory}
for patch in patches:
 target=HERE/'instrumented'/patch.name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(patch.text.encode('utf-8'))
traced=dict(plain)
for name,row in proof.items():traced[name]=row['instrumented_sha256']
record={'base_project':str(BASE),'pinned_commit':base_record['commit'],'original_source':base_record['source'],'plain_source':plain,'traced_source':traced,'input':str(source_input),'input_sha256':sha(source_input.read_bytes()),'source_inverse':proof,'engine_executables':base_record['engine_executables'],'native':base_record['native'],'driver':DRIVER,'helper':HELPER,'scope':'Only an external new copy. One readonly dump and two cold normal Runtime processes with one real step each, no commands or actor manipulation. Source hooks observe original bodies once; two complete ending envelopes must match.'}
(HERE/'identity.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
print(json.dumps({'project':str(PROJECT),'original_files':len(base_record['source']),'plain_files':len(plain),'wrapped_methods':16,'full_original_bytes_restore_exactly':True,'engine_started':False}))
