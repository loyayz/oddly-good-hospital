extends SceneTree
const Trace = preload("res://tools/performance/current/boundary_step_trace.gd")

func _initialize() -> void: call_deferred("run")

func run() -> void:
	var input: String="";var output: String="";var mode: String="readonly"
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--input="): input=arg.trim_prefix("--input=")
		if arg.begins_with("--output="): output=arg.trim_prefix("--output=")
		if arg.begins_with("--mode="): mode=arg.trim_prefix("--mode=")
	if input.is_empty() or output.is_empty() or FileAccess.file_exists(output) or not mode in ["readonly","plain","trace"]: quit(2);return
	var content:=HospitalContent.new();var file: FileAccess=FileAccess.open(input,FileAccess.READ);var envelope: Dictionary=file.get_var(false);file.close()
	var world:=WorldState.new(envelope.facts);var before: Dictionary=world.freeze();var reason: String=world.validate(content)
	if not reason.is_empty() or envelope.content_fingerprint!=content.content_fingerprint: quit(2);return
	if mode=="readonly":
		var space:=HospitalSpace.new(content);var dump: Dictionary=Trace.dump(space,world)
		dump.input_sha256=FileAccess.get_sha256(input)
		FileAccess.open(output,FileAccess.WRITE).store_string(JSON.stringify(dump,"\t",true,true))
		print(JSON.stringify({"mode":mode,"tick":world.sim_tick,"actors":world.facts.actors.size(),"unchanged":dump.unchanged}));quit(0 if dump.unchanged else 1);return
	var policy: Dictionary=ClassDB.class_call_static("PlatformThreadPolicy","apply_main_thread")
	var sim:=HospitalSimulation.new(world,content)
	sim.services.experience.sample_workers_enabled=true;sim.services.experience.sample_worker_tasks=4
	var floor_preparation: Dictionary=sim.prepare_floor_static(1)
	var initialized: Dictionary=world.freeze()
	if mode=="trace": Trace.start()
	var result: TickResult=sim.step()
	var trace: Dictionary=Trace.finish(sim.space,world) if mode=="trace" else {}
	var validation: String=world.validate(content)
	var ending: Dictionary=envelope.duplicate(true)
	ending.facts=world.freeze()
	var events: Array=envelope.get("events",[]).duplicate(true)
	for event: SimEvent in result.facts: events.append(event.to_record())
	ending.events=events
	var binary: FileAccess=FileAccess.open(output+".bin",FileAccess.WRITE);binary.store_var(ending);binary.close()
	var report: Dictionary={"mode":mode,"input_sha256":FileAccess.get_sha256(input),"initial_tick":int(before.sim_tick),"final_tick":world.sim_tick,"actual_steps":1,"initial_actor_records":before.actors.size(),"final_actor_records":world.facts.actors.size(),"initial_facts_sha256":Trace.hash_value(before),"cold_initialized_facts_sha256":Trace.hash_value(initialized),"cold_initialization_changed_facts":before!=initialized,"final_facts_sha256":Trace.hash_value(world.freeze()),"final_rng_sha256":Trace.hash_value(world.facts.rng),"full_world_and_ordered_events_bin_sha256":FileAccess.get_sha256(output+".bin"),"new_ordered_events":result.facts.map(func(e: SimEvent)->Dictionary:return e.to_record()),"world_validation":validation,"main_thread_policy":policy,"worker_tasks":4,"worker_report":sim.services.experience.sample_worker_report(),"floor_preparation":floor_preparation,"trace":trace,"scope":"Normal cold HospitalSimulation restore and one unmodified real step. No command is enqueued, no actor is moved by the driver and no extra quote or movement attempt is executed. Initialization is recorded separately. Diagnostic elapsed time is not performance evidence."}
	FileAccess.open(output,FileAccess.WRITE).store_string(JSON.stringify(report,"\t",true,true))
	print(JSON.stringify({"mode":mode,"initial_tick":int(before.sim_tick),"final_tick":world.sim_tick,"steps":1,"hash":report.full_world_and_ordered_events_bin_sha256,"validation":validation,"trace_errors":trace.get("errors",[])}))
	sim.dispose();quit(0 if validation.is_empty() and trace.get("errors",[]).is_empty() else 1)
