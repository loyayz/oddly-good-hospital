extends RefCounted

static var active: bool=false
static var owner_thread: int=0
static var rows: Array=[]
static var stack: Array=[]
static var errors: Array=[]
static var contact_calls: int=0
static var omitted_clear_contact_records: int=0

static func point(value: Vector2) -> Array: return [value.x,value.y]
static func rect(value: Rect2) -> Array: return [value.position.x,value.position.y,value.size.x,value.size.y]

static func hash_value(value: Variant) -> String:
	var context:=HashingContext.new();context.start(HashingContext.HASH_SHA256)
	context.update(var_to_bytes(value));return context.finish().hex_encode()

static func move_summary(value: Dictionary) -> Dictionary:
	if value.is_empty(): return {}
	var row: Dictionary={}
	for key: String in ["actor_id","target_floor","target_cell","cursor","request_sequence","route_pending","route_retry_tick","waiting_reason","local_move","detour","convoy","members","offsets","route_waypoint","transit_ticket","blocked_since","exit_kind","waiting_seat_id","floor_guidance_visit_id"]:
		if value.has(key): row[key]=value[key].duplicate(true) if value[key] is Array or value[key] is Dictionary else value[key]
	row.path_size=value.get("path",[]).size()
	var index: int=int(value.get("cursor",-1))
	row.current_segment=value.path[index].duplicate(true) if index>=0 and index<row.path_size else {}
	return row

static func owners(world: WorldState, id: String) -> Array:
	var result: Array=[]
	if world.facts.staff.has(id): result.append({"kind":"staff","record":world.facts.staff[id].duplicate(true)})
	for visit: Dictionary in world.facts.visits.values():
		if visit.actor_id==id:
			result.append({"kind":"visit","record":visit.duplicate(true),"departure":world.facts.wait_departures.get(id,{}).duplicate(true)})
	for stay: Dictionary in world.facts.get("visitors",{}).get("stays",{}).values():
		if stay.actor_id==id: result.append({"kind":"family","record":stay.duplicate(true)})
	var contractor: Dictionary=world.facts.get("maintenance",{}).get("contractors",{}).get(id,{})
	if not contractor.is_empty():
		var job_id: String=str(contractor.get("job_id",""));var jobs: Array=[]
		for kind: String in ["jobs","upgrades"]:
			if world.facts.maintenance.get(kind,{}).has(job_id): jobs.append({"kind":kind,"record":world.facts.maintenance[kind][job_id].duplicate(true)})
		for order: Dictionary in world.facts.environment.get("orders",{}).values():
			for unit: Dictionary in order.get("units",[]):
				if unit.id==job_id: jobs.append({"kind":"environment_unit","order_id":order.id,"record":unit.duplicate(true)})
		result.append({"kind":"contractor","record":contractor.duplicate(true),"jobs":jobs})
	return result

static func actor_state(space: HospitalSpace, world: WorldState, id: String) -> Dictionary:
	var actor: Dictionary=world.facts.actors.get(id,{})
	if actor.is_empty(): return {"id":id,"missing":true}
	var result: Dictionary={"actor":actor.duplicate(true),"owners":owners(world,id),"move":move_summary(world.facts.moves.get(id,{}))}
	if actor.location.kind=="floor":
		result.body_rect=rect(space.body_rectangle(actor))
		result.body_dimensions=space.body(actor).duplicate(true)
	return result

static func index_record(value: BodyIndex.Record) -> Dictionary:
	if value==null: return {}
	var regions: Array=[]
	for region: Rect2 in value.regions: regions.append(rect(region))
	return {"id":value.id,"floor_id":value.floor_id,"rect":rect(value.rect),"sweep_from":rect(value.sweep_from),"sweep_to":rect(value.sweep_to),"regions":regions,"boundary":value.boundary}

static func motion(space: HospitalSpace, world: WorldState, value: Variant) -> Variant:
	if value==null: return null
	var blockers: Dictionary={};var reservations: Dictionary={}
	for id: String in value.blocker_actor_ids:
		var row: Dictionary=actor_state(space,world,id)
		row.index_record=index_record(space._actor_index._records.get(id))
		row.accepted_sweep=index_record(space.movement._accepted_sweeps.get(id))
		blockers[id]=row
	for id: String in value.reservation_ids: reservations[id]=world.facts.adaptations.get(id,{}).duplicate(true)
	return {"blocked":value.blocked,"requested_motion":point(value.requested_motion),"actual_motion":point(value.actual_motion),"blocker_actor_ids":value.blocker_actor_ids.duplicate(),"reservation_ids":value.reservation_ids.duplicate(),"static_reason":value.static_reason,"door_id":value.door_id,"first_contact_only":value.first_contact_only,"blocker_states_at_return":blockers,"reservation_states_at_return":reservations,"index_owner":{"same_world":space._indexed_world==world,"same_facts":is_same(space._indexed_facts,world.facts),"indexed_revision":space._indexed_revision,"world_revision":world.revision}}

static func start() -> void:
	owner_thread=OS.get_thread_caller_id();rows=[];stack=[];errors=[];contact_calls=0;omitted_clear_contact_records=0;active=true

static func enabled() -> bool: return active and OS.get_thread_caller_id()==owner_thread

static func enter(name: String, space: HospitalSpace, world: WorldState, id: String, extra: Dictionary={}) -> Dictionary:
	if not enabled(): return {}
	var context: Dictionary={"name":name,"actor_id":id,"tick":world.sim_tick,"parent":stack.duplicate(),"before":actor_state(space,world,id) if not id.is_empty() else {},"extra":extra}
	stack.append(name);return context

static func leave(context: Dictionary, space: HospitalSpace, world: WorldState, value: Variant=null, result_kind: String="value") -> void:
	if context.is_empty(): return
	if stack.is_empty() or stack.back()!=context.name: errors.append("Unbalanced boundary wrapper: "+str(context.name))
	else: stack.pop_back()
	context.after=actor_state(space,world,context.actor_id) if not str(context.actor_id).is_empty() else {}
	context.result=motion(space,world,value) if result_kind=="motion" else value
	context.result_kind=result_kind
	rows.append(context)

static func contact_enter() -> Array:
	if not enabled(): return []
	contact_calls+=1;return stack.duplicate()

static func contact_leave(parent: Array, space: HospitalSpace, world: WorldState, id: String, broad: Rect2, result: Variant) -> void:
	if not enabled(): return
	if not result.blocked: omitted_clear_contact_records+=1;return
	rows.append({"name":"_movement_contacts","actor_id":id,"tick":world.sim_tick,"parent":parent,"kind":"readonly_return_proof_contact" if result.first_contact_only else ("actual_move_attempt_contact" if "_move_step" in parent else "runtime_contact_query"),"broad_rect":rect(broad),"actor_at_contact":actor_state(space,world,id),"result":motion(space,world,result)})

static func actor_turn(space: HospitalSpace, world: WorldState, actor: Dictionary, movement: Dictionary) -> void:
	if not enabled(): return
	rows.append({"name":"actor_turn","tick":world.sim_tick,"actor_id":actor.id,"state":actor_state(space,world,actor.id),"branch_inputs":{"location_kind":actor.location.kind,"route_pending":movement.get("route_pending",false),"accepted_sweep_already_spent":space.movement._accepted_sweeps.has(actor.id),"has_local":movement.has("local_move"),"has_convoy":movement.has("convoy")}})

static func finish(space: HospitalSpace, world: WorldState) -> Dictionary:
	active=false
	if not stack.is_empty(): errors.append("Boundary wrappers did not close")
	return {"records":rows,"errors":errors,"contact_calls":contact_calls,"omitted_clear_contact_records":omitted_clear_contact_records,"scope":"One original real sim.step. Wrapped bodies run once unchanged. MotionResult records are actual method returns; readonly return-proof contacts are labeled separately. Clear contact records alone are omitted from output, never from execution. No extra movement, command, yield or random draw is submitted."}

static func dump(space: HospitalSpace, world: WorldState) -> Dictionary:
	var before: Dictionary=world.freeze();var actors: Dictionary={};var floors: Dictionary={};var critical: Dictionary={}
	var visits_by_actor: Dictionary={}
	for visit: Dictionary in world.facts.visits.values(): visits_by_actor[visit.actor_id]=visit
	for id: String in world.ids("actors"):
		var actor: Dictionary=world.facts.actors[id];var move: Dictionary=world.facts.moves.get(id,{})
		actors[id]=actor_state(space,world,id)
		var floor_id: int=int(actor.location.get("floor_id",0)) if actor.location.kind=="floor" else 0
		var key: String=str(floor_id) if floor_id>0 else str(actor.location.kind)
		var group: Dictionary=floors.get_or_add(key,{"actors":0,"moves":0,"local":0,"route_pending":0,"leaving_visits":0,"target_floors":{}})
		group.actors+=1
		if not move.is_empty():
			group.moves+=1
			if move.has("local_move"): group.local+=1
			if move.get("route_pending",false): group.route_pending+=1
			var target: String=str(move.target_floor);group.target_floors[target]=int(group.target_floors.get(target,0))+1
		var visit: Dictionary=visits_by_actor.get(id,{})
		if visit.get("phase","")=="leaving": group.leaving_visits+=1
		var diagnosis: Dictionary=visit.get("diagnosis",{})
		var selected: bool=(visit.get("id","") in ["bench_visit_0020","bench_visit_0021","bench_visit_0022","bench_visit_0023"] or visit.get("phase","") in ["wait_examination","wait_consult"] or diagnosis.get("exam_completed",false) and not diagnosis.get("review_completed",false))
		selected=selected or world.facts.get("maintenance",{}).get("contractors",{}).has(id)
		for owner: Dictionary in actors[id].owners:
			if owner.kind=="family": selected=true
		if selected: critical[id]=actors[id]
	var result: Dictionary={"tick":world.sim_tick,"actor_records":world.facts.actors.size(),"present":world.present_actor_count(),"floors":floors,"actors":actors,"critical":critical,"moves":world.facts.moves.duplicate(true),"connectors":world.facts.connectors.duplicate(true),"ward_stays":world.facts.ward_stays.duplicate(true),"visitors":world.facts.visitors.duplicate(true),"wait_departures":world.facts.wait_departures.duplicate(true),"facts":before,"complete_facts_sha256":hash_value(before),"rng_sha256":hash_value(before.rng),"unchanged":world.freeze()==before,"scope":"Readonly complete fixed-final facts and current bodies. Stored Move flags are branch inputs, not a claim that a branch executed. Actual one-hop blockers and decisions come from the separate traced real step, not an extra quote or move."}
	return result
