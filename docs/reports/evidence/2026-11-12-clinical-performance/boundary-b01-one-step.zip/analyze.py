import collections
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
read = lambda name: json.loads((HERE / name).read_text(encoding="utf-8-sig"))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
dump, traced, identity = read("readonly.json"), read("trace.json"), read("identity.json")
records = traced["trace"]["records"]
motions = [r for r in records if r["name"] == "_move_step"]
actual_by_actor = {r["actor_id"]: r for r in motions}
edges = {(r["actor_id"], b) for r in motions for b in r["result"]["blocker_actor_ids"]}
mutual_pairs = sorted({tuple(sorted((a, b))) for a, b in edges if (b, a) in edges})


def owner_summary(owners):
    result = []
    for owner in owners:
        row, value = {"kind": owner["kind"]}, owner["record"]
        for key in ["id", "phase", "visit_id", "purpose", "remaining_ticks", "return_ward_first", "yielding", "role", "on_shift", "active_job_id", "base_prepared", "base_task", "life_task", "job_id", "diagnosis", "ticket_id", "final_result", "departure_reason"]:
            if key in value:
                row[key] = value[key]
        if "jobs" in owner:
            row["jobs"] = owner["jobs"]
        result.append(row)
    return result


def state_summary(value):
    return {"actor": value.get("actor"), "body_rect": value.get("body_rect"), "move": value.get("move"), "owners": owner_summary(value.get("owners", []))}


def actual_summary(r):
    value = r["result"]
    result = {key: item for key, item in value.items() if key not in ["blocker_states_at_return", "reservation_states_at_return"]}
    result["blockers"] = {actor_id: {**state_summary(state), "index_record": state["index_record"], "accepted_sweep": state["accepted_sweep"]} for actor_id, state in value["blocker_states_at_return"].items()}
    result["before"] = state_summary(r["before"])
    result["after"] = state_summary(r["after"])
    return result


critical = {}
for actor_id, original in dump["critical"].items():
    if original["actor"]["location"]["kind"] == "outside":
        continue
    rows = [r for r in records if r["actor_id"] == actor_id]
    decisions = [{"name": r["name"], "result": r.get("result"), "before_move": r.get("before", {}).get("move"), "after_move": r.get("after", {}).get("move")} for r in rows if r["name"] in ["_active_route_clear", "_local_resume", "_local_try_return", "_local_movable", "_local_collision", "queue_waypoint"]]
    critical[actor_id] = {"input": state_summary(original), "actual_move_step": actual_summary(actual_by_actor[actor_id]) if actor_id in actual_by_actor else None, "decisions": decisions}

no_attempts = []
for row in records:
    if row["name"] != "actor_turn" or row["actor_id"] in actual_by_actor:
        continue
    no_attempts.append({"actor_id": row["actor_id"], "branch_inputs": row["branch_inputs"], "state": state_summary(row["state"])})

summary = {
    "scope": "A single latest B01 end boundary, one readonly dump and two independent cold normal Runtime processes with exactly one real step. No commands, extra quotes, injected movements, cancelled requests, load reduction or rule changes. This is behavior diagnosis, not a performance sample or a historical deadlock proof.",
    "base_commit": identity["pinned_commit"],
    "input": identity["input"],
    "input_sha256": identity["input_sha256"],
    "initial_facts_sha256": dump["complete_facts_sha256"],
    "cold_initialized_facts_sha256": traced["cold_initialized_facts_sha256"],
    "cold_initialization_changed_facts": traced["cold_initialization_changed_facts"],
    "output_sha256": traced["full_world_and_ordered_events_bin_sha256"],
    "equivalence": read("equivalence.json"),
    "executions": read("execution.json"),
    "source_inventory_count": len(identity["original_source"]),
    "plain_and_traced_inventory_count": len(identity["plain_source"]),
    "source_identity_file_sha256": sha(HERE / "identity.json"),
    "engine_executables": identity["engine_executables"],
    "native": identity["native"],
    "tick_before": traced["initial_tick"],
    "tick_after": traced["final_tick"],
    "actor_records": dump["actor_records"],
    "present": dump["present"],
    "floors": dump["floors"],
    "method_calls": dict(collections.Counter(r["name"] for r in records)),
    "actual_ground_moves": {
        "attempts": len(motions),
        "blocked": sum(r["result"]["blocked"] for r in motions),
        "clear_with_actual_displacement": sum(not r["result"]["blocked"] and r["result"]["actual_motion"] != [0, 0] for r in motions),
        "blocked_by_floor": dict(collections.Counter(str(r["before"]["actor"]["location"]["floor_id"]) for r in motions if r["result"]["blocked"])),
        "all_blocked_have_actor_only_contacts": all(r["result"]["blocker_actor_ids"] and not r["result"]["static_reason"] and not r["result"]["reservation_ids"] for r in motions if r["result"]["blocked"]),
        "one_step_mutual_blocking_pairs": mutual_pairs,
        "directed_edges": sorted(edges),
    },
    "all_active_route_checks_clear": all(r["result"] for r in records if r["name"] == "_active_route_clear"),
    "all_actual_bed_goal_and_local_checks_empty": all(r["result"] == "" for r in records if r["name"] in ["_bed_goal_blocker", "_bed_local_path_blocker"]),
    "no_actual_ground_attempt": no_attempts,
    "critical": critical,
    "transit": {"input_connections": dump["connectors"], "actual_calls": [r for r in records if r["name"] in ["_alight", "egress_clear"]]},
    "local_intent_handoff_0077_staff0016": {
        "staff_initial_target": dump["actors"]["bench_staff_0016"]["move"]["local_move"]["target"],
        "staff_actual_step_target": actual_by_actor["bench_staff_0016"]["before"]["move"]["local_move"]["target"],
        "patient_actual_step": actual_summary(actual_by_actor["bench_patient_0077"]),
        "staff_actual_step": actual_summary(actual_by_actor["bench_staff_0016"]),
        "interpretation": "Both actual attempts move toward the other current body. Staff local target changed inside this original advance before its turn; this is not evidence of a collision false positive. A blocker index sweep may describe an intention even when accepted_sweep is empty; it is not proof of actual movement. The current one-step trace does not establish duration or a new yielding priority.",
    },
    "new_ordered_events": traced["new_ordered_events"],
    "limitations": [
        "The complete 7000-step performance campaign remains unqualified. A one-step equivalent replay does not fill missing business coverage.",
        "Only this restored boundary is observed. Mutual one-step contacts alone do not prove a persistent cycle or explain all earlier missing work.",
        "egress_clear false is directly observed; its internal first failing static/reservation/body/sweep branch is not instrumented here. The nearby 0077 body is a separate geometry fact, not an asserted actual return-site blocker.",
        "Plain and trace process elapsed times include loading and diagnostic serialization. They are not simulation latency or optimization evidence.",
    ],
    "artifact_sha256": {name: sha(HERE / name) for name in ["prepare.py", "run.py", "analyze.py", "driver.gd", "trace.gd", "identity.json", "readonly.json", "plain.json", "trace.json", "plain.json.bin", "trace.json.bin", "equivalence.json", "execution.json"]},
}
target = HERE / "boundary-summary.json"
assert not target.exists(), "Preserve existing summary evidence"
target.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps({"summary": str(target), "bytes": target.stat().st_size, "sha256": sha(target), "actual_move_attempts": len(motions), "mutual_pairs": len(mutual_pairs)}))
