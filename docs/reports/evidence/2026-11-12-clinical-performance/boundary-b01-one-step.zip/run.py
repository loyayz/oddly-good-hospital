import hashlib,importlib.util,json,os,shutil,subprocess,time
from pathlib import Path

HERE=Path(__file__).resolve().parent;identity=json.loads((HERE/'identity.json').read_text(encoding='utf-8'));PROJECT=HERE/'project'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
spec=importlib.util.spec_from_file_location('campaign',PROJECT/'tools/performance/current/campaign160.py');campaign=importlib.util.module_from_spec(spec);spec.loader.exec_module(campaign)
engine=Path('C:/programs/Godot/Godot_v4.7.2-stable_win64_console.exe');results=[]
for mode in ['readonly','plain','trace']:
 assert not campaign.processes(),'Another engine/compiler is active'
 assert campaign.engine_identity(engine)==identity['engine_executables'] and campaign.native_identity(PROJECT)==identity['native']
 assert sha(Path(identity['input']))==identity['input_sha256']
 if mode=='trace':
  assert all(sha(PROJECT/n)==v for n,v in identity['plain_source'].items())
  for n,p in identity['source_inverse'].items():
   source=HERE/'instrumented'/n;assert sha(source)==p['instrumented_sha256'];shutil.copy2(source,PROJECT/n)
 source=identity['traced_source'] if mode=='trace' else identity['plain_source']
 assert all(sha(PROJECT/n)==v for n,v in source.items())
 target=HERE/(mode+'.json');log_path=HERE/(mode+'.log');assert not target.exists() and not log_path.exists()
 command=[str(engine),'--headless','--path',str(PROJECT),'--script','res://'+identity['driver'],'--','--input='+identity['input'],'--output='+str(target),'--mode='+mode]
 environment=dict(os.environ,OMP_NUM_THREADS='1',APPDATA=str(HERE/'runtime'/mode/'Roaming'),LOCALAPPDATA=str(HERE/'runtime'/mode/'Local'))
 for key in ['APPDATA','LOCALAPPDATA']:Path(environment[key]).mkdir(parents=True,exist_ok=True)
 row={'mode':mode,'command':command};started=time.perf_counter()
 with log_path.open('w',encoding='utf-8') as log:
  process=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,env=environment,creationflags=subprocess.CREATE_NO_WINDOW)
  row['engine_launcher_pid']=process.pid;(HERE/'status.json').write_text(json.dumps(row),encoding='utf-8')
  try:
   while process.poll() is None:
    time.sleep(.25);text=log_path.read_text(encoding='utf-8')
    if 'SCRIPT ERROR:' in text or any(l.startswith('ERROR:') for l in text.splitlines()):row['failure']='Godot diagnostic error';break
    if time.perf_counter()-started>120:row['failure']='One-step diagnostic exceeded 120 seconds';break
  finally:campaign.stop_owned_process_tree(process)
 row.update(returncode=process.returncode,elapsed_seconds=time.perf_counter()-started);results.append(row)
 (HERE/'execution.json').write_text(json.dumps(results,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in row.items() if k!='command'}),flush=True)
 assert process.returncode==0 and 'failure' not in row,(row,log_path)
 assert all(sha(PROJECT/n)==v for n,v in source.items())
 assert campaign.engine_identity(engine)==identity['engine_executables'] and campaign.native_identity(PROJECT)==identity['native']
 if mode=='readonly':assert read(target)['unchanged'] and read(target)['actor_records']==179
 else:assert read(target)['actual_steps']==1 and read(target)['initial_tick']==7633 and read(target)['final_tick']==7634 and not read(target)['world_validation']
plain,traced=read(HERE/'plain.json'),read(HERE/'trace.json')
checks={'same_complete_source_input':plain['input_sha256']==traced['input_sha256']==identity['input_sha256'],'one_normal_real_step_each':plain['actual_steps']==traced['actual_steps']==1,'complete_world_and_all_ordered_events_equal':sha(HERE/'plain.json.bin')==sha(HERE/'trace.json.bin')==plain['full_world_and_ordered_events_bin_sha256']==traced['full_world_and_ordered_events_bin_sha256'],'same_cold_initialization':plain['cold_initialized_facts_sha256']==traced['cold_initialized_facts_sha256'],'world_validation_passed':not plain['world_validation'] and not traced['world_validation'],'trace_stack_complete':not traced['trace']['errors'],'readonly_full179_facts_unchanged':read(HERE/'readonly.json')['unchanged'],'base_b01_unchanged':all(sha(Path(identity['base_project'])/n)==v for n,v in identity['original_source'].items())}
for n,p in identity['source_inverse'].items():
 restored=(PROJECT/n).read_text(encoding='utf-8')
 for r in reversed(p['replacements']):
  if r['original']:assert restored.count(r['instrumented'])==1;restored=restored.replace(r['instrumented'],r['original'],1)
  else:assert restored.endswith(r['instrumented']);restored=restored[:-len(r['instrumented'])]
 checks[n+'_inverse_exact']=hashlib.sha256(restored.encode('utf-8')).hexdigest()==p['original_sha256']
report={'passed':all(checks.values()),'checks':checks,'final_bin_sha256':sha(HERE/'plain.json.bin'),'record_count':len(traced['trace']['records']),'contact_calls':traced['trace']['contact_calls'],'omitted_clear_contact_records':traced['trace']['omitted_clear_contact_records'],'scope':identity['scope']}
(HERE/'equivalence.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report),flush=True);assert report['passed']
