"""Instrument only a frozen diagnostic clone; this is not a production builder.

Usage: python prepare-graph-probe.py PATH_TO_CLONE
The runner can read Engine.get_meta("cold_graph_build_phases", []) after a step.
Original predicates, point IDs and ordered RIGHT/DOWN engine connections remain.
The phase regrouping is read-only, but its timing/outputs require the usual full
path/final-state comparison and cannot be used as an uninstrumented A/B result.
"""
from pathlib import Path
import sys


BUILD = '''func _build() -> void:
	var started: int = Time.get_ticks_usec()
	var ids: Array[int] = []
	for plot: Vector2i in geometry._plots:
		for y: int in range(plot.y*32,(plot.y+1)*32):
			for x: int in range(plot.x*32,(plot.x+1)*32): ids.append(y*SIDE+x)
	ids.sort()
	var phase: Dictionary = {"points":ids.size(),"body_size":geometry._size,"ids_us":Time.get_ticks_usec()-started}
	started = Time.get_ticks_usec()
	for id: int in ids:
		_enabled[id] = int(geometry.reason(_cell(id)).is_empty())
	phase.enabled_us = Time.get_ticks_usec()-started
	started = Time.get_ticks_usec()
	reserve_space(ids.size())
	for id: int in ids:
		add_point(id,Vector2(_cell(id)))
		if _enabled[id]==0: set_point_disabled(id,true)
	phase.engine_points_us = Time.get_ticks_usec()-started
	started = Time.get_ticks_usec()
	var connections: Array[Vector2i] = []
	var checked: int = 0
	for id: int in ids:
		if _enabled[id]==0: continue
		var cell: Vector2i = _cell(id)
		for direction: int in range(2,4):
			var next: Vector2i = cell+NEIGHBOURS[direction]
			if not _inside(next) or _enabled[_id(next)]==0: continue
			checked += 1
			if geometry.edge_reason(cell,next).is_empty():
				var other: int = _id(next)
				connections.append(Vector2i(id,other))
				_edges[id] |= 1<<direction
				_edges[other] |= 1<<(3-direction)
	phase.static_edges_us = Time.get_ticks_usec()-started
	phase.edge_checks = checked
	phase.connections = connections.size()
	started = Time.get_ticks_usec()
	for pair: Vector2i in connections: connect_points(pair.x,pair.y,true)
	phase.engine_connections_us = Time.get_ticks_usec()-started
	var phases: Array = Engine.get_meta("cold_graph_build_phases",[])
	phases.append(phase)
	Engine.set_meta("cold_graph_build_phases",phases)

'''


def main() -> None:
    project = Path(sys.argv[1]).resolve(strict=True)
    target = project / "game/building/floor_navigation.gd"
    source = target.read_text(encoding="utf-8")
    start = source.index("func _build() -> void:\n")
    end = source.index("func refresh(", start)
    if "cold_graph_build_phases" in source:
        raise SystemExit("clone is already instrumented")
    target.write_text(source[:start] + BUILD + source[end:], encoding="utf-8", newline="\n")
    print(f"diagnostic phase builder: {target}")


if __name__ == "__main__":
    main()
