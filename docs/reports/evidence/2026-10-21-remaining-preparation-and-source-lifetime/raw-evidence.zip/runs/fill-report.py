import json,pathlib,statistics
root=pathlib.Path(__file__).resolve().parent
repo=root.parent.parent
report=repo/'docs/reports/2026-10-21-remaining-preparation-and-source-lifetime.md'
def read(name):return json.loads((root/(name+'.json')).read_text(encoding='utf-8-sig'))
lines=['| 指标，毫秒 | 基线A | 修复B | 修复C | 基线D |','| --- | ---: | ---: | ---: | ---: |']
rows=[('public360','公共平均整步','mean_us'),('public360','公共P95','p95_us'),('public360','公共P99','p99_us'),('public360','公共冷首步/最大','max_us'),('gp80','GP平均整步','mean_us'),('gp80','GPP50','p50_us'),('gp80','GPP95','p95_us'),('gp80','GP最大步','max_us'),('gp80','GP冷首步','cold_first_us'),('operations40','运营平均整步','mean_us'),('operations40','运营非冷步平均','following_mean_us'),('operations40','运营P95','p95_us'),('operations40','运营冷首步/最大','max_us')]
for win,label,key in rows:lines.append('| '+label+' | '+' | '.join(f"{read(x+'-'+win)['metrics'][key]/1000:.3f}" for x in ['ga','gb','gc','gd'])+' |')
summaries=[]
for win,label in [('public360','公共'),('gp80','GP'),('operations40','运营')]:
 values=[read(x+'-'+win)['metrics']['mean_us']/1000 for x in ['ga','gb','gc','gd']]
 before=statistics.mean(values[i] for i in [0,3]);after=statistics.mean(values[i] for i in [1,2]);change=(1-after/before)*100
 summaries.append(f'{label}{before:.3f}→{after:.3f}ms（'+('下降' if change>=0 else '退化')+f'{abs(change):.2f}%）')
metrics='\n'.join(lines)+'\n\n两次基线与两次修复的窗口平均值分别为：'+'；'.join(summaries)+'。这是本次快速窗口结果，百分位分别保留，不合并成正式矩阵百分位。运营C平均步44.275ms、非冷步25.805ms、P9532.635ms均慢于两次基线；运营无稳定改善证据，不能借用GP收益宣称运营达标。'
profile='''| 同一输出步的诊断工作 | 基线 | 最终修复 |
| --- | ---: | ---: |
| GP825，移动阶段 | 182.539ms | 1.397ms |
| GP825，来源实际采集/静态几何构建 | 24 / 16次 | 0 / 0次 |
| GP80窗口，虚假floor复验/全部路线复验 | 270 / 426次 | 0 / 156次 |
| GP80窗口，行程派发/退让尝试 | 146 / 27次 | 146 / 27次 |
| GP851，4次完整冷图构建 | 188.012ms | 146.805ms |
| GP851，完整入口排序构建 | 28次 / 92.085ms | 19次 / 4.911ms |
| GP851，包含全部子调用的入口排序入口 | 102次 / 94.102ms | 102次 / 6.845ms |
| GP851，取得结构图 | 2698次 | 1364次 |
| GP851，设施成员查询累计 | 614次 / 52.194ms | 614次 / 16.166ms |
| GP851，完整点路线/A* | 1118 / 263次 | 1118 / 263次 |
| 公共2651，完整入口排序构建 | 25次 / 78.746ms | 17次 / 4.512ms |
| 公共2764，等待签名累计 | 24次 / 25.870ms | 24次 / 17.567ms |
| 公共2764，同次周边依赖查询累计 | 480次 / 9.202ms | 340次 / 5.643ms |

入口排序两槽减少的只是真正重复的依据，不是将28个不同合法问题合并为1个。native完整排序的耗时包含在`_ordered_entry_cells`内。公共2651最终排序数为17，全部88次入口查询保持；相应实际毫秒以函数明细为准。

公共2764的24次签名分别来自12名候诊患者、8名家属与4个公共需求，全部仍命中已有负结果，`remember_wait`为0。耗时来自核对等待依据，不能说本步又给24人重新选座或寻路。去重只去掉同次并集的140次重复点查询，未合并不同人物观察、未延迟调度。

剩余成本明确保留：GP851的候诊/公共调度仍约756.124ms，完整点路线累计412.760ms，其中4张冷图146.805ms、实际A*34.291ms均为子成本，不能与父成本相加。查询数量1118和实际A*263没有下降，仍有大量合法不同目标的完整编排。公共冷2624区域派生`_ensure`约141.105ms，实际建造后2625又发生约149.643ms区域派生；这里3332/34是方法访问次数，不是3332/34次重建。普通公共2764仍有等待签名17.567ms、移动19.283ms、环境采样18.699ms和临床派发16.768ms。运营1190环境采样约14.553ms仍是普通步主要成本之一。当前证据没有证明这些剩余工作都可取消，亦未宣称这些长尾已全部解决。'''
# Read the actual final sort measurement rather than copying another profile.
public=read('dependency-all-public360')
step=next(s for s in public['profile']['step_records'] if s['tick']==2651)
actual=step['calls']['public_areas._ordered_entry_cells']['inclusive_us']/1000
profile=profile.replace('17次 / 4.512ms',f'17次 / {actual:.3f}ms')
text=report.read_text(encoding='utf8').replace('<!-- FINAL_METRICS -->',metrics).replace('<!-- FINAL_PROFILE -->',profile)
assert '<!-- FINAL_' not in text
text=text.replace('来源生命周期最终变更补验SPACE-10/46/48/51/54/55/56/57共8项全部通过；','来源生命周期最终变更补验SPACE-10/46/48/51/54/55/56/57共8项全部通过；等待依赖去重后补验STAFF-69/70/71/72/75共5项全部通过；')
text=text.replace('最终8项干净通过。详细批次','来源8项干净通过；同次等待依赖去重后的5项亦干净通过。详细批次')
text=text.replace('基线工程逐文件核对Git基线及工程原始字节；最终工程与当前game/content/tools-performance源码核对。','基线439个game/content/tools-performance文件逐一核对Git基线及工程原始字节；最终441个对应文件与当前源码核对，最终测试工程123个acceptance文件及生产文件匹配。')
report.write_text(text,encoding='utf8')
print('Report filled; final public sort_ms=',actual)
