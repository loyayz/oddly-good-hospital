import hashlib,json,pathlib,statistics,subprocess,zipfile
REPO=pathlib.Path(r'C:\code\loyayz\oddly-good-hospital')
ROOT=pathlib.Path(__file__).resolve().parent
OUT=REPO/'docs/reports/evidence/2026-10-21-remaining-preparation-and-source-lifetime'
BASE='fa9898b85280dc9342f6f4829a73297f3d71a359'
OUT.mkdir(parents=True,exist_ok=True)
def read(p): return json.loads(pathlib.Path(p).read_text(encoding='utf-8-sig'))
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def dump(n,v): (OUT/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def measured(name):
 d=read(ROOT/(name+'.json'))
 assert d['qualified'] and d['complete'] and not d['errors']
 assert all(d.get('public_checks',{}).values())
 return dict(run=name,metrics=d['metrics'],qualification=d['qualification'],public_checks=d.get('public_checks'),
  final_hash=d['final_binary_sha256'],input_sha256=d['source_input_sha256'],work=d['final']['work_ticks_by_kind'],query_counts=d['public']['query_counts'],
  public_work={k:d['public'][k] for k in ['actual_use_ticks','queue_actor_ticks','actual_exit_then_reuse_count']},
  starts=len(d['public']['actual_use_starts']),completions=len(d['public']['actual_use_completions']))
windows=[]
for window in ['public360','gp80','operations40']:
 rows=[measured(x+'-'+window) for x in ['ga','gb','gc','gd']]
 intermediate=[measured(x+'-'+window) for x in ['a','b','c','d','fa','fb','fc','fd']]
 if window=='gp80': intermediate.append(measured('source-fix-gp80'))
 assert len({r['final_hash'] for r in rows+intermediate})==1
 assert len({r['input_sha256'] for r in rows+intermediate})==1
 assert all(r['work']==rows[0]['work'] and r['public_work']==rows[0]['public_work'] for r in rows+intermediate)
 before=statistics.mean(rows[i]['metrics']['mean_us'] for i in [0,3]);after=statistics.mean(rows[i]['metrics']['mean_us'] for i in [1,2])
 windows.append(dict(window=window,runs=rows,intermediate_runs=intermediate,whole_world_equal=True,before_mean_us=before,after_mean_us=after,reduction_percent=(1-after/before)*100))
dump('quick-summary.json',dict(baseline=BASE,formal_pass=False,formal_acceptance_paused=True,windows=windows,caution='Final ga/gb/gc/gd are plain A/B/B/A complete steps. a/b/c/d retain partial fixes before source lifetime correction, including GP-C regression. fa/fb/fc/fd retain source lifetime fix before the last same-call dependency deduplication. Source-fix-gp80 is exploratory. Window percentiles are not pooled formal percentiles.'))
profiles=[]
for side in ['before','after','final','dependency']:
 for window in ['public360','gp80','operations40']:
  name=side+'-all-'+window;d=read(ROOT/(name+'.json'));p=d['profile'];assert not p['errors']
  assert d['qualified'] and d['complete'] and not d['errors']
  assert d['final_binary_sha256']==read(ROOT/('fa-'+window+'.json'))['final_binary_sha256']
  indices={s['tick']:s['index'] for s in d['samples']}
  steps=[dict(index=indices[s['tick']],tick=s['tick'],outer_us=s['outer_elapsed_us'],observer_us=s['observer_handler_us'],stages=s['stages'],calls=s['calls']) for s in p['step_records'] if s['calls']]
  profiles.append(dict(run=name,hash=d['final_binary_sha256'],errors=p['errors'],steps=steps))
dump('function-summary.json',dict(profiles=profiles,caution='All-instance wrappers include observer perturbation. Inclusive includes new helpers and child calls; do not sum overlapping inclusive costs. Plain windows alone quantify whole-step gains.'))
batches=[]
for line in (ROOT/'batches.txt').read_text().splitlines():
 if not line.strip(): continue
 directory=REPO/'.cache/acceptance'/line.strip();result=directory/'acceptance-results.json'
 d=read(result) if result.exists() else None
 batches.append(dict(batch=line.strip(),result=d,timing=read(directory/'timing-summary.json'),execution=read(directory/'execution-status.json')))
assert batches[-1]['result']['failed']==0 and batches[-1]['result']['completed']
dump('functional-summary.json',dict(batches=batches,formal_pass=False,caution='Initial parse failure has no result; subsequent helper readonly failure and obsolete private-interface load error are retained. Script errors invalidate the affected batch even when some case assertions pass. Final affected 8 pass; unchanged tests reuse earlier valid passing evidence.'))
before=read(ROOT/'before-project/source-identity.json');after=read(ROOT/'dependency-project/source-identity.json')
rows=[r for r in before['source'] if r['path'].startswith(('game/','content/','tools/performance/'))]
raw=subprocess.run(['git','cat-file','--batch'],input=''.join(BASE+':'+r['path']+'\n' for r in rows).encode(),cwd=REPO,check=True,stdout=subprocess.PIPE).stdout
cursor=0;baseline=[]
for r in rows:
 end=raw.index(b'\n',cursor);size=int(raw[cursor:end].split()[-1]);cursor=end+1;blob=raw[cursor:cursor+size];cursor+=size+1
 assert hashlib.sha256(blob).hexdigest()==r['sha256'],r['path']
 assert sha(ROOT/'before-project'/r['path'])==r['sha256']
 baseline.append(r)
current=[dict(**r,match=sha(REPO/r['path'])==r['sha256'] and sha(ROOT/'dependency-project'/r['path'])==r['sha256']) for r in after['source'] if r['path'].startswith(('game/','content/','tools/performance/'))]
assert all(r['match'] for r in current)
binary={k:before[k]==after[k] for k in ['engine_sha256','native_sha256','gmp_sha256','mpfr_sha256','runtime_sha256']}
assert all(v for k,v in binary.items() if k!='native_sha256') and not binary['native_sha256']
assert sha(REPO/'game/platform/windows/bin/oddly_good_platform.windows.x86_64.dll').upper()==after['native_sha256'].upper()
transforms=[]
for side in ['before','after','final','dependency']:
 directory=ROOT/(side+'-all-project');identity=read(directory/'all-instance-profile-identity.json');plain=ROOT/(side+'-project')
 for r in identity['files']:
  assert sha(plain/r['path'])==r['original_sha256']
  assert sha(directory/'.cache/tail-profile-originals'/r['path'])==r['original_sha256']
 transforms.append(dict(side=side,files=identity['transformed_file_count'],methods=identity['actual_method_count'],all_originals_match=True))
test_identity=read(REPO/'.cache/acceptance'/batches[-1]['batch']/'source-identity.json')
test_rows=[r for r in test_identity['source'] if r['path'].startswith('tests/acceptance/')]
assert test_rows and all(sha(REPO/r['path'])==r['sha256'] for r in test_rows)
test_game=[r for r in test_identity['source'] if r['path'].startswith(('game/','content/'))]
assert all(sha(REPO/r['path'])==r['sha256'] for r in test_game)
test_binary={k:after[k]==test_identity[k] for k in binary};assert all(test_binary.values())
dump('source-check.json',dict(baseline=BASE,baseline_files=baseline,final_files=current,binary_equal=binary,before_native=before['native_sha256'],after_native=after['native_sha256'],native_build_log='runs/native-build.log',test_binary_equal=test_binary,transform_originals=transforms,final_test_files=test_rows,test_game_matches=True))
files=[]
for p in ROOT.iterdir():
 if p.is_file() and p.suffix in ['.json','.bin','.ndjson','.log','.py','.ps1','.txt']: files.append(p)
 if p.is_dir() and p.name.endswith('.sources'): files.extend(x for x in p.rglob('*') if x.is_file())
for side in ['before','after','final','dependency','graph-probe']:
 directory=ROOT/(side+'-project')
 for name in ['source-identity.json','import.log','graph-probe-identity.json','entry-order-probe.gd']:
  if (directory/name).exists(): files.append(directory/name)
for side in ['before','after','final','dependency']:
 directory=ROOT/(side+'-all-project');files.append(directory/'all-instance-profile-identity.json')
 for r in read(directory/'all-instance-profile-identity.json')['files']: files.extend([directory/r['path'],directory/'.cache/tail-profile-originals'/r['path']])
archive=OUT/'raw-evidence.zip';manifest=[]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 def add(p,name):
  z.write(p,name);manifest.append(dict(path=name,sha256=sha(p),bytes=p.stat().st_size))
 for p in sorted(set(files)): add(p,'runs/'+p.relative_to(ROOT).as_posix())
 for name in ['public-v6.input.bin','gp.input.bin','op.input.bin']:
  add(REPO/'.cache/task-navigation-20261019'/name,'inputs/'+name)
 for b in batches:
  directory=REPO/'.cache/acceptance'/b['batch']
  for name in ['acceptance-results.json','execution.log','execution-status.json','source-identity.json','timing-summary.json','import.log']:
   p=directory/name
   if p.exists(): add(p,'acceptance/'+b['batch']+'/'+name)
 for r in current:
  if r['path'].startswith('game/platform/windows/') or r['path'] in ['game/building/navigation_cache.gd']:
   add(REPO/r['path'],'final-source/'+r['path'])
 for name in ['.cache/platform-guard/abi/platform_guard_abi.h','tools/build-platform-guard.ps1']:
  add(REPO/name,'build/'+pathlib.Path(name).name)
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(manifest)
 for r in manifest: assert hashlib.sha256(z.read(r['path'])).hexdigest()==r['sha256']
dump('raw-manifest.json',dict(archive='raw-evidence.zip',sha256=sha(archive),bytes=archive.stat().st_size,entries=manifest))
print(json.dumps(dict(archive_entries=len(manifest),archive_bytes=archive.stat().st_size,baseline_files=len(baseline),final_files=len(current),test_files=len(test_rows))))
for w in windows: print(w['window'],w['before_mean_us'],w['after_mean_us'],w['reduction_percent'])
