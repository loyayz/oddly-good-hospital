import importlib.util,json,pathlib,shutil,sys
root=pathlib.Path(__file__).resolve().parent
side=sys.argv[1];source=root/(side+'-project');target=root/(side+'-all-project')
assert not target.exists()
shutil.copytree(source,target)
path=source/'tools/performance/instrument_all_instances.py'
spec=importlib.util.spec_from_file_location('instrument',path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
extra={
 'public_areas':['_facility_environment','_environment_sample_indices','_queue_fit_current','_queue_fit_basis','_queue_fit_clear','_actor_index_scope'],
 'point_navigation':['_connector_preparation','_connector_edges'],
 'environment':['_prepare_facility_sources','_build_facility_sources','_prepare_actor_sources','_prepare_sample_sources']
}
for group,methods in extra.items(): module.EXTRA.setdefault(group,[]).extend(methods)
result=module.instrument(target)
result['extra_methods']=extra
(target/'all-instance-profile-identity.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps(dict(side=side,files=len(result['files']),methods=result['actual_method_count'])))
