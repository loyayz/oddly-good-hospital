extends SceneTree

const Clinical = preload("res://tools/performance/representative_clinical.gd")

# Diagnostic-only wrapper. The original candidate builder, cache and selector
# run unchanged. These retained dictionaries observe derived views, never facts.
class EntryProbe extends HospitalPublicAreas:
	var active: bool = false
	var tick: int = -1
	var rows: Array = []
	var geometries: Array = []
	var seen: Dictionary = {}
	var order_calls: int = 0
	var cell_visits: int = 0
	var facility_rows: Array = []
	func facilities(world: WorldState, reference: Dictionary, definitions: Array) -> Array:
		var result: Array = super.facilities(world,reference,definitions)
		if active:
			var area: Dictionary = region(world,reference)
			facility_rows.append({"tick":tick,"area":reference.duplicate(true),"definitions":definitions.duplicate(),"area_facilities_scanned":area.get("facilities",[]).size(),"result_ids":result.size()})
		return result
	func _entry_geometry_view(world: WorldState, actor: Dictionary, area: Dictionary) -> Dictionary:
		var result: Dictionary = super._entry_geometry_view(world,actor,area)
		if active: _geometry_id(result,area.ref)
		return result
	func _geometry_id(geometry: Dictionary, reference: Dictionary = {}) -> int:
		for index: int in geometries.size():
			if is_same(geometries[index].geometry,geometry): return index
		geometries.append({"geometry":geometry,"area":reference.duplicate(true),"cells":geometry.cells.size(),"version":geometry.get("version",-1)})
		return geometries.size()-1
	func _entry_order(actor: Dictionary, origin: Vector2, bounds: Dictionary, geometry: Dictionary, maximum_travel_ticks: int) -> Dictionary:
		if not active: return super._entry_order(actor,origin,bounds,geometry,maximum_travel_ticks)
		var start: Vector2i = Vector2i(roundi(origin.x),roundi(origin.y))
		var speed: float = float(space.content.balance.movement_speeds[str(space.clearance(actor))])
		var basis: Array = ["walking",speed,start]
		var prefix: int = ceili(origin.distance_to(Vector2(start))/speed/WorldState.TICK_SECONDS)
		if not bounds.unknown and not bounds.landings.is_empty():
			prefix = int(bounds.landings[0].ticks)
			for landing: Dictionary in bounds.landings: prefix = mini(prefix,int(landing.ticks))
			var landings: Array = []
			for landing: Dictionary in bounds.landings: landings.append({"cell":landing.cell,"ticks":int(landing.ticks)-prefix})
			basis = ["landings",speed,landings]
		var geometry_id: int = _geometry_id(geometry)
		var key: String = JSON.stringify(basis,"",true,true)
		var history: Dictionary = seen.get_or_add(geometry_id,{})
		var previous: Dictionary = history.get(key,{"calls":0})
		var cached: bool = geometry.get("ordering",{}).get("basis",[])==basis
		var before_calls: int = order_calls
		var before_visits: int = cell_visits
		var result: Dictionary = super._entry_order(actor,origin,bounds,geometry,maximum_travel_ticks)
		rows.append({"tick":tick,"actor_id":actor.id,"geometry_id":geometry_id,"origin":origin,"basis":basis,"prefix":prefix,"same_as_last_retained_basis":cached,"seen_same_basis_before":int(previous.calls)>0,"previous_same_basis_calls":previous.calls,"ordered_builder_calls":order_calls-before_calls,"full_candidate_cell_visits":cell_visits-before_visits,"area_cells":geometry.cells.size(),"known_static_points":geometry.points.size(),"result_cells":result.packed.size() if result.compact else result.fallback.size(),"compact":result.compact,"maximum_travel_ticks":maximum_travel_ticks})
		previous.calls += 1
		history[key] = previous
		return result
	func _ordered_entry_cells(actor: Dictionary, origin: Vector2, bounds: Dictionary, geometry: Dictionary, maximum_travel_ticks: int) -> Dictionary:
		if active:
			order_calls += 1
			cell_visits += geometry.cells.size()
		return super._ordered_entry_cells(actor,origin,bounds,geometry,maximum_travel_ticks)
	func report() -> Dictionary:
		var metadata: Array = []
		for index: int in geometries.size():
			metadata.append({"geometry_id":index,"area":geometries[index].area,"cells":geometries[index].cells,"version":geometries[index].version,"distinct_bases":seen.get(index,{}).size()})
		return {"rows":rows,"geometries":metadata,"ordered_builder_calls":order_calls,"full_candidate_cell_visits":cell_visits,"facilities_calls":facility_rows,"semantics":"Candidate/basis observations cover selected real steps only; no geometry or full fact tree is serialized. Seen-before means previously observed within these selected steps. Facilities counts enumerate the actual current region list and production result length."}

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var options: Dictionary = {"input":"","output":"","steps":"80","selected":"27"}
	for argument: String in OS.get_cmdline_user_args():
		if argument.begins_with("--") and "=" in argument:
			options[argument.trim_prefix("--").get_slice("=",0)] = argument.substr(argument.find("=")+1)
	if str(options.input).is_empty() or str(options.output).is_empty() or FileAccess.file_exists(str(options.output)):
		push_error("Fresh --input and --output are required")
		quit(2)
		return
	var selected: Array[int] = []
	for text: String in str(options.selected).split(",",false): selected.append(int(text))
	var content: HospitalContent = HospitalContent.new()
	var clinical: RefCounted = Clinical.new(content,str(options.input))
	if not clinical.errors.is_empty():
		push_error(JSON.stringify(clinical.errors))
		clinical.dispose()
		quit(2)
		return
	var probe: EntryProbe = EntryProbe.new(clinical.simulation.space)
	clinical.simulation.space.public_areas = probe
	var input_file: FileAccess = FileAccess.open(str(options.input),FileAccess.READ)
	var source: Dictionary = input_file.get_var()
	input_file.close()
	var public_input: Dictionary = source.get("representative_clinical",{}).get("metadata",{}).get("public_input",{})
	var events: Array = []
	for index: int in int(options.steps):
		if public_input.has("manual_command") and index==int(public_input.get("manual_command_step",0)):
			var command: Dictionary = public_input.manual_command.duplicate(true)
			command.expected_revision = clinical.world.revision
			clinical.simulation.enqueue(command)
		probe.active = index in selected
		probe.tick = clinical.world.sim_tick
		var result: TickResult = clinical.simulation.step()
		if result==null:
			clinical.errors.append(clinical.simulation.preparing_error())
			break
		clinical.observe(result)
		for event: SimEvent in result.facts: events.append(event.to_record())
	var report: Dictionary = probe.report()
	report.diagnostic_only = true
	report.formal_acceptance_paused = true
	report.input = str(options.input)
	report.input_sha256 = clinical.source_sha256
	report.selected_indices = selected
	report.requested_steps = int(options.steps)
	report.errors = clinical.errors.duplicate()
	report.final = clinical.inspect(true)
	report.complete = report.errors.is_empty() and report.final.ok
	var final_file: FileAccess = FileAccess.open(str(options.output)+".final.bin",FileAccess.WRITE)
	final_file.store_var({"facts":clinical.world.freeze(),"events":events})
	final_file.close()
	report.final_binary_sha256 = FileAccess.get_sha256(str(options.output)+".final.bin")
	var output: FileAccess = FileAccess.open(str(options.output),FileAccess.WRITE)
	output.store_string(JSON.stringify(report,"\t"))
	output.close()
	probe.active = false
	probe.geometries.clear()
	clinical.dispose()
	print("ENTRY_ORDER_DIAGNOSTIC="+JSON.stringify({"complete":report.complete,"ordered_builder_calls":report.ordered_builder_calls,"full_candidate_cell_visits":report.full_candidate_cell_visits,"output":options.output}))
	quit(0 if report.complete else 1)
