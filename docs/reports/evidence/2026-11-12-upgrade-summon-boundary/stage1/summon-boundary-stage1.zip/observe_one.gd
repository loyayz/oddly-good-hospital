extends SceneTree
class Observer extends HospitalMovement:
	var rows: Array=[]
	func _init(geometry: HospitalSpace) -> void: super(geometry)
	func _record(kind: String, world: WorldState, actor: Dictionary, movement: Dictionary, contact: HospitalMovement.MotionResult) -> void:
		if int(actor.get("location",{}).get("floor_id",-1))!=3:return
		var blockers: Dictionary={}
		for id: String in contact.blocker_actor_ids:
			blockers[id]={"actor":world.facts.actors.get(id,{}).duplicate(true),"move":world.facts.moves.get(id,{}).duplicate(true)}
		rows.append({"kind":kind,"tick":world.sim_tick,"actor":actor.duplicate(true),"move":movement.duplicate(true),"blockers":blockers,"requested":[contact.requested_motion.x,contact.requested_motion.y],"actual":[contact.actual_motion.x,contact.actual_motion.y],"static_reason":contact.static_reason,"door_id":contact.door_id,"reservation_ids":contact.reservation_ids.duplicate()})
	func _move_step(world: WorldState, actor: Dictionary, movement: Dictionary, segment: Dictionary) -> HospitalMovement.MotionResult:
		var result: HospitalMovement.MotionResult=super._move_step(world,actor,movement,segment)
		_record("move_return",world,actor,movement,result)
		return result
	func _local_collision(world: WorldState, actor: Dictionary, movement: Dictionary, contact: HospitalMovement.MotionResult) -> void:
		_record("local_entry",world,actor,movement,contact)
		super._local_collision(world,actor,movement,contact)
func _save(path: String, value: Variant) -> void:
	var file:=FileAccess.open(path,FileAccess.WRITE);file.store_var(value,false);file.close()
func _json(path: String, value: Variant) -> void:
	var file:=FileAccess.open(path,FileAccess.WRITE);file.store_string(JSON.stringify(value,"  "));file.close()
func _initialize() -> void: call_deferred("_run")
func _run() -> void:
	var args:=OS.get_cmdline_user_args();var mode: String=args[0];var out: String=args[1]
	var input: Dictionary=FileAccess.open(args[2],FileAccess.READ).get_var(false)
	var expected: Dictionary=input.duplicate(true)
	_save(out+"/expected.bin",expected)
	var sim:=HospitalSimulation.new(WorldState.new(input),HospitalContent.new())
	var pre: Dictionary=sim.world.freeze()
	_save(out+"/pre.bin",pre)
	var checks: Dictionary={"constructor_facts_equal":pre==expected,"constructor_bytes_equal":FileAccess.get_file_as_bytes(out+"/pre.bin")==FileAccess.get_file_as_bytes(out+"/expected.bin"),"input_bytes_equal":FileAccess.get_file_as_bytes(args[2])==FileAccess.get_file_as_bytes(out+"/expected.bin")}
	var observer: Observer
	if mode=="observer":
		observer=Observer.new(sim.space);sim.space.movement=observer
	if checks.constructor_facts_equal and checks.constructor_bytes_equal:
		var tick: TickResult=sim.step()
		var events: Array=[]
		for event: SimEvent in tick.facts:events.append(event.to_record())
		_save(out+"/events.bin",events);_json(out+"/events.json",events)
		var final: Dictionary=sim.world.freeze()
		_save(out+"/final.bin",final);_json(out+"/final.json",final)
		checks.steps=1;checks.final_tick=sim.world.sim_tick
	if mode=="observer":_json(out+"/contacts.json",observer.rows)
	_json(out+"/checks.json",checks)
	sim.dispose();quit(0 if checks.get("steps",0)==1 else 1)
