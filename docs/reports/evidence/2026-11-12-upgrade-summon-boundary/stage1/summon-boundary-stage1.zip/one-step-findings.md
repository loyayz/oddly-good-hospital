# Qualified cold-boundary one-step observation

Scope: original complete tick7633 input, one ordinary full HospitalSimulation.step per arm, no commands or added business queries. Plain uses ordinary production initialization; observer replaces only Movement after identical initialization. Expected is an independent deep copy saved before construction. Both restore checks and original input bytes match. Complete final World (including RNG) and ordered events match byte-for-byte; JSON also matches. Tick7634 in both. This is not original continuous warm history or performance acceptance.

Selected patient0003 actually advances east by 0.199996948242188 cells with no blocker in this step; patient0038 cannot be called its actual current blocker. Patients0034 and0118 actually collide with0003 later in the step. Thus this observation does not establish a selected-group dependency cycle or permanent stall.

Other actual retreat contacts:0054→0018(ticket54),0110→0029(ticket40),0022→0114(ticket78), each zero displacement. These establish real retreat contacts with ticketed connector waiters in the same idle/assigned landing, but not a causal path from selected0003. Preserve distinction between observed contact and static owner-eligibility inference. No production fix is proposed on a guessed dependency chain.

Exact actors/moves at contact are in observer1/contacts.json; all final facts in final.json/bin. No extra query is used for actor classification; records are passive copies. _move_step calls super once then records the real result; _local_collision records actual arguments then super. No further step was run.

Parse, plain and observer exit0/reaped. Plain wall4.646018201s, observer4.225022899s are process diagnostic times, not CPU acceptance. Production hashes and all663UID unchanged. Engine slot released.

Next useful evidence, if authorized separately: a narrowly bounded same-input trace until selected first actual blocked motion or a repeated selected local state, with passive event/World qualification. No inference of permanent deadlock from current one-step or elapsed idle alone.
