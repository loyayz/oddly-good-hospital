extends SceneTree
func _initialize() -> void:
	var args: PackedStringArray=OS.get_cmdline_user_args()
	var facts: Dictionary=FileAccess.open(args[2],FileAccess.READ).get_var(false)
	var selected: Dictionary={}
	for key: String in ["sim_tick","actors","moves","connectors","staff","visits","sessions","maintenance","tickets","adaptations","rng"]:
		selected[key]=facts.get(key,{})
	FileAccess.open(args[1]+"/decoded.json",FileAccess.WRITE).store_string(JSON.stringify(selected,"  "))
	quit(0)
