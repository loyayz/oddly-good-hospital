# New summon boundary: zero-step facts only
Input final tick7633 SHA14a9a3c17ad52e684d6a803a38e48fb08be15a07718f19100e26bfd85ee3aecf. Pure FileAccess export, no World/Sim or business query. Engine exit0 and reaped. All actors/moves/connectors and role/task collections exported, not just1F.

Lift idle3F assigned patient0003. Selected is standing3F[86,46.5999946594], request4101, ticket29 from3 to1, transit_wait cell[86,46], originalgoal1F[48,91]. Currentfloorpath [86,45]→[86,44] thenconnector; active local target[87,46.5999946594], rejoin[86,44]index1. Clinical visit is leaving/abandoned; not a maintenance worker.

Nearby patient0038 standing[86,46], request4090,ticket36,waitingcell[86,46], currentconnector3→1, no local/pending. Patient0018[85,45]ticket54,0029[84,45]ticket40,0010[87,44]ticket74,0030[88,44]ticket44 and0114[85,44]ticket78 also wait on connector. Other immediate bodies0034/0118/0106/0050 etc have floor/local routes; nurses0018/0022 and cleaner0030 have distinct ongoing floor journeys. Complete compact identities in nearby-3f-owners.json. Worker226 remains1F[85,45], not a3F collision body.

No actual contact or permanent cycle inferred from proximity. Proposed next qualification: same complete input plain1 vs observer1, one real HospitalSimulation.step each. Test-only Movement records actual _move_step result and _local_collision parameters/blocker facts then unchanged super, no added query. Compare fullpre/final World/RNG and ordered events. Await approval before any positive step.
