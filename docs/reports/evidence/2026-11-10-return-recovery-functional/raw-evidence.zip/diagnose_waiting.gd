extends SceneTree

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var args: PackedStringArray=OS.get_cmdline_user_args()
	var file: FileAccess=FileAccess.open(args[1],FileAccess.READ)
	var envelope: Dictionary=file.get_var(false)
	file.close()
	var content: HospitalContent=HospitalContent.new()
	var world: WorldState=WorldState.new(envelope.facts)
	var initial_validation: String=world.validate(content)
	var sim: HospitalSimulation=HospitalSimulation.new(world,content)
	var before: Dictionary=world.freeze()
	sim.space.begin_dynamic_route_query(world)
	var rows: Array=[]
	var counts: Dictionary={"waiting":0,"current_intent_connects":0,"earlier_unearned_point_connects":0,"neither_connects":0}
	for id: String in world.facts.moves:
		var movement: Dictionary=world.facts.moves[id]
		if movement.get("waiting_reason","")!="等待原路线局部连接空出" or not movement.has("local_move"): continue
		var actor: Dictionary=world.facts.actors[id]
		var current: Dictionary=movement.duplicate(true)
		var current_connected: bool=sim.space.movement._local_try_return(world,actor,current)
		var restarted: Dictionary=movement.duplicate(true)
		restarted.local_move.erase("rejoin")
		restarted.local_move.erase("corners")
		var restarted_connected: bool=sim.space.movement._local_try_return(world,actor,restarted)
		var earlier: bool=not current_connected and restarted_connected and int(restarted.local_move.rejoin.index)<int(movement.local_move.get("rejoin",{}).get("index",movement.cursor))
		counts.waiting+=1
		if current_connected: counts.current_intent_connects+=1
		if earlier: counts.earlier_unearned_point_connects+=1
		if not current_connected and not restarted_connected: counts.neither_connects+=1
		var nearby: Array=[]
		var rect: Rect2=sim.space.body_rectangle(actor).grow(sim.space.clearance(actor))
		for other_id: String in sim.space._actor_index.candidates(int(actor.location.floor_id),rect,[id]):
			nearby.append({"id":other_id,"rectangle":str(sim.space._actor_index.rectangle(other_id)),"movable":sim.space.movement._local_movable(world,world.facts.actors[other_id],world.facts.moves.get(other_id,{}))})
		var cursor: int=int(movement.cursor)
		rows.append({"actor_id":id,"floor":actor.location.floor_id,"location":actor.location.cell,"facing":actor.facing,"cursor":cursor,"path_size":movement.path.size(),"local":movement.local_move,"first_unearned_route_points":movement.path.slice(cursor,mini(cursor+6,movement.path.size())),"current_intent_connects":current_connected,"current_proposal":current.get("local_move",{}),"restart_connects":restarted_connected,"restart_proposal":restarted.get("local_move",{}),"earlier_connects":earlier,"nearby_actors":nearby,"recent_history":movement.travelled.slice(-8)})
	sim.space.end_route_query()
	var unchanged: bool=before==world.freeze()
	var output: FileAccess=FileAccess.open(args[0],FileAccess.WRITE)
	output.store_string(JSON.stringify({"input_sha256":FileAccess.get_sha256(args[1]),"tick":world.sim_tick,"initial_validation":initial_validation,"scope":"Cold retained terminal facts; query proposals on private movement copies only, no simulation steps or fabricated arrival","facts_unchanged":unchanged,"counts":counts,"rows":rows},"\t"))
	output.close()
	print(JSON.stringify({"counts":counts,"facts_unchanged":unchanged,"validation":initial_validation}))
	sim.dispose()
	quit(0 if unchanged and initial_validation.is_empty() else 1)
