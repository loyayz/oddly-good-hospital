from __future__ import annotations
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil

CACHE = Path(__file__).resolve().parent
REPO = CACHE.parents[1]
PRIOR = REPO/'.cache/vacant-queue-fit-50f9e9b-20261022'
SOURCE = PRIOR/'after-project'
PROJECT = CACHE/'sections-project'

def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p, value): Path(p).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')

def prepare(counts=False,variant='sections'):
    assert not PROJECT.exists()
    shutil.copytree(SOURCE,PROJECT)
    path=PROJECT/'game/life/public_areas.gd'
    original=path.read_bytes()
    text=original.decode('utf-8')
    start=text.index('func _decision_signature(')
    end=text.index('func _environment_samples(',start)
    body=text[start:end]
    nl='\r\n' if '\r\n' in body else '\n'
    modifications=[]
    def inject(token, lines):
        nonlocal body
        assert body.count(token)==1,token
        insertion=''.join(line+' # signature-section-diagnostic'+nl for line in lines)
        body=body.replace(token,insertion+token,1)
        modifications.append((insertion+token,token))
    inject('\tvar view: Dictionary', ['\tvar _sig_marks: PackedInt64Array = PackedInt64Array([Time.get_ticks_usec()])'])
    for token in ['\tvar points: Array', '\tfor number: int in _facility_members', '\tvar reach: float',
                  '\tif route_dependent:', '\tvar queue_key: String', '\tvar sorted_ids: Array',
                  '\tvar reservation_ids: Array', '\trecords.append_array(_environment_samples']:
        inject(token,['\t_sig_marks.append(Time.get_ticks_usec())'])
    fields=['setup','region','facilities','dynamic','routing','queue','actors','reservations','environment']
    inject('\treturn records',[
        '\t_sig_marks.append(Time.get_ticks_usec())',
        '\tvar _sig_keys: Array = '+json.dumps(['diag_signature_'+x+'_us' for x in fields]),
        '\tfor _sig_index: int in _sig_keys.size():',
        '\t\tvar _sig_key: String = str(_sig_keys[_sig_index])',
        '\t\tspace.query_counts[_sig_key] = int(space.query_counts.get(_sig_key,0))+_sig_marks[_sig_index+1]-_sig_marks[_sig_index]',
        '\tspace.query_counts["diag_signature_calls"] = int(space.query_counts.get("diag_signature_calls",0))+1',
    ])
    reversed_body=body
    for replacement,token in reversed(modifications): reversed_body=reversed_body.replace(replacement,token,1)
    assert reversed_body==text[start:end]
    generated_text=text[:start]+body+text[end:]
    counter_modifications=[]
    counter_proof={}
    if counts:
        counter_start=generated_text.index('func _add_dynamic_dependencies(')
        counter_end=generated_text.index('func facility_changed(',counter_start)
        original_counter=generated_text[counter_start:counter_end]
        counter=original_counter
        replacements=[
            ('\tfor id: String in space._actor_index.candidates(floor_id,bounds,members): actors[id] = true',
             '\tvar _before_actor_count: int = actors.size()'+nl+'\tvar _before_reservation_count: int = reservations.size()'+nl+'\tvar _actor_candidates: Array = space._actor_index.candidates(floor_id,bounds,members)'+nl+'\tfor id: String in _actor_candidates: actors[id] = true'),
            ('\tfor region: Dictionary in space._reservation_regions(world,floor_id,bounds):',
             '\tvar _reservation_candidates: Array = space._reservation_regions(world,floor_id,bounds)'+nl+'\tfor region: Dictionary in _reservation_candidates:'),
        ]
        for old,new in replacements:
            assert counter.count(old)==1
            counter=counter.replace(old,new,1)
            counter_modifications.append((new,old))
        tail=''.join('\tspace.query_counts["diag_dependency_'+name+'"] = int(space.query_counts.get("diag_dependency_'+name+'",0))+'+value+nl for name,value in [
            ('queries','1'),('actor_candidates','_actor_candidates.size()'),('reservation_regions','_reservation_candidates.size()'),
            ('new_actors','actors.size()-_before_actor_count'),('new_reservations','reservations.size()-_before_reservation_count')])
        counter=counter.rstrip('\r\n')+nl+tail+nl
        before_counter=generated_text
        generated_text=generated_text[:counter_start]+counter+generated_text[counter_end:]
        assert generated_text.replace(counter,original_counter,1)==before_counter
        counter_proof={'original':original_counter,'generated':counter,'inverse_byte_equal':True}
        assert all(old in original_counter for old,new in replacements)
    generated=generated_text.encode('utf-8')
    path.write_bytes(generated)
    dump(CACHE/(variant+'-source-proof.json'),{'production_path':'game/life/public_areas.gd',
        'original_sha256':hashlib.sha256(original).hexdigest(),'generated_sha256':sha(path),
        'only_inline_timestamps_and_runtime_counters':True,'inverse_byte_equal':True,
        'sections':fields,'modifications':modifications,'counter_modifications':counter_modifications,'counter_proof':counter_proof,'source_project':str(SOURCE),'project':str(PROJECT)})
    print(json.dumps({'project':str(PROJECT),'sections':fields,'inverse_byte_equal':True}),flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('action',choices=['prepare','run']);parser.add_argument('--window',choices=['public360','gp80'],default='public360');parser.add_argument('--counts',action='store_true');parser.add_argument('--after',action='store_true');args=parser.parse_args()
    assert not (args.after and args.counts)
    if args.counts: PROJECT=CACHE/'counts-project'
    variant='counts' if args.counts else 'sections'
    if args.after:
        SOURCE=CACHE/'after-project'
        PROJECT=CACHE/'after-sections-project'
        variant='after-sections'
    if args.action=='prepare': prepare(args.counts,variant)
    else:
        identity=read(PROJECT/'source-identity.json');proof=read(CACHE/(variant+'-source-proof.json'))
        assert not (PROJECT/'all-instance-profile-identity.json').exists()
        for row in identity['source']:
            assert sha(REPO/row['path'])==row['sha256'],row['path']
            if row['path']=='game/life/public_areas.gd': assert sha(PROJECT/row['path'])==proof['generated_sha256']
            elif Path(row['path']).suffix in ['.gd','.json','.py']: assert sha(PROJECT/row['path'])==row['sha256'],row['path']
        spec=importlib.util.spec_from_file_location('prior_runner',PRIOR/'run.py');runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner);runner.ROOT=CACHE
        filename,steps=runner.WINDOWS[args.window];source_input=REPO/'.cache/task-navigation-20261019'/filename
        output=CACHE/(variant+'-'+args.window+'.json');assert not output.exists()
        runner.launch(['--headless','--path',PROJECT,'--script','res://tools/performance/representative.gd','--','--input='+str(source_input),'--output='+str(output),'--steps='+str(steps),'--profile=plain'],output)
        d=read(output);ref=read(PRIOR/('b-'+args.window+'.json'))
        assert d['complete'] and d['qualified'] and not d['errors']
        assert d['final_binary_sha256']==ref['final_binary_sha256']
        for key in ['final','operations','qualification','public_checks','event_records']: assert d.get(key)==ref.get(key),key
        query_counts=dict(d['public']['query_counts']);diag={k:query_counts.pop(k) for k in list(query_counts) if k.startswith('diag_')}
        expected_counts=dict(ref['public']['query_counts'])
        if args.after:
            for key in ['public_wait_dependency_batches','public_wait_dependency_rectangles','reservation_candidate_queries']:
                query_counts.pop(key,None);expected_counts.pop(key,None)
        assert query_counts==expected_counts
        print(json.dumps({'window':args.window,'metrics_us':d['metrics'],'sections':diag,
                          'ms_per_step':{k:v/steps/1000 for k,v in diag.items() if k.endswith('_us')},'semantics_equal':True},ensure_ascii=False),flush=True)
