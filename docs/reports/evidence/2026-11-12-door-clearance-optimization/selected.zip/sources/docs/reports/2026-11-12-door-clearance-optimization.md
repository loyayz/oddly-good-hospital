# Same-instance door reach optimization: implementation and selected validation

## Rule and handoff before implementation

No gameplay rule changes. `movement_doors` must conservatively include the complete actor and every member's required door reach. Same actor ID does not imply the same dictionary or proxy body. Live static-door and reservation candidate queries, original floor-door ordering, exact permissions and full physical release remain unchanged.

The only intended production change skips recalculating the member clearance when `is_same(world.facts.actors[id], actor)` proves the initial actor reach already covers that exact dictionary. The handoff is candidate-door discovery, before existing acquisition/ownership checks.

Evidence: the fixed 48-pair real empty-door/same-instance API microbenchmark showed a local gain; it does not establish whole-step gain or nonempty/proxy correctness. Rules: `docs/specs/26-11/2026-11-05-convoy-following.md` and `tests/acceptance/convoy_door_lifecycle.md`.

## Selected validation and reasons

- New door reach query boundary: same-instance, empty members, different member, same-ID different dictionary with a larger real world member, genuine nonempty ordered doors, cold/warm query agreement and unchanged World. Query boundaries do not claim physical crossing.
- `ordinary_door_passage`: its four actual passage/body/remodel/expanded-owner cases.
- `door_passage_static_fit`: existing cold/warm, exact proxy, live ownership and cross-world/static-change checks.
- `convoy_door_lifecycle`: only `mixed_large_reverse`, `permissions`, `authorized_regroup_tail`, covering mixed bodies, outsider exclusion and real trailing ownership.

No full performance window, microbenchmark repeat, full movement suite, commit or push is included. Runtime/native/imported assets are reused by identity. Results pending below.

## Implemented result

Production diff: `hospital_space.gd` adds only the exact-instance member guard (3 insertions / 1 replaced line). Final SHA256: `97aea6add01864da51d73db7853c7a242b3ceb61505ac1bd8620f26c9fb9e69b`.

All selected executions exited 0:

| Selection | Process wall seconds | Result |
|---|---:|---|
| New final query boundary | 4.215947 | passed |
| Ordinary passage, four cases | 3.717094 | passed |
| Static fit | 3.216992 | passed |
| Convoy: mixed_large_reverse, permissions, authorized_regroup_tail | 4.319503 | passed |

The new query test constructs two real doors using production commands. Exact candidate order is `door_00000001`, `door_00000003`. A real indexed boundary query at `(42,74)` size `(0.25,0.25)` has no door for the small proxy alone, but includes `door_00000001` when the larger same-ID world member participates. Both `_convoy_size` and `_convoy_body` proxies, mixed-member maximum in both orders, empty members, exact-instance members, independently cold and warm calls, and unchanged World are checked. A production-acquired expanded reservation is present in both index and live reservation sources; its candidate appears once, in original order, with exact `door_candidates` increment and unchanged owner/world. Independent proof queries use a separate space so they do not warm the cold subject.

The initial query-only revision passed in 4.213453 s; explicitly requested extra boundaries passed in 4.113622 s; the final cold-evidence isolation correction reran only this affected query in 4.215947 s. All three raw runs are retained, not silently replaced. Unchanged ordinary/static-fit/convoy selections ran once.

`git diff --check` passed. Existing UID files are byte-preserved. No native rebuild/import, new full performance window, repeated microbenchmark, full regression, commit or push was performed. Local API microbenchmark gain is not a full-step gain or performance acceptance result.

Raw evidence is prepared in the sibling `door-clearance-selected-20261112` directory with original process commands/exits/times, test inputs/results/trace, exact test sources, identities and member hashes; publication is left to the coordinating parent.
