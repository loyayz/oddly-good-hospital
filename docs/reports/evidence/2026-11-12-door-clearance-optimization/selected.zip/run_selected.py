from pathlib import Path
import sys,json,hashlib,traceback
BASE=Path(__file__).resolve().parent;ROOT=BASE.parent/'root-stage-recovery-20261112';N=BASE.parent/'movement-stage-recovery-20261112';REPO=BASE.parent/'oddly-good-hospital-cloud-recovery-20261112'
sys.path.insert(0,str(N));import full_narrow_v1 as h
c=h.c;g=h.g;cfg=c.read(ROOT/'config.json');c.verify(cfg);c.idle();g.PROJECT=REPO;g.LIBRARY_PATH=cfg['library_path']
uid={str(p.relative_to(REPO)):c.sha(p) for p in REPO.rglob('*.uid') if '.git' not in p.parts};c.write(BASE/'uid-before.json',uid)
selected=[('query','res://tests/acceptance/run_door_reach_same_instance.gd',[]),('ordinary','res://tests/acceptance/run_ordinary_door_passage.gd',[]),('static-fit','res://tests/acceptance/run_door_passage_static_fit.gd',[]),('convoy','res://tests/acceptance/convoy_door_lifecycle.gd',['mixed_large_reverse,permissions,authorized_regroup_tail'])]
c.write(BASE/'identity.json',{'runtime':cfg,'selections':selected,'production_sha256':c.sha(REPO/'game/building/hospital_space.gd'),'new_test_sha256':{n:c.sha(REPO/'tests/acceptance'/n) for n in ['door_reach_same_instance.gd','run_door_reach_same_instance.gd']}})
for name,script,args in selected:
 c.idle();folder=BASE/name
 try:
  g.run([cfg['engine'],'--headless','--path',str(REPO),'--script',script,'--',str(folder/'result.json')]+args,folder,timeout=360,allowed_exits=(0,1))
 except BaseException:c.write(BASE/(name+'-error.json'),{'error':traceback.format_exc()});raise
 print(name,'exit',c.read(folder/'process.json')['returncode'],flush=True)
 if c.read(folder/'process.json')['returncode']!=0:break
assert all(c.sha(REPO/p)==v for p,v in uid.items());c.write(BASE/'uid-preservation.json',{'all_existing_uid_bytes_unchanged':True,'count':len(uid)})
