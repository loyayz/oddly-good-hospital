from pathlib import Path
r=Path('oddly-good-hospital-cloud-recovery-20261112');p=r/'game/building/hospital_transit.gd';s=p.read_text()
def rep(a,b):
 global s
 assert s.count(a)==1,(a[:70],s.count(a));s=s.replace(a,b)
rep('''	for id: String in world.ids("moves"):
		var m: Dictionary=world.facts.moves[id]
		if m.get("transit_ticket",{}).get("connector_id","")==connection.id and m.has("transit_wait") and _ticket_valid(space,world,m):
			return {"ok":false,"status":"estimate_unknown","reason":"实际候位或召入步行尚未完成"}
	var queued: Array = _waiting(space,world,connection.id)''','\tvar queued: Array = _waiting(space,world,connection.id,false)')
rep('''	for actor_id: String in queued:
		if actor_id==querying_actor:
			break
		var movement: Dictionary = world.facts.moves[actor_id]''','''	for actor_id: String in queued:
		var movement: Dictionary = world.facts.moves[actor_id]
		if movement.has("transit_wait") and not _at_landing(space,world,connection,movement,movement.transit_ticket):
			return {"ok":false,"status":"estimate_unknown","reason":"前方实际候位或本组召入步行尚未完成"}
		if actor_id==querying_actor:
			break''')
rep('static func _waiting(space: HospitalSpace, world: WorldState, connector_id: String) -> Array:', 'static func _waiting(space: HospitalSpace, world: WorldState, connector_id: String, available_only: bool = true) -> Array:')
rep('and _ticket_valid(space,world,movement) and _waiting_position(space,world,movement):','and _ticket_valid(space,world,movement) and (not available_only or _waiting_position(space,world,movement)):')
rep('\tif movement.transit_wait.sequence!=movement.get("request_sequence",-1): return false','\tif movement.transit_wait.sequence!=movement.get("request_sequence",-1): return false\n\tif not fits(space,world,connection,movement.actor_id,movement.get("members",[])).ok: return false')
rep('\treturn space.at(world,movement.actor_id,int(ticket.from),movement.transit_wait.cell)', '''	if not space.at(world,movement.actor_id,int(ticket.from),movement.transit_wait.cell): return false
	var members: Array=movement.get("members",[movement.actor_id])
	var poses: Dictionary=ConvoyTrail.positions(movement.convoy,members) if movement.has("convoy") else {}
	for id: String in members:
		var actor: Dictionary=world.facts.actors[id]
		if actor.location.kind!="floor" or int(actor.location.floor_id)!=int(ticket.from) or actor.posture!="standing" or actor.has("support_facility_id") or float(actor.location.get("height_m",0))!=0: return false
		if poses.has(id) and actor.location.cell!=poses[id].cell: return false
		var rect: Rect2=space._actor_rect(actor,ConvoyTrail.point(actor.location.cell))
		if not space.static_reason(world,actor,int(ticket.from),ConvoyTrail.point(actor.location.cell),[id],{}).is_empty(): return false
		for room: Dictionary in world.facts.rooms.values():
			if int(room.floor_id)==int(ticket.from) and rect.intersects(Rect2(ConvoyTrail.point(room.origin),ConvoyTrail.point(room.size)),false): return false
	return true''')
rep('offsets,true)','offsets,true,selected)')
rep('movement,plan,true)','movement,plan,true,selected)')
rep('offsets: Dictionary, entry_only: bool = false) -> void:', 'offsets: Dictionary, entry_only: bool = false, selected_id: String = "") -> void:')
rep('plan: Dictionary, entry_only: bool = false) -> void:', 'plan: Dictionary, entry_only: bool = false, selected_id: String = "") -> void:')
rep('\tvar exit: Rect2=space._unit_rect(world,actor,Vector2(anchor),members,offsets)', '\tvar exit: Rect2=_selected_entry(space,world,connection,selected_id) if entry_only else Rect2()\n\tif entry_only and not exit.has_area(): return')
rep('\t\texit=Rect2(ConvoyTrail.point(plan.entry)+Vector2.ONE*float(movement.convoy.shift),Vector2.ONE*float(movement.convoy.size))','\t\texit=_selected_entry(space,world,connection,selected_id)\n\t\tif not exit.has_area(): return')
rep('static func _waiting(space:', '''static func _selected_entry(space: HospitalSpace, world: WorldState, connection: Dictionary, id: String) -> Rect2:
	var m: Dictionary=world.facts.moves.get(id,{})
	if m.is_empty(): return Rect2()
	if m.has("convoy"):
		var plan: Dictionary=ConvoyPortal.plan(space,world,connection,id,m.members,m.convoy)
		if not plan.ok: return Rect2()
		var shift: Vector2=Vector2.ONE*float(m.convoy.shift)
		return Rect2(ConvoyTrail.point(plan.entry)+shift,Vector2.ONE*float(m.convoy.size)).merge(Rect2(ConvoyTrail.point(plan.egress)+shift,Vector2.ONE*float(m.convoy.size)))
	return space._unit_rect(world,world.facts.actors[id],ConvoyTrail.point(connection.anchor),m.get("members",[id]),m.get("offsets",{}))

# Only a structural routing failure ends this optional local approach.
# Dynamic contact and a temporarily unavailable side step never call this.
static func waiting_route_failed(world: WorldState, movement: Dictionary) -> void:
	if not movement.has("transit_wait"): return
	cancel_waiting(world,movement)
	movement.erase("route_waypoint")

static func _waiting(space:''')
rep('# A waiting ticket belongs to the complete unit physically at its landing.\n# Leaving (including walking clear of an incoming rider) ends that wait.', '# Admitted identity survives Transit-owned ground waiting. An unrelated\n# departure or invalidated journey ends that identity, not ordinary courtesy.')
p.write_bytes(s.encode())
p=r/'game/building/hospital_movement.gd';s=p.read_text();a='\t\t\tif quote.get("status","")=="unreachable": _remember_failure(world,movement,str(quote.reason))';assert s.count(a)==1
s=s.replace(a,'\t\t\tif quote.get("status","")=="unreachable":\n\t\t\t\tHospitalTransit.waiting_route_failed(world,movement)\n\t\t\t\t_remember_failure(world,movement,str(quote.reason))');p.write_bytes(s.encode())
