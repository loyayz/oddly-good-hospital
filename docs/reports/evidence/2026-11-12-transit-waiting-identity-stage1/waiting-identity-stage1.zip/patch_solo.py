from pathlib import Path
r=Path('oddly-good-hospital-cloud-recovery-20261112'); p=r/'game/building/hospital_transit.gd'; s=p.read_text()
s=s.replace('if movement.has("transit_ticket") and not _at_landing(space,world,world.facts.connectors[segment.connector_id],movement,movement.transit_ticket):','if movement.has("transit_ticket") and not _ticket_valid(space,world,movement):',1)
s=s.replace('if not at_entry and not _landing_in_use(connection,int(segment.from)):', 'if not at_entry and not movement.has("transit_wait") and not _landing_in_use(connection,int(segment.from)):',1)
s=s.replace('\tvar waiting: Array = _waiting(space,world,connection.id)\n\tif waiting.is_empty() or waiting[0]!=actor.id:\n\t\treturn\n\tconnection.assigned_actor_id = actor.id', '''	var waiting: Array = _waiting(space,world,connection.id)
	var selected: String=str(connection.get("assigned_actor_id",""))
	if selected.is_empty() and not waiting.is_empty(): selected=waiting[0]
	if selected!=actor.id:
		if at_entry and movement.has("transit_ticket"): _stand_aside(space,world,connection,actor,movement,members,offsets,true)
		return
	connection.assigned_actor_id = actor.id''',1)
needle='\tvar travel: int = _travel_ticks(space,connection,int(segment.from),int(segment.to))'
s=s.replace(needle, '''	if not at_entry:
		space.queue_waypoint(world,movement,int(segment.from),connection.anchor)
		return
'''+needle,1)
s=s.replace('\tmovement.erase("transit_ticket")\n\tconnection.erase("assigned_actor_id")','\tmovement.erase("transit_ticket")\n\tmovement.erase("transit_wait")\n\tconnection.erase("assigned_actor_id")')
s=s.replace('\tmovement.erase("transit_ticket")\n\n# A waiting ticket', '\tmovement.erase("transit_ticket")\n\tmovement.erase("transit_wait")\n\n# A waiting ticket')
s=s.replace('if connection.is_empty() or not _at_landing(space,world,connection,movement,ticket):','if connection.is_empty() or not _ticket_valid(space,world,movement):',1)
s=s.replace('and _at_landing(space,world,world.facts.connectors[connector_id],movement,movement.transit_ticket):','and _ticket_valid(space,world,movement) and _waiting_position(space,world,movement):',1)
s=s.replace('members: Array, offsets: Dictionary) -> void:\n\tif not space.at(world,actor.id,int(connection.to),connection.anchor):','members: Array, offsets: Dictionary, entry_only: bool = false) -> void:\n\tvar floor_id: int=int(actor.location.floor_id)\n\tif not space.at(world,actor.id,floor_id,connection.anchor):',1)
a=s.index('\tvar incoming_id: String = connection.get(',s.index('static func _stand_aside(')); z=s.index('\tfor radius:',a)
old=s[a:z]; old=old.replace('\tvar exit: Rect2\n',''); old='\n'.join('\t'+line if line else line for line in old.rstrip().split('\n'))+'\n'
s=s[:a]+'''\tvar exit: Rect2=space._unit_rect(world,actor,Vector2(anchor),members,offsets)
	if not entry_only:
'''+old+s[z:]
a=s.index('static func _stand_aside('); z=s.index('static func _waiting(',a); part=s[a:z].replace('int(connection.to)','floor_id')
part=part.replace('\t\t\t\t\tspace.queue_waypoint(world,movement,floor_id,[cell.x,cell.y])','''					space.queue_waypoint(world,movement,floor_id,[cell.x,cell.y])
					if movement.has("transit_ticket"):
						movement.transit_wait={"sequence":movement.request_sequence,"cell":[cell.x,cell.y]}''')
s=s[:a]+part+s[z:]
helper='''# Identity survives only the owner's temporary waiting journey, never an
# unrelated floor waypoint or a changed movement request.
static func _ticket_valid(space: HospitalSpace, world: WorldState, movement: Dictionary) -> bool:
	var ticket: Dictionary=movement.get("transit_ticket",{})
	var connection: Dictionary=world.facts.connectors.get(ticket.get("connector_id",""),{})
	if connection.is_empty(): return false
	if not movement.has("transit_wait"): return _at_landing(space,world,connection,movement,ticket)
	if movement.transit_wait.sequence!=movement.get("request_sequence",-1): return false
	if not has_stop(connection,int(ticket.from)) or not has_stop(connection,int(ticket.to)) or (_lowering(connection) and int(ticket.to)>=int(ticket.from)): return false
	for id: String in movement.get("members",[movement.actor_id]):
		var actor: Dictionary=world.facts.actors.get(id,{})
		if actor.get("location",{}).get("kind")!="floor" or int(actor.location.floor_id)!=int(ticket.from): return false
	var suffix: Array=movement.get("route_waypoint",{}).get("continuation",movement.path.slice(int(movement.cursor)))
	for segment: Dictionary in suffix:
		if segment.kind=="connector": return segment.connector_id==ticket.connector_id and segment.from==ticket.from and segment.to==ticket.to
	return false

static func _waiting_position(space: HospitalSpace, world: WorldState, movement: Dictionary) -> bool:
	var ticket: Dictionary=movement.transit_ticket
	var connection: Dictionary=world.facts.connectors[ticket.connector_id]
	if _at_landing(space,world,connection,movement,ticket): return true
	if not movement.has("transit_wait") or movement.get("route_pending",false) or movement.has("local_move") or movement.has("detour"): return false
	return space.at(world,movement.actor_id,int(ticket.from),movement.transit_wait.cell)

'''
s=s.replace('static func _at_landing(',helper+'static func _at_landing(',1)
# A pending or active summon has real, unestimated walking time; never fabricate zero.
s=s.replace('\tvar queued: Array = _waiting(space,world,connection.id)', '''	for id: String in world.ids("moves"):
		var m: Dictionary=world.facts.moves[id]
		if m.get("transit_ticket",{}).get("connector_id","")==connection.id and m.has("transit_wait") and _ticket_valid(space,world,m):
			return {"ok":false,"status":"estimate_unknown","reason":"实际候位或召入步行尚未完成"}
	var queued: Array = _waiting(space,world,connection.id)''',1)
p.write_bytes(s.encode())
p=r/'game/sim/world_state.gd';s=p.read_text();needle='\t\tif movement.has("transit_ticket"):\n'; pos=s.index(needle,s.index('if movement.has("route_waypoint")'))
s=s[:pos]+'''		if movement.has("transit_wait"):
			var waiting: Variant=movement.transit_wait
			if not waiting is Dictionary or not _point(waiting.get("cell")) or waiting.get("sequence")!=movement.get("request_sequence",-1) or not movement.has("transit_ticket"): return "实际候位绑定无效"
'''+s[pos:];p.write_bytes(s.encode())
