extends "res://tests/acceptance/transit_busy_recovery.gd"

func _run() -> void:
	suite.content=HospitalContent.new()
	var args: PackedStringArray=OS.get_cmdline_user_args()
	var out: String=args[0]
	var convoy: bool=args.size()>1 and args[1]=="convoy"
	var sim: HospitalSimulation=_order_fixture(convoy,2)
	suite._history_height(sim,3)
	var cid: String=suite._connection(sim)
	var extended: CommandResult=suite._command(sim,"connector_extend",{"connection_id":cid,"floor_id":3})
	var world: WorldState=sim.world
	var c: Dictionary=world.facts.connectors[cid]
	suite._add_actor(sim,"aaa_incoming","S49",c.anchor,1)
	suite._add_actor(sim,"zzz_later","S49",c.anchor,3)
	var requested: bool=sim.space.request_move(world,"aaa_incoming",2,[44,86]).is_empty()
	requested=requested and _request_waiter(sim,convoy,1).is_empty()
	requested=requested and sim.space.request_move(world,"zzz_later",1,[48,86]).is_empty()
	if args.size()>2:
		var input: Dictionary=FileAccess.open(args[2],FileAccess.READ).get_var()
		sim.dispose();sim=HospitalSimulation.new(WorldState.new(input.duplicate(true)),suite.content);world=sim.world;c=world.facts.connectors[suite._connection(sim)];cid=c.id
	var expected: Dictionary=world.freeze().duplicate(true)
	FileAccess.open(out+"/preWorld.bin",FileAccess.WRITE).store_var(expected)
	var valid: String=world.validate(suite.content)
	var ticket: int=-1
	var kept: bool=true
	var departed: bool=false
	var safe: bool=true
	var stable: bool=true
	var original: Dictionary=world.facts.moves.leader.duplicate(true)
	var order: Array=[]
	var frames: Array=[]
	var arrived: bool=false
	var twin: HospitalSimulation=null
	var restored: bool=false
	var cold_equal: bool=true
	for step: int in 240:
		if not valid.is_empty(): break
		var before: Dictionary=world.facts.actors.duplicate(true)
		suite._movement_tick(sim)
		if twin!=null:
			suite._movement_tick(twin)
			cold_equal=cold_equal and twin.world.freeze()==world.freeze()
		c=world.facts.connectors[cid]
		var m: Dictionary=world.facts.moves.get("leader",{})
		var actor: Dictionary=world.facts.actors.leader
		if m.has("transit_ticket") and ticket<0: ticket=int(m.transit_ticket.sequence)
		if ticket>0 and actor.location.kind=="floor" and int(actor.location.floor_id)==2 and not sim.space.at(world,"leader",2,c.anchor):
			departed=true
			kept=kept and int(m.get("transit_ticket",{}).get("sequence",-1))==ticket
		if departed and not restored:
			var saved: Dictionary=bytes_to_var(var_to_bytes(world.freeze()))
			FileAccess.open(out+"/restore.bin",FileAccess.WRITE).store_var(saved)
			twin=HospitalSimulation.new(WorldState.new(saved),suite.content)
			restored=true
			cold_equal=cold_equal and twin.world.freeze()==world.freeze()
		if not m.is_empty(): stable=stable and m.request_sequence==original.request_sequence and m.target_cell==original.target_cell and m.target_floor==original.target_floor
		var primary: String=str(c.get("primary_actor_id",""))
		if not primary.is_empty() and not order.has(primary): order.append(primary)
		safe=safe and _floor_safety(sim,before)
		valid=world.validate(suite.content)
		frames.append({"tick":world.sim_tick,"actors":world.facts.actors.duplicate(true),"moves":world.facts.moves.duplicate(true),"connector":c.duplicate(true)})
		if m.is_empty() and sim.space.at(world,"leader",1,[44,82]): arrived=true;break
	var checks: Dictionary={"requested":requested,"extension":extended.accepted,"valid":valid.is_empty(),"departed":departed,"ticket_unchanged":kept and ticket>0,"service_order":order.size()>=2 and order[0]=="aaa_incoming" and order[1]=="leader","arrived":arrived,"safe":safe,"original_request_goal":stable,"cold_equal":cold_equal and restored}
	FileAccess.open(out+"/frames.bin",FileAccess.WRITE).store_var(frames)
	FileAccess.open(out+"/final.bin",FileAccess.WRITE).store_var(world.freeze())
	var result: Dictionary={"ok":checks.values().all(func(v: bool)->bool:return v),"checks":checks,"order":order,"ticket":ticket,"validation":valid,"ticks":frames.size()}
	FileAccess.open(out+"/result.json",FileAccess.WRITE).store_string(JSON.stringify(result,"  "))
	print(JSON.stringify(result));sim.dispose()
	if twin!=null: twin.dispose()
	quit(0 if result.ok else 1)
