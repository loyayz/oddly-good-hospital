extends RefCounted
static var step_enabled: bool=false
static var parent_active: bool=false
static var owner: int=0
static var handler: int=0
static var stack: Array=[]
static var rows: Dictionary={}
static var records: Array=[]
static var errors: Array=[]
static var outcomes: Dictionary={}
static func begin_step() -> void:
	if parent_active or not stack.is_empty():errors.append("unclosed prior step")
	step_enabled=true;parent_active=false;owner=OS.get_thread_caller_id();handler=0;stack=[];rows={};outcomes={}
static func enter(name: String, root: bool=false) -> bool:
	if not step_enabled or OS.get_thread_caller_id()!=owner:return false
	if not root and not parent_active:return false
	var t: int=Time.get_ticks_usec()
	if root:
		if parent_active:errors.append("nested parent");return false
		parent_active=true
	var frame: Dictionary={"name":name,"children":0,"start":0,"handler":0}
	stack.append(frame)
	var end: int=Time.get_ticks_usec();handler+=end-t;frame.start=end;frame.handler=handler
	return true
static func leave(name: String, root: bool=false, result: Variant=null) -> void:
	var t: int=Time.get_ticks_usec()
	if not parent_active or OS.get_thread_caller_id()!=owner or stack.is_empty() or stack.back().name!=name:errors.append("unbalanced "+name);return
	var frame: Dictionary=stack.pop_back()
	var inclusive: int=t-int(frame.start)-(handler-int(frame.handler))
	var exclusive: int=inclusive-int(frame.children)
	var row: Dictionary=rows.get(name,{"calls":0,"inclusive_us":0,"exclusive_us":0,"max_us":0})
	row.calls+=1;row.inclusive_us+=inclusive;row.exclusive_us+=exclusive;row.max_us=maxi(int(row.max_us),inclusive);rows[name]=row
	if not stack.is_empty():stack.back().children+=inclusive
	if root:
		if not stack.is_empty():errors.append("root stack not empty")
		parent_active=false
		if result!=null:
			var key: String="door_wait" if not result.door_id.is_empty() else ("blocked" if result.blocked else "unblocked")
			outcomes[key]=int(outcomes.get(key,0))+1
	handler+=Time.get_ticks_usec()-t
static func end_step(tick: int, elapsed: int) -> void:
	if parent_active or not stack.is_empty():errors.append("unclosed step")
	step_enabled=false
	var parent: Dictionary=rows.get("_move_step",{"calls":0,"inclusive_us":0,"exclusive_us":0})
	var sum_exclusive: int=0
	for r: Dictionary in rows.values():sum_exclusive+=int(r.exclusive_us)
	if sum_exclusive!=int(parent.inclusive_us):errors.append("partition mismatch")
	records.append({"tick":tick,"outer_elapsed_us":elapsed,"methods":rows.duplicate(true),"handler_us":handler,"partition_check_us":int(parent.inclusive_us)-sum_exclusive,"parent_uncovered_us":int(parent.exclusive_us),"outside_parent_and_gaps_us":elapsed-int(parent.inclusive_us)-handler,"outcomes":outcomes.duplicate(true)})
static func report() -> Dictionary:
	return {"records":records,"errors":errors,"scope":"Selected methods only inside owner-thread active _move_step during real steps. Exclusive contributions partition parent elapsed; do not sum inclusive. Parent uncovered is not synonymous with commit. Measured handler excluded; dispatch/timer overhead not fully removed. This eight-step restored-state sample is not whole-window attribution."}
