from pathlib import Path
import sys,shutil,re,runpy,json,hashlib,zipfile,traceback,ast
BASE=Path(__file__).resolve().parent;REPO=BASE.parent/'oddly-good-hospital-cloud-recovery-20261112';ROOT=BASE.parent/'root-stage-recovery-20261112';N=BASE.parent/'movement-stage-recovery-20261112'
sys.path.insert(0,str(N));import full_narrow_v1 as h
c=h.c;g=h.g;MARK='# move-step-observer-v1';TIMER='tools/performance/current/move_step_timer.gd';DRIVER='tools/performance/current/plain_v4.gd'
TARGETS={'game/building/hospital_movement.gd':['_move_step','_unit_sweeps','_reserve_doors','_movement_contacts','_mark_door_use','_move_convoy'],'game/building/hospital_space.gd':['movement_doors']}
def transform(original,names,split):
 source=original;headers=[];wrappers=[]
 for name in names:
  hits=list(re.finditer(r'^func '+re.escape(name)+r'\((.*)\) -> ([^:\n]+):$',source,re.M));assert len(hits)==1,name
  m=hits[0];header=m[0];renamed=header.replace('func '+name,'func _breakdown_original_'+name,1);source=source[:m.start()]+renamed+source[m.end():];headers.append((header,renamed))
  args=[x.split(':',1)[0].strip() for x in split(m[1])];ret=m[2];root=name=='_move_step'
  w=header+'\n\tvar traced: bool=_StepTimer.enter("'+name+'",'+str(root).lower()+')\n'
  w+='\t'+('var value: '+ret+'=' if ret!='void' else '')+'_breakdown_original_'+name+'('+','.join(args)+')\n'
  w+='\tif traced:_StepTimer.leave("'+name+'",'+str(root).lower()+(',value' if root else '')+')\n'
  if ret!='void':w+='\treturn value\n'
  wrappers.append(w)
 if '_move_step' in names:
  a='\t\tvar actual_clearance: RouteClearance=space.navigation.structural_clearance(world,actor,int(actor.location.floor_id))\n';b='\t\tresult.static_reason=actual_clearance.sweep_reason(start,next)\n';assert source.count(a)==source.count(b)==1
  source=source.replace(a,'\t\tvar structural_traced: bool=_StepTimer.enter("structural-check") '+MARK+'\n'+a).replace(b,b+'\t\tif structural_traced:_StepTimer.leave("structural-check") '+MARK+'\n')
 source=source.replace('extends RefCounted\n','extends RefCounted\nconst _StepTimer=preload("res://'+TIMER+'") '+MARK+'\n',1)
 source+='\n# generated-breakdown-wrappers\n'+'\n'.join(wrappers)
 undo=source.split('\n# generated-breakdown-wrappers\n')[0];undo=''.join(x for x in undo.splitlines(True) if MARK not in x)
 for header,renamed in headers:undo=undo.replace(renamed,header,1)
 assert undo==original
 return source

def archive():
 files=[p for p in BASE.rglob('*') if p.is_file() and p.relative_to(BASE).parts[0] not in ['plain-project','observer-project'] and p.name not in ['batch.zip','members.json','checkpoint.json']];m={str(p.relative_to(BASE)):{'bytes':p.stat().st_size,'sha256':c.sha(p)} for p in files};c.write(BASE/'members.json',m)
 with zipfile.ZipFile(BASE/'batch.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
  for p in files:z.write(p,str(p.relative_to(BASE)))
  z.write(BASE/'members.json','MEMBERS.json')
 with zipfile.ZipFile(BASE/'batch.zip') as z:
  assert z.testzip() is None
  for n,v in m.items():assert hashlib.sha256(z.read(n)).hexdigest()==v['sha256']
 c.write(BASE/'checkpoint.json',{'sha256':c.sha(BASE/'batch.zip'),'bytes':(BASE/'batch.zip').stat().st_size,'members':len(m),'local_readback_verified':True})
def main():
 cfg=c.read(ROOT/'config.json');c.verify(cfg);c.idle()
 plain=BASE/'plain-project';shutil.copytree(REPO,plain,ignore=shutil.ignore_patterns('.git','docs','art-source','.cache'));obs=BASE/'observer-project';shutil.copytree(plain,obs)
 split=runpy.run_path(str(plain/'tools/performance/instrument_all_instances.py'))['split_arguments'];manifest={}
 for rel,names in TARGETS.items():
  original=(obs/rel).read_text();source=transform(original,names,split);(BASE/(Path(rel).name+'.original')).write_text(original);(BASE/(Path(rel).name+'.observer')).write_text(source);(obs/rel).write_text(source);manifest[rel]={'original':c.sha(plain/rel),'observer':c.sha(obs/rel),'inverse_exact':True,'methods':names}
 shutil.copy2(BASE/'timer.gd',obs/TIMER)
 original=(obs/DRIVER).read_text();s=original.replace('extends SceneTree\n','extends SceneTree\nconst _StepTimer=preload("res://'+TIMER+'") '+MARK+'\n',1)
 for anchor,line,after in [('\t\tvar started: int = Time.get_ticks_usec()\n','\t\t_StepTimer.begin_step() '+MARK+'\n',False),('\t\tvar elapsed: int = Time.get_ticks_usec()-started\n','\t\t_StepTimer.end_step(world.sim_tick,elapsed) '+MARK+'\n',True),('\tvar window_end: int = Time.get_ticks_usec()\n','\twrite_json(output+".breakdown.json",_StepTimer.report()) '+MARK+'\n',True)]:
  assert s.count(anchor)==1;s=s.replace(anchor,anchor+line if after else line+anchor)
 assert ''.join(x for x in s.splitlines(True) if MARK not in x)==original;(obs/DRIVER).write_text(s);(BASE/'driver.observer.gd').write_text(s)
 # Statically exercise missing signatures and disabled/parent guard ordering.
 try:transform((plain/'game/building/hospital_space.gd').read_text(),['_not_present'],split);raise RuntimeError('missing signature accepted')
 except AssertionError:pass
 timer=(BASE/'timer.gd').read_text();assert timer.index('if not step_enabled')<timer.index('var t: int=Time.get_ticks_usec()');assert 'if not root and not parent_active:return false' in timer
 with zipfile.ZipFile(ROOT/'full-plain.zip') as z:
  data=z.read('run/result.json.final.bin');assert hashlib.sha256(data).hexdigest()=='41928476a199dbf3e35b3ff74cd54a52fd0801feb92c5b1d1a5d6fe035258a68';(BASE/'input.bin').write_bytes(data)
 inventories={n:c.inventory(p) for n,p in [('plain',plain),('observer',obs)]};c.write(BASE/'identity.json',{'source_commit':'a8f1a09','runtime':cfg,'inventories':inventories,'transform':manifest,'step_limit':8,'input_sha256':c.sha(BASE/'input.bin'),'runner_sha256':c.sha(__file__),'timer_sha256':c.sha(BASE/'timer.gd')})
 for p in [ROOT/'controller_v2.py',ROOT/'linux_guard_v2.py',N/'full_narrow_v1.py',N/'qualify_v1.py',N/'prepare_v1.py']:shutil.copy2(p,BASE/('dependency-'+p.name))
 g.LIBRARY_PATH=cfg['library_path']
 try:
  for name,project in [('plain',plain),('observer',obs)]:
   c.idle();c.verify(cfg);g.PROJECT=project;c.write(BASE/(name+'.host-before.json'),h.host())
   cmd=[cfg['engine'],'--headless','--path',str(project),'--script','res://'+DRIVER,'--','--input='+str(BASE/'input.bin'),'--output='+str(BASE/name/'result.json'),'--steps=8','--prefix-steps=0','--worker-tasks=4','--main-thread-policy=app','--observed-floor=1']
   try:g.run(cmd,BASE/name,timeout=180,allowed_exits=(0,1))
   finally:c.write(BASE/(name+'.host-after.json'),h.host())
   assert c.inventory(project)==inventories[name];r=c.read(BASE/name/'result.json');assert r['complete'] and r['all_completed_steps']==8
  assert (BASE/'plain/result.json.final.bin').read_bytes()==(BASE/'observer/result.json.final.bin').read_bytes()
  a=c.read(BASE/'plain/result.json');b=c.read(BASE/'observer/result.json')
  for key in ['business','sample_business','prefix_business','errors','complete']:assert a[key]==b[key]
  d=c.read(BASE/'observer/result.json.breakdown.json');assert not d['errors'] and len(d['records'])==8
  rows=[json.loads(x)['sample'] for x in (BASE/'observer/result.json.steps.ndjson').read_text().splitlines() if json.loads(x)['kind']=='complete']
  for r,row in zip(d['records'],rows):
   assert r['tick']==row['tick'] and r['outer_elapsed_us']==row['elapsed_us'] and r['partition_check_us']==0
   assert all(v['exclusive_us']>=0 and v['inclusive_us']>=v['exclusive_us'] for v in r['methods'].values())
   assert sum(v['exclusive_us'] for v in r['methods'].values())==r['methods']['_move_step']['inclusive_us']
  c.write(BASE/'comparison.json',{'world_rng_ordered_events_equal':True,'business_equal':True,'records':8,'partition_and_tick_checks':True,'final_sha256':b['final_sha256'],'scope':'Current-code restored-state eight-step sample only, not whole-window attribution.'})
 except BaseException:c.write(BASE/'error.json',{'traceback':traceback.format_exc()});raise
 finally:
  for rel in list(TARGETS)+[DRIVER]:(obs/rel).write_bytes((plain/rel).read_bytes())
  c.write(BASE/'restoration.json',{'modified_sources_restored':all((obs/r).read_bytes()==(plain/r).read_bytes() for r in list(TARGETS)+[DRIVER]),'timer_dormant':True});archive()
if __name__=='__main__':main()
