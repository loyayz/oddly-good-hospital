extends RefCounted
static var step_enabled: bool=false
static var parent_active: bool=false
static var owner: int=0
static var handler: int=0
static var stack: Array=[]
static var rows: Dictionary={}
static var records: Array=[]
static var errors: Array=[]
static var outcomes: Dictionary={}
static var branches: Dictionary={}
static var collection_us: int=0
static var corpus: Array=[]
static var captured_keys: Dictionary={}
static var miss_keys: Dictionary={}
static var pending: Dictionary={}
static var lookup_outcome: String=""
const CAPTURE_LIMIT: int=8
static func begin_step() -> void:
	if parent_active or not stack.is_empty():errors.append("unclosed prior step")
	step_enabled=true;parent_active=false;owner=OS.get_thread_caller_id();handler=0;stack=[];rows={};outcomes={};branches={};collection_us=0;pending={};lookup_outcome=""
static func enter(name: String, root: bool=false) -> bool:
	if not step_enabled or OS.get_thread_caller_id()!=owner:return false
	if not root and not parent_active:return false
	if name in ["cache-lookup","fallback-constructor"] and scope().is_empty():return false
	var t: int=Time.get_ticks_usec()
	if root:
		if parent_active:errors.append("nested parent");return false
		parent_active=true
	var frame: Dictionary={"name":name,"children":0,"start":0,"handler":0}
	stack.append(frame)
	var end: int=Time.get_ticks_usec();handler+=end-t;frame.start=end;frame.handler=handler
	return true
static func leave(name: String, root: bool=false, result: Variant=null) -> void:
	var t: int=Time.get_ticks_usec()
	if not parent_active or OS.get_thread_caller_id()!=owner or stack.is_empty() or stack.back().name!=name:errors.append("unbalanced "+name);return
	var frame: Dictionary=stack.pop_back()
	var inclusive: int=t-int(frame.start)-(handler-int(frame.handler))
	var exclusive: int=inclusive-int(frame.children)
	var row_name: String="cache-lookup:"+lookup_outcome if name=="cache-lookup" else name
	var row: Dictionary=rows.get(row_name,{"calls":0,"inclusive_us":0,"exclusive_us":0,"max_us":0})
	row.calls+=1;row.inclusive_us+=inclusive;row.exclusive_us+=exclusive;row.max_us=maxi(int(row.max_us),inclusive);rows[row_name]=row
	if not stack.is_empty():stack.back().children+=inclusive
	if root:
		if not stack.is_empty():errors.append("root stack not empty")
		parent_active=false
		if result!=null:
			var key: String="door_wait" if not result.door_id.is_empty() else ("blocked" if result.blocked else "unblocked")
			outcomes[key]=int(outcomes.get(key,0))+1
	handler+=Time.get_ticks_usec()-t
static func end_step(tick: int, elapsed: int) -> void:
	if parent_active or not stack.is_empty():errors.append("unclosed step")
	step_enabled=false
	var parent: Dictionary=rows.get("_move_step",{"calls":0,"inclusive_us":0,"exclusive_us":0})
	var sum_exclusive: int=0
	for r: Dictionary in rows.values():sum_exclusive+=int(r.exclusive_us)
	if sum_exclusive!=int(parent.inclusive_us):errors.append("partition mismatch")
	records.append({"tick":tick,"outer_elapsed_us":elapsed,"methods":rows.duplicate(true),"handler_us":handler,"collection_us":collection_us,"partition_check_us":int(parent.inclusive_us)-sum_exclusive,"parent_uncovered_us":int(parent.exclusive_us),"outside_parent_and_gaps_us":elapsed-int(parent.inclusive_us)-handler,"outcomes":outcomes.duplicate(true),"branches":branches.duplicate(true)})
static func report() -> Dictionary:
	return {"records":records,"errors":errors,"miss_keys":miss_keys,"corpus_count":corpus.size(),"captured_keys":captured_keys.keys(),"corpus_complete":corpus.all(func(item: Dictionary)->bool:return item.has("returned")),"scope":"Selected methods only inside owner-thread active _move_step during real steps. Exclusive contributions partition parent elapsed; do not sum inclusive. Parent uncovered is not synonymous with commit. Measured handler excluded; dispatch/timer overhead not fully removed. This eight-step restored-state sample is not whole-window attribution."}

static func count_branch(name: String) -> void:
	if not step_enabled or OS.get_thread_caller_id()!=owner or not parent_active:return
	var scope: String=""
	for frame: Dictionary in stack:
		if frame.name in ["structural-acquisition","structural-sweep"]:scope=frame.name
	if scope.is_empty():return
	var started: int=Time.get_ticks_usec()
	var counts: Dictionary=branches.get(scope,{})
	counts[name]=int(counts.get(name,0))+1;branches[scope]=counts
	handler+=Time.get_ticks_usec()-started

static func scope() -> String:
	if not step_enabled or OS.get_thread_caller_id()!=owner or not parent_active:return ""
	for frame: Dictionary in stack:
		if frame.name in ["structural-acquisition","structural-sweep"]:return frame.name
	return ""
static func lookup_branch(name: String, key: String, source_record: Dictionary, floor_id: int) -> void:
	if scope().is_empty():return
	count_branch(name)
	var started: int=Time.get_ticks_usec()
	lookup_outcome=name
	pending={}
	if name!="hit":
		var record: Dictionary=miss_keys.get(key,{"calls":0,"floor_id":floor_id,"versions":{}})
		record.calls+=1
		var version: String=source_record.static_version
		record.versions[version]=int(record.versions.get(version,0))+1;miss_keys[key]=record
		pending={"key":key,"floor_id":floor_id,"source":source_record.source,"static_source":source_record.static_source,"version":source_record.version,"static_version":version,"branch":name}
	handler+=Time.get_ticks_usec()-started
static func capture_before(world: WorldState, actor: Dictionary, floor_id: int, members: Array, offsets: Dictionary) -> int:
	if scope().is_empty() or pending.is_empty():return -1
	if captured_keys.has(pending.key) or corpus.size()>=CAPTURE_LIMIT:return -1
	var started: int=Time.get_ticks_usec()
	var row: Dictionary={"step_index":records.size(),"tick":world.sim_tick,"lookup":pending.duplicate(true),"facts":world.freeze(),"actor":actor.duplicate(true),"actor_is_world_instance":is_same(actor,world.facts.actors.get(actor.id,{})),"floor_id":floor_id,"members":members.duplicate(true),"offsets":offsets.duplicate(true)}
	var index: int=corpus.size();captured_keys[pending.key]=index;corpus.append(row)
	var elapsed: int=Time.get_ticks_usec()-started;collection_us+=elapsed;handler+=elapsed
	return index
static func capture_after(index: int, query: RouteClearance) -> void:
	if index<0 or scope().is_empty():return
	var started: int=Time.get_ticks_usec()
	var summary: Dictionary={}
	for field: String in ["_size","_height_m","_plain","_indexed_static","source","_doors","_dependencies","_reservations","_plots","_blocked","_facilities","_connectors","_walls","_facility_cells","_connector_cells","_open_door_cells","_closed_door_cells","_horizontal_walls","_vertical_walls"]:
		var value: Variant=query.get(field)
		summary[field]=value.duplicate(true) if value is Dictionary or value is Array else value
	summary.member_count=query._members.size();corpus[index].returned=summary
	var elapsed: int=Time.get_ticks_usec()-started;collection_us+=elapsed;handler+=elapsed
static func save_corpus(path: String) -> void:
	var file: FileAccess=FileAccess.open(path,FileAccess.WRITE)
	file.store_var(corpus);file.close()
