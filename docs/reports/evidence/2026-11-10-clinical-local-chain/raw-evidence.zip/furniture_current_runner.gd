extends SceneTree
func _initialize()->void:call_deferred("run")
func run()->void:
 var suite:RefCounted=load("res://tests/acceptance/space.gd").new();suite.content=HospitalContent.new()
 var result:Dictionary=load("res://tests/acceptance/unified_local_behavior.gd").new()._double_corner_rejoin(suite)
 FileAccess.open(OS.get_cmdline_user_args()[0],FileAccess.WRITE).store_string(JSON.stringify(result,"\t"))
 print(JSON.stringify(result));quit(0 if result.ok else 1)
