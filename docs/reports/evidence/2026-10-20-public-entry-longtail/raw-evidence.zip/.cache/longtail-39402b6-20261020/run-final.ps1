#requires -Version 7.0
$ErrorActionPreference='Stop'
$repo='C:/code/loyayz/oddly-good-hospital'
$root=Join-Path $repo '.cache/longtail-39402b6-20261020'
$godot='C:/programs/godot/Godot_v4.7.2-stable_win64_console.exe'
$runs=@(
    @{name='final-plain-public360';input='public-v6.input.bin';steps=360;mode='plain';trace='false'},
    @{name='final-plain-gp80';input='gp.input.bin';steps=80;mode='plain';trace='false'},
    @{name='final-plain-operations40';input='op.input.bin';steps=40;mode='plain';trace='false'},
    @{name='final-nested-public40';input='public-v6.input.bin';steps=40;mode='nested';trace='false'},
    @{name='final-nested-gp40';input='gp.input.bin';steps=40;mode='nested';trace='false'},
    @{name='final-nested-operations40';input='op.input.bin';steps=40;mode='nested';trace='false'},
    @{name='final-trace-public360';input='public-v6.input.bin';steps=360;mode='plain';trace='true'}
)
foreach($run in $runs){
    $output=Join-Path $root ($run.name+'.json')
    if(Test-Path -LiteralPath $output){throw "Evidence already exists: $output"}
    $input=Join-Path $repo ('.cache/task-navigation-20261019/'+$run.input)
    $log=[IO.Path]::ChangeExtension($output,'.log')
    & $godot --headless --path (Join-Path $root 'final-project') --script res://tools/performance/representative.gd -- "--input=$input" "--output=$output" "--steps=$($run.steps)" "--profile=$($run.mode)" "--movement-trace=$($run.trace)" *> $log
    if($LASTEXITCODE -ne 0 -or (Select-String -LiteralPath $log -Pattern 'SCRIPT ERROR:|ERROR:' -Quiet)){Get-Content -LiteralPath $log -Tail 15;throw "Run failed: $log"}
    $result=Get-Content -LiteralPath $output -Raw|ConvertFrom-Json
    if(-not $result.qualified){throw "Unqualified: $output"}
    if($run.name -like '*public360' -and @($result.public_checks.PSObject.Properties|Where-Object Value -NE $true).Count -gt 0){throw "Public checks failed: $output"}
    [ordered]@{run=$run.name;qualified=$result.qualified;metrics=$result.metrics;use_starts=@($result.public.actual_use_starts.PSObject.Properties).Count;use_completions=@($result.public.actual_use_completions.PSObject.Properties).Count;use_ticks=$result.public.actual_use_ticks;final_hash=$result.final_binary_sha256}|ConvertTo-Json -Depth 4 -Compress
}
