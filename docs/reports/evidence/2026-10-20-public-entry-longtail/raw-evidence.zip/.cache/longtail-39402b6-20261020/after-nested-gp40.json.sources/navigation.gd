extends "res://game/building/navigation_cache.gd"
var _step_profile_observer: RefCounted

func floor_source(space: HospitalSpace, world: WorldState, floor_id: int) -> Dictionary:
	_step_profile_observer.enter_call("navigation.floor_source")
	var _step_profile_result: Variant = super.floor_source(space,world,floor_id)
	_step_profile_observer.exit_call("navigation.floor_source")
	return _step_profile_result

func facility_index(space: HospitalSpace, world: WorldState, floor_id: int) -> BodyIndex:
	_step_profile_observer.enter_call("navigation.facility_index")
	var _step_profile_result: Variant = super.facility_index(space,world,floor_id)
	_step_profile_observer.exit_call("navigation.facility_index")
	return _step_profile_result

func floor_static_version(space: HospitalSpace, world: WorldState, floor_id: int) -> int:
	_step_profile_observer.enter_call("navigation.floor_static_version")
	var _step_profile_result: Variant = super.floor_static_version(space,world,floor_id)
	_step_profile_observer.exit_call("navigation.floor_static_version")
	return _step_profile_result

func _static_identity(world: WorldState, floor_id: int, current: Dictionary) -> Dictionary:
	_step_profile_observer.enter_call("navigation._static_identity")
	var _step_profile_result: Variant = super._static_identity(world,floor_id,current)
	_step_profile_observer.exit_call("navigation._static_identity")
	return _step_profile_result

func cached_static_geometry(space: HospitalSpace, world: WorldState, floor_id: int, actor: Dictionary) -> RouteClearance:
	_step_profile_observer.enter_call("navigation.cached_static_geometry")
	var _step_profile_result: Variant = super.cached_static_geometry(space,world,floor_id,actor)
	_step_profile_observer.exit_call("navigation.cached_static_geometry")
	return _step_profile_result

func query_graphs(space: HospitalSpace, world: WorldState, floor_id: int, actor: Dictionary, members: Array, offsets: Dictionary) -> Dictionary:
	_step_profile_observer.enter_call("navigation.query_graphs")
	var _step_profile_result: Variant = super.query_graphs(space,world,floor_id,actor,members,offsets)
	_step_profile_observer.exit_call("navigation.query_graphs")
	return _step_profile_result

func graph(space: HospitalSpace, world: WorldState, floor_id: int, actor: Dictionary, members: Array, offsets: Dictionary) -> FloorNavigation:
	_step_profile_observer.enter_call("navigation.graph")
	var _step_profile_result: Variant = super.graph(space,world,floor_id,actor,members,offsets)
	_step_profile_observer.exit_call("navigation.graph")
	return _step_profile_result

func _refresh_graph(space: HospitalSpace, world: WorldState, floor_id: int, actor: Dictionary, members: Array, offsets: Dictionary, source: Dictionary, entry: Dictionary) -> Dictionary:
	_step_profile_observer.enter_call("navigation._refresh_graph")
	var _step_profile_result: Variant = super._refresh_graph(space,world,floor_id,actor,members,offsets,source,entry)
	_step_profile_observer.exit_call("navigation._refresh_graph")
	return _step_profile_result

func _trim(target: int, counts: Dictionary = {}) -> void:
	_step_profile_observer.enter_call("navigation._trim")
	super._trim(target,counts)
	_step_profile_observer.exit_call("navigation._trim")

func clearance(space: HospitalSpace, world: WorldState, floor_id: int, actor: Dictionary, members: Array = [], offsets: Dictionary = {}) -> RouteClearance:
	_step_profile_observer.enter_call("navigation.clearance")
	var _step_profile_result: Variant = super.clearance(space,world,floor_id,actor,members,offsets)
	_step_profile_observer.exit_call("navigation.clearance")
	return _step_profile_result

func _reservation_stamp(space: HospitalSpace, graph: FloorNavigation, world: WorldState, floor_id: int, actor_id: String) -> Array:
	_step_profile_observer.enter_call("navigation._reservation_stamp")
	var _step_profile_result: Variant = super._reservation_stamp(space,graph,world,floor_id,actor_id)
	_step_profile_observer.exit_call("navigation._reservation_stamp")
	return _step_profile_result

func _build_reservation_stamp(graph: FloorNavigation, world: WorldState, floor_id: int, actor_id: String) -> Array:
	_step_profile_observer.enter_call("navigation._build_reservation_stamp")
	var _step_profile_result: Variant = super._build_reservation_stamp(graph,world,floor_id,actor_id)
	_step_profile_observer.exit_call("navigation._build_reservation_stamp")
	return _step_profile_result

func cached_floor_path(space: HospitalSpace, world: WorldState, floor_id: int, actor: Dictionary, graph: FloorNavigation, query: RouteClearance, start: Vector2i, goal: Vector2i, cost_only: bool = false) -> Dictionary:
	_step_profile_observer.enter_call("navigation.cached_floor_path")
	var _step_profile_result: Variant = super.cached_floor_path(space,world,floor_id,actor,graph,query,start,goal,cost_only)
	_step_profile_observer.exit_call("navigation.cached_floor_path")
	return _step_profile_result

func travel_distance(space: HospitalSpace, world: WorldState, floor_id: int, actor: Dictionary, start: Vector2i, goal: Vector2i, witness: bool = false) -> Dictionary:
	_step_profile_observer.enter_call("navigation.travel_distance")
	var _step_profile_result: Variant = super.travel_distance(space,world,floor_id,actor,start,goal,witness)
	_step_profile_observer.exit_call("navigation.travel_distance")
	return _step_profile_result

func forward_distance(space: HospitalSpace, world: WorldState, floor_id: int, actor: Dictionary, start: Vector2i, goal: Vector2i, structural_only: bool = false) -> Dictionary:
	_step_profile_observer.enter_call("navigation.forward_distance")
	var _step_profile_result: Variant = super.forward_distance(space,world,floor_id,actor,start,goal,structural_only)
	_step_profile_observer.exit_call("navigation.forward_distance")
	return _step_profile_result

func _travel_distance(space: HospitalSpace, world: WorldState, floor_id: int, actor: Dictionary, start: Vector2i, goal: Vector2i, witness: bool, forward: bool, structural_only: bool = false) -> Dictionary:
	_step_profile_observer.enter_call("navigation._travel_distance")
	var _step_profile_result: Variant = super._travel_distance(space,world,floor_id,actor,start,goal,witness,forward,structural_only)
	_step_profile_observer.exit_call("navigation._travel_distance")
	return _step_profile_result
