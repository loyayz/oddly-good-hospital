extends "res://game/clinic/hospital_visitors.gd"
var _step_profile_observer: RefCounted

func arrivals(world: WorldState) -> void:
	_step_profile_observer.enter_call("visitors.arrivals")
	super.arrivals(world)
	_step_profile_observer.exit_call("visitors.arrivals")

func dispatch(world: WorldState) -> void:
	_step_profile_observer.enter_call("visitors.dispatch")
	super.dispatch(world)
	_step_profile_observer.exit_call("visitors.dispatch")

func advance(world: WorldState) -> void:
	_step_profile_observer.enter_call("visitors.advance")
	super.advance(world)
	_step_profile_observer.exit_call("visitors.advance")

func _public_waiting(world: WorldState, stay: Dictionary) -> bool:
	_step_profile_observer.enter_call("visitors._public_waiting")
	var _step_profile_result: Variant = super._public_waiting(world,stay)
	_step_profile_observer.exit_call("visitors._public_waiting")
	return _step_profile_result

func _public_wait_position(world: WorldState, stay: Dictionary) -> bool:
	_step_profile_observer.enter_call("visitors._public_wait_position")
	var _step_profile_result: Variant = super._public_wait_position(world,stay)
	_step_profile_observer.exit_call("visitors._public_wait_position")
	return _step_profile_result

func _public_seat_quote(world: WorldState, stay: Dictionary, facility_id: String) -> Dictionary:
	_step_profile_observer.enter_call("visitors._public_seat_quote")
	var _step_profile_result: Variant = super._public_seat_quote(world,stay,facility_id)
	_step_profile_observer.exit_call("visitors._public_seat_quote")
	return _step_profile_result

func _take_waiting_seat(world: WorldState, stay: Dictionary, quote: Dictionary) -> bool:
	_step_profile_observer.enter_call("visitors._take_waiting_seat")
	var _step_profile_result: Variant = super._take_waiting_seat(world,stay,quote)
	_step_profile_observer.exit_call("visitors._take_waiting_seat")
	return _step_profile_result

func yield_seat(world: WorldState, facility_id: String) -> bool:
	_step_profile_observer.enter_call("visitors.yield_seat")
	var _step_profile_result: Variant = super.yield_seat(world,facility_id)
	_step_profile_observer.exit_call("visitors.yield_seat")
	return _step_profile_result

func _waiting_point(world: WorldState, actor_id: String) -> Dictionary:
	_step_profile_observer.enter_call("visitors._waiting_point")
	var _step_profile_result: Variant = super._waiting_point(world,actor_id)
	_step_profile_observer.exit_call("visitors._waiting_point")
	return _step_profile_result

func _bedside(world: WorldState, actor_id: String, stay: Dictionary) -> Dictionary:
	_step_profile_observer.enter_call("visitors._bedside")
	var _step_profile_result: Variant = super._bedside(world,actor_id,stay)
	_step_profile_observer.exit_call("visitors._bedside")
	return _step_profile_result

func _bedside_in_query(world: WorldState, actor_id: String, stay: Dictionary) -> Dictionary:
	_step_profile_observer.enter_call("visitors._bedside_in_query")
	var _step_profile_result: Variant = super._bedside_in_query(world,actor_id,stay)
	_step_profile_observer.exit_call("visitors._bedside_in_query")
	return _step_profile_result
