extends "res://game/staff/staff_wellbeing.gd"
var _step_profile_observer: RefCounted

func dispatch(world: WorldState) -> void:
	_step_profile_observer.enter_call("wellbeing.dispatch")
	super.dispatch(world)
	_step_profile_observer.exit_call("wellbeing.dispatch")

func boundaries(world: WorldState) -> void:
	_step_profile_observer.enter_call("wellbeing.boundaries")
	super.boundaries(world)
	_step_profile_observer.exit_call("wellbeing.boundaries")

func advance(world: WorldState, worked: Dictionary = {}, before_movement: Dictionary = {}) -> void:
	_step_profile_observer.enter_call("wellbeing.advance")
	super.advance(world,worked,before_movement)
	_step_profile_observer.exit_call("wellbeing.advance")

func _dispatch_task(world: WorldState, staff_id: String) -> void:
	_step_profile_observer.enter_call("wellbeing._dispatch_task")
	super._dispatch_task(world,staff_id)
	_step_profile_observer.exit_call("wellbeing._dispatch_task")

func _reserve(world: WorldState, staff_id: String, task: Dictionary, selection: Dictionary) -> bool:
	_step_profile_observer.enter_call("wellbeing._reserve")
	var _step_profile_result: Variant = super._reserve(world,staff_id,task,selection)
	_step_profile_observer.exit_call("wellbeing._reserve")
	return _step_profile_result

func _select_facility(world: WorldState, staff_id: String, kind: String, query: Dictionary = {}) -> Dictionary:
	_step_profile_observer.enter_call("wellbeing._select_facility")
	var _step_profile_result: Variant = super._select_facility(world,staff_id,kind,query)
	_step_profile_observer.exit_call("wellbeing._select_facility")
	return _step_profile_result

func _tea_position(world: WorldState, staff_id: String) -> Dictionary:
	_step_profile_observer.enter_call("wellbeing._tea_position")
	var _step_profile_result: Variant = super._tea_position(world,staff_id)
	_step_profile_observer.exit_call("wellbeing._tea_position")
	return _step_profile_result

func _public_entry(world: WorldState, staff_id: String, area: Dictionary, task: Dictionary, selected: Dictionary = {}) -> Dictionary:
	_step_profile_observer.enter_call("wellbeing._public_entry")
	var _step_profile_result: Variant = super._public_entry(world,staff_id,area,task,selected)
	_step_profile_observer.exit_call("wellbeing._public_entry")
	return _step_profile_result

func _public_wait_safety(world: WorldState, staff_id: String, area: Dictionary) -> void:
	_step_profile_observer.enter_call("wellbeing._public_wait_safety")
	super._public_wait_safety(world,staff_id,area)
	_step_profile_observer.exit_call("wellbeing._public_wait_safety")

func _dispatch_public_rest(world: WorldState, staff_id: String) -> void:
	_step_profile_observer.enter_call("wellbeing._dispatch_public_rest")
	super._dispatch_public_rest(world,staff_id)
	_step_profile_observer.exit_call("wellbeing._dispatch_public_rest")

func _recreation_choice(world: WorldState, ids: Array, preferred: String, area: Dictionary, intent: Dictionary = {}, known_target: Dictionary = {}) -> Dictionary:
	_step_profile_observer.enter_call("wellbeing._recreation_choice")
	var _step_profile_result: Variant = super._recreation_choice(world,ids,preferred,area,intent,known_target)
	_step_profile_observer.exit_call("wellbeing._recreation_choice")
	return _step_profile_result

func _recreation_choice_in_query(world: WorldState, ids: Array, preferred: String, area: Dictionary, intent: Dictionary, known_target: Dictionary) -> Dictionary:
	_step_profile_observer.enter_call("wellbeing._recreation_choice_in_query")
	var _step_profile_result: Variant = super._recreation_choice_in_query(world,ids,preferred,area,intent,known_target)
	_step_profile_observer.exit_call("wellbeing._recreation_choice_in_query")
	return _step_profile_result

func _recreation_equipment_quote(world: WorldState, ids: Array, facility_id: String, known_target: Dictionary = {}) -> Dictionary:
	_step_profile_observer.enter_call("wellbeing._recreation_equipment_quote")
	var _step_profile_result: Variant = super._recreation_equipment_quote(world,ids,facility_id,known_target)
	_step_profile_observer.exit_call("wellbeing._recreation_equipment_quote")
	return _step_profile_result

func _dispatch_public_recreation(world: WorldState, leader_id: String, known_target: Dictionary = {}) -> void:
	_step_profile_observer.enter_call("wellbeing._dispatch_public_recreation")
	super._dispatch_public_recreation(world,leader_id,known_target)
	_step_profile_observer.exit_call("wellbeing._dispatch_public_recreation")

func _adapted_candidate(world: WorldState, facility_id: String, fit: Dictionary, actor_id: String) -> WorldState:
	_step_profile_observer.enter_call("wellbeing._adapted_candidate")
	var _step_profile_result: Variant = super._adapted_candidate(world,facility_id,fit,actor_id)
	_step_profile_observer.exit_call("wellbeing._adapted_candidate")
	return _step_profile_result

func _patient_occupancy(world: WorldState) -> Dictionary:
	_step_profile_observer.enter_call("wellbeing._patient_occupancy")
	var _step_profile_result: Variant = super._patient_occupancy(world)
	_step_profile_observer.exit_call("wellbeing._patient_occupancy")
	return _step_profile_result

func _staff_query(world: WorldState) -> Dictionary:
	_step_profile_observer.enter_call("wellbeing._staff_query")
	var _step_profile_result: Variant = super._staff_query(world)
	_step_profile_observer.exit_call("wellbeing._staff_query")
	return _step_profile_result
