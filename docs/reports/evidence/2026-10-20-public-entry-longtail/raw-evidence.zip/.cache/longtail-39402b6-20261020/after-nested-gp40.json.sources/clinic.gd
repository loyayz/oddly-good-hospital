extends "res://game/clinic/clinical_runtime.gd"
var _step_profile_observer: RefCounted

func arrivals(world: WorldState) -> void:
	_step_profile_observer.enter_call("clinic.arrivals")
	super.arrivals(world)
	_step_profile_observer.exit_call("clinic.arrivals")

func dispatch(world: WorldState) -> void:
	_step_profile_observer.enter_call("clinic.dispatch")
	super.dispatch(world)
	_step_profile_observer.exit_call("clinic.dispatch")

func advance(world: WorldState) -> void:
	_step_profile_observer.enter_call("clinic.advance")
	super.advance(world)
	_step_profile_observer.exit_call("clinic.advance")

func release_departed(world: WorldState) -> void:
	_step_profile_observer.enter_call("clinic.release_departed")
	super.release_departed(world)
	_step_profile_observer.exit_call("clinic.release_departed")

func _dispatch_service(world: WorldState, visit: Dictionary, ticket: Dictionary) -> void:
	_step_profile_observer.enter_call("clinic._dispatch_service")
	super._dispatch_service(world,visit,ticket)
	_step_profile_observer.exit_call("clinic._dispatch_service")

func _gather_assigned(world: WorldState, visit: Dictionary, ticket: Dictionary) -> bool:
	_step_profile_observer.enter_call("clinic._gather_assigned")
	var _step_profile_result: Variant = super._gather_assigned(world,visit,ticket)
	_step_profile_observer.exit_call("clinic._gather_assigned")
	return _step_profile_result

func service_candidates(world: WorldState, visit: Dictionary, kind: String, structural_only: bool = false, reference_schedule: bool = false, selection: Dictionary = {}) -> Array:
	_step_profile_observer.enter_call("clinic.service_candidates")
	var _step_profile_result: Variant = super.service_candidates(world,visit,kind,structural_only,reference_schedule,selection)
	_step_profile_observer.exit_call("clinic.service_candidates")
	return _step_profile_result

func plan_quote(world: WorldState, visit_id: String, plan_id: String, options: Dictionary = {}) -> Dictionary:
	_step_profile_observer.enter_call("clinic.plan_quote")
	var _step_profile_result: Variant = super.plan_quote(world,visit_id,plan_id,options)
	_step_profile_observer.exit_call("clinic.plan_quote")
	return _step_profile_result

func _select_plan(world: WorldState, visit: Dictionary, doctor_id: String = "", consultation: Dictionary = {}) -> Dictionary:
	_step_profile_observer.enter_call("clinic._select_plan")
	var _step_profile_result: Variant = super._select_plan(world,visit,doctor_id,consultation)
	_step_profile_observer.exit_call("clinic._select_plan")
	return _step_profile_result

func _gather(world: WorldState, visit: Dictionary, facility: Dictionary, staff_ids: Array) -> bool:
	_step_profile_observer.enter_call("clinic._gather")
	var _step_profile_result: Variant = super._gather(world,visit,facility,staff_ids)
	_step_profile_observer.exit_call("clinic._gather")
	return _step_profile_result

func _outpatient_quote(world: WorldState, visit: Dictionary, staff: Dictionary, facility: Dictionary, plan_id: String = "", ignore_supplies: bool = false, structural_only: bool = false, reference_schedule: bool = false, bed_quotes: Variant = null) -> Dictionary:
	_step_profile_observer.enter_call("clinic._outpatient_quote")
	var _step_profile_result: Variant = super._outpatient_quote(world,visit,staff,facility,plan_id,ignore_supplies,structural_only,reference_schedule,bed_quotes)
	_step_profile_observer.exit_call("clinic._outpatient_quote")
	return _step_profile_result

func _compatible_bed(world: WorldState, visit: Dictionary, floor_id: int, excluded: Array, structural_only: bool = false, preferred_bed: String = "", reference_schedule: bool = false, alternatives: Variant = null) -> Dictionary:
	_step_profile_observer.enter_call("clinic._compatible_bed")
	var _step_profile_result: Variant = super._compatible_bed(world,visit,floor_id,excluded,structural_only,preferred_bed,reference_schedule,alternatives)
	_step_profile_observer.exit_call("clinic._compatible_bed")
	return _step_profile_result

func _prepare_surgery(world: WorldState, visit: Dictionary, ticket: Dictionary) -> void:
	_step_profile_observer.enter_call("clinic._prepare_surgery")
	super._prepare_surgery(world,visit,ticket)
	_step_profile_observer.exit_call("clinic._prepare_surgery")

func _surgery_quote(world: WorldState, visit: Dictionary, requested_team: Array = [], options: Dictionary = {}) -> Dictionary:
	_step_profile_observer.enter_call("clinic._surgery_quote")
	var _step_profile_result: Variant = super._surgery_quote(world,visit,requested_team,options)
	_step_profile_observer.exit_call("clinic._surgery_quote")
	return _step_profile_result

func _surgery_bundle_quote(world: WorldState, visit: Dictionary, team: Array, facility_id: String, options: Dictionary, bed_quotes: Dictionary) -> Dictionary:
	_step_profile_observer.enter_call("clinic._surgery_bundle_quote")
	var _step_profile_result: Variant = super._surgery_bundle_quote(world,visit,team,facility_id,options,bed_quotes)
	_step_profile_observer.exit_call("clinic._surgery_bundle_quote")
	return _step_profile_result

func _qualified_surgery_bundle_quote(world: WorldState, visit: Dictionary, team: Array, facility_id: String, options: Dictionary, bed_quotes: Dictionary, plan: Dictionary, protocol: Dictionary) -> Dictionary:
	_step_profile_observer.enter_call("clinic._qualified_surgery_bundle_quote")
	var _step_profile_result: Variant = super._qualified_surgery_bundle_quote(world,visit,team,facility_id,options,bed_quotes,plan,protocol)
	_step_profile_observer.exit_call("clinic._qualified_surgery_bundle_quote")
	return _step_profile_result

func _reservation_candidate(world: WorldState, facility_ids: Array, actor_ids: Array = []) -> WorldState:
	_step_profile_observer.enter_call("clinic._reservation_candidate")
	var _step_profile_result: Variant = super._reservation_candidate(world,facility_ids,actor_ids)
	_step_profile_observer.exit_call("clinic._reservation_candidate")
	return _step_profile_result

func _reserve_bundle(world: WorldState, visit: Dictionary, quote: Dictionary, owner_id: String) -> String:
	_step_profile_observer.enter_call("clinic._reserve_bundle")
	var _step_profile_result: Variant = super._reserve_bundle(world,visit,quote,owner_id)
	_step_profile_observer.exit_call("clinic._reserve_bundle")
	return _step_profile_result

func _complete_service(world: WorldState, session: Dictionary) -> void:
	_step_profile_observer.enter_call("clinic._complete_service")
	super._complete_service(world,session)
	_step_profile_observer.exit_call("clinic._complete_service")

func _dispatch_clinical_releases(world: WorldState) -> void:
	_step_profile_observer.enter_call("clinic._dispatch_clinical_releases")
	super._dispatch_clinical_releases(world)
	_step_profile_observer.exit_call("clinic._dispatch_clinical_releases")

func _dispatch_ward_returns(world: WorldState) -> void:
	_step_profile_observer.enter_call("clinic._dispatch_ward_returns")
	super._dispatch_ward_returns(world)
	_step_profile_observer.exit_call("clinic._dispatch_ward_returns")

func _ward_covering(world: WorldState, stay: Dictionary, nurse_coverage: Dictionary = {}) -> bool:
	_step_profile_observer.enter_call("clinic._ward_covering")
	var _step_profile_result: Variant = super._ward_covering(world,stay,nurse_coverage)
	_step_profile_observer.exit_call("clinic._ward_covering")
	return _step_profile_result

func _round_candidate(world: WorldState, visit: Dictionary, stay: Dictionary) -> String:
	_step_profile_observer.enter_call("clinic._round_candidate")
	var _step_profile_result: Variant = super._round_candidate(world,visit,stay)
	_step_profile_observer.exit_call("clinic._round_candidate")
	return _step_profile_result

func _availability(world: WorldState) -> Dictionary:
	_step_profile_observer.enter_call("clinic._availability")
	var _step_profile_result: Variant = super._availability(world)
	_step_profile_observer.exit_call("clinic._availability")
	return _step_profile_result

func _build_availability(world: WorldState) -> Dictionary:
	_step_profile_observer.enter_call("clinic._build_availability")
	var _step_profile_result: Variant = super._build_availability(world)
	_step_profile_observer.exit_call("clinic._build_availability")
	return _step_profile_result

func arrival_readiness(world: WorldState, binding_id: String, complex_case: bool = false, explain: bool = true) -> Dictionary:
	_step_profile_observer.enter_call("clinic.arrival_readiness")
	var _step_profile_result: Variant = super.arrival_readiness(world,binding_id,complex_case,explain)
	_step_profile_observer.exit_call("clinic.arrival_readiness")
	return _step_profile_result

func reference_demand(world: WorldState, binding_id: String, complex_case: bool = false, _shift: int = 0, query: Variant = null) -> Dictionary:
	_step_profile_observer.enter_call("clinic.reference_demand")
	var _step_profile_result: Variant = super.reference_demand(world,binding_id,complex_case,_shift,query)
	_step_profile_observer.exit_call("clinic.reference_demand")
	return _step_profile_result

func _reference_options(world: WorldState, binding_id: String, complex_case: bool, shift: int, prior_quote: Dictionary = {}, shared: Dictionary = {}, query: Dictionary = {}) -> Dictionary:
	_step_profile_observer.enter_call("clinic._reference_options")
	var _step_profile_result: Variant = super._reference_options(world,binding_id,complex_case,shift,prior_quote,shared,query)
	_step_profile_observer.exit_call("clinic._reference_options")
	return _step_profile_result

func worked_staff() -> Dictionary:
	_step_profile_observer.enter_call("clinic.worked_staff")
	var _step_profile_result: Variant = super.worked_staff()
	_step_profile_observer.exit_call("clinic.worked_staff")
	return _step_profile_result

func take_events() -> Array[SimEvent]:
	_step_profile_observer.enter_call("clinic.take_events")
	var _step_profile_result: Variant = super.take_events()
	_step_profile_observer.exit_call("clinic.take_events")
	return _step_profile_result

func settle_practice(world: WorldState) -> void:
	_step_profile_observer.enter_call("clinic.settle_practice")
	super.settle_practice(world)
	_step_profile_observer.exit_call("clinic.settle_practice")
