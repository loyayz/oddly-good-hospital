extends "res://game/building/hospital_movement.gd"
var _step_profile_observer: RefCounted

func request_move(world: WorldState, actor_id: String, floor_id: int, target: Array) -> String:
	_step_profile_observer.enter_call("movement.request_move")
	var _step_profile_result: Variant = super.request_move(world,actor_id,floor_id,target)
	_step_profile_observer.exit_call("movement.request_move")
	return _step_profile_result

func _retarget(world: WorldState, previous: Dictionary, floor_id: int, target: Array) -> String:
	_step_profile_observer.enter_call("movement._retarget")
	var _step_profile_result: Variant = super._retarget(world,previous,floor_id,target)
	_step_profile_observer.exit_call("movement._retarget")
	return _step_profile_result

func request_group_move(world: WorldState, primary_id: String, members: Array, offsets: Dictionary, floor_id: int, target: Array) -> String:
	_step_profile_observer.enter_call("movement.request_group_move")
	var _step_profile_result: Variant = super.request_group_move(world,primary_id,members,offsets,floor_id,target)
	_step_profile_observer.exit_call("movement.request_group_move")
	return _step_profile_result

func failure(world: WorldState, actor_id: String) -> Dictionary:
	_step_profile_observer.enter_call("movement.failure")
	var _step_profile_result: Variant = super.failure(world,actor_id)
	_step_profile_observer.exit_call("movement.failure")
	return _step_profile_result

func cancel_ground(world: WorldState, actor_id: String) -> bool:
	_step_profile_observer.enter_call("movement.cancel_ground")
	var _step_profile_result: Variant = super.cancel_ground(world,actor_id)
	_step_profile_observer.exit_call("movement.cancel_ground")
	return _step_profile_result

func advance(world: WorldState, present_at_start: int = -1) -> void:
	_step_profile_observer.enter_call("movement.advance")
	super.advance(world,present_at_start)
	_step_profile_observer.exit_call("movement.advance")

func _move_step(world: WorldState, actor: Dictionary, movement: Dictionary, segment: Dictionary) -> MotionResult:
	_step_profile_observer.enter_call("movement._move_step")
	var _step_profile_result: Variant = super._move_step(world,actor,movement,segment)
	_step_profile_observer.exit_call("movement._move_step")
	return _step_profile_result

func _queue_route(world: WorldState, movement: Dictionary) -> void:
	_step_profile_observer.enter_call("movement._queue_route")
	super._queue_route(world,movement)
	_step_profile_observer.exit_call("movement._queue_route")

func _replan_goal(world: WorldState, movement: Dictionary, preserve_order: bool = false) -> void:
	_step_profile_observer.enter_call("movement._replan_goal")
	super._replan_goal(world,movement,preserve_order)
	_step_profile_observer.exit_call("movement._replan_goal")

func _active_route_clear(world: WorldState, actor: Dictionary, movement: Dictionary, versions: Dictionary) -> bool:
	_step_profile_observer.enter_call("movement._active_route_clear")
	var _step_profile_result: Variant = super._active_route_clear(world,actor,movement,versions)
	_step_profile_observer.exit_call("movement._active_route_clear")
	return _step_profile_result

func _dispatch_routes(world: WorldState, present_at_start: int) -> void:
	_step_profile_observer.enter_call("movement._dispatch_routes")
	super._dispatch_routes(world,present_at_start)
	_step_profile_observer.exit_call("movement._dispatch_routes")

func queue_waypoint(world: WorldState, movement: Dictionary, floor_id: int, cell: Array) -> void:
	_step_profile_observer.enter_call("movement.queue_waypoint")
	super.queue_waypoint(world,movement,floor_id,cell)
	_step_profile_observer.exit_call("movement.queue_waypoint")

func _queue_local_route(world: WorldState, actor: Dictionary, movement: Dictionary) -> void:
	_step_profile_observer.enter_call("movement._queue_local_route")
	super._queue_local_route(world,actor,movement)
	_step_profile_observer.exit_call("movement._queue_local_route")

func _movement_contacts(world: WorldState, actor_id: String, floor_id: int, broad: Rect2, sweeps: Array[BodyIndex.Record], members: Array, result: MotionResult) -> void:
	_step_profile_observer.enter_call("movement._movement_contacts")
	super._movement_contacts(world,actor_id,floor_id,broad,sweeps,members,result)
	_step_profile_observer.exit_call("movement._movement_contacts")

func _reserve_doors(world: WorldState, actor: Dictionary, movement: Dictionary, swept: Rect2, doors: Array[Dictionary], result: MotionResult) -> bool:
	_step_profile_observer.enter_call("movement._reserve_doors")
	var _step_profile_result: Variant = super._reserve_doors(world,actor,movement,swept,doors,result)
	_step_profile_observer.exit_call("movement._reserve_doors")
	return _step_profile_result

func _route_occupancy(world: WorldState, actor: Dictionary, movement: Dictionary, floor_id: int) -> BodyIndex:
	_step_profile_observer.enter_call("movement._route_occupancy")
	var _step_profile_result: Variant = super._route_occupancy(world,actor,movement,floor_id)
	_step_profile_observer.exit_call("movement._route_occupancy")
	return _step_profile_result

func _yield(world: WorldState, actor: Dictionary, movement: Dictionary, result: MotionResult) -> void:
	_step_profile_observer.enter_call("movement._yield")
	super._yield(world,actor,movement,result)
	_step_profile_observer.exit_call("movement._yield")

func _yield_idle_staff(world: WorldState, actor: Dictionary, movement: Dictionary, blocker_actor_ids: Array[String]) -> bool:
	_step_profile_observer.enter_call("movement._yield_idle_staff")
	var _step_profile_result: Variant = super._yield_idle_staff(world,actor,movement,blocker_actor_ids)
	_step_profile_observer.exit_call("movement._yield_idle_staff")
	return _step_profile_result
