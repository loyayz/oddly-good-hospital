extends "res://game/building/hospital_navigation.gd"
var _step_profile_observer: RefCounted

func _route_result(world: WorldState, actor_id: String, floor_id: int, target: Array, members: Array, offsets: Dictionary, _ignore_people: bool, distance_only: bool) -> Dictionary:
	_step_profile_observer.enter_call("point_navigation._route_result")
	var _step_profile_result: Variant = super._route_result(world,actor_id,floor_id,target,members,offsets,_ignore_people,distance_only)
	_step_profile_observer.exit_call("point_navigation._route_result")
	return _step_profile_result

func travel_quote(world: WorldState, actor_id: String, floor_id: int, target: Array) -> Dictionary:
	_step_profile_observer.enter_call("point_navigation.travel_quote")
	var _step_profile_result: Variant = super.travel_quote(world,actor_id,floor_id,target)
	_step_profile_observer.exit_call("point_navigation.travel_quote")
	return _step_profile_result

func connection_basis(world: WorldState) -> Array:
	_step_profile_observer.enter_call("point_navigation.connection_basis")
	var _step_profile_result: Variant = super.connection_basis(world)
	_step_profile_observer.exit_call("point_navigation.connection_basis")
	return _step_profile_result

func routing_floor_basis(world: WorldState) -> Array:
	_step_profile_observer.enter_call("point_navigation.routing_floor_basis")
	var _step_profile_result: Variant = super.routing_floor_basis(world)
	_step_profile_observer.exit_call("point_navigation.routing_floor_basis")
	return _step_profile_result

func structural_clearance(world: WorldState, actor: Dictionary, floor_id: int, members: Array = [], offsets: Dictionary = {}) -> RouteClearance:
	_step_profile_observer.enter_call("point_navigation.structural_clearance")
	var _step_profile_result: Variant = super.structural_clearance(world,actor,floor_id,members,offsets)
	_step_profile_observer.exit_call("point_navigation.structural_clearance")
	return _step_profile_result

func _topology(world: WorldState) -> Dictionary:
	_step_profile_observer.enter_call("point_navigation._topology")
	var _step_profile_result: Variant = super._topology(world)
	_step_profile_observer.exit_call("point_navigation._topology")
	return _step_profile_result

func _topology_floor_nodes(world: WorldState, topology: Dictionary, floor_id: int) -> Dictionary:
	_step_profile_observer.enter_call("point_navigation._topology_floor_nodes")
	var _step_profile_result: Variant = super._topology_floor_nodes(world,topology,floor_id)
	_step_profile_observer.exit_call("point_navigation._topology_floor_nodes")
	return _step_profile_result

func _point_route(world: WorldState, actor: Dictionary, source_floor: int, start: Vector2i, target_floor: int, goal: Vector2i, members: Array, offsets: Dictionary, initial_ticks: int, distance_only: bool) -> Dictionary:
	_step_profile_observer.enter_call("point_navigation._point_route")
	var _step_profile_result: Variant = super._point_route(world,actor,source_floor,start,target_floor,goal,members,offsets,initial_ticks,distance_only)
	_step_profile_observer.exit_call("point_navigation._point_route")
	return _step_profile_result

func _point_edges(id: String, world: WorldState, actor: Dictionary, context: Dictionary) -> Array:
	_step_profile_observer.enter_call("point_navigation._point_edges")
	var _step_profile_result: Variant = super._point_edges(id,world,actor,context)
	_step_profile_observer.exit_call("point_navigation._point_edges")
	return _step_profile_result

func _floor_route(world: WorldState, actor: Dictionary, floor_id: int, start: Vector2i, goal: Vector2i, members: Array = [], offsets: Dictionary = {}, ignore_people: bool = false, navigation: Dictionary = {}, structural_only: bool = false, cost_only: bool = false) -> Dictionary:
	_step_profile_observer.enter_call("point_navigation._floor_route")
	var _step_profile_result: Variant = super._floor_route(world,actor,floor_id,start,goal,members,offsets,ignore_people,navigation,structural_only,cost_only)
	_step_profile_observer.exit_call("point_navigation._floor_route")
	return _step_profile_result
