extends "res://game/building/hospital_space.gd"
var _step_profile_observer: RefCounted

func prepare_projection(world: WorldState, projected: WorldState, facility_ids: Array = [], route_floors: Array = []) -> void:
	_step_profile_observer.enter_call("space.prepare_projection")
	super.prepare_projection(world,projected,facility_ids,route_floors)
	_step_profile_observer.exit_call("space.prepare_projection")

func _ensure_actor_index(world: WorldState) -> void:
	_step_profile_observer.enter_call("space._ensure_actor_index")
	super._ensure_actor_index(world)
	_step_profile_observer.exit_call("space._ensure_actor_index")

func finish_boundary(world: WorldState) -> void:
	_step_profile_observer.enter_call("space.finish_boundary")
	super.finish_boundary(world)
	_step_profile_observer.exit_call("space.finish_boundary")

func route(world: WorldState, actor_id: String, floor_id: int, target: Array, members: Array = [], offsets: Dictionary = {}, ignore_people: bool = false) -> Dictionary:
	_step_profile_observer.enter_call("space.route")
	var _step_profile_result: Variant = super.route(world,actor_id,floor_id,target,members,offsets,ignore_people)
	_step_profile_observer.exit_call("space.route")
	return _step_profile_result

func route_cost(world: WorldState, actor_id: String, floor_id: int, target: Array, members: Array = [], offsets: Dictionary = {}, ignore_people: bool = false) -> Dictionary:
	_step_profile_observer.enter_call("space.route_cost")
	var _step_profile_result: Variant = super.route_cost(world,actor_id,floor_id,target,members,offsets,ignore_people)
	_step_profile_observer.exit_call("space.route_cost")
	return _step_profile_result

func can_reach(world: WorldState, actor_id: String, floor_id: int, target: Array, members: Array = [], offsets: Dictionary = {}, ignore_people: bool = false) -> bool:
	_step_profile_observer.enter_call("space.can_reach")
	var _step_profile_result: Variant = super.can_reach(world,actor_id,floor_id,target,members,offsets,ignore_people)
	_step_profile_observer.exit_call("space.can_reach")
	return _step_profile_result

func _route_result(world: WorldState, actor_id: String, floor_id: int, target: Array, members: Array, offsets: Dictionary, ignore_people: bool, distance_only: bool) -> Dictionary:
	_step_profile_observer.enter_call("space._route_result")
	var _step_profile_result: Variant = super._route_result(world,actor_id,floor_id,target,members,offsets,ignore_people,distance_only)
	_step_profile_observer.exit_call("space._route_result")
	return _step_profile_result

func travel_quote(world: WorldState, actor_id: String, floor_id: int, target: Array) -> Dictionary:
	_step_profile_observer.enter_call("space.travel_quote")
	var _step_profile_result: Variant = super.travel_quote(world,actor_id,floor_id,target)
	_step_profile_observer.exit_call("space.travel_quote")
	return _step_profile_result

func nearby_reachable(world: WorldState, actor_id: String, floor_id: int, start: Vector2i, goal: Vector2i, radius: int = 3) -> bool:
	_step_profile_observer.enter_call("space.nearby_reachable")
	var _step_profile_result: Variant = super.nearby_reachable(world,actor_id,floor_id,start,goal,radius)
	_step_profile_observer.exit_call("space.nearby_reachable")
	return _step_profile_result

func advance(world: WorldState, present_at_start: int = -1) -> void:
	_step_profile_observer.enter_call("space.advance")
	super.advance(world,present_at_start)
	_step_profile_observer.exit_call("space.advance")

func _floor_route(world: WorldState, actor: Dictionary, floor_id: int, start: Vector2i, goal: Vector2i, members: Array = [], offsets: Dictionary = {}, ignore_people: bool = false, navigation: Dictionary = {}, cost_only: bool = false) -> Dictionary:
	_step_profile_observer.enter_call("space._floor_route")
	var _step_profile_result: Variant = super._floor_route(world,actor,floor_id,start,goal,members,offsets,ignore_people,navigation,cost_only)
	_step_profile_observer.exit_call("space._floor_route")
	return _step_profile_result

func _build_reservation_view(world: WorldState) -> Dictionary:
	_step_profile_observer.enter_call("space._build_reservation_view")
	var _step_profile_result: Variant = super._build_reservation_view(world)
	_step_profile_observer.exit_call("space._build_reservation_view")
	return _step_profile_result

func reservation_view(world: WorldState) -> Dictionary:
	_step_profile_observer.enter_call("space.reservation_view")
	var _step_profile_result: Variant = super.reservation_view(world)
	_step_profile_observer.exit_call("space.reservation_view")
	return _step_profile_result

func movement_doors(world: WorldState, actor: Dictionary, swept: Rect2, members: Array = [], floor_id: int = 0) -> Array[Dictionary]:
	_step_profile_observer.enter_call("space.movement_doors")
	var _step_profile_result: Variant = super.movement_doors(world,actor,swept,members,floor_id)
	_step_profile_observer.exit_call("space.movement_doors")
	return _step_profile_result

func _reservation_regions(world: WorldState, floor_id: int, rect: Rect2) -> Array:
	_step_profile_observer.enter_call("space._reservation_regions")
	var _step_profile_result: Variant = super._reservation_regions(world,floor_id,rect)
	_step_profile_observer.exit_call("space._reservation_regions")
	return _step_profile_result

func _dynamic_clear(world: WorldState, actor_id: String, floor_id: int, rect: Rect2, members: Array = []) -> bool:
	_step_profile_observer.enter_call("space._dynamic_clear")
	var _step_profile_result: Variant = super._dynamic_clear(world,actor_id,floor_id,rect,members)
	_step_profile_observer.exit_call("space._dynamic_clear")
	return _step_profile_result

func facility_quote(world: WorldState, facility_id: String, actor_id: String, staff_ids: Array = []) -> Dictionary:
	_step_profile_observer.enter_call("space.facility_quote")
	var _step_profile_result: Variant = super.facility_quote(world,facility_id,actor_id,staff_ids)
	_step_profile_observer.exit_call("space.facility_quote")
	return _step_profile_result

func facility_preflight_quote(world: WorldState, facility_id: String, actor_id: String, staff_ids: Array = []) -> Dictionary:
	_step_profile_observer.enter_call("space.facility_preflight_quote")
	var _step_profile_result: Variant = super.facility_preflight_quote(world,facility_id,actor_id,staff_ids)
	_step_profile_observer.exit_call("space.facility_preflight_quote")
	return _step_profile_result

func facility_geometry_quote(world: WorldState, facility_id: String, actor_id: String, staff_ids: Array = []) -> Dictionary:
	_step_profile_observer.enter_call("space.facility_geometry_quote")
	var _step_profile_result: Variant = super.facility_geometry_quote(world,facility_id,actor_id,staff_ids)
	_step_profile_observer.exit_call("space.facility_geometry_quote")
	return _step_profile_result

func _facility_quote(world: WorldState, facility_id: String, actor_id: String, staff_ids: Array, geometry_only: bool, prove_exits: bool = true) -> Dictionary:
	_step_profile_observer.enter_call("space._facility_quote")
	var _step_profile_result: Variant = super._facility_quote(world,facility_id,actor_id,staff_ids,geometry_only,prove_exits)
	_step_profile_observer.exit_call("space._facility_quote")
	return _step_profile_result

func _facility_geometry_view(world: WorldState, facility: Dictionary) -> Dictionary:
	_step_profile_observer.enter_call("space._facility_geometry_view")
	var _step_profile_result: Variant = super._facility_geometry_view(world,facility)
	_step_profile_observer.exit_call("space._facility_geometry_view")
	return _step_profile_result

func _facility_exit_quote(world: WorldState, facility_id: String, actor_id: String, staff_ids: Array, quote: Dictionary) -> Dictionary:
	_step_profile_observer.enter_call("space._facility_exit_quote")
	var _step_profile_result: Variant = super._facility_exit_quote(world,facility_id,actor_id,staff_ids,quote)
	_step_profile_observer.exit_call("space._facility_exit_quote")
	return _step_profile_result

func _exit_witness(world: WorldState, actor: Dictionary, floor_id: int, start: Vector2i, exit: Vector2i) -> Dictionary:
	_step_profile_observer.enter_call("space._exit_witness")
	var _step_profile_result: Variant = super._exit_witness(world,actor,floor_id,start,exit)
	_step_profile_observer.exit_call("space._exit_witness")
	return _step_profile_result

func facility_trip_quote(world: WorldState, facility_id: String, actor_id: String, staff_ids: Array = []) -> Dictionary:
	_step_profile_observer.enter_call("space.facility_trip_quote")
	var _step_profile_result: Variant = super.facility_trip_quote(world,facility_id,actor_id,staff_ids)
	_step_profile_observer.exit_call("space.facility_trip_quote")
	return _step_profile_result

func reserve_facility(world: WorldState, facility_id: String, actor_id: String, owner_id: String, staff_ids: Array = []) -> String:
	_step_profile_observer.enter_call("space.reserve_facility")
	var _step_profile_result: Variant = super.reserve_facility(world,facility_id,actor_id,owner_id,staff_ids)
	_step_profile_observer.exit_call("space.reserve_facility")
	return _step_profile_result
