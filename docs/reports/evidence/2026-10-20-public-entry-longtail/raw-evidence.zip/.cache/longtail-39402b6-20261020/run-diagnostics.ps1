#requires -Version 7.0
$ErrorActionPreference='Stop'
$repo='C:/code/loyayz/oddly-good-hospital'
$root=Join-Path $repo '.cache/longtail-39402b6-20261020'
$godot='C:/programs/godot/Godot_v4.7.2-stable_win64_console.exe'
$runs=@(
    @{name='after-nested-public40';project='after-project';input='public-v6.input.bin';steps=40;mode='nested';trace='false'},
    @{name='after-nested-gp40';project='after-project';input='gp.input.bin';steps=40;mode='nested';trace='false'},
    @{name='before-nested-operations40';project='before-detail-project';input='op.input.bin';steps=40;mode='nested';trace='false'},
    @{name='after-nested-operations40';project='after-project';input='op.input.bin';steps=40;mode='nested';trace='false'},
    @{name='after-trace-public360';project='after-project';input='public-v6.input.bin';steps=360;mode='plain';trace='true'}
)
foreach($run in $runs){
    $output=Join-Path $root ($run.name+'.json')
    if(Test-Path -LiteralPath $output){throw "Evidence already exists: $output"}
    $input=Join-Path $repo ('.cache/task-navigation-20261019/'+$run.input)
    $log=[IO.Path]::ChangeExtension($output,'.log')
    & $godot --headless --path (Join-Path $root $run.project) --script res://tools/performance/representative.gd -- "--input=$input" "--output=$output" "--steps=$($run.steps)" "--profile=$($run.mode)" "--movement-trace=$($run.trace)" *> $log
    if($LASTEXITCODE -ne 0 -or (Select-String -LiteralPath $log -Pattern 'SCRIPT ERROR:|ERROR:' -Quiet)){Get-Content -LiteralPath $log -Tail 15;throw "Run failed: $log"}
    $result=Get-Content -LiteralPath $output -Raw|ConvertFrom-Json
    if(-not $result.qualified){throw "Unqualified: $output"}
    [ordered]@{run=$run.name;qualified=$result.qualified;metrics=$result.metrics;final_hash=$result.final_binary_sha256}|ConvertTo-Json -Depth 4 -Compress
}
