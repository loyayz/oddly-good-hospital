extends "res://game/life/public_areas.gd"
var _step_profile_observer: RefCounted

func should_recheck(world: WorldState, intent: Dictionary, definitions: Array, members: Array = [], extra: Dictionary = {}) -> bool:
	_step_profile_observer.enter_call("public_areas.should_recheck")
	var _step_profile_result: Variant = super.should_recheck(world,intent,definitions,members,extra)
	_step_profile_observer.exit_call("public_areas.should_recheck")
	return _step_profile_result

func remember_wait(world: WorldState, intent: Dictionary, definitions: Array, members: Array = [], extra: Dictionary = {}) -> void:
	_step_profile_observer.enter_call("public_areas.remember_wait")
	super.remember_wait(world,intent,definitions,members,extra)
	_step_profile_observer.exit_call("public_areas.remember_wait")

func _decision_view(world: WorldState) -> Dictionary:
	_step_profile_observer.enter_call("public_areas._decision_view")
	var _step_profile_result: Variant = super._decision_view(world)
	_step_profile_observer.exit_call("public_areas._decision_view")
	return _step_profile_result

func _decision_signature(world: WorldState, intent: Dictionary, definitions: Array, members: Array, extra: Dictionary, route_floors: Array = []) -> String:
	_step_profile_observer.enter_call("public_areas._decision_signature")
	var _step_profile_result: Variant = super._decision_signature(world,intent,definitions,members,extra,route_floors)
	_step_profile_observer.exit_call("public_areas._decision_signature")
	return _step_profile_result

func _add_dynamic_dependencies(world: WorldState, floor_id: int, bounds: Rect2, members: Array, actors: Dictionary, reservations: Dictionary) -> void:
	_step_profile_observer.enter_call("public_areas._add_dynamic_dependencies")
	super._add_dynamic_dependencies(world,floor_id,bounds,members,actors,reservations)
	_step_profile_observer.exit_call("public_areas._add_dynamic_dependencies")

func _ensure(world: WorldState, requested_floor: int = 0) -> void:
	_step_profile_observer.enter_call("public_areas._ensure")
	super._ensure(world,requested_floor)
	_step_profile_observer.exit_call("public_areas._ensure")

func region(world: WorldState, reference: Dictionary) -> Dictionary:
	_step_profile_observer.enter_call("public_areas.region")
	var _step_profile_result: Variant = super.region(world,reference)
	_step_profile_observer.exit_call("public_areas.region")
	return _step_profile_result

func contains(world: WorldState, reference: Dictionary, actor_id: String) -> bool:
	_step_profile_observer.enter_call("public_areas.contains")
	var _step_profile_result: Variant = super.contains(world,reference,actor_id)
	_step_profile_observer.exit_call("public_areas.contains")
	return _step_profile_result

func current_area(world: WorldState, actor_id: String) -> Dictionary:
	_step_profile_observer.enter_call("public_areas.current_area")
	var _step_profile_result: Variant = super.current_area(world,actor_id)
	_step_profile_observer.exit_call("public_areas.current_area")
	return _step_profile_result

func facilities(world: WorldState, reference: Dictionary, definitions: Array) -> Array:
	_step_profile_observer.enter_call("public_areas.facilities")
	var _step_profile_result: Variant = super.facilities(world,reference,definitions)
	_step_profile_observer.exit_call("public_areas.facilities")
	return _step_profile_result

func compatible_geometry(world: WorldState, reference: Dictionary, definitions: Array, members: Array) -> bool:
	_step_profile_observer.enter_call("public_areas.compatible_geometry")
	var _step_profile_result: Variant = super.compatible_geometry(world,reference,definitions,members)
	_step_profile_observer.exit_call("public_areas.compatible_geometry")
	return _step_profile_result

func select(world: WorldState, actor_id: String, definitions: Array, room_kinds: Array, purpose: String, members: Array = [], maximum_travel_ticks: int = 9223372036854775807, selected_entries: Dictionary = {}) -> Dictionary:
	_step_profile_observer.enter_call("public_areas.select")
	var _step_profile_result: Variant = super.select(world,actor_id,definitions,room_kinds,purpose,members,maximum_travel_ticks,selected_entries)
	_step_profile_observer.exit_call("public_areas.select")
	return _step_profile_result

func waiting_point(world: WorldState, actor_id: String, reference: Dictionary, maximum_travel_ticks: int = 9223372036854775807) -> Dictionary:
	_step_profile_observer.enter_call("public_areas.waiting_point")
	var _step_profile_result: Variant = super.waiting_point(world,actor_id,reference,maximum_travel_ticks)
	_step_profile_observer.exit_call("public_areas.waiting_point")
	return _step_profile_result

func _waiting_point(world: WorldState, actor_id: String, reference: Dictionary, maximum_travel_ticks: int) -> Dictionary:
	_step_profile_observer.enter_call("public_areas._waiting_point")
	var _step_profile_result: Variant = super._waiting_point(world,actor_id,reference,maximum_travel_ticks)
	_step_profile_observer.exit_call("public_areas._waiting_point")
	return _step_profile_result

func _entry_landings(world: WorldState, actor_id: String, floor_id: int) -> Dictionary:
	_step_profile_observer.enter_call("public_areas._entry_landings")
	var _step_profile_result: Variant = super._entry_landings(world,actor_id,floor_id)
	_step_profile_observer.exit_call("public_areas._entry_landings")
	return _step_profile_result

func _entry_lower_bound(actor: Dictionary, origin: Vector2, point: Vector2i, bounds: Dictionary) -> int:
	_step_profile_observer.enter_call("public_areas._entry_lower_bound")
	var _step_profile_result: Variant = super._entry_lower_bound(actor,origin,point,bounds)
	_step_profile_observer.exit_call("public_areas._entry_lower_bound")
	return _step_profile_result

func safe_wait(world: WorldState, actor_id: String, floor_id: int, cell: Array, geometry: Dictionary = {}) -> bool:
	_step_profile_observer.enter_call("public_areas.safe_wait")
	var _step_profile_result: Variant = super.safe_wait(world,actor_id,floor_id,cell,geometry)
	_step_profile_observer.exit_call("public_areas.safe_wait")
	return _step_profile_result

func _safe_wait_geometry(world: WorldState, actor: Dictionary, floor_id: int, origin: Vector2, geometry: RouteClearance) -> bool:
	_step_profile_observer.enter_call("public_areas._safe_wait_geometry")
	var _step_profile_result: Variant = super._safe_wait_geometry(world,actor,floor_id,origin,geometry)
	_step_profile_observer.exit_call("public_areas._safe_wait_geometry")
	return _step_profile_result

func _entry_geometry_view(world: WorldState, actor: Dictionary, area: Dictionary) -> Dictionary:
	_step_profile_observer.enter_call("public_areas._entry_geometry_view")
	var _step_profile_result: Variant = super._entry_geometry_view(world,actor,area)
	_step_profile_observer.exit_call("public_areas._entry_geometry_view")
	return _step_profile_result

func _wait_constraints(world: WorldState) -> Dictionary:
	_step_profile_observer.enter_call("public_areas._wait_constraints")
	var _step_profile_result: Variant = super._wait_constraints(world)
	_step_profile_observer.exit_call("public_areas._wait_constraints")
	return _step_profile_result

func _wait_estimate(world: WorldState, reference: Dictionary, facility_ids: Array, purpose: String) -> int:
	_step_profile_observer.enter_call("public_areas._wait_estimate")
	var _step_profile_result: Variant = super._wait_estimate(world,reference,facility_ids,purpose)
	_step_profile_observer.exit_call("public_areas._wait_estimate")
	return _step_profile_result

func _wait_estimate_view(world: WorldState) -> Dictionary:
	_step_profile_observer.enter_call("public_areas._wait_estimate_view")
	var _step_profile_result: Variant = super._wait_estimate_view(world)
	_step_profile_observer.exit_call("public_areas._wait_estimate_view")
	return _step_profile_result

func _intent_view(world: WorldState) -> Dictionary:
	_step_profile_observer.enter_call("public_areas._intent_view")
	var _step_profile_result: Variant = super._intent_view(world)
	_step_profile_observer.exit_call("public_areas._intent_view")
	return _step_profile_result

func _queue_members(world: WorldState) -> Dictionary:
	_step_profile_observer.enter_call("public_areas._queue_members")
	var _step_profile_result: Variant = super._queue_members(world)
	_step_profile_observer.exit_call("public_areas._queue_members")
	return _step_profile_result

func _facility_queue(world: WorldState, purpose: String, facility_id: String) -> Array:
	_step_profile_observer.enter_call("public_areas._facility_queue")
	var _step_profile_result: Variant = super._facility_queue(world,purpose,facility_id)
	_step_profile_observer.exit_call("public_areas._facility_queue")
	return _step_profile_result

func turn(world: WorldState, intent: Dictionary, facility_id: String) -> bool:
	_step_profile_observer.enter_call("public_areas.turn")
	var _step_profile_result: Variant = super.turn(world,intent,facility_id)
	_step_profile_observer.exit_call("public_areas.turn")
	return _step_profile_result

func _queue_fit(world: WorldState, facility_id: String, ids: Array) -> Dictionary:
	_step_profile_observer.enter_call("public_areas._queue_fit")
	var _step_profile_result: Variant = super._queue_fit(world,facility_id,ids)
	_step_profile_observer.exit_call("public_areas._queue_fit")
	return _step_profile_result

func _queue_fit_in_query(world: WorldState, facility_id: String, ids: Array) -> Dictionary:
	_step_profile_observer.enter_call("public_areas._queue_fit_in_query")
	var _step_profile_result: Variant = super._queue_fit_in_query(world,facility_id,ids)
	_step_profile_observer.exit_call("public_areas._queue_fit_in_query")
	return _step_profile_result
