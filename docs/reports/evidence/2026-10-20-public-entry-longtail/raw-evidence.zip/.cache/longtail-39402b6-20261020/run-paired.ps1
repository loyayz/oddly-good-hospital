#requires -Version 7.0
$ErrorActionPreference='Stop'
$repo='C:/code/loyayz/oddly-good-hospital'
$root=Join-Path $repo '.cache/longtail-39402b6-20261020'
$godot='C:/programs/godot/Godot_v4.7.2-stable_win64_console.exe'
$projects=@{before=Join-Path $repo '.cache/public-flow-20261020/after-project';after=Join-Path $root 'after-project'}
foreach($scenario in @(@{name='public360';input='public-v6.input.bin';steps=360},@{name='gp80';input='gp.input.bin';steps=80},@{name='operations40';input='op.input.bin';steps=40})) {
    foreach($version in @('before','after')) {
        $output=Join-Path $root ($version+'-plain-'+$scenario.name+'.json')
        if(Test-Path -LiteralPath $output){throw "Evidence already exists: $output"}
        $input=Join-Path $repo ('.cache/task-navigation-20261019/'+$scenario.input)
        $log=[IO.Path]::ChangeExtension($output,'.log')
        & $godot --headless --path $projects[$version] --script res://tools/performance/representative.gd -- "--input=$input" "--output=$output" "--steps=$($scenario.steps)" --profile=plain *> $log
        if($LASTEXITCODE -ne 0 -or (Select-String -LiteralPath $log -Pattern 'SCRIPT ERROR:|ERROR:' -Quiet)){Get-Content -LiteralPath $log -Tail 20;throw "Run failed: $log"}
        $result=Get-Content -LiteralPath $output -Raw|ConvertFrom-Json
        if(-not $result.qualified){throw "Unqualified: $output"}
        if($scenario.name -eq 'public360' -and @($result.public_checks.PSObject.Properties|Where-Object Value -NE $true).Count -gt 0){throw "Public checks failed: $output"}
        [ordered]@{run=($version+'-'+$scenario.name);metrics=$result.metrics;qualified=$result.qualified;public_checks=$result.public_checks;final_hash=$result.final_binary_sha256}|ConvertTo-Json -Depth 5 -Compress
    }
}
