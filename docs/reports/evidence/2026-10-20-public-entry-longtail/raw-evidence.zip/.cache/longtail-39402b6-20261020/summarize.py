import hashlib, json, pathlib, subprocess, zipfile

REPO = pathlib.Path(r'C:\code\loyayz\oddly-good-hospital')
ROOT = REPO / '.cache/longtail-39402b6-20261020'
OUT = REPO / 'docs/reports/evidence/2026-10-20-public-entry-longtail'
OUT.mkdir(parents=True, exist_ok=True)

def read(path):
    return json.loads(pathlib.Path(path).read_text(encoding='utf-8-sig'))

def dump(name, value):
    (OUT/name).write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')

def sha(path):
    return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()

def measured(name):
    r = read(ROOT/(name+'.json'))
    p = r.get('public', {})
    return dict(run=name, metrics=r['metrics'], qualified=r['qualified'], qualification=r['qualification'],
                public_checks=r.get('public_checks'), final_binary_sha256=r['final_binary_sha256'],
                input_sha256=r['source_input_sha256'], work_ticks=r['final']['work_ticks_by_kind'],
                query_counts=p.get('query_counts', {}),
                public_work=dict(starts=len(p.get('actual_use_starts', {})), completions=len(p.get('actual_use_completions', {})),
                                 actual_use_ticks=p.get('actual_use_ticks'), queue_actor_ticks=p.get('queue_actor_ticks'),
                                 released_then_reused=p.get('actual_exit_then_reuse_count')),
                original_tail_step=r['samples'][27] if len(r['samples'])>27 else None)

comparisons=[]
for window in ['public360','gp80','operations40']:
    before, after = measured('before-plain-'+window), measured('final-plain-'+window)
    comparisons.append(dict(window=window,before=before,after=after,
        reductions={k:1-after['metrics'][k]/before['metrics'][k] for k in ['mean_us','p95_us','max_us']},
        same_final_binary=before['final_binary_sha256']==after['final_binary_sha256']))
dump('quick-summary.json', dict(baseline='39402b6c127d52bce425c3c7e834ca75f072bf39',formal_pass=False,
    formal_acceptance_paused=True,windows=comparisons,
    superseded_before_collision_drift_repair=[measured('after-plain-'+w) for w in ['public360','gp80','operations40']]))

profiles=[]
for path in sorted(ROOT.glob('*-root-*.json'))+sorted(ROOT.glob('*-nested-*.json'))+[ROOT/'before-detail-public40.json']:
    r=read(path)
    if 'profile' not in r: continue
    p=r['profile']; records=p['step_records']
    indices=sorted(set([0,27,max(range(len(records)),key=lambda n:records[n]['outer_elapsed_us'])]))
    compact=[]
    for n in indices:
        s=records[n]
        compact.append(dict(index=n,tick=s['tick'],outer_us=s['outer_elapsed_us'],observer_handler_us=s['observer_handler_us'],
            residual_us=s['residual_us'],stages=s['stages'],
            hottest_functions=sorted([dict(name=k,**v) for k,v in s['calls'].items()],key=lambda row:row['exclusive_us'],reverse=True)[:16],
            entry_functions={k:v for k,v in s['calls'].items() if k in ['public_areas._entry_lower_bound','public_areas._ordered_entry_cells','public_areas._waiting_point','public_areas.select']}))
    profiles.append(dict(run=path.stem,final_binary_sha256=r['final_binary_sha256'],errors=p['errors'],
        semantics=p['semantics'],sources=p['sources'],totals=dict(profiled_whole_us=p['profiled_whole_us'],observer_handler_us=p['observer_handler_us'],residual_us=p['residual_us']),steps=compact))
dump('stage-function-summary.json',dict(profiles=profiles,
    caution='Diagnostic inclusive times overlap. Root stages are disjoint; exclusive function times subtract wrapped children. Observer handler time is measured separately but wrapper perturbation remains. Plain paired whole-step elapsed times define the performance comparison. Unwrapped leaf work stays with its nearest timed caller.'))

traces=[]
for name in ['legacy-trace-public360','before-trace-public360','after-trace-public360','final-trace-public360']:
    r=read(ROOT/(name+'.json')); trace=r['movement_trace']
    traces.append(dict(run=name,final_binary_sha256=r['final_binary_sha256'],counts=trace['counts'],
        query_counts=r['public']['query_counts'],errors=trace['errors'],dispatch_count_check=trace['dispatch_count_check'],
        top_actors=sorted(trace['actors'],key=lambda a:a['counts'].get('queue.local_fallback',0),reverse=True)[:8]))
dump('movement-summary.json',dict(traces=traces,
    caution='Repeated signatures alone do not prove live occupancy unchanged. Actual current contacts and goal occupancy justify the production gate; yield_attempts keeps its original meaning. Legacy913 explains the earlier increase and is not the optimization baseline.'))

batch_ids=['cfa57464eee640748e17f570e1bf29f1','9117679370ba4719b64036b9f43ac05e','666776bf44094762b74894e89d9f7a24','cd0eec5fe63d4b158ea263c7ad19ca2c','8892f7a748b94b3e977ca2dc87529f09']
batches=[]
for batch in batch_ids:
    base=REPO/'.cache/acceptance'/batch
    r=read(base/'acceptance-results.json')
    batches.append(dict(id=batch,requested_cases=r['requested_cases'],checks=r['checks'],assertions_failed=r['failed'],
        script_errors='SCRIPT ERROR:' in (base/'execution.log').read_text(encoding='utf-8-sig'),timing=read(base/'timing-summary.json')))
dump('functional-summary.json',dict(unique_final_selected_cases=['STAFF-45','STAFF-61','STAFF-65','STAFF-71','STAFF-75','SPACE-10','SPACE-53','SPACE-56','SPACE-57'],
    batches=batches,reused_pass={'case':'STAFF-75','batch':batch_ids[0],
    'reason':'Candidate calculation only; public_areas.gd, public_phase_use.gd and calculation dependencies are unchanged. The later correction only changes movement sweep targets, never called by this case.'},
    failures=['Initial SPACE56 assertion passed but an incomplete CourtesyProbe journey caused a script error; complete cursor/path input repaired the probe.',
              'Initial single-person old-sweep expectation was not actually exercised by that real trajectory; retain real release/arrival and use a separate lawful collision-calculation boundary for the old-sweep contract.',
              'SPACE57 group safety failed in three runs. Numeric production-vs-canonical sweep snapshots proved float32 rectangle drift and an actual missed timed collision; fixed production destination construction with no epsilon relaxation.']))

failed_details=read(REPO/'.cache/acceptance'/batch_ids[2]/'acceptance-results.json')['results']['SPACE-57']['details']
fixed_details=read(REPO/'.cache/acceptance'/batch_ids[3]/'acceptance-results.json')['results']['SPACE-57']['details']
dump('collision-repair.json',dict(failed=failed_details,fixed=fixed_details,
    cause='The same-facing fast path translated the prior float32 rectangle repeatedly instead of deriving it from the actual actor position and cached shape. Numeric actual-sweep snapshots differ from canonical bodies; the timed crossing was missed. No overlap epsilon or movement rule was relaxed.'))

final_id=read(ROOT/'final-project/source-identity.json')
source_checks=[]
for item in final_id['source']:
    path=REPO/item['path']
    if item['path'].startswith(('game/','content/','tools/performance/')) and path.is_file():
        source_checks.append(dict(path=item['path'],measured=item['sha256'],current=sha(path),match=item['sha256']==sha(path)))
test_id=read(REPO/'.cache/acceptance'/batch_ids[-1]/'source-identity.json')
# Acceptance identities may use a different key for source rows.
test_rows=test_id.get('source',test_id.get('files',[]))
test_checks=[]
for item in test_rows:
    if item['path'].startswith('tests/acceptance/') and (REPO/item['path']).is_file():
        test_checks.append(dict(path=item['path'],match=item['sha256']==sha(REPO/item['path'])))
baseline_id=read(REPO/'.cache/public-flow-20261020/after-project/source-identity.json')
binary_keys=['engine_sha256','native_sha256','gmp_sha256','mpfr_sha256','runtime_sha256']
binary_matches={k:final_id[k]==baseline_id[k] for k in binary_keys}
dump('source-check.json',dict(baseline=read(ROOT/'baseline-identity.json'),
    final_source_rows=len(source_checks),mismatches=[r for r in source_checks if not r['match']],source=source_checks,
    acceptance_source_rows=len(test_checks),acceptance_mismatches=[r for r in test_checks if not r['match']],binary_matches=binary_matches,
    engine_sha256=final_id['engine_sha256'],native_sha256=final_id['native_sha256'],gmp_sha256=final_id['gmp_sha256'],mpfr_sha256=final_id['mpfr_sha256'],runtime_sha256=final_id['runtime_sha256']))
assert source_checks and not any(not r['match'] for r in source_checks)
assert test_checks and not any(not r['match'] for r in test_checks)
assert all(binary_matches.values())

raw={}
def add(path,arc=None):
    path=pathlib.Path(path)
    if path.is_file(): raw[arc or path.relative_to(REPO).as_posix()]=path
for path in ROOT.iterdir():
    if path.is_file(): add(path)
    elif path.name.endswith('.sources'):
        for source in path.rglob('*.gd'): add(source)
    elif path.name.endswith('-project'):
        for relative in ['source-identity.json','import.log','project.godot','game/life/public_areas.gd','game/building/hospital_movement.gd','tools/performance/representative.gd','tools/performance/step_profile.gd','tools/performance/movement_trace.gd']:
            add(path/relative)
baseline=REPO/'.cache/public-flow-20261020/after-project'
for relative in ['source-identity.json','game/life/public_areas.gd','game/building/hospital_movement.gd','tools/performance/representative.gd','tools/performance/step_profile.gd']:
    add(baseline/relative)
for name in ['public-v6.input.bin','gp.input.bin','op.input.bin']:
    add(REPO/'.cache/task-navigation-20261019'/name)
for batch in batch_ids:
    base=REPO/'.cache/acceptance'/batch
    for name in ['acceptance-results.json','execution.log','execution-status.json','import.log','timing-summary.json','source-identity.json']:
        add(base/name)
    for name in ['movement_goal_wait.gd','movement_result.gd','public_phase_use.gd']:
        add(base/'tests/acceptance'/name)
for path in sorted(OUT.glob('*.json')):
    if path.name!='raw-manifest.json': add(path)
archive=OUT/'raw-evidence.zip'
manifest=[]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,path in sorted(raw.items()):
        z.write(path,name)
        manifest.append(dict(path=name,bytes=path.stat().st_size,sha256=sha(path)))
with zipfile.ZipFile(archive) as z:
    for row in manifest:
        assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256']
dump('raw-manifest.json',dict(archive_sha256=sha(archive),archive_bytes=archive.stat().st_size,entries=manifest,verified_entries=len(manifest)))
print(json.dumps(dict(windows=[dict(window=x['window'],before=x['before']['metrics'],after=x['after']['metrics'],reduction=x['reductions'],public=x['after']['public_work']) for x in comparisons],raw_entries=len(manifest),raw_bytes=archive.stat().st_size,source_rows=len(source_checks),test_rows=len(test_checks)),ensure_ascii=False))
