from pathlib import Path
import sys,shutil,json,hashlib,zipfile,traceback,subprocess
BASE=Path(__file__).resolve().parent;REPO=BASE.parent/'oddly-good-hospital-cloud-recovery-20261112';ROOT=BASE.parent/'root-stage-recovery-20261112';N=BASE.parent/'movement-stage-recovery-20261112';OLD=BASE.parent/'move-step-breakdown-20261112'
sys.path.insert(0,str(N));import full_narrow_v1 as h
c=h.c;g=h.g
cfg=c.read(ROOT/'config.json');c.verify(cfg);c.idle();head=subprocess.check_output(['git','-C',str(REPO),'rev-parse','HEAD'],text=True).strip();assert head=='73fd37695602442c91b36644d471cfa51045655d';assert not subprocess.check_output(['git','-C',str(REPO),'diff','HEAD','--'],text=True)
receipt=c.read(ROOT/'full-plain.durable-receipt.json');assert receipt['readback_verified'];assert receipt['archive_sha256']==c.sha(ROOT/'full-plain.zip')
short=BASE.parent/'fallback-safe-arrival-20261112';short_receipt=c.read(short/'selected.durable-receipt.json');assert short_receipt['readback_verified'] and short_receipt['archive_sha256']==c.sha(short/'selected.zip')
with zipfile.ZipFile(ROOT/'full-plain.zip') as z:
 manifest=json.loads(z.read('MEMBERS.json'))
 for n in ['run/result.json','run/result.json.final.bin']:
  data=z.read(n);assert hashlib.sha256(data).hexdigest()==manifest[n]['sha256'];dest=BASE/'baseline'/n;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
shutil.copy2(ROOT/'mixed160.input.bin',BASE/'input.bin')
assert c.sha(BASE/'input.bin')=='75f5e1d922f39f12382c0ceb74806bda0293251189f68a1ac158842f65fa78ca'
project=BASE/'project';shutil.copytree(REPO,project,ignore=shutil.ignore_patterns('.git','docs','art-source','.cache'));driver='tools/performance/current/plain_v4.gd';assert c.sha(project/driver)==c.sha(OLD/'plain-project'/driver)
prior=c.read(OLD/'identity.json')['inventories']['plain'];inventory=c.inventory(project)
for rel,digest in prior.items():
 if rel.startswith(('content/','native/')):assert inventory[rel]==digest,rel
c.write(BASE/'identity.json',{'head':head,'inventory':inventory,'runtime':cfg,'input_sha256':c.sha(BASE/'input.bin'),'driver_sha256':c.sha(project/driver),'baseline_receipt':receipt,'fixed_steps':6000,'prefix_steps':1000,'functional_durable_receipt':short_receipt,'step_seconds':0.1,'requested_thread_policy':'app','workers':4,'OMP_NUM_THREADS':1,'controller_sha256':c.sha(__file__)})
for rel in [driver,'game/building/navigation_cache.gd','game/building/hospital_navigation.gd','game/operations/floor_guidance.gd','game/life/public_areas.gd','game/life/waiting_life.gd','tools/performance/current/comprehensive_operations.gd','tools/performance/current/comprehensive_observer.gd']:
 dest=BASE/'sources'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(project/rel,dest)
for p in [ROOT/'controller_v2.py',ROOT/'linux_guard_v2.py',N/'full_narrow_v1.py',N/'qualify_v1.py',N/'prepare_v1.py']:shutil.copy2(p,BASE/('dependency-'+p.name))
g.PROJECT=project;g.LIBRARY_PATH=cfg['library_path'];c.write(BASE/'host-before.json',h.host())
try:
 g.run([cfg['engine'],'--headless','--path',str(project),'--script','res://'+driver,'--','--input='+str(BASE/'input.bin'),'--output='+str(BASE/'plain/result.json'),'--steps=6000','--prefix-steps=1000','--expected-scenario=mixed160-clinical-ops-v1','--require-coverage','--worker-tasks=4','--main-thread-policy=app','--observed-floor=1'],BASE/'plain',timeout=1800,allowed_exits=(0,1))
 assert c.inventory(project)==inventory;c.verify(cfg)
 a=c.read(BASE/'baseline/run/result.json');b=c.read(BASE/'plain/result.json')
 checks={k:a[k]==b[k] for k in ['business','sample_business','prefix_business','errors','complete']};checks['full_world_rng_events_binary_equal']=(BASE/'baseline/run/result.json.final.bin').read_bytes()==(BASE/'plain/result.json.final.bin').read_bytes();checks['seven_thousand_steps_executed']=b['all_completed_steps']==7000
 checks['raw_complete']=b['complete']
 checks['performance_pass']=b['performance_pass']
 c.write(BASE/'comparison.json',{'checks':checks,'descriptive_old_behavior_equal_not_correctness_gate':all(checks[k] for k in ['business','sample_business','prefix_business','errors','complete','full_world_rng_events_binary_equal']),'final_sha256':b['final_sha256'],'scope':'One complete original mixed fixed-load window. Execution, descriptive old-state difference, business coverage and latency acceptance are distinct. Corrected business trajectory may differ; old final is not a correctness gate. Not three-repeat acceptance.'});assert checks['seven_thousand_steps_executed'],checks
except BaseException:c.write(BASE/'error.json',{'traceback':traceback.format_exc()});raise
finally:
 c.write(BASE/'host-after.json',h.host())
 files=[p for p in BASE.rglob('*') if p.is_file() and p.relative_to(BASE).parts[0]!='project' and p.name not in ['full-plain.zip','members.json','checkpoint.json']];m={str(p.relative_to(BASE)):{'bytes':p.stat().st_size,'sha256':c.sha(p)} for p in files};c.write(BASE/'members.json',m)
 with zipfile.ZipFile(BASE/'full-plain.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
  for p in files:z.write(p,str(p.relative_to(BASE)))
  z.write(BASE/'members.json','MEMBERS.json')
 with zipfile.ZipFile(BASE/'full-plain.zip') as z:
  assert z.testzip() is None
  for n,v in m.items():assert len(z.read(n))==v['bytes'] and hashlib.sha256(z.read(n)).hexdigest()==v['sha256']
 c.write(BASE/'checkpoint.json',{'sha256':c.sha(BASE/'full-plain.zip'),'bytes':(BASE/'full-plain.zip').stat().st_size,'members':len(m),'local_readback_verified':True})
c.idle()
