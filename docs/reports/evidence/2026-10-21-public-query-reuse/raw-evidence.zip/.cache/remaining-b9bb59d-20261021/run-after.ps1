#requires -Version 7.0
$ErrorActionPreference='Stop'
$repo='C:/code/loyayz/oddly-good-hospital'
$root=Join-Path $repo '.cache/remaining-b9bb59d-20261021'
$godot='C:/programs/godot/Godot_v4.7.2-stable_win64_console.exe'
$runs=@(
    @{name='after-plain-public360';project='after-project';script='representative.gd';input='public-v6.input.bin';steps=360;mode='plain';selected='0'},
    @{name='after-plain-gp80';project='after-project';script='representative.gd';input='gp.input.bin';steps=80;mode='plain';selected='0'},
    @{name='after-plain-operations40';project='after-project';script='representative.gd';input='op.input.bin';steps=40;mode='plain';selected='0'},
    @{name='after-all-public360';project='after-all-project';script='representative_selected.gd';input='public-v6.input.bin';steps=360;mode='all';selected='0,27,140,239,339'},
    @{name='after-all-gp40';project='after-all-project';script='representative_selected.gd';input='gp.input.bin';steps=40;mode='all';selected='0,27'},
    @{name='after-all-operations40';project='after-all-project';script='representative_selected.gd';input='op.input.bin';steps=40;mode='all';selected='0'},
    @{name='before-trace-public360';project='before-trace-project';script='representative.gd';input='public-v6.input.bin';steps=360;mode='plain';selected='0';trace='true'},
    @{name='after-trace-public360';project='after-project';script='representative.gd';input='public-v6.input.bin';steps=360;mode='plain';selected='0';trace='true'}
)
foreach($run in $runs){
    $output=Join-Path $root ($run.name+'.json')
    if(Test-Path -LiteralPath $output){throw "Evidence already exists: $output"}
    $input=Join-Path $repo ('.cache/task-navigation-20261019/'+$run.input)
    $trace=if($run.trace){$run.trace}else{"false"}
    $log=[IO.Path]::ChangeExtension($output,'.log')
    & $godot --headless --path (Join-Path $root $run.project) --script ('res://tools/performance/'+$run.script) -- "--input=$input" "--output=$output" "--steps=$($run.steps)" "--profile=$($run.mode)" "--selected=$($run.selected)" "--movement-trace=$trace" *> $log
    if($LASTEXITCODE -ne 0 -or (Select-String -LiteralPath $log -Pattern 'SCRIPT ERROR:|ERROR:' -Quiet)){Get-Content -LiteralPath $log -Tail 15;throw "Run failed: $log"}
    $result=Get-Content -LiteralPath $output -Raw|ConvertFrom-Json
    if(-not $result.qualified){throw "Unqualified: $output"}
    [ordered]@{run=$run.name;qualified=$result.qualified;metrics=$result.metrics;public_checks=$result.public_checks;final_hash=$result.final_binary_sha256}|ConvertTo-Json -Depth 4 -Compress
}

