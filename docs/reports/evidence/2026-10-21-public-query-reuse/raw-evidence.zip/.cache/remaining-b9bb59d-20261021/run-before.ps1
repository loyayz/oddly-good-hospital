#requires -Version 7.0
$ErrorActionPreference='Stop'
$repo='C:/code/loyayz/oddly-good-hospital'
$root=Join-Path $repo '.cache/remaining-b9bb59d-20261021'
$godot='C:/programs/godot/Godot_v4.7.2-stable_win64_console.exe'
$runs=@(
    @{name='before-plain-public360';project='before-project';script='representative.gd';input='public-v6.input.bin';steps=360;mode='plain';selected='0'},
    @{name='before-plain-gp80';project='before-project';script='representative.gd';input='gp.input.bin';steps=80;mode='plain';selected='0'},
    @{name='before-plain-operations40';project='before-project';script='representative.gd';input='op.input.bin';steps=40;mode='plain';selected='0'},
    @{name='before-all-public360';project='before-all-project';script='representative_selected.gd';input='public-v6.input.bin';steps=360;mode='all';selected='0,27,140,239,339'},
    @{name='before-all-gp40';project='before-all-project';script='representative_selected.gd';input='gp.input.bin';steps=40;mode='all';selected='0,27'},
    @{name='before-all-operations40';project='before-all-project';script='representative_selected.gd';input='op.input.bin';steps=40;mode='all';selected='0'}
)
foreach($run in $runs){
    $output=Join-Path $root ($run.name+'.json')
    if(Test-Path -LiteralPath $output){throw "Evidence already exists: $output"}
    $input=Join-Path $repo ('.cache/task-navigation-20261019/'+$run.input)
    $log=[IO.Path]::ChangeExtension($output,'.log')
    & $godot --headless --path (Join-Path $root $run.project) --script ('res://tools/performance/'+$run.script) -- "--input=$input" "--output=$output" "--steps=$($run.steps)" "--profile=$($run.mode)" "--selected=$($run.selected)" *> $log
    if($LASTEXITCODE -ne 0 -or (Select-String -LiteralPath $log -Pattern 'SCRIPT ERROR:|ERROR:' -Quiet)){Get-Content -LiteralPath $log -Tail 15;throw "Run failed: $log"}
    $result=Get-Content -LiteralPath $output -Raw|ConvertFrom-Json
    if(-not $result.qualified){throw "Unqualified: $output"}
    [ordered]@{run=$run.name;qualified=$result.qualified;metrics=$result.metrics;public_checks=$result.public_checks;final_hash=$result.final_binary_sha256}|ConvertTo-Json -Depth 4 -Compress
}
