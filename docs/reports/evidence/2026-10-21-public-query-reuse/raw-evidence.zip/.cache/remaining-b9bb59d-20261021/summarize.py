import hashlib
import json
import pathlib
import subprocess
import zipfile

REPO = pathlib.Path(r'C:\code\loyayz\oddly-good-hospital')
ROOT = REPO / '.cache/remaining-b9bb59d-20261021'
OUT = REPO / 'docs/reports/evidence/2026-10-21-public-query-reuse'
BASE = 'b9bb59d59ec5db1d75f80e6db25f27f335f7fa41'
OUT.mkdir(parents=True, exist_ok=True)

def read(path):
    return json.loads(pathlib.Path(path).read_text(encoding='utf-8-sig'))

def sha(path):
    return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()

def dump(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')

def measured(name):
    r = read(ROOT / (name+'.json'))
    p = r.get('public', {})
    return dict(run=name, metrics=r['metrics'], qualified=r['qualified'], qualification=r['qualification'],
                public_checks=r.get('public_checks'), input_sha256=r['source_input_sha256'],
                final_binary_sha256=r['final_binary_sha256'], work_ticks=r['final']['work_ticks_by_kind'],
                query_counts=p.get('query_counts', {}),
                public_work=dict(starts=len(p.get('actual_use_starts', {})), completions=len(p.get('actual_use_completions', {})),
                                 actual_use_ticks=p.get('actual_use_ticks'), queue_actor_ticks=p.get('queue_actor_ticks'),
                                 released_then_reused=p.get('actual_exit_then_reuse_count')),
                original_tail_step=r['samples'][27] if len(r['samples'])>27 else None)

comparisons = []
for window in ['public360', 'gp80', 'operations40']:
    before, after = measured('before-plain-'+window), measured('after-plain-'+window)
    assert before['input_sha256'] == after['input_sha256']
    assert before['qualified'] and after['qualified']
    if window=='public360':
        assert all(before['public_checks'].values()) and all(after['public_checks'].values())
        assert before['public_work']==after['public_work']
    assert before['work_ticks']==after['work_ticks']
    comparisons.append(dict(window=window, before=before, after=after,
        reductions={k: 1-after['metrics'][k]/before['metrics'][k] for k in ['mean_us','p50_us','p95_us','max_us']},
        same_final_binary=before['final_binary_sha256']==after['final_binary_sha256']))
dump('quick-summary.json', dict(baseline=BASE, formal_pass=False, formal_acceptance_paused=True, windows=comparisons))

profiles = []
for path in sorted(ROOT.glob('*-all-*.json')):
    r = read(path)
    p = r['profile']
    assert not p['errors']
    compact = []
    for n, step in enumerate(p['step_records']):
        if not step['calls']: continue
        compact.append(dict(index=n, tick=step['tick'], outer_us=step['outer_elapsed_us'],
            observer_handler_us=step['observer_handler_us'], residual_us=step['residual_us'], stages=step['stages'],
            hottest_functions=sorted([dict(name=k, **v) for k,v in step['calls'].items()], key=lambda row:row['exclusive_us'], reverse=True)[:18],
            target_functions={k:v for k,v in step['calls'].items() if k in [
                'space._ensure_actor_index','floor_graph._build','floor_graph._repair','clearance._build_static',
                'public_areas._decision_signature','public_areas._environment_samples','public_areas._ordered_entry_cells']}))
    reference = 'after-plain-' if path.stem.startswith('after-') else 'before-plain-'
    window = path.stem.split('-all-')[1]
    matching = ROOT/(reference+window+'.json')
    plain_hash = read(matching)['final_binary_sha256'] if matching.exists() else None
    # GP40 is the prefix of GP80. Its shared final hash is also the separately
    # retained prior plain40 witness; do not compare it to an 80-step world.
    if plain_hash is not None: assert plain_hash == r['final_binary_sha256']
    profiles.append(dict(run=path.stem, final_binary_sha256=r['final_binary_sha256'], errors=p['errors'],
        same_window_plain_hash=plain_hash, semantics=p['semantics'], sources=p['sources'],
        totals=dict(profiled_whole_us=p['profiled_whole_us'], observer_handler_us=p['observer_handler_us'], residual_us=p['residual_us']), steps=compact))
fine = read(ROOT/'before-signature-public160.json')
dump('stage-function-summary.json', dict(profiles=profiles,
    signature_prefix_diagnostic=dict(steps=160, input_sha256=fine['source_input_sha256'], qualified=fine['qualified'],
        counters={k:v for k,v in fine['public']['query_counts'].items() if k.startswith('signature_')},
        complete_public_service_window=False),
    caution='Diagnostic inclusive times overlap; exclusive subtracts wrapped children. The after signature has one additional timed environment child, so compare signature inclusive, or combine its exclusive with that child. Observer handlers are separate, wrapper perturbation remains. Only uninstrumented paired whole-step measurements define headline improvements.'))

traces = []
for prefix in ['before', 'after']:
    name = prefix+'-trace-public360'
    r = read(ROOT/(name+'.json'))
    p = r['movement_trace']
    assert not p['errors']
    assert p['dispatch_count_check'] and p['stack_depth']==0
    assert r['final_binary_sha256'] == read(ROOT/(prefix+'-plain-public360.json'))['final_binary_sha256']
    traces.append(dict(run=name, final_binary_sha256=r['final_binary_sha256'], counts=p['counts'],
        query_counts=r['public']['query_counts'], errors=p['errors'], dispatch_count_check=p['dispatch_count_check'],
        top_actors=sorted(p['actors'], key=lambda a:a['counts'].get('queue.local_fallback',0), reverse=True)[:8],
        goal_gate_samples=p.get('goal_gate_samples', [])))
dump('movement-summary.json', dict(traces=traces,
    caution='A repeated dispatch key is diagnostic, not proof of unchanged occupancy. Goal-gate observations use current bodies and are retained per actor. The production gate only runs following an actual collision.'))

batches = ['3155cd5aa21342a39d502d876b8c1d9a', '895a7e6bb45a4bd681888e8aad598085']
batch_rows = []
for batch in batches:
    directory = REPO/'.cache/acceptance'/batch
    r = read(directory/'acceptance-results.json')
    batch_rows.append(dict(id=batch, requested_cases=r['requested_cases'], checks=r['checks'], assertions_failed=r['failed'],
        completed=r['completed'], script_errors='SCRIPT ERROR:' in (directory/'execution.log').read_text(encoding='utf-8-sig'),
        timing=read(directory/'timing-summary.json')))
assert batch_rows[0]['assertions_failed']==1 and batch_rows[1]['assertions_failed']==0
assert all(not row['script_errors'] and row['completed'] for row in batch_rows)
dump('functional-summary.json', dict(unique_final_selected_cases=read(REPO/'.cache/acceptance'/batches[0]/'acceptance-results.json')['requested_cases'],
    final_selected_passed=15, batches=batch_rows,
    failure='SPACE56 counted every body-index query as a forbidden partner re-query. The new legitimate destination-core occupancy query is now separately counted by the probe; original actual-contact identity and no duplicate partner lookup assertions remain. Only this affected case was rerun.'))

before_id = read(ROOT/'before-project/source-identity.json')
after_id = read(ROOT/'after-project/source-identity.json')
rows = [row for row in before_id['source'] if row['path'].startswith(('game/','content/','tools/performance/'))]
request = ''.join(BASE+':'+row['path']+'\n' for row in rows).encode()
raw_git = subprocess.run(['git','cat-file','--batch'], input=request, cwd=REPO, stdout=subprocess.PIPE, check=True).stdout
cursor = 0
baseline_checks = []
for row in rows:
    end = raw_git.index(b'\n', cursor)
    header = raw_git[cursor:end].split()
    assert header[-1] != b'missing', row['path']
    size = int(header[-1]); cursor = end+1
    blob = raw_git[cursor:cursor+size]; cursor += size+1
    baseline_checks.append(dict(path=row['path'], sha256=row['sha256'], match=hashlib.sha256(blob).hexdigest()==row['sha256']))
assert all(row['match'] for row in baseline_checks)
source_checks = [dict(path=row['path'], sha256=row['sha256'], match=sha(REPO/row['path'])==row['sha256'])
                 for row in after_id['source'] if row['path'].startswith(('game/','content/','tools/performance/'))]
assert source_checks and all(row['match'] for row in source_checks)
test_id = read(REPO/'.cache/acceptance'/batches[-1]/'source-identity.json')
test_checks = [dict(path=row['path'], sha256=row['sha256'], match=sha(REPO/row['path'])==row['sha256'])
               for row in test_id.get('source',test_id.get('files',[])) if row['path'].startswith('tests/acceptance/')]
assert test_checks and all(row['match'] for row in test_checks)
first_test_id = read(REPO/'.cache/acceptance'/batches[0]/'source-identity.json')
first_test_rows = first_test_id.get('source',first_test_id.get('files',[]))
first_batch_changes = [row['path'] for row in first_test_rows
    if row['path'].startswith(('game/','content/','tests/acceptance/')) and sha(REPO/row['path'])!=row['sha256']]
assert first_batch_changes==['tests/acceptance/movement_result.gd'], first_batch_changes
binary_matches = {k:before_id[k]==after_id[k] for k in ['engine_sha256','native_sha256','gmp_sha256','mpfr_sha256','runtime_sha256']}
assert all(binary_matches.values())
transforms = []
for prefix in ['before','after']:
    directory = ROOT/(prefix+'-all-project')
    identity = read(directory/'all-instance-profile-identity.json')
    for row in identity['files']:
        assert sha(directory/row['path']) == row['generated_sha256']
        assert sha(directory/'.cache/tail-profile-originals'/row['path']) == row['original_sha256']
        assert sha(ROOT/(prefix+'-project')/row['path']) == row['original_sha256']
    transforms.append(dict(project=directory.name, files=identity['transformed_file_count'], methods=identity['actual_method_count'], originals_match_plain=True))
dump('source-check.json',dict(baseline=BASE, baseline_source_rows=len(baseline_checks), baseline_checks=baseline_checks,
    final_source_rows=len(source_checks), source=source_checks, acceptance_source_rows=len(test_checks), acceptance=test_checks,
    binary_matches=binary_matches, transforms=transforms,
    first_batch_only_later_source_change=first_batch_changes,
    engine_sha256=after_id['engine_sha256'], native_sha256=after_id['native_sha256'], gmp_sha256=after_id['gmp_sha256'], mpfr_sha256=after_id['mpfr_sha256'], runtime_sha256=after_id['runtime_sha256']))

raw = {}
def add(path):
    path = pathlib.Path(path)
    if path.is_file(): raw[path.relative_to(REPO).as_posix()] = path
for path in ROOT.iterdir():
    if path.is_file(): add(path)
    elif path.name.endswith('.sources'):
        for child in path.rglob('*.gd'): add(child)
    elif path.name.endswith('-project'):
        for relative in ['source-identity.json','all-instance-profile-identity.json','import.log','project.godot',
            'game/life/public_areas.gd','game/life/waiting_life.gd','game/building/hospital_space.gd',
            'game/building/hospital_movement.gd','game/building/floor_navigation.gd',
            'tools/performance/representative.gd','tools/performance/representative_selected.gd','tools/performance/step_profile.gd','tools/performance/movement_trace.gd']:
            add(path/relative)
        for original in (path/'.cache/tail-profile-originals').rglob('*.gd'): add(original)
for name in ['public-v6.input.bin','gp.input.bin','op.input.bin']:
    add(REPO/'.cache/task-navigation-20261019'/name)
for batch in batches:
    directory = REPO/'.cache/acceptance'/batch
    for name in ['acceptance-results.json','execution.log','execution-status.json','import.log','timing-summary.json','source-identity.json']:
        add(directory/name)
    for name in ['movement_goal_wait.gd','movement_result.gd','public_phase_use.gd','navigation_cold_graph.gd','navigation_static_reuse.gd','movement_review.gd']:
        add(directory/'tests/acceptance'/name)
for path in sorted(OUT.glob('*.json')):
    if path.name != 'raw-manifest.json': add(path)
archive = OUT/'raw-evidence.zip'
manifest = []
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as target:
    for name,path in sorted(raw.items()):
        target.write(path,name)
        manifest.append(dict(path=name, bytes=path.stat().st_size, sha256=sha(path)))
with zipfile.ZipFile(archive) as target:
    for row in manifest: assert hashlib.sha256(target.read(row['path'])).hexdigest()==row['sha256']
dump('raw-manifest.json',dict(archive_sha256=sha(archive), archive_bytes=archive.stat().st_size, entries=manifest, verified_entries=len(manifest)))
print(json.dumps(dict(windows=[dict(window=row['window'],before=row['before']['metrics'],after=row['after']['metrics'],reductions=row['reductions']) for row in comparisons], raw_entries=len(manifest), raw_bytes=archive.stat().st_size, baseline_rows=len(baseline_checks), source_rows=len(source_checks), test_rows=len(test_checks)),ensure_ascii=False))
