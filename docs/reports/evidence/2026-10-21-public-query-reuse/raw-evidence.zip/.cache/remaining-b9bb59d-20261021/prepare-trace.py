import hashlib, json, pathlib, shutil, uuid
root=pathlib.Path(__file__).resolve().parent
repo=root.parents[1]
source=root/'before-project'
target=root/'before-trace-project'
shutil.copytree(source,target)
relative='tools/performance/movement_trace.gd'
path=target/relative
old_sha=hashlib.sha256(path.read_bytes()).hexdigest()
shutil.copyfile(repo/relative,path)
identity=json.loads((target/'source-identity.json').read_text(encoding='utf-8-sig'))
profile='OddlyGoodHospital Trace '+uuid.uuid4().hex
project=target/'project.godot'
project.write_text(project.read_text(encoding='utf-8-sig').replace(identity['profile'],profile),encoding='utf-8',newline='\n')
identity['project']=str(target)
identity['profile']=profile
for entry in identity['source']:
    if entry['path']==relative: entry['sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
identity['diagnostic_overlay']={'file':relative,'previous_sha256':old_sha,'reason':'Observe actual local goal body contacts with unchanged b9bb59d game source.'}
(target/'source-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
print(str(target))
