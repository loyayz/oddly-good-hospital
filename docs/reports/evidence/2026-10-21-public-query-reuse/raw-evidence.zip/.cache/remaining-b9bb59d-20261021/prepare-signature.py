import hashlib, json, pathlib, shutil, uuid
root=pathlib.Path(__file__).resolve().parent
source=root/'before-project'
target=root/'before-signature-project'
shutil.copytree(source,target)
path=target/'game/life/public_areas.gd'
text=path.read_text(encoding='utf-8')
start=text.index('func _decision_signature(')
end=text.index('\nfunc _add_dynamic_dependencies(',start)
original=text[start:end]
changed=original.replace('\n\tvar view: Dictionary = _decision_view(world)', '\n\tvar _signature_started: int = Time.get_ticks_usec()\n\tvar view: Dictionary = _decision_view(world)',1)
changed=changed.replace('\n\tif not points.is_empty():', '\n\tvar _samples_started: int = Time.get_ticks_usec()\n\tif not points.is_empty():',1)
tail='\treturn JSON.stringify(records,"",true,true)'
assert changed.count(tail)==1
replacement='''\tvar _json_started: int = Time.get_ticks_usec()
\tvar _result: String = JSON.stringify(records,"",true,true)
\tvar _finished: int = Time.get_ticks_usec()
\tspace.query_counts["signature_samples_us"] = int(space.query_counts.get("signature_samples_us",0))+_json_started-_samples_started
\tspace.query_counts["signature_json_us"] = int(space.query_counts.get("signature_json_us",0))+_finished-_json_started
\tspace.query_counts["signature_other_us"] = int(space.query_counts.get("signature_other_us",0))+_samples_started-_signature_started
\tspace.query_counts["signature_calls"] = int(space.query_counts.get("signature_calls",0))+1
\treturn _result'''
changed=changed.replace(tail,replacement,1)
path.write_text(text[:start]+changed+text[end:],encoding='utf-8',newline='\n')
identity=json.loads((target/'source-identity.json').read_text(encoding='utf-8-sig'))
profile='OddlyGoodHospital Signature '+uuid.uuid4().hex
project=target/'project.godot'
project.write_text(project.read_text(encoding='utf-8-sig').replace(identity['profile'],profile),encoding='utf-8',newline='\n')
identity['project']=str(target)
identity['profile']=profile
identity['diagnostic_overlay']={'file':'game/life/public_areas.gd','original_sha256':hashlib.sha256(text.encode()).hexdigest(),'observed_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'operation':'Time-only split of dependency collection, environment sample loop and JSON encoding; only derived query counters change.'}
(target/'source-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
print(str(target))
