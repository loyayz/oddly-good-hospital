"""Only one plain/observer 8-step pair; no microbenchmark or full-window entry."""
from pathlib import Path
import sys,shutil,json,zipfile,hashlib,traceback,ast
BASE=Path(__file__).resolve().parent;OLD=BASE.parent/'root-stage-recovery-20261112';NARROW=BASE.parent/'movement-stage-recovery-20261112'
sys.path.insert(0,str(NARROW));import full_narrow_v1 as support
c=support.c;g=support.g
REL='game/building/hospital_space.gd';DRIVER='tools/performance/current/plain_v4.gd';TIMER='tools/performance/current/door_observer.gd';MARK='# door-observer-v1'
def prepare(src):
 p=BASE/'observer-project';shutil.copytree(src,p,ignore=shutil.ignore_patterns('.cache'))
 original=(p/REL).read_text();source=original
 headers=['func clearance(actor: Dictionary) -> int:', 'func movement_doors(world: WorldState, actor: Dictionary, swept: Rect2, members: Array = [], floor_id: int = 0, geometry: FloorStaticGeometry = null) -> Array[Dictionary]:']
 for h in headers:assert source.count(h)==1;source=source.replace(h,h.replace('func ','func _door_original_',1),1)
 undo=source
 for h in headers:undo=undo.replace(h.replace('func ','func _door_original_',1),h,1)
 assert undo==original
 source=source.replace('extends RefCounted\n','extends RefCounted\nconst _DoorObserver=preload("res://'+TIMER+'")\n',1)
 source+='\n'+headers[0]+'\n\tvar value: int=_door_original_clearance(actor)\n\t_DoorObserver.clearance_result(actor,value)\n\treturn value\n\n'+headers[1]+'\n\t_DoorObserver.enter(self,world,actor,swept,members,floor_id,geometry)\n\tvar value: Array[Dictionary]=_door_original_movement_doors(world,actor,swept,members,floor_id,geometry)\n\t_DoorObserver.leave(self,value)\n\treturn value\n'
 (BASE/'hospital_space.gd.original').write_bytes(original.encode());(BASE/'hospital_space.gd.observer').write_bytes(source.encode());(p/REL).write_bytes(source.encode())
 original=(p/DRIVER).read_text();source=original.replace('extends SceneTree\n','extends SceneTree\nconst _DoorObserver=preload("res://'+TIMER+'") '+MARK+'\n',1)
 a='\t\tvar started: int = Time.get_ticks_usec()\n';assert source.count(a)==1;source=source.replace(a,'\t\t_DoorObserver.begin_step(index) '+MARK+'\n'+a)
 a='\t\tvar elapsed: int = Time.get_ticks_usec()-started\n';assert source.count(a)==1;source=source.replace(a,a+'\t\t_DoorObserver.end_step(world.sim_tick) '+MARK+'\n')
 a='\tvar window_end: int = Time.get_ticks_usec()\n';assert source.count(a)==1;source=source.replace(a,a+'\twrite_json(output+".door-counts.json",_DoorObserver.report()) '+MARK+'\n\tvar corpus_file: FileAccess=FileAccess.open(output+".door-corpus.bin",FileAccess.WRITE) '+MARK+'\n\tcorpus_file.store_var(_DoorObserver.corpus);corpus_file.close() '+MARK+'\n')
 assert ''.join(x for x in source.splitlines(True) if MARK not in x)==original
 (BASE/'plain_v4.gd.original').write_bytes(original.encode());(BASE/'plain_v4.gd.observer').write_bytes(source.encode());(p/DRIVER).write_bytes(source.encode());shutil.copy2(BASE/'door_observer.gd',p/TIMER)
 return p

def package():
 files=[p for p in BASE.rglob('*') if p.is_file() and p.relative_to(BASE).parts[0] not in ['plain-project','observer-project'] and p.name not in ['bounded.zip','members.json','checkpoint.json']]
 members={str(p.relative_to(BASE)):{'bytes':p.stat().st_size,'sha256':c.sha(p)} for p in files};c.write(BASE/'members.json',members)
 with zipfile.ZipFile(BASE/'bounded.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
  for p in files:z.write(p,str(p.relative_to(BASE)))
  z.write(BASE/'members.json','MEMBERS.json')
 with zipfile.ZipFile(BASE/'bounded.zip') as z:
  assert z.testzip() is None
  for n,v in members.items():assert hashlib.sha256(z.read(n)).hexdigest()==v['sha256']
 c.write(BASE/'checkpoint.json',{'sha256':c.sha(BASE/'bounded.zip'),'bytes':(BASE/'bounded.zip').stat().st_size,'members':len(members),'local_readback_verified':True})
def main():
 cfg=c.read(OLD/'config.json');c.verify(cfg);c.idle();plain=BASE/'plain-project';shutil.copytree(Path(cfg['project']),plain,ignore=shutil.ignore_patterns('.cache'));observed=prepare(Path(cfg['project']))
 with zipfile.ZipFile(OLD/'full-plain.zip') as z:
  data=z.read('run/result.json.final.bin');assert hashlib.sha256(data).hexdigest()=='41928476a199dbf3e35b3ff74cd54a52fd0801feb92c5b1d1a5d6fe035258a68';(BASE/'input.final.bin').write_bytes(data)
 inv={name:c.inventory(p) for name,p in [('plain',plain),('observer',observed)]};c.write(BASE/'identity.json',{'config':cfg,'inventories':inv,'input_sha256':c.sha(BASE/'input.final.bin'),'source_undo_exact':True,'steps':8,'plain_durable_receipt':c.read(OLD/'full-plain.durable-receipt.json')})
 for p in [OLD/'linux_guard_v2.py',OLD/'controller_v2.py',NARROW/'qualify_v1.py',NARROW/'full_narrow_v1.py',NARROW/'prepare_v1.py']:shutil.copy2(p,BASE/('dependency-'+p.name))
 g.LIBRARY_PATH=cfg['library_path']
 try:
  for name,p in [('plain',plain),('observer',observed)]:
   c.idle();c.verify(cfg);g.PROJECT=p;c.write(BASE/(name+'.host-before.json'),support.host());folder=BASE/name
   cmd=[cfg['engine'],'--headless','--path',str(p),'--script','res://'+DRIVER,'--','--input='+str(BASE/'input.final.bin'),'--output='+str(folder/'result.json'),'--steps=8','--prefix-steps=0','--worker-tasks=4','--main-thread-policy=app','--observed-floor=1']
   try:g.run(cmd,folder,timeout=180,allowed_exits=(0,1))
   finally:c.write(BASE/(name+'.host-after.json'),support.host())
   assert c.inventory(p)==inv[name];r=c.read(folder/'result.json');assert r['all_completed_steps']==8 and r['complete'];assert c.sha(folder/'result.json.final.bin')==r['final_sha256']
  # Restored final envelope has no scenario tag, so compare all available business fields without inventing coverage.
  a=c.read(BASE/'plain/result.json');b=c.read(BASE/'observer/result.json');assert (BASE/'plain/result.json.final.bin').read_bytes()==(BASE/'observer/result.json.final.bin').read_bytes()
  for key in ['prefix_business','sample_business','business','errors','complete']:assert a[key]==b[key]
  counts=c.read(BASE/'observer/result.json.door-counts.json');assert not counts['errors'] and len(counts['records'])==8 and counts['corpus_count']<=8
  c.write(BASE/'comparison.json',{'full_world_rng_ordered_events_equal':True,'business_and_failure_equal':True,'final_sha256':a['final_sha256'],'steps':8,'scenario_observer':'No scenario tag in archived final envelope; not original full workload coverage acceptance.','corpus_count':counts['corpus_count']})
 except BaseException:c.write(BASE/'error.json',{'traceback':traceback.format_exc()});raise
 finally:
  for rel in [REL,DRIVER]:(observed/rel).write_bytes((plain/rel).read_bytes())
  c.verify(cfg);c.write(BASE/'restoration.json',{'modified_source_and_driver_restored':True,'production_and_prior_project_unchanged':True});package()
if __name__=='__main__':main()
