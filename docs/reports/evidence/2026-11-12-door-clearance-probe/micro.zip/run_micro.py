from pathlib import Path
import sys,json,zipfile,hashlib,shutil,traceback
BASE=Path(__file__).resolve().parent;ROOT=BASE.parent/'root-stage-recovery-20261112';V2=BASE.parent/'door-clearance-recovery-v2-20261112';NARROW=BASE.parent/'movement-stage-recovery-20261112'
sys.path.insert(0,str(NARROW));import full_narrow_v1 as h
c=h.c;g=h.g
cfg=c.read(ROOT/'config.json');c.verify(cfg);c.idle();receipt=c.read(V2/'observer8.durable-receipt.json');assert receipt['readback_verified'] and receipt['archive_sha256']==c.sha(V2/'observer8.zip')
with zipfile.ZipFile(V2/'observer8.zip') as z:
 m=json.loads(z.read('MEMBERS.json'));n='observer/result.json.door-corpus.bin';b=z.read(n);assert hashlib.sha256(b).hexdigest()==m[n]['sha256'];(BASE/'corpus.bin').write_bytes(b)
project=BASE/'project';inventory=c.inventory(project);c.write(BASE/'identity.json',{'runtime_config':cfg,'inventory':inventory,'corpus_sha256':c.sha(BASE/'corpus.bin'),'corpus_durable_receipt':receipt,'fixed_plan':{'corpus':8,'pairs_each':6,'order':['AB','BA','AB','BA','AB','BA'],'warm_iterations_per_arm':2000,'cold_calls_per_arm':1}})
for rel in ['tools/performance/current/door_micro.gd','tools/performance/current/door_candidate.gd']:shutil.copy2(project/rel,BASE/Path(rel).name)
for p in [ROOT/'linux_guard_v2.py',ROOT/'controller_v2.py',NARROW/'full_narrow_v1.py',NARROW/'qualify_v1.py',NARROW/'prepare_v1.py']:shutil.copy2(p,BASE/('dependency-'+p.name))
g.PROJECT=project;g.LIBRARY_PATH=cfg['library_path']
try:
 c.write(BASE/'host-before.json',h.host())
 try:g.run([cfg['engine'],'--headless','--path',str(project),'--script','res://tools/performance/current/door_micro.gd','--','--input='+str(BASE/'corpus.bin'),'--output='+str(BASE/'run/result.json')],BASE/'run',timeout=360,allowed_exits=(0,1))
 finally:c.write(BASE/'host-after.json',h.host())
 assert c.inventory(project)==inventory;c.verify(cfg)
except BaseException:c.write(BASE/'error.json',{'traceback':traceback.format_exc()});raise
finally:
 files=[p for p in BASE.rglob('*') if p.is_file() and p.relative_to(BASE).parts[0]!='project' and p.name not in ['micro.zip','members.json','checkpoint.json']]
 m={str(p.relative_to(BASE)):{'bytes':p.stat().st_size,'sha256':c.sha(p)} for p in files};c.write(BASE/'members.json',m)
 with zipfile.ZipFile(BASE/'micro.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
  for p in files:z.write(p,str(p.relative_to(BASE)))
  z.write(BASE/'members.json','MEMBERS.json')
 with zipfile.ZipFile(BASE/'micro.zip') as z:
  assert z.testzip() is None
  for n,v in m.items():assert hashlib.sha256(z.read(n)).hexdigest()==v['sha256']
 c.write(BASE/'checkpoint.json',{'sha256':c.sha(BASE/'micro.zip'),'bytes':(BASE/'micro.zip').stat().st_size,'members':len(m),'local_readback_verified':True})
