extends SceneTree
const Candidate=preload("res://tools/performance/current/door_candidate.gd")
var output: String
var records: Array=[]
var errors: Array=[]
func cache(space: HospitalSpace) -> Dictionary:
	var nav: NavigationCache=space._navigation
	var sources: Dictionary={}
	for key: String in nav._sources:
		var value: Dictionary=nav._sources[key].duplicate(true);value.erase("world");sources[key]=value
	var geometry: Dictionary={}
	for key: String in nav._floor_geometries:
		var entry: Dictionary=nav._floor_geometries[key]
		geometry[key]={"charge":entry.charge,"used":entry.used,"door_order":entry.geometry.door_order,"doors":entry.geometry.doors}
	var reservations: Dictionary={}
	for key: int in space._reservation_views:
		var entry: Dictionary=space._reservation_views[key]
		var view: Dictionary=entry.view.duplicate(true);view.erase("index")
		reservations[str(key)]={"source":entry.source,"revision":entry.revision,"view":view}
	return {"bodies":space._bodies.duplicate(true),"query_counts":space.query_counts.duplicate(true),"sources":sources,"geometry":geometry,"reservations":reservations,"nav_counters":[nav._used,nav._charged,nav._query_charged,nav._source_charged,nav._floor_charged,nav._defer_trim],"entry_keys":nav._entries.keys(),"source_key":[nav._source_key_world_id,nav._source_key_floor_id,nav._source_key]}
func run_arm(space: HospitalSpace, world: WorldState, item: Dictionary, expected: Array) -> Dictionary:
	var actor: Dictionary=world.facts.actors[item.actor.id]
	assert(item.actor_is_world_instance and actor==item.actor)
	assert(item.members.size()==1 and is_same(world.facts.actors[item.members[0]],actor))
	var t: int=Time.get_ticks_usec()
	var result: Array[Dictionary]=space.movement_doors(world,actor,item.swept,item.members,int(item.floor_id))
	var cold_us: int=Time.get_ticks_usec()-t
	var cold_equal: bool=result==expected
	var cold_cache: Dictionary=cache(space)
	var all_equal: bool=true
	t=Time.get_ticks_usec()
	for i: int in 2000:
		result=space.movement_doors(world,actor,item.swept,item.members,int(item.floor_id))
		if result!=expected:all_equal=false
	var warm_us: int=Time.get_ticks_usec()-t
	return {"cold_us":cold_us,"warm_batch_us":warm_us,"iterations":2000,"all_returns_equal":cold_equal and all_equal,"cold_cache":cold_cache,"warm_cache":cache(space)}
func _initialize() -> void:call_deferred("run")
func run() -> void:
	var input: String=""
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--input="):input=arg.trim_prefix("--input=")
		if arg.begins_with("--output="):output=arg.trim_prefix("--output=")
	var f: FileAccess=FileAccess.open(input,FileAccess.READ);var corpus: Array=f.get_var(false);f.close()
	var content: HospitalContent=HospitalContent.new()
	var stream: FileAccess=FileAccess.open(output+".pairs.ndjson",FileAccess.WRITE)
	assert(corpus.size()==8)
	for ci: int in corpus.size():
		var item: Dictionary=corpus[ci]
		var world: WorldState=WorldState.new(item.facts)
		var before: Dictionary=world.freeze()
		for pair: int in 6:
			var a: HospitalSpace=HospitalSpace.new(content)
			var b: HospitalSpace=Candidate.new(content)
			var a_before: Dictionary=cache(a);var b_before: Dictionary=cache(b)
			var aa: Dictionary
			var bb: Dictionary
			if pair%2==0:
				aa=run_arm(a,world,item,item.returned_doors);bb=run_arm(b,world,item,item.returned_doors)
			else:
				bb=run_arm(b,world,item,item.returned_doors);aa=run_arm(a,world,item,item.returned_doors)
			var checks: Dictionary={"initial_cache_equal":a_before==b_before,"cold_cache_equal":aa.cold_cache==bb.cold_cache,"warm_cache_equal":aa.warm_cache==bb.warm_cache,"world_unchanged":world.freeze()==before,"returns_equal":aa.all_returns_equal and bb.all_returns_equal}
			for key: String in checks:
				if not checks[key]:errors.append(str(ci)+":"+str(pair)+":"+key)
			var row: Dictionary={"corpus_index":ci,"source_tick":item.tick,"pair":pair,"order":"AB" if pair%2==0 else "BA","checks":checks,"a":aa,"b":bb}
			records.append(row);stream.store_line(JSON.stringify(row));stream.flush()
			a=null;b=null
	stream.close()
	f=FileAccess.open(output,FileAccess.WRITE);f.store_string(JSON.stringify({"complete":errors.is_empty() and records.size()==48,"errors":errors,"pairs":records.size(),"iterations_per_arm":2000,"order":"AB/BA/AB/BA/AB/BA per each of eight actual corpus items","scope":"Entire movement_doors API; warm batch includes same return-array equality check per call. Fresh cache cold calls are not original live cache. Empty-door single same-instance corpus only; not full-step gain.","cache_scope":"body cache, query counters, full navigation source records excluding weak world handle, retained floor geometry charge/use and door data, navigation counters/keys, reservation source/revision and full view except runtime index object; World exact. No claim of bytewise runtime-object equality."},"\t"));f.close();quit(0 if errors.is_empty() else 1)
