"""One observer8 retry only, compares sealed plain8. No plain or microbenchmark run."""
from pathlib import Path
import sys,shutil,json,zipfile,hashlib,traceback
BASE=Path(__file__).resolve().parent;OLD=BASE.parent/'door-clearance-recovery-20261112';ROOT=BASE.parent/'root-stage-recovery-20261112';NARROW=BASE.parent/'movement-stage-recovery-20261112'
sys.path.insert(0,str(NARROW));import full_narrow_v1 as helper
c=helper.c;g=helper.g
REL='game/building/hospital_space.gd';DRIVER='tools/performance/current/plain_v4.gd';TIMER='tools/performance/current/door_observer_v2.gd'
def package():
 paths=[p for p in BASE.rglob('*') if p.is_file() and p.relative_to(BASE).parts[0]!='project' and p.name not in ['observer8.zip','members.json','checkpoint.json']]
 m={str(p.relative_to(BASE)):{'bytes':p.stat().st_size,'sha256':c.sha(p)} for p in paths};c.write(BASE/'members.json',m)
 with zipfile.ZipFile(BASE/'observer8.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
  for p in paths:z.write(p,str(p.relative_to(BASE)))
  z.write(BASE/'members.json','MEMBERS.json')
 with zipfile.ZipFile(BASE/'observer8.zip') as z:
  assert z.testzip() is None
  for n,v in m.items():assert hashlib.sha256(z.read(n)).hexdigest()==v['sha256']
 c.write(BASE/'checkpoint.json',{'sha256':c.sha(BASE/'observer8.zip'),'bytes':(BASE/'observer8.zip').stat().st_size,'members':len(m),'local_readback_verified':True})
def main():
 cfg=c.read(ROOT/'config.json');c.verify(cfg);c.idle();receipt=c.read(OLD/'bounded.durable-receipt.json');assert receipt['readback_verified'] and receipt['archive_sha256']==c.sha(OLD/'bounded.zip')
 for n,h in {'door_observer_v2.gd':'16c2584577374c7566aef688d54a1a1300056334986d81fbc376889d4778f7ed','hospital_space.gd.observer':'90e4022c6d8e2821c9a9ad9e3bad2a8b1fb52fbe998554593c9a2ab858721174','plain_v4.gd.observer':'2ac4274c3dcbd24066aa8f49b4b7ed84c468b0aa88c06a1bbefa1082d3692aae'}.items():assert c.sha(BASE/n)==h
 baseline=BASE/'baseline';baseline.mkdir()
 with zipfile.ZipFile(OLD/'bounded.zip') as z:
  assert z.testzip() is None;m=json.loads(z.read('MEMBERS.json'))
  for n,dest in [('input.final.bin',BASE/'input.final.bin'),('plain/result.json',baseline/'result.json'),('plain/result.json.final.bin',baseline/'result.json.final.bin')]:
   b=z.read(n);assert hashlib.sha256(b).hexdigest()==m[n]['sha256'];dest.write_bytes(b)
 assert c.sha(BASE/'input.final.bin')=='41928476a199dbf3e35b3ff74cd54a52fd0801feb92c5b1d1a5d6fe035258a68'
 assert c.sha(baseline/'result.json.final.bin')=='6ecee78b194a7925938549383dc9fb87f222a3843d901d790fe83ac7aeaeb93d'
 p=BASE/'project';shutil.copytree(Path(cfg['project']),p,ignore=shutil.ignore_patterns('.cache'));pristine=c.inventory(p)
 for rel in [REL,DRIVER]:(p/rel).write_bytes((BASE/(Path(rel).name+'.observer')).read_bytes())
 shutil.copy2(BASE/'door_observer_v2.gd',p/TIMER);overlay=c.inventory(p)
 c.write(BASE/'identity.json',{'config':cfg,'pristine':pristine,'observer_overlay':overlay,'input_sha256':c.sha(BASE/'input.final.bin'),'v1_durable_receipt':receipt,'runner_sha256':c.sha(__file__)})
 for source in [ROOT/'controller_v2.py',ROOT/'linux_guard_v2.py',NARROW/'full_narrow_v1.py',NARROW/'qualify_v1.py',NARROW/'prepare_v1.py']:shutil.copy2(source,BASE/('dependency-'+source.name))
 try:
  c.verify(cfg);c.idle();g.PROJECT=p;g.LIBRARY_PATH=cfg['library_path'];c.write(BASE/'host-before.json',helper.host())
  cmd=[cfg['engine'],'--headless','--path',str(p),'--script','res://'+DRIVER,'--','--input='+str(BASE/'input.final.bin'),'--output='+str(BASE/'observer/result.json'),'--steps=8','--prefix-steps=0','--worker-tasks=4','--main-thread-policy=app','--observed-floor=1']
  try:g.run(cmd,BASE/'observer',timeout=180,allowed_exits=(0,1))
  finally:c.write(BASE/'host-after.json',helper.host())
  assert c.inventory(p)==overlay;c.verify(cfg)
  a=c.read(baseline/'result.json');b=c.read(BASE/'observer/result.json');assert b['complete'] and b['all_completed_steps']==8
  assert (baseline/'result.json.final.bin').read_bytes()==(BASE/'observer/result.json.final.bin').read_bytes()
  for k in ['prefix_business','sample_business','business','errors','complete']:assert a[k]==b[k]
  d=c.read(BASE/'observer/result.json.door-counts.json');assert not d['errors'] and len(d['records'])==8 and d['corpus_count']<=8
  rows=[json.loads(x)['sample'] for x in (BASE/'observer/result.json.steps.ndjson').read_text().splitlines() if json.loads(x)['kind']=='complete']
  assert [(r['index'],r['tick']) for r in d['records']]==[(r['index'],r['tick']) for r in rows]
  c.write(BASE/'comparison.json',{'complete_world_rng_ordered_events_equal':True,'business_equal':True,'steps':8,'final_sha256':b['final_sha256'],'record_count':len(d['records']),'corpus_count':d['corpus_count'],'limits':'Return values and arguments captured in binary corpus; candidate equivalence/microbenchmark and unexercised boundary cases are not yet tested.'})
 except BaseException:c.write(BASE/'error.json',{'traceback':traceback.format_exc()});raise
 finally:
  for rel in [REL,DRIVER]:(p/rel).write_bytes((Path(cfg['project'])/rel).read_bytes())
  after=c.inventory(p);after.pop(TIMER);okay=after==pristine;c.write(BASE/'restoration.json',{'source_restored':okay,'timer_dormant':True});package();assert okay
if __name__=='__main__':main()
