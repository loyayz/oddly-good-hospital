"""Static guards plus synthetic state model, not a GDScript runtime test."""
from pathlib import Path
import unittest
BASE=Path(__file__).parent
class Gate:
 def __init__(self):self.enabled=False;self.active=False;self.owner=1;self.count=0;self.clocks=0;self.errors=[]
 def begin(self):self.enabled=True
 def enter(self,thread=1):
  if not self.enabled or thread!=self.owner:return False
  if self.active:self.errors.append('nested');return False
  self.active=True;self.count+=1;self.clocks+=1;return True
 def clearance(self,thread=1):
  if self.enabled and self.active and thread==self.owner:self.count+=1
 def leave(self):self.clocks+=1;self.active=False
 def end(self):self.enabled=False
class Tests(unittest.TestCase):
 def test_disabled_and_wrong_thread(self):
  g=Gate();self.assertFalse(g.enter());g.clearance();self.assertEqual((g.count,g.clocks),(0,0))
  g.begin();self.assertFalse(g.enter(2));g.clearance(2);self.assertEqual((g.count,g.clocks),(0,0))
  self.assertTrue(g.enter());g.clearance();g.leave();g.end();before=(g.count,g.clocks)
  self.assertFalse(g.enter());g.clearance();self.assertEqual((g.count,g.clocks),before)
 def test_nested_pairing(self):
  g=Gate();g.begin();self.assertTrue(g.enter());self.assertFalse(g.enter());self.assertTrue(g.active);self.assertEqual(g.errors,['nested']);g.leave();self.assertFalse(g.active)
 def test_source_guards(self):
  s=(BASE/'door_observer_v2.gd').read_text();enter=s.split('static func enter(',1)[1].split('static func clearance_result',1)[0]
  self.assertLess(enter.index('if not step_enabled'),enter.index('counters.calls'))
  self.assertLess(enter.index('if not step_enabled'),enter.index('Time.get_ticks_usec'))
  self.assertIn('return false',enter);self.assertIn('return true',enter)
  self.assertIn('step_enabled=false',s.split('static func end_step',1)[1])
  w=(BASE/'hospital_space.gd.observer').read_text();self.assertIn('var traced: bool=_DoorObserver.enter',w);self.assertIn('if traced:_DoorObserver.leave',w)
if __name__=='__main__':unittest.main()
