extends RefCounted
static var step_enabled: bool=false
static var door_call_active: bool=false
static var owner_thread: int=0
static var step_index: int=-1
static var owner_actor: Dictionary={}
static var counters: Dictionary={}
static var records: Array=[]
static var corpus: Array=[]
static var selected: bool=false
static var call_record: Dictionary={}
static var clearance_rows: Array=[]
static var started: int=0
static var errors: Array=[]
static func begin_step(index: int) -> void:
	step_enabled=true;owner_thread=OS.get_thread_caller_id();step_index=index;selected=false;counters={"calls":0,"member_same_instance":0,"member_same_id_other_instance":0,"clearance_calls":0,"clearance_same_owner":0,"original_method_elapsed_us":0};door_call_active=false
static func enter(space: HospitalSpace, world: WorldState, actor: Dictionary, swept: Rect2, members: Array, floor_id: int, geometry: FloorStaticGeometry) -> bool:
	if not step_enabled or OS.get_thread_caller_id()!=owner_thread:return false
	if door_call_active:
		errors.append("nested movement_doors")
		return false
	door_call_active=true;owner_actor=actor;counters.calls+=1;clearance_rows=[];call_record={}
	for id: String in members:
		if is_same(world.facts.actors[id],actor):counters.member_same_instance+=1
		elif id==actor.id:counters.member_same_id_other_instance+=1
	if not selected and geometry==null:
		selected=true
		call_record={"step_index":step_index,"tick":world.sim_tick,"facts":world.freeze(),"actor":actor.duplicate(true),"actor_is_world_instance":is_same(actor,world.facts.actors.get(actor.id,{})),"swept":swept,"members":members.duplicate(true),"floor_id":floor_id,"geometry_supplied":false,"bodies_before":space._bodies.duplicate(true),"query_counts_before":space.query_counts.duplicate(true)}
	started=Time.get_ticks_usec()
	return true
static func clearance_result(actor: Dictionary, value: int) -> void:
	if not step_enabled or not door_call_active or OS.get_thread_caller_id()!=owner_thread:return
	counters.clearance_calls+=1
	if is_same(actor,owner_actor):counters.clearance_same_owner+=1
	clearance_rows.append({"actor_id":actor.id,"same_owner_instance":is_same(actor,owner_actor),"value":value})
static func leave(space: HospitalSpace, value: Array[Dictionary]) -> void:
	if not step_enabled or not door_call_active or OS.get_thread_caller_id()!=owner_thread:
		errors.append("unpaired movement_doors leave")
		return
	var elapsed: int=Time.get_ticks_usec()-started
	counters.original_method_elapsed_us+=elapsed
	if not call_record.is_empty():
		call_record.returned_doors=value.duplicate(true);call_record.clearance_results=clearance_rows.duplicate(true);call_record.bodies_after=space._bodies.duplicate(true);call_record.query_counts_after=space.query_counts.duplicate(true);call_record.observed_elapsed_us=elapsed;corpus.append(call_record)
	door_call_active=false;owner_actor={};call_record={};clearance_rows=[]
static func end_step(tick: int) -> void:
	if door_call_active:errors.append("unclosed door observation")
	step_enabled=false
	records.append({"index":step_index,"tick":tick,"counters":counters.duplicate(true)})
static func report() -> Dictionary:
	return {"records":records,"errors":errors,"corpus_count":corpus.size(),"scope":"Counters on actual door calls; at most first geometry-null call per real step captured. Original-method timing includes clearance observer dispatch and is NOT a speedup measurement. Cold first step separated from seven following steps."}
