from pathlib import Path
import sys,json,zipfile,hashlib,shutil,traceback
BASE=Path(__file__).resolve().parent;ROOT=BASE.parent/'root-stage-recovery-20261112';N=BASE.parent/'movement-stage-recovery-20261112';CORPUS=BASE.parent/'structural-corpus-20261112'
sys.path.insert(0,str(N));import full_narrow_v1 as h
c=h.c;g=h.g
stage,run_id=sys.argv[1:];assert stage in ['precheck','measure'];run=BASE/run_id;assert not run.exists()
cfg=c.read(ROOT/'config.json');c.verify(cfg);c.idle();receipt=c.read(CORPUS/'batch.durable-receipt.json');assert receipt['readback_verified'] and receipt['archive_sha256']==c.sha(CORPUS/'batch.zip')
with zipfile.ZipFile(CORPUS/'batch.zip') as z:
 m=json.loads(z.read('MEMBERS.json'));name='observer/result.json.corpus.bin';data=z.read(name);assert hashlib.sha256(data).hexdigest()==m[name]['sha256'];(BASE/'corpus.bin').write_bytes(data)
project=BASE/'project';inventory=c.inventory(project)
if stage=='measure':
 pre=c.read(BASE/'precheck-passed.json');assert pre['complete'];assert pre['inventory']==inventory;assert c.read(BASE/pre['run_id']/'result.json')['complete']
run.mkdir();c.write(run/'identity.json',{'inventory':inventory,'runtime':cfg,'corpus_sha256':c.sha(BASE/'corpus.bin'),'durable_receipt':receipt,'plan':c.read(BASE/'plan.json')})
for p in BASE.glob('*.gd'):shutil.copy2(p,run/p.name)
for p in [ROOT/'linux_guard_v2.py',ROOT/'controller_v2.py',N/'full_narrow_v1.py',N/'qualify_v1.py',N/'prepare_v1.py']:shutil.copy2(p,BASE/('dependency-'+p.name))
g.PROJECT=project;g.LIBRARY_PATH=cfg['library_path'];c.write(run/'host-before.json',h.host())
try:
 g.run([cfg['engine'],'--headless','--path',str(project),'--script','res://tools/performance/current/micro.gd','--','--input='+str(BASE/'corpus.bin'),'--output='+str(run/'result.json'),'--stage='+stage],run,timeout=360,allowed_exits=(0,1))
 assert c.inventory(project)==inventory
 result=c.read(run/'result.json');assert result['complete'],result['errors']
 if stage=='precheck':c.write(BASE/'precheck-passed.json',{'complete':True,'run_id':run_id,'inventory':inventory})
except BaseException:c.write(run/'error.json',{'traceback':traceback.format_exc()});raise
finally:c.write(run/'host-after.json',h.host())
