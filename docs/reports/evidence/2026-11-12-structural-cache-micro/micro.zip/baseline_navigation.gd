extends HospitalNavigation
var fallback_builds: int=0
func structural_clearance(world: WorldState, actor: Dictionary, floor_id: int, members: Array = [], offsets: Dictionary = {}) -> RouteClearance:
	if actor.has("_convoy_size") or members.size()==1 and members[0]==actor.id: members = []
	var query: RouteClearance = space._navigation.cached_static_geometry(space,world,floor_id,actor) if members.is_empty() else null
	if query==null:
		fallback_builds+=1
		query = RouteClearance.new(space,world,actor,floor_id,members,offsets,false,space._navigation.floor_source(space,world,floor_id))
	return query
