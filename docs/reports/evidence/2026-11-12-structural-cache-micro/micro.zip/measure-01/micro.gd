extends SceneTree
const CandidateCache=preload("res://tools/performance/current/candidate_cache.gd")
const CandidateNavigation=preload("res://tools/performance/current/candidate_navigation.gd")
const BaselineNavigation=preload("res://tools/performance/current/baseline_navigation.gd")
var output: String
var stage: String
var errors: Array=[]
var records: Array=[]
func _initialize() -> void:call_deferred("run")
func make_space(content: HospitalContent, candidate: bool) -> HospitalSpace:
	var space: HospitalSpace=HospitalSpace.new(content)
	if candidate:
		space._navigation=CandidateCache.new();space.navigation=CandidateNavigation.new(space)
	else:space.navigation=BaselineNavigation.new(space)
	return space
func actor_for(world: WorldState, item: Dictionary) -> Dictionary:
	if item.actor_is_world_instance:
		assert(world.facts.actors[item.actor.id]==item.actor)
		return world.facts.actors[item.actor.id]
	return item.actor.duplicate(true)
func canonical(query: RouteClearance) -> Dictionary:
	var result: Dictionary={}
	for field: String in ["_size","_height_m","_plain","_indexed_static","source","_doors","_dependencies","_reservations","_plots","_blocked","_facilities","_connectors","_walls","_facility_cells","_connector_cells","_open_door_cells","_closed_door_cells","_horizontal_walls","_vertical_walls"]:
		var v: Variant=query.get(field);result[field]=v.duplicate(true) if v is Dictionary or v is Array else v
	result.source.erase("occupancy");result.member_count=query._members.size()
	return result
func expected(item: Dictionary) -> Dictionary:
	var result: Dictionary=item.returned.duplicate(true);result.source.erase("occupancy");return result
func accounting(space: HospitalSpace) -> Dictionary:
	var nav: NavigationCache=space._navigation
	var body_charge: int=0;var stats: Dictionary={};var builds: int=0
	if nav is CandidateCache:
		body_charge=nav._body_charged;stats=nav.body_stats.duplicate(true);builds=int(stats.builds)
	else:builds=space.navigation.fallback_builds
	var total: int=body_charge+nav._charged+nav._query_charged+nav._source_charged+nav._floor_charged
	var sum_body: int=0
	if nav is CandidateCache:
		for entry: Dictionary in nav._body_entries.values():sum_body+=int(entry.charge)
	return {"body_charge_allowance":body_charge,"sum_body_charge":sum_body,"total_allowance":total,"budget_ok":total<=134217728 and sum_body==body_charge,"stats":stats,"constructor_calls":builds,"graphs":nav._entries.size(),"floor_charge":nav._floor_charged,"source_charge":nav._source_charged,"query_counts":space.query_counts.duplicate(true)}
func compare_predicates(a: RouteClearance, b: RouteClearance, actor: Dictionary) -> Dictionary:
	var positions: bool=true
	for y: int in 96:
		for x: int in 96:
			if a.reason(Vector2i(x,y))!=b.reason(Vector2i(x,y)):positions=false
	var sweeps: bool=true
	# Explicit verification probes, not claimed as recorded live sweep parameters.
	var cell: Array=actor.location.cell
	var origin: Vector2=Vector2(float(cell[0]),float(cell[1]))
	for delta: Vector2 in [Vector2.ZERO,Vector2(0.25,0),Vector2(-0.25,0),Vector2(0,0.25),Vector2(0,-0.25)]:
		if a.position_reason(origin+delta)!=b.position_reason(origin+delta) or a.sweep_reason(origin,origin+delta)!=b.sweep_reason(origin,origin+delta):sweeps=false
	var doors: bool=true
	for key: String in a._dependencies:
		if key.begins_with("door:") and a.door_static_fit(key.trim_prefix("door:"))!=b.door_static_fit(key.trim_prefix("door:")):doors=false
	return {"integer_positions":positions,"fractional_position_sweep_probes":sweeps,"door_static_fit":doors}
func precheck(corpus: Array, content: HospitalContent) -> void:
	for ci: int in corpus.size():
		var item: Dictionary=corpus[ci];var world: WorldState=WorldState.new(item.facts.duplicate(true));var before: Dictionary=world.freeze();var actor: Dictionary=actor_for(world,item)
		var a: HospitalSpace=make_space(content,false);var b: HospitalSpace=make_space(content,true)
		var qa: RouteClearance=a.navigation.structural_clearance(world,actor,int(item.floor_id),item.members,item.offsets)
		var qb: RouteClearance=b.navigation.structural_clearance(world,actor,int(item.floor_id),item.members,item.offsets)
		var checks: Dictionary=compare_predicates(qa,qb,actor)
		checks.canonical_equal=canonical(qa)==canonical(qb) and canonical(qa)==expected(item)
		checks.world_unchanged=world.freeze()==before
		checks.budget_ok=accounting(a).budget_ok and accounting(b).budget_ok
		checks.graph_not_built=a._navigation._entries.is_empty() and b._navigation._entries.is_empty()
		for key: String in checks:
			if not checks[key]:errors.append(str(ci)+":"+key)
		records.append({"corpus_index":ci,"actor_is_world_instance":item.actor_is_world_instance,"members":item.members,"checks":checks,"a":accounting(a),"b":accounting(b),"metadata":{"a_source_has_occupancy":qa.source.has("occupancy"),"b_source_has_occupancy":qb.source.has("occupancy")}})
		if not errors.is_empty():return
func arm(space: HospitalSpace,world: WorldState,item: Dictionary) -> Dictionary:
	var actor: Dictionary=actor_for(world,item);var want: Dictionary=expected(item)
	var t: int=Time.get_ticks_usec()
	var q: RouteClearance=space.navigation.structural_clearance(world,actor,int(item.floor_id),item.members,item.offsets)
	var cold_us: int=Time.get_ticks_usec()-t
	var cold_ok: bool=canonical(q)==want;var cold_account: Dictionary=accounting(space)
	var all_lightweight: bool=true
	t=Time.get_ticks_usec()
	for i: int in 500:
		q=space.navigation.structural_clearance(world,actor,int(item.floor_id),item.members,item.offsets)
		if q._size!=int(want._size) or q._height_m!=float(want._height_m) or q._doors.size()!=want._doors.size():all_lightweight=false
	var warm_us: int=Time.get_ticks_usec()-t
	return {"cold_us":cold_us,"warm_batch_us":warm_us,"iterations":500,"returns_ok":cold_ok and all_lightweight and canonical(q)==want,"cold_accounting":cold_account,"warm_accounting":accounting(space)}
func measure(corpus: Array, content: HospitalContent) -> void:
	var stream: FileAccess=FileAccess.open(output+".pairs.ndjson",FileAccess.WRITE)
	for ci: int in corpus.size():
		var item: Dictionary=corpus[ci];var world: WorldState=WorldState.new(item.facts.duplicate(true));var before: Dictionary=world.freeze()
		for pair: int in 6:
			var a: HospitalSpace=make_space(content,false);var b: HospitalSpace=make_space(content,true);var aa: Dictionary;var bb: Dictionary
			if pair%2==0:aa=arm(a,world,item);bb=arm(b,world,item)
			else:bb=arm(b,world,item);aa=arm(a,world,item)
			var checks: Dictionary={"returns":aa.returns_ok and bb.returns_ok,"world_unchanged":world.freeze()==before,"budget_ok":aa.cold_accounting.budget_ok and aa.warm_accounting.budget_ok and bb.cold_accounting.budget_ok and bb.warm_accounting.budget_ok}
			for key: String in checks:
				if not checks[key]:errors.append(str(ci)+":"+str(pair)+":"+key)
			var row: Dictionary={"corpus_index":ci,"pair":pair,"order":"AB" if pair%2==0 else "BA","a":aa,"b":bb,"checks":checks};records.append(row);stream.store_line(JSON.stringify(row));stream.flush()
			if not errors.is_empty():stream.close();return
	stream.close()
func run() -> void:
	var input: String=""
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--input="):input=arg.trim_prefix("--input=")
		if arg.begins_with("--output="):output=arg.trim_prefix("--output=")
		if arg.begins_with("--stage="):stage=arg.trim_prefix("--stage=")
	var f: FileAccess=FileAccess.open(input,FileAccess.READ);var corpus: Array=f.get_var(false);f.close();assert(corpus.size()==3)
	var content: HospitalContent=HospitalContent.new()
	if stage=="precheck":precheck(corpus,content)
	else:assert(stage=="measure");measure(corpus,content)
	f=FileAccess.open(output,FileAccess.WRITE);f.store_string(JSON.stringify({"complete":errors.is_empty() and records.size()==(3 if stage=="precheck" else 18),"stage":stage,"errors":errors,"records":records,"scope":"Three captured missing envelopes only. Fresh cold and repeated API micro, not whole-step improvement. Warm batch includes identical lightweight return checks. Allowance is not measured RAM. Occupancy metadata omitted only in static equivalence comparison."},"\t"));f.close();quit(0 if errors.is_empty() else 1)
