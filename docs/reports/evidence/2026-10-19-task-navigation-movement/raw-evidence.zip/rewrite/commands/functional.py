from pathlib import Path
import json,subprocess,sys,time
root=Path.cwd();task=root/'.cache/task-navigation-20261019';label=sys.argv[1];cases=sys.argv[2]
log=task/(label+'.log');status=task/(label+'.status.json');assert not log.exists() and not status.exists()
command=['pwsh','-NoProfile','-File','tests/run-acceptance.ps1','-CaseId',cases]
started=time.perf_counter()
with log.open('w',encoding='utf8') as f:r=subprocess.run(command,cwd=root,stdout=f,stderr=subprocess.STDOUT)
errors=[line for line in log.read_text(encoding='utf8',errors='replace').splitlines() if 'SCRIPT ERROR:' in line or 'ERROR:' in line]
status.write_text(json.dumps({'command':command,'cwd':str(root),'cases':cases.split(','),'exit_code':r.returncode,'engine_errors':errors,'elapsed_seconds':time.perf_counter()-started,'log':str(log)},ensure_ascii=False,indent=2),encoding='utf8')
print('Passed.' if r.returncode==0 and not errors else 'Incomplete: '+str(status),flush=True)
raise SystemExit(0 if r.returncode==0 and not errors else 4)
