from pathlib import Path
import json,hashlib,subprocess,time,sys,shutil
root=Path.cwd();task=root/'.cache/task-navigation-20261019'
engine=Path('C:/programs/godot/Godot_v4.7.2-stable_win64_console.exe')
before=root/'.cache/decision-ledger-20261019/final-after-project';after=task/'after-v2';inputs=root/'.cache/continuing-perf-20261019'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,value):p.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf8',newline='\n')
def run(label,command):
 log=task/(label+'.log');status=task/(label+'.status.json');assert not log.exists() and not status.exists(),label
 started=time.perf_counter()
 with log.open('w',encoding='utf8') as stream:r=subprocess.run(command,cwd=root,stdout=stream,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
 errors=[s for s in log.read_text(encoding='utf8',errors='replace').splitlines() if 'SCRIPT ERROR:' in s or 'ERROR:' in s]
 write(status,{'command':command,'cwd':str(root),'exit_code':r.returncode,'engine_errors':errors,'elapsed_seconds':time.perf_counter()-started,'log':str(log)})
 print(json.dumps({'operation':label,'exit_code':r.returncode,'engine_errors':len(errors)}),flush=True)
 if r.returncode or errors:raise SystemExit('Incomplete: '+str(status))
def verify(project,current=False):
 identity=load(project/'source-identity.json');assert sha(engine).lower()==identity['engine_sha256'].lower()
 for name,value in {'oddly_good_platform.windows.x86_64.dll':identity['native_sha256'],'libgmp-10.dll':identity['gmp_sha256'],'libmpfr-6.dll':identity['mpfr_sha256'],**identity['runtime_sha256']}.items():assert sha(project/'game/platform/windows/bin'/name).lower()==value.lower(),name
 for row in identity['source']:
  if row['path'].startswith(('game/','content/')):
   assert sha(project/row['path']).lower()==row['sha256'].lower(),row['path']
   if current:assert sha(root/row['path']).lower()==row['sha256'].lower(),row['path']
 return sha(project/'source-identity.json')
def measure(project,label,scene,steps,profile='plain',selected='0'):
 input_path=inputs/(scene+'.input.bin') if project==before else task/(scene+'.input.bin')
 output=task/(label+'.json')
 run(label,[str(engine),'--headless','--path',str(project),'--script','res://tools/performance/representative_selected.gd','--','--input='+str(input_path),'--output='+str(output),'--steps='+str(steps),'--profile='+profile,'--selected='+selected])
 r=load(output);assert r['complete'] and r['qualified'] and (steps<300 or all(r.get('public_checks',{}).values())),label
 return r
mode=sys.argv[1]
if mode=='freeze':
 run('freeze-v2',['pwsh','-NoProfile','-File','tools/performance/prepare.ps1','-Output',str(after)])
 verify(after,True)
 write(task/'v2-identity.json',{'baseline_identity_sha256':verify(before),'after_identity_sha256':verify(after,True)})
elif mode=='plain':
 verify(before);verify(after,True)
 summary={'complete':False,'formal_pass':False,'formal_acceptance_paused':True,'pairs':[]}
 baseline=load(task/'public-before-1.json')
 for n in [1,2]:
  new=measure(after,f'v2-public-after-{n}','public-v6',300)
  old=baseline if n==1 else measure(before,'v2-public-before-2','public-v6',300)
  assert old['initial']['present']==new['initial']['present']==160
  summary['pairs'].append({'scene':'public','round':n,'before':old['metrics'],'after':new['metrics']})
  write(task/'v2-quick-summary.json',summary)
 for scene,steps in [('gp',80),('op',40)]:
  pair={side:measure(before if side=='before' else after,f'v2-{scene}-{side}',scene,steps) for side in ['before','after']}
  summary['pairs'].append({'scene':scene,'before':pair['before']['metrics'],'after':pair['after']['metrics']})
  write(task/'v2-quick-summary.json',summary)
 assert load(task/'v2-public-after-1.json')['final_binary_sha256']==load(task/'v2-public-after-2.json')['final_binary_sha256']
 summary['complete']=True;write(task/'v2-quick-summary.json',summary)
elif mode=='profile':
 verify(after,True);project=task/'v2-probe';assert not project.exists();shutil.copytree(after,project)
 identity=load(project/'source-identity.json');identity['project']=str(project);identity['derived_from_identity_sha256']=sha(after/'source-identity.json');write(project/'source-identity.json',identity)
 run('instrument-v2',['python','-X','utf8','tools/performance/instrument_all_instances.py',str(project),'--ledger'])
 run('import-v2-probe',[str(engine),'--headless','--editor','--path',str(project),'--import','--quit'])
 r=measure(project,'v2-probe','public-v6',61,'ledger','59')
 write(task/'v2-probe-only.json',{'complete_diagnostic':True,'not_complete_performance_window':True,'formal_pass':False})
else:raise ValueError(mode)
print('Passed.',flush=True)
