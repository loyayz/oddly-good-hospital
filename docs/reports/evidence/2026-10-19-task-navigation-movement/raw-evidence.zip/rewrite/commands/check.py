from pathlib import Path
import json,subprocess,time,sys
task=Path(__file__).resolve().parent; root=task.parents[1]
label=sys.argv[1]
log=task/(label+'.log'); status=task/(label+'.status.json')
assert not log.exists() and not status.exists()
command=['pwsh','-NoProfile','-File','tools/performance/prepare.ps1','-Output',str(task/(label+'-project'))]
started=time.perf_counter()
with log.open('w',encoding='utf8') as f:result=subprocess.run(command,cwd=root,stdout=f,stderr=subprocess.STDOUT)
status.write_text(json.dumps({'command':command,'cwd':str(root),'exit_code':result.returncode,'elapsed_seconds':time.perf_counter()-started,'log':str(log)},indent=2),encoding='utf8')
print('Passed.' if result.returncode==0 else 'Incomplete: '+str(status),flush=True)
raise SystemExit(result.returncode)
