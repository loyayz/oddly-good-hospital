from pathlib import Path
import json,hashlib,subprocess,time,sys,shutil
root=Path.cwd();task=root/'.cache/task-navigation-20261019'
engine=Path('C:/programs/godot/Godot_v4.7.2-stable_win64_console.exe')
before=root/'.cache/decision-ledger-20261019/final-after-project';after=task/'after-project';inputs=root/'.cache/continuing-perf-20261019'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,value):p.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf8',newline='\n')
def run(label,command):
 log=task/(label+'.log');status=task/(label+'.status.json');assert not log.exists() and not status.exists(),label
 started=time.perf_counter()
 with log.open('w',encoding='utf8') as stream:r=subprocess.run(command,cwd=root,stdout=stream,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
 errors=[s for s in log.read_text(encoding='utf8',errors='replace').splitlines() if 'SCRIPT ERROR:' in s or 'ERROR:' in s]
 write(status,{'command':command,'cwd':str(root),'exit_code':r.returncode,'engine_errors':errors,'elapsed_seconds':time.perf_counter()-started,'log':str(log)})
 print(json.dumps({'operation':label,'exit_code':r.returncode,'engine_errors':len(errors)}),flush=True)
 if r.returncode or errors:raise SystemExit('Incomplete: '+str(status))
def verify(project,current=False):
 identity=load(project/'source-identity.json');assert sha(engine).lower()==identity['engine_sha256'].lower()
 for name,value in {'oddly_good_platform.windows.x86_64.dll':identity['native_sha256'],'libgmp-10.dll':identity['gmp_sha256'],'libmpfr-6.dll':identity['mpfr_sha256'],**identity['runtime_sha256']}.items():assert sha(project/'game/platform/windows/bin'/name).lower()==value.lower(),name
 for row in identity['source']:
  if row['path'].startswith(('game/','content/')):
   assert sha(project/row['path']).lower()==row['sha256'].lower(),row['path']
   if current:assert sha(root/row['path']).lower()==row['sha256'].lower(),row['path']
 return sha(project/'source-identity.json')
def measure(project,label,scene,steps,profile='plain',selected='0'):
 input_path=inputs/(scene+'.input.bin') if project==before else task/(scene+'.input.bin')
 output=task/(label+'.json')
 run(label,[str(engine),'--headless','--path',str(project),'--script','res://tools/performance/representative_selected.gd','--','--input='+str(input_path),'--output='+str(output),'--steps='+str(steps),'--profile='+profile,'--selected='+selected])
 r=load(output);assert r['complete'] and r['qualified'] and (steps<300 or all(r.get('public_checks',{}).values())),label
 return r
mode=sys.argv[1]
if mode=='freeze':
 assert not subprocess.check_output(['git','diff','d558e7e','b17b7d6','--','game','content'],cwd=root)
 verify(before)
 run('freeze-after',['pwsh','-NoProfile','-File','tools/performance/prepare.ps1','-Output',str(after)])
 verify(after,True)
 for scene in ['gp','op','public-v6']:
  run('rebase-'+scene,[str(engine),'--headless','--path',str(after),'--script',str(task/'rebase_input.gd'),'--','--input='+str(inputs/(scene+'.input.bin')),'--output='+str(task/(scene+'.input.bin'))])
 write(task/'frozen-identities.json',{'baseline_identity_sha256':verify(before),'after_identity_sha256':verify(after,True),'input_provenance':{scene:load(task/(scene+'.input.bin.provenance.json')) for scene in ['gp','op','public-v6']}})
elif mode=='plain':
 verify(before);verify(after,True)
 summary={'complete':False,'formal_pass':False,'formal_acceptance_paused':True,'pairs':[]}
 for n in [1,2]:
  pair={}
  for side in (['before','after'] if n==1 else ['after','before']):pair[side]=measure(before if side=='before' else after,f'public-{side}-{n}','public-v6',300)
  assert pair['before']['initial']['present']==pair['after']['initial']['present']==160
  summary['pairs'].append({'scene':'public','round':n,'before':pair['before']['metrics'],'after':pair['after']['metrics']});write(task/'quick-summary.json',summary)
 for scene,steps in [('gp',80),('op',40)]:
  pair={side:measure(before if side=='before' else after,f'{scene}-{side}',scene,steps) for side in ['before','after']}
  summary['pairs'].append({'scene':scene,'before':pair['before']['metrics'],'after':pair['after']['metrics']});write(task/'quick-summary.json',summary)
 assert load(task/'public-after-1.json')['final_binary_sha256']==load(task/'public-after-2.json')['final_binary_sha256']
 summary['complete']=True;write(task/'quick-summary.json',summary)
elif mode in ['profile','diagnose']:
 verify(after,True);project=task/('after-probe' if mode=='diagnose' else 'after-ledger');assert not project.exists();shutil.copytree(after,project)
 identity=load(project/'source-identity.json');identity['project']=str(project);identity['derived_from_identity_sha256']=sha(after/'source-identity.json');write(project/'source-identity.json',identity)
 run('instrument-probe' if mode=='diagnose' else 'instrument-after',['python','-X','utf8','tools/performance/instrument_all_instances.py',str(project),'--ledger'])
 run('import-probe' if mode=='diagnose' else 'import-ledger',[str(engine),'--headless','--editor','--path',str(project),'--import','--quit'])
 r=measure(project,'after-probe' if mode=='diagnose' else 'after-ledger','public-v6',61 if mode=='diagnose' else 300,'ledger','59' if mode=='diagnose' else '0,285,298')
 if mode=='diagnose':
  write(task/'probe-only.json',{'complete_diagnostic':True,'not_complete_performance_window':True,'formal_pass':False});print('Passed.',flush=True);sys.exit(0)
 assert r['final_binary_sha256']==load(task/'public-after-1.json')['final_binary_sha256']
 for row in r['profile']['decision_ledger']:
  assert row['call_partition_difference_us']==0
  assert row['outer_elapsed_us']==row['root_stage_us']+row['observer_handler_us']+row['residual_us']
 write(task/'profile-check.json',{'passed':True,'binary_equal_plain':True,'all_selected_ledgers_balanced':True,'selected':[row['index'] for row in r['profile']['decision_ledger']]})
else:raise ValueError(mode)
print('Passed.',flush=True)
