from pathlib import Path
import hashlib, json, shutil, subprocess, sys, time

task=Path(__file__).resolve().parent
root=task.parents[1]
engine=Path('C:/programs/godot/Godot_v4.7.2-stable_win64_console.exe')
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()

def run(name, command, timeout=1200):
    log=task/(name+'.log'); status=task/(name+'.status.json')
    assert not log.exists() and not status.exists(), name
    start=time.perf_counter(); timed_out=False
    with log.open('w',encoding='utf8') as stream:
        p=subprocess.Popen(command,cwd=root,stdout=stream,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
        try: code=p.wait(timeout)
        except subprocess.TimeoutExpired:
            timed_out=True
            subprocess.run(['taskkill','/PID',str(p.pid),'/T','/F'],capture_output=True)
            code=p.wait(10)
    errors=[s for s in log.read_text(encoding='utf8',errors='replace').splitlines() if 'SCRIPT ERROR:' in s or 'ERROR:' in s]
    result={'command':command,'cwd':str(root),'exit_code':code,'timed_out':timed_out,'engine_errors':errors,'elapsed_seconds':time.perf_counter()-start,'log':str(log)}
    status.write_text(json.dumps(result,indent=2),encoding='utf8')
    print(json.dumps({'name':name,'exit_code':code,'engine_errors':errors[:4],'elapsed_seconds':result['elapsed_seconds']}),flush=True)
    if code or timed_out or errors: raise SystemExit(4)

def measurement(project,name,mode,source='public-v6.input.bin',steps=300,selected='0,285,298'):
    output=task/(name+'.json')
    run(name,[str(engine),'--headless','--path',str(project),'--script','res://tools/performance/representative_selected.gd','--',f'--input={root/".cache/continuing-perf-20261019"/source}',f'--output={output}',f'--steps={steps}',f'--selected={selected}',f'--profile={mode}'])
    result=load(output)
    assert result['complete'] and result['qualified'] and not result['errors']
    assert all(result['qualification'].values()) and all(result.get('public_checks',{}).values())
    return result

if sys.argv[1]=='diagnose':
    plain=task/'before-project'; profile=task/'before-profile'
    run('prepare',['pwsh','-NoProfile','-File','tools/performance/prepare.ps1','-Output',str(plain)],300)
    assert not profile.exists()
    shutil.copytree(plain,profile)
    identity=load(profile/'source-identity.json'); identity['derived_from_identity_sha256']=sha(plain/'source-identity.json');identity['project']=str(profile)
    (profile/'source-identity.json').write_text(json.dumps(identity,indent=2),encoding='utf8')
    run('instrument',['python','-X','utf8','tools/performance/instrument_all_instances.py',str(profile),'--ledger'])
    run('import',[str(engine),'--headless','--editor','--path',str(profile),'--import','--quit'],300)
    before=measurement(plain,'before-plain','plain')
    detail=measurement(profile,'before-ledger','ledger')
    assert before['final_binary_sha256']==detail['final_binary_sha256']
    for step in detail['profile']['decision_ledger']:
        assert step['call_partition_difference_us']==0
        assert step['outer_elapsed_us']==step['root_stage_us']+step['observer_handler_us']+step['residual_us']
    (task/'diagnose-summary.json').write_text(json.dumps({'complete':True,'binary_equal':True,'formal_acceptance_paused':True,'plain_metrics':before['metrics'],'ledger_metrics':detail['metrics'],'source_identity_sha256':sha(plain/'source-identity.json')},indent=2),encoding='utf8')
    print('Passed.',flush=True)
elif sys.argv[1]=='validate':
    cases='CLIN-30,CLIN-31,CLIN-32,STAFF-29,STAFF-30,STAFF-42,STAFF-45,STAFF-46,STAFF-48,STAFF-50,STAFF-51,STAFF-57,STAFF-62,STAFF-64,STAFF-65,SPACE-48,SPACE-51'
    run('visitor-functional',['pwsh','-NoProfile','-File','tests/run-acceptance.ps1','-CaseId',cases],600)
    (task/'functional-selection.json').write_text(json.dumps({'case_ids':cases.split(','),'count':17,'scope':'visitor public seating query lifetime, FIFO priority, manual targets and safe release'},indent=2),encoding='utf8')
    print('Passed.',flush=True)
elif sys.argv[1]=='validate-routes':
    cases='CLIN-01,CLIN-02,CLIN-06,CLIN-07,CLIN-33,CLIN-34,CLIN-35,SPACE-08,SPACE-26,SPACE-51,GROW-83'
    run('route-functional',['pwsh','-NoProfile','-File','tests/run-acceptance.ps1','-CaseId',cases],600)
    (task/'route-functional-selection.json').write_text(json.dumps({'case_ids':cases.split(','),'count':11,'scope':'patient negative proof, clinical candidate order, real service, complete traffic prefix permissions and department routing'},indent=2),encoding='utf8')
    print('Passed.',flush=True)
elif sys.argv[1] in ['measure','measure-final']:
    final=sys.argv[1]=='measure-final'
    prefix='final-' if final else ''
    before=task/'before-project'; after=task/(prefix+'after-project'); profile=task/(prefix+'after-profile')
    run(prefix+'after-prepare',['pwsh','-NoProfile','-File','tools/performance/prepare.ps1','-Output',str(after)],300)
    pairs=[]
    for round_id in [1,2]:
        pair={}
        for side in (['after','before'] if round_id==1 else ['before','after']):
            name=f'{prefix}visitor-public-{side}-{round_id}'
            pair[side]=measurement(before if side=='before' else after,name,'plain')
        assert pair['before']['final_binary_sha256']==pair['after']['final_binary_sha256']
        pairs.append({'scene':'public','round':round_id,'before':pair['before']['metrics'],'after':pair['after']['metrics'],'binary_equal':True})
        print(json.dumps(pairs[-1]),flush=True)
        (task/(prefix+'measure-summary.json')).write_text(json.dumps({'pairs':pairs,'complete':False},indent=2),encoding='utf8')
    for scene,source,steps in [('gp','gp.input.bin',80),('op','op.input.bin',40)]:
        pair={}
        for side in ['before','after']:
            pair[side]=measurement(before if side=='before' else after,f'{prefix}visitor-{scene}-{side}','plain',source,steps,'0')
        assert pair['before']['final_binary_sha256']==pair['after']['final_binary_sha256']
        pairs.append({'scene':scene,'before':pair['before']['metrics'],'after':pair['after']['metrics'],'binary_equal':True})
    assert not profile.exists()
    shutil.copytree(after,profile)
    identity=load(profile/'source-identity.json');identity['derived_from_identity_sha256']=sha(after/'source-identity.json');identity['project']=str(profile)
    (profile/'source-identity.json').write_text(json.dumps(identity,indent=2),encoding='utf8')
    run(prefix+'after-instrument',['python','-X','utf8','tools/performance/instrument_all_instances.py',str(profile),'--ledger'])
    run(prefix+'after-import',[str(engine),'--headless','--editor','--path',str(profile),'--import','--quit'],300)
    detail=measurement(profile,prefix+'after-ledger','ledger')
    assert detail['final_binary_sha256']==load(task/(prefix+'visitor-public-after-1.json'))['final_binary_sha256']
    for step in detail['profile']['decision_ledger']:
        assert step['call_partition_difference_us']==0
        assert step['outer_elapsed_us']==step['root_stage_us']+step['observer_handler_us']+step['residual_us']
    (task/(prefix+'measure-summary.json')).write_text(json.dumps({'pairs':pairs,'complete':True,'ledger_binary_equal':True,'formal_acceptance_paused':True,'before_source':load(before/'source-identity.json')['head'],'after_source':load(after/'source-identity.json')['head']},indent=2),encoding='utf8')
    print('Passed.',flush=True)
