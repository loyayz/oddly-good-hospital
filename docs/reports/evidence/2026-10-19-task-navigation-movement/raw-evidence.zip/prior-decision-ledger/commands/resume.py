from pathlib import Path
import hashlib, json, shutil, subprocess, time

task=Path(__file__).resolve().parent
root=task.parents[1]
engine=Path('C:/programs/godot/Godot_v4.7.2-stable_win64_console.exe')
inputs=root/'.cache/continuing-perf-20261019'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
tool_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()

def run(name, command, timeout=1200):
    log=task/(name+'.log'); status=task/(name+'.status.json')
    assert not log.exists() and not status.exists(), name
    start=time.perf_counter(); timed_out=False
    with log.open('w',encoding='utf8') as stream:
        p=subprocess.Popen(command,cwd=root,stdout=stream,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
        try: code=p.wait(timeout)
        except subprocess.TimeoutExpired:
            timed_out=True
            subprocess.run(['taskkill','/PID',str(p.pid),'/T','/F'],capture_output=True)
            code=p.wait(10)
    errors=[s for s in log.read_text(encoding='utf8',errors='replace').splitlines() if 'SCRIPT ERROR:' in s or 'ERROR:' in s]
    result={'command':command,'cwd':str(root),'exit_code':code,'timed_out':timed_out,'engine_errors':errors,'elapsed_seconds':time.perf_counter()-start,'log':str(log)}
    status.write_text(json.dumps(result,indent=2),encoding='utf8')
    print(json.dumps({'name':name,'exit_code':code,'engine_errors':errors[:4],'elapsed_seconds':result['elapsed_seconds']}),flush=True)
    if code or timed_out or errors: raise SystemExit(4)

before=task/'before-project'; after=task/'final-after-project'
assert load(before/'source-identity.json')['head'].startswith('e82de55')
assert load(after/'source-identity.json')['head'].startswith('d558e7e')
assert not subprocess.check_output(['git','diff','d558e7e',tool_head,'--','game','content'],cwd=root)
for project in [before,after]:
    identity=load(project/'source-identity.json')
    assert sha(engine).lower()==identity['engine_sha256'].lower()
    for item in identity['source']:
        if item['path'].startswith(('game/','content/')):
            assert sha(project/item['path']).lower()==item['sha256'].lower(),item['path']

partial=task/'final-visitor-public-before-1.json.steps.ndjson'
pause={'reason':'user_requested_pause','batch':'measure-final','complete':False,'included_in_complete_window_metrics':False,
       'partial_records':[json.loads(line) for line in partial.read_text(encoding='utf8').splitlines()],
       'completed_after_window':'final-visitor-public-after-1.json','completed_after_window_retained_as_unpaired':True,
       'resumed_policy':'Fresh complete interleaved pairs; never append partial steps or overwrite interrupted outputs.'}
(task/'pause-record.json').write_text(json.dumps(pause,ensure_ascii=False,indent=2),encoding='utf8')

profiles={}
for side,project in [('before',before),('after',after)]:
    target=task/('light-'+side+'-profile')
    assert not target.exists()
    shutil.copytree(project,target)
    identity=load(target/'source-identity.json'); identity['project']=str(target)
    identity['derived_from_identity_sha256']=sha(project/'source-identity.json')
    identity['diagnostic_tool_head']=tool_head;identity['diagnostic_tool_overlay']=[]
    for name in ['decision_profile.gd','representative_selected.gd','instrument_all_instances.py','analyze_decisions.py']:
        relative='tools/performance/'+name
        old=sha(target/relative) if (target/relative).exists() else None
        shutil.copy2(root/relative,target/relative)
        value=sha(target/relative)
        identity['diagnostic_tool_overlay'].append({'path':relative,'before_sha256':old,'after_sha256':value})
        entry=next((r for r in identity['source'] if r['path']==relative),None)
        if entry: entry['sha256']=value
        else: identity['source'].append({'path':relative,'sha256':value})
    (target/'source-identity.json').write_text(json.dumps(identity,indent=2),encoding='utf8')
    run('light-'+side+'-instrument',['python','-X','utf8','tools/performance/instrument_all_instances.py',str(target),'--ledger'],120)
    run('light-'+side+'-import',[str(engine),'--headless','--editor','--path',str(target),'--import','--quit'],300)
    profiles[side]=target

def measure(project,name,source,steps,mode='plain',selected='0'):
    output=task/(name+'.json')
    run(name,[str(engine),'--headless','--path',str(project),'--script','res://tools/performance/representative_selected.gd','--',f'--input={inputs/source}',f'--output={output}',f'--steps={steps}',f'--selected={selected}',f'--profile={mode}'])
    r=load(output)
    assert r['complete'] and r['qualified'] and not r['errors']
    assert all(r['qualification'].values()) and all(r.get('public_checks',{}).values())
    return r

summary={'complete':False,'tool_head':tool_head,'before_head':load(before/'source-identity.json')['head'],'after_head':load(after/'source-identity.json')['head'],
         'formal_pass':False,'formal_acceptance_paused':True,'pairs':[],'diagnostics':[]}
def checkpoint():
    (task/'resumed-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8')
checkpoint()
for round_id in [1,2]:
    pair={}
    for side in (['before','after'] if round_id==1 else ['after','before']):
        name=f'resumed-public-{side}-{round_id}'
        pair[side]=measure(before if side=='before' else after,name,'public-v6.input.bin',300)
    assert pair['before']['final_binary_sha256']==pair['after']['final_binary_sha256']
    row={'scene':'public','round':round_id,'binary_equal':True,'before':pair['before']['metrics'],'after':pair['after']['metrics']}
    summary['pairs'].append(row);checkpoint();print(json.dumps(row),flush=True)
for scene,source,steps in [('gp','gp.input.bin',80),('op','op.input.bin',40)]:
    pair={}
    for side in ['before','after']:
        pair[side]=measure(before if side=='before' else after,f'resumed-{scene}-{side}',source,steps)
    assert pair['before']['final_binary_sha256']==pair['after']['final_binary_sha256']
    row={'scene':scene,'binary_equal':True,'before':pair['before']['metrics'],'after':pair['after']['metrics']}
    summary['pairs'].append(row);checkpoint();print(json.dumps(row),flush=True)
for side in ['before','after']:
    r=measure(profiles[side],'light-'+side+'-ledger','public-v6.input.bin',300,'ledger','0,285,298')
    control=load(task/('resumed-public-'+side+'-1.json'))
    assert r['final_binary_sha256']==control['final_binary_sha256']
    for step in r['profile']['decision_ledger']:
        assert step['call_partition_difference_us']==0
        assert step['outer_elapsed_us']==step['root_stage_us']+step['observer_handler_us']+step['residual_us']
    summary['diagnostics'].append({'side':side,'final_binary_equal_plain':True,'metrics':r['metrics'],'calls':[s['call_count'] for s in r['profile']['decision_ledger']]})
    checkpoint()
summary['complete']=True;checkpoint();print('Passed.',flush=True)
