from pathlib import Path
import json, subprocess, time

task=Path(__file__).resolve().parent; root=task.parents[1]
for side in ['before','after']:
    name='light-'+side+'-analysis'
    log=task/(name+'.log'); status=task/(name+'.status.json')
    assert not log.exists() and not status.exists()
    command=['python','-X','utf8','tools/performance/analyze_decisions.py',str(task/('light-'+side+'-ledger.json')),str(task/(name+'.json'))]
    started=time.perf_counter()
    with log.open('w',encoding='utf8') as f:
        result=subprocess.run(command,cwd=root,stdout=f,stderr=subprocess.STDOUT)
    status.write_text(json.dumps({'command':command,'cwd':str(root),'exit_code':result.returncode,'elapsed_seconds':time.perf_counter()-started,'log':str(log)},indent=2),encoding='utf8')
    if result.returncode:raise SystemExit(result.returncode)
print('Passed.',flush=True)
