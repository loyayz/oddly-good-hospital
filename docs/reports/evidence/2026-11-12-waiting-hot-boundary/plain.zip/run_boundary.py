from pathlib import Path
import sys,shutil,json,hashlib,zipfile,traceback,subprocess
BASE=Path(__file__).resolve().parent;REPO=BASE.parent/'oddly-good-hospital-cloud-recovery-20261112';ROOT=BASE.parent/'root-stage-recovery-20261112';N=BASE.parent/'movement-stage-recovery-20261112';OLD=BASE.parent/'move-step-breakdown-20261112'
sys.path.insert(0,str(N));import full_narrow_v1 as h
c=h.c;g=h.g
cfg=c.read(ROOT/'config.json');c.verify(cfg);c.idle();head=subprocess.check_output(['git','-C',str(REPO),'rev-parse','HEAD'],text=True).strip();assert head=='2220eb7a2f5c826aac89bb1ff7b9348b8dafe786';assert not subprocess.check_output(['git','-C',str(REPO),'diff','HEAD','--'],text=True)
full=BASE.parent/'structural-cache-full-plain-20261112'
receipt=c.read(full/'full-plain.durable-receipt.json');assert receipt['readback_verified'];assert receipt['archive_sha256']==c.sha(full/'full-plain.zip')
short=BASE.parent/'structural-cache-plain8-20261112';short_receipt=c.read(short/'plain8.durable-receipt.json');assert short_receipt['readback_verified'] and short_receipt['archive_sha256']==c.sha(short/'plain8.zip')
with zipfile.ZipFile(full/'full-plain.zip') as z:
 manifest=json.loads(z.read('MEMBERS.json'))
 for n in ['plain/result.json.steps.ndjson','plain/result.json']:
  data=z.read(n);assert hashlib.sha256(data).hexdigest()==manifest[n]['sha256'];dest=BASE/'baseline'/n;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
shutil.copy2(ROOT/'mixed160.input.bin',BASE/'input.bin')
assert c.sha(BASE/'input.bin')=='75f5e1d922f39f12382c0ceb74806bda0293251189f68a1ac158842f65fa78ca'
project=BASE/'project';shutil.copytree(REPO,project,ignore=shutil.ignore_patterns('.git','docs','art-source','.cache'));driver='tools/performance/current/plain_v4.gd';assert c.sha(project/driver)==c.sha(OLD/'plain-project'/driver)
prior=c.read(OLD/'identity.json')['inventories']['plain'];inventory=c.inventory(project)
for rel,digest in prior.items():
 if rel.startswith(('content/','native/')):assert inventory[rel]==digest,rel
short_inv=c.read(short/'identity.json')['inventory']
for rel,digest in short_inv.items():
 if rel.startswith(('game/','content/','native/')) or rel==driver:assert inventory[rel]==digest,rel
c.write(BASE/'identity.json',{'head':head,'inventory':inventory,'runtime':cfg,'input_sha256':c.sha(BASE/'input.bin'),'driver_sha256':c.sha(project/driver),'baseline_receipt':receipt,'fixed_steps':1253,'prefix_steps':1000,'short_qualification_receipt':short_receipt,'step_seconds':0.1,'requested_thread_policy':'app','workers':4,'OMP_NUM_THREADS':1,'controller_sha256':c.sha(__file__)})
for rel in [driver,'game/building/navigation_cache.gd','game/building/hospital_navigation.gd','game/operations/floor_guidance.gd']:
 dest=BASE/'sources'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(project/rel,dest)
for p in [ROOT/'controller_v2.py',ROOT/'linux_guard_v2.py',N/'full_narrow_v1.py',N/'qualify_v1.py',N/'prepare_v1.py']:shutil.copy2(p,BASE/('dependency-'+p.name))
g.PROJECT=project;g.LIBRARY_PATH=cfg['library_path'];c.write(BASE/'host-before.json',h.host())
try:
 g.run([cfg['engine'],'--headless','--path',str(project),'--script','res://'+driver,'--','--input='+str(BASE/'input.bin'),'--output='+str(BASE/'plain/result.json'),'--steps=1253','--prefix-steps=1000','--expected-scenario=mixed160-clinical-ops-v1','--require-coverage','--worker-tasks=4','--main-thread-policy=app','--observed-floor=1'],BASE/'plain',timeout=1800,allowed_exits=(0,1))
 assert c.inventory(project)==inventory;c.verify(cfg)
 result=c.read(BASE/'plain/result.json')
 def read_rows(path):return [json.loads(line) for line in path.read_text().splitlines()]
 current=read_rows(BASE/'plain/result.json.steps.ndjson');previous=read_rows(BASE/'baseline/plain/result.json.steps.ndjson')[:2253*2]
 checks={'executed_2253':result['all_completed_steps']==2253,'records_2253_enter_complete':len(current)==4506,'prefix_still_1000':result['requested_prefix_steps']==1000,'sample_still_1253':result['requested_sample_steps']==1253,'non_timing_trace_equal':True}
 for i,(x,y) in enumerate(zip(current,previous)):
  assert x['kind']==y['kind']
  if x['kind']=='enter':checks['non_timing_trace_equal']=checks['non_timing_trace_equal'] and x==y
  else:
   checks['non_timing_trace_equal']=checks['non_timing_trace_equal'] and all(x['sample'][k]==y['sample'][k] for k in ['index','tick','moves','present','sessions'])
 checks['last_tick_2886']=current[-1]['sample']['tick']==2886
 c.write(BASE/'comparison.json',{'checks':checks,'diagnostic_trace_qualified':all(checks.values()),'full_final_sha256':result['final_sha256'],'raw_complete':result['complete'],'raw_performance_pass':result['performance_pass'],'scope':'Intentionally truncated hot-history diagnostic baseline, 1000 prefix plus 1253 sample. No pre-existing intermediate full-World binary exists to compare. Final binary saved for future observer comparison. Not full-window acceptance.'});assert all(checks.values()),checks

except BaseException:c.write(BASE/'error.json',{'traceback':traceback.format_exc()});raise
finally:
 c.write(BASE/'host-after.json',h.host())
 files=[p for p in BASE.rglob('*') if p.is_file() and p.relative_to(BASE).parts[0]!='project' and p.name not in ['boundary-plain.zip','members.json','checkpoint.json']];m={str(p.relative_to(BASE)):{'bytes':p.stat().st_size,'sha256':c.sha(p)} for p in files};c.write(BASE/'members.json',m)
 with zipfile.ZipFile(BASE/'boundary-plain.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
  for p in files:z.write(p,str(p.relative_to(BASE)))
  z.write(BASE/'members.json','MEMBERS.json')
 with zipfile.ZipFile(BASE/'boundary-plain.zip') as z:
  assert z.testzip() is None
  for n,v in m.items():assert len(z.read(n))==v['bytes'] and hashlib.sha256(z.read(n)).hexdigest()==v['sha256']
 c.write(BASE/'checkpoint.json',{'sha256':c.sha(BASE/'boundary-plain.zip'),'bytes':(BASE/'boundary-plain.zip').stat().st_size,'members':len(m),'local_readback_verified':True})
c.idle()
