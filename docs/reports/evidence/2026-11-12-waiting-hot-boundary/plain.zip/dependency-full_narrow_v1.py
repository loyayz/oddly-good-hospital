"""One full narrow window only. Requires parent-issued durable release; never runs plain."""
from pathlib import Path
import sys,json,shutil,traceback,argparse,hashlib,zipfile
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE));import qualify_v1 as q
c=q.checks;g=q.guard;prep=q.prep
OLD=q.OLD

def host():
    d=q.host()
    for name in ['/proc/self/mountinfo','/proc/mounts','/sys/fs/cgroup/cpu/cpu.cfs_quota_us','/sys/fs/cgroup/cpu/cpu.cfs_period_us','/sys/fs/cgroup/cpu/cpu.stat','/sys/fs/cgroup/cpu,cpuacct/cpu.cfs_quota_us','/sys/fs/cgroup/cpu,cpuacct/cpu.cfs_period_us','/sys/fs/cgroup/cpu,cpuacct/cpu.stat','/sys/fs/cgroup/cpuset/cpuset.cpus','/sys/fs/cgroup/memory/memory.limit_in_bytes','/sys/fs/cgroup/memory/memory.usage_in_bytes']:
        try:d[name]=Path(name).read_text()
        except OSError as e:d[name]='unavailable: '+str(e)
    return d

def validate(folder):
    d=c.read(folder/'result.json.movement-stages.json');assert not d['errors']
    rows=[json.loads(line)['sample'] for line in (folder/'result.json.steps.ndjson').read_text().splitlines() if json.loads(line)['kind']=='complete']
    assert len(rows)==7000 and [r['index'] for r in rows]==list(range(7000))
    records=d['records'];assert len(records)==6000
    for r,row in zip(records,rows[1000:]):
        assert r['tick']==row['tick'] and r['outer_elapsed_us']==row['elapsed_us']
        assert r['advance_count']==1 and set(r['phases'])==q.PHASES
        assert sum(r['phases'].values())==r['phase_sum_us']
        assert r['outer_elapsed_us']==r['phase_sum_us']+r['handler_us']+r['outside_spans_and_gaps_us']
        covered={p:0 for p in q.PHASES}
        for key,v in r['calls'].items():
            assert v['method'] in prep.NAMES and v['phase'] in q.PHASES and key==v['phase']+':'+v['method']
            assert 0<=v['exclusive_us']<=v['inclusive_us'] and v['calls']>0
            covered[v['phase']]+=v['exclusive_us']
        for p in q.PHASES:assert r['uncovered_by_selected_calls_us'][p]==r['phases'][p]-covered[p]>=0
    return {'records':len(records),'exact_measured_tick_elapsed_alignment':True,'scoped_phase_exclusive_partition':True,'errors':d['errors']}

def receipt_matches(receipt,expected):
    assert receipt['readback_verified'] is True and receipt['archive_sha256']==expected and receipt['destination']

def identities():
    identity=c.read(BASE/'identity.json')
    for path,h in identity['tool_sha256'].items():assert c.sha(path)==h,path
    assert c.sha(BASE/'mixed160.input.bin')==identity['input_sha256']==c.INPUT_SHA
    manifest=c.read(BASE/'source-transform.json')
    for rel,v in manifest['changes'].items():
        assert c.sha(BASE/(Path(rel).name+'.observer'))==v['observer_sha256']
        assert c.sha(BASE/(Path(rel).name+'.original'))==v['original_sha256']
    assert c.sha(BASE/'movement_stage_timer.gd')==manifest['timer_sha256']
    cfg=identity['runtime_config'];c.verify(cfg)
    return identity,cfg

def archive(out):
    paths=[p for p in out.rglob('*') if p.is_file() and p.relative_to(out).parts[0]!='project']
    members={str(p.relative_to(out)):{'bytes':p.stat().st_size,'sha256':c.sha(p)} for p in paths};c.write(out.with_suffix('.members.json'),members)
    with zipfile.ZipFile(out.with_suffix('.zip'),'x',compression=zipfile.ZIP_DEFLATED) as z:
        for p in paths:z.write(p,str(p.relative_to(out)))
        z.write(out.with_suffix('.members.json'),'MEMBERS.json')
    with zipfile.ZipFile(out.with_suffix('.zip')) as z:
        assert z.testzip() is None
        for n,v in members.items():
            b=z.read(n);assert len(b)==v['bytes'] and hashlib.sha256(b).hexdigest()==v['sha256']
    c.write(out.with_suffix('.checkpoint.json'),{'sha256':c.sha(out.with_suffix('.zip')),'bytes':out.with_suffix('.zip').stat().st_size,'members':len(members),'local_readback_verified':True,'durable_verified':False})

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--release',required=True,type=Path);args=ap.parse_args();release=c.read(args.release)
    assert release['phase']=='full-narrow' and release['entry_sha256']==c.sha(__file__)
    identity,cfg=identities()
    assert release['qualification_identity_sha256']==c.sha(BASE/'identity.json')
    receipt_matches(release['qualification_durable_receipt'],c.sha(BASE/'qualification.zip'))
    assert c.sha(BASE/'qualification.zip')=='6af002837a69bb826c6a4dea602d645e1edee8be2e37715f6e12953caa8a2d22'
    assert c.read(BASE/'comparison.json')['complete_world_rng_ordered_events_equal']
    receipt_matches(release['plain_durable_receipt'],'0aaf766947d28dc8c5c7cade528b24e6ebc1241293c624245b71fbf7cb09b3ba')
    assert c.sha(OLD/'full-plain.zip')==release['plain_durable_receipt']['archive_sha256']
    c.idle();out=BASE/'full-narrow';out.mkdir(exist_ok=False)
    # Materialize the exact durable baseline bytes for comparison, not a new simulation.
    baseline=out/'baseline';baseline.mkdir()
    with zipfile.ZipFile(OLD/'full-plain.zip') as z:
        assert z.testzip() is None;members=json.loads(z.read('MEMBERS.json'))
        for n in ['run/result.json','run/result.json.final.bin']:
            b=z.read(n);assert hashlib.sha256(b).hexdigest()==members[n]['sha256'];(baseline/Path(n).name).write_bytes(b)
    project=out/'project';shutil.copytree(Path(cfg['project']),project,ignore=shutil.ignore_patterns('.cache'))
    pristine=c.inventory(project)
    for rel in [prep.REL,prep.DRIVER]:(project/rel).write_bytes((BASE/(Path(rel).name+'.observer')).read_bytes())
    shutil.copy2(BASE/'movement_stage_timer.gd',project/prep.TIMER)
    overlay=c.inventory(project);assert overlay==identity['project_inventories']['narrow']
    c.write(out/'phase-identity.json',{'qualification_identity':identity,'entry_sha256':c.sha(__file__),'overlay_inventory':overlay,'plain_archive_sha256':c.sha(OLD/'full-plain.zip'),'qualification_archive_sha256':c.sha(BASE/'qualification.zip')})
    c.write(out/'release.json',release)
    for name in ['full_narrow_v1.py','qualify_v1.py','prepare_v1.py','movement_stage_timer.gd','linux_guard_v2.py','source-transform.json','hospital_movement.gd.observer','plain_v4.gd.observer','hospital_movement.gd.original','plain_v4.gd.original','mixed160.input.bin']:shutil.copy2(BASE/name,out/name)
    shutil.copy2(OLD/'controller_v2.py',out/'controller_v2.py')
    try:
        identities();c.idle();g.PROJECT=project;g.LIBRARY_PATH=cfg['library_path'];c.write(out/'host-before.json',host())
        command=[cfg['engine'],'--headless','--path',str(project),'--script','res://'+prep.DRIVER,'--','--input='+str(BASE/'mixed160.input.bin'),'--output='+str(out/'run/result.json'),'--prefix-steps=1000','--steps=6000','--observed-floor=1','--worker-tasks=4','--main-thread-policy=app','--expected-scenario=mixed160-clinical-ops-v1','--require-coverage']
        try:g.run(command,out/'run',timeout=3600,allowed_exits=(0,1))
        finally:c.write(out/'host-after.json',host())
        assert c.inventory(project)==overlay;identities();c.result_checks(out/'run',7000,False)
        c.write(out/'narrow-checks.json',validate(out/'run'));c.write(out/'comparison.json',c.pair(baseline,out/'run'))
    except BaseException:
        c.write(out/'error.json',{'error':traceback.format_exc()});raise
    finally:
        for rel in [prep.REL,prep.DRIVER]:(project/rel).write_bytes((BASE/(Path(rel).name+'.original')).read_bytes())
        restored=c.inventory(project);restored.pop(prep.TIMER)
        okay=restored==pristine;c.write(out/'restoration.json',{'source_restored':okay,'timer_dormant':True})
        archive(out);assert okay
if __name__=='__main__':main()
