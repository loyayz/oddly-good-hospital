from pathlib import Path
import sys,json,hashlib,shutil,traceback,zipfile,re
B=Path(__file__).resolve().parent;N=B.parent/'movement-stage-recovery-20261112';P=B.parent/'waiting-boundary-plain-20261112';R=B.parent/'oddly-good-hospital-cloud-recovery-20261112'
sys.path.insert(0,str(N));import full_narrow_v1 as h
c=h.c;g=h.g;mode=sys.argv[1];assert mode in ['parse','run'];m=c.read(B/'manifest.json');project=B/'project';c.verify(m['runtime']);c.idle()
assert c.sha(B/'manifest.json')=='78df825b57bde1cc43bc8a0fa9ae130d827e7d9cf906da55313458f3d40ddef2'
assert c.sha(P/'identity.json')==m['plain_identity_sha256'];prior=c.read(P/'identity.json')['inventory'];scope=c.read(B/'scope.json')
for rel,entry in m['files'].items():
 assert c.sha(B/'original'/rel)==entry['original_sha256']==prior[rel]==c.sha(R/rel)
 assert c.sha(project/rel)==entry['observer_sha256']
 text=(project/rel).read_text();undo=text.replace('\n\nconst _WH = preload("res://tools/performance/current/waiting_hot_observer.gd")','',1)
 for row in [x for x in scope if x['file']==rel]:
  name=row['function'];a=undo.index('func '+name+'(');z=undo.index('func _wh_original_'+name+'(',a)
  header=undo[a:undo.index('\n',a)];renamed=undo[z:undo.index('\n',z)]
  assert renamed.replace('func _wh_original_'+name+'(','func '+name+'(')==header
  undo=undo[:a]+undo[z:].replace('func _wh_original_'+name+'(','func '+name+'(',1)
 assert undo.encode()==(B/'original'/rel).read_bytes(),rel
for rel,digest in prior.items():
 if rel not in m['files']:assert c.sha(project/rel)==digest,rel
for rel,field in [('input.bin','input_sha256'),('observer.patch','patch_sha256'),('linux_guard_v2.py','guard_sha256')]:assert c.sha(B/rel)==m[field]
assert c.sha(project/'tools/performance/current/waiting_hot_observer.gd')==m['helper_sha256']
receipt=c.read(P/'boundary-plain.durable-receipt.json');assert receipt['readback_verified'] and receipt['archive_sha256']==c.sha(P/'boundary-plain.zip')
if mode=='parse':
 script='extends SceneTree\n'+''.join('const Check%d=preload("res://%s")\n'%(i,rel) for i,rel in enumerate(m['files']))
 (project/'tools/performance/current/check_waiting_observer.gd').write_text(script)
cmd=[m['runtime']['engine'],'--headless','--path',str(project),'--script','res://tools/performance/current/'+('check_waiting_observer.gd' if mode=='parse' else 'plain_v4.gd')]
if mode=='parse':cmd+=['--check-only']
else:
 assert c.read(B/'parse-qualified.json')['ok']
 cmd+=['--','--input='+str(B/'input.bin'),'--output='+str(B/'observer/result.json'),'--steps=1253','--prefix-steps=1000','--expected-scenario=mixed160-clinical-ops-v1','--require-coverage','--worker-tasks=4','--main-thread-policy=app','--observed-floor=1']
g.PROJECT=project;g.LIBRARY_PATH=m['runtime']['library_path'];out=B/('parser-02' if mode=='parse' else 'observer');inv=c.inventory(project);c.write(B/(mode+'-identity.json'),{'manifest_sha256':c.sha(B/'manifest.json'),'inventory':inv,'runtime':m['runtime'],'baseline_receipt':receipt,'exact_inverse_verified':True});c.write(B/(mode+'-host-before.json'),h.host())
try:
 g.run(cmd,out,timeout=1800,allowed_exits=(0,) if mode=='parse' else (0,1))
 assert c.inventory(project)==inv
 if mode=='parse':c.write(B/'parse-qualified.json',{'ok':True,'manifest_sha256':c.sha(B/'manifest.json')})
 else:
  a=c.read(P/'plain/result.json');b=c.read(out/'result.json');checks={k:a[k]==b[k] for k in ['business','sample_business','prefix_business','errors','complete']}
  checks['full_world_rng_events_equal']=(P/'plain/result.json.final.bin').read_bytes()==(out/'result.json.final.bin').read_bytes()
  before=[json.loads(x) for x in (P/'plain/result.json.steps.ndjson').read_text().splitlines()];after=[json.loads(x) for x in (out/'result.json.steps.ndjson').read_text().splitlines()];checks['2253_rows']=len(before)==len(after)==4506
  checks['non_timing_steps_equal']=all(x==y if x['kind']=='enter' else all(x['sample'][k]==y['sample'][k] for k in ['index','tick','moves','present','sessions']) for x,y in zip(before,after))
  traces=list(out.rglob('waiting-hot.ndjson'));assert len(traces)==1;shutil.copy2(traces[0],B/'waiting-hot.ndjson');rows=[json.loads(x) for x in (B/'waiting-hot.ndjson').read_text().splitlines()];byid={r['id']:r for r in rows};roots=[r for r in rows if r['parent']==0];checks['five_roots']=len(roots)==5 and sorted(r['output_tick'] for r in roots)==list(range(2882,2887));arithmetic=True
  for r in rows:
   children=[q for q in rows if q['parent']==r['id']]
   arithmetic=arithmetic and r['inclusive_raw_us']==r['body_end_us']-r['body_start_us'] and r['child_wrapper_us']==sum(q['wrapper_us'] for q in children) and r['descendant_handler_us']==sum(q['own_handler_us']+q['descendant_handler_us'] for q in children) and r['exclusive_us']==r['inclusive_raw_us']-r['child_wrapper_us'] and r['inclusive_less_descendant_handler_us']==r['inclusive_raw_us']-r['descendant_handler_us'] and r['own_handler_us']==r['wrapper_us']-r['inclusive_raw_us'] and r['exclusive_us']>=0
   if r['parent']:
    parent=byid[r['parent']];arithmetic=arithmetic and parent['body_start_us']<=r['entered_us'] and r['entered_us']+r['wrapper_us']<=parent['body_end_us'] and r['output_tick']==parent['output_tick']
  checks['stack_parent_arithmetic']=arithmetic
  c.write(B/'comparison.json',{'checks':checks,'qualified':all(checks.values()),'rows':len(rows),'final_sha256':b['final_sha256'],'scope':'Hot-history truncated observer; flush stays in outer step, inclusive sums forbidden; not acceptance.'});assert all(checks.values()),checks
except BaseException:c.write(B/(mode+'-error.json'),{'traceback':traceback.format_exc()});raise
finally:c.write(B/(mode+'-host-after.json'),h.host())
