# Waiting hot-boundary qualified observation

2253 real steps preserve original prefix1000/sample1253 and command schedule. Full final World/RNG/events, business and per-step non-timing fields equal plain. Final SHA53af4f26c2b95307ba9357c33b44b02951544b86629deb32d76735e569d1de1f. Coverage remains22/31 and exit1, not acceptance.

Output2884 waiting raw297.909ms, descendant handler37.140ms, corrected estimate260.769ms. _start_fallback57 calls exclusive223.735ms; six owners0003/0026/0011/0012/0027/0059 contribute222.908ms. All have original started_tick2433 and toilet purpose; seek_seconds45 means world2883 deadline. Each transitions area_travel→fallback_travel, unsafe current origin and empty current_area, then successful request to a real safe waiting point. Void fallback return is null; request result is empty error string. Neighbor outputs2882/2883/2885/2886 have zero fallback calls.

Root corrected estimates for neighbors:9.020/8.644/8.729/8.087ms. Root flush20.131/18.085/33.838/18.404/17.219ms remains in outer steps. No inclusive rows may be summed; exclusive partition checks equal corrected root, not net production CPU. Root exclusive25us at hot step is distinct from uninstrumented work inside deeper wrappers.

Specific next question, not a new run: how much of these six floor_waiting_point paths is full public-point enumeration/sort versus can_reach? Actual source enumerates complete owned public floor and sorts nearest-first with y/x ties before safe_wait/can_reach. Existing wrapper does not time floor_waiting_point, room_use.public_point, can_reach or toilets.leave individually. Thus223.735ms is scoped fallback residual, not a proved sorting/pathfinding cost. No production patch or second replay was made.

Coordinate-summary amendment preserved <=4 scalar arrays and Vector2 x/y before replay. Both parser-only runs and identities kept. No parser failure occurred. Exact inverse and original signatures verified; isolated overlays restored after copying to archive inputs.
