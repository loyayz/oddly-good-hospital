extends RefCounted
# Read-only observational state. No World/service query or retained business container.
static var stack: Array = []
static var rows: Array = []
static var serial: int = 0

static func active() -> bool:
	return not stack.is_empty()

static func summary(value: Variant) -> Variant:
	if value is Dictionary:
		var out: Dictionary = {"size":value.size()}
		for key: String in ["id","actor_id","visit_id","ticket_id","facility_id","phase","purpose","public_purpose","mode","deadline","deadline_tick","started_tick","arrived_tick","next_need_tick","floor_id","travel_ticks","reason","code","accepted","reachable","cost","request_id","waiting_reason","kind","status","ok","remaining_ticks","queued_ticks","retry_tick","next_retry_tick","recheck_tick","next_check_tick","next_scan_tick","start_ticks","sequence","next_purpose"]:
			if value.has(key) and (value[key] == null or typeof(value[key]) in [TYPE_BOOL,TYPE_INT,TYPE_FLOAT,TYPE_STRING]): out[key]=value[key]
		for key: String in ["cell","target","area"]:
			if value.has(key):
				var item: Variant = value[key]
				if item is Array and item.size()<=3: out[key]=item.duplicate()
				elif item is Dictionary: out[key]=summary(item)
		return out
	if value is Array:
		var scalar: bool=value.size()<=4
		for item: Variant in value:
			if item!=null and not typeof(item) in [TYPE_BOOL,TYPE_INT,TYPE_FLOAT,TYPE_STRING]:scalar=false;break
		return value.duplicate() if scalar else {"array_size":value.size()}
	if value is Vector2 or value is Vector2i:return {"x":value.x,"y":value.y}
	if value == null or typeof(value) in [TYPE_BOOL,TYPE_INT,TYPE_FLOAT,TYPE_STRING]: return value
	return {"type":typeof(value)}

static func context(values: Dictionary) -> Dictionary:
	var out: Dictionary = {}
	for key: String in values: out[key]=summary(values[key])
	return out

static func begin(label: String, tick: int, values: Dictionary, entered: int) -> Dictionary:
	serial+=1
	var frame: Dictionary = {"id":serial,"parent":0 if stack.is_empty() else stack.back().id,"label":label,"world_tick":tick,"output_tick":tick+1,"before":context(values),"entered_us":entered,"child_wrapper_us":0,"descendant_handler_us":0}
	stack.append(frame)
	frame.body_start_us=Time.get_ticks_usec()
	return frame

static func finish(frame: Dictionary, values: Dictionary, result: Variant, body_end: int) -> void:
	assert(stack.back()==frame)
	frame.body_end_us=body_end
	frame.after=context(values)
	frame.result=summary(result)
	frame.inclusive_raw_us=body_end-int(frame.body_start_us)
	frame.exclusive_us=int(frame.inclusive_raw_us)-int(frame.child_wrapper_us)
	frame.inclusive_less_descendant_handler_us=int(frame.inclusive_raw_us)-int(frame.descendant_handler_us)
	stack.pop_back()
	rows.append(frame)
	var finished: int = Time.get_ticks_usec()
	frame.wrapper_us=finished-int(frame.entered_us)
	frame.own_handler_us=int(frame.body_start_us)-int(frame.entered_us)+finished-body_end
	if not stack.is_empty():
		stack.back().child_wrapper_us+=int(frame.wrapper_us)
		stack.back().descendant_handler_us+=int(frame.own_handler_us)+int(frame.descendant_handler_us)
	else:
		var flush_start: int = Time.get_ticks_usec()
		var path: String = "user://waiting-hot.ndjson"
		var file: FileAccess = FileAccess.open(path,FileAccess.READ_WRITE if FileAccess.file_exists(path) else FileAccess.WRITE)
		assert(file!=null)
		file.seek_end()
		for row: Dictionary in rows: file.store_line(JSON.stringify(row))
		file.close()
		rows.clear()
		print("WAITING_OBSERVER_FLUSH world_tick=",frame.world_tick," elapsed_us=",Time.get_ticks_usec()-flush_start," path=",ProjectSettings.globalize_path(path))
