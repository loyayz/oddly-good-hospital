from pathlib import Path
import json,re,hashlib,difflib
b=Path(__file__).resolve().parent; p=b/'project';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
prep=b/'prepare.py';s=prep.read_text(); old='"status"]';new='"status","ok","remaining_ticks","queued_ticks","retry_tick","next_retry_tick","recheck_tick","next_check_tick","next_scan_tick","start_ticks","sequence","next_purpose"]';assert old in s;s=s.replace(old,new)
line='  if ret==\'void\':'
extra='  if "visit" in args and "world" in args:\n   for source in ["clocks","seats","needs"]: context=context[:-1]+\',"_owner_\'+source+\'":world.facts.get("waiting_life",{}).get("\'+source+\'",{}).get(str(visit.get("id","")),{})}\'\n'
assert line in s;s=s.replace(line,extra+line);prep.write_text(s);compile(s,str(prep),'exec')
h=p/'tools/performance/current/waiting_hot_observer.gd';s=h.read_text();assert old in s;h.write_text(s.replace(old,new))
f=p/'game/life/waiting_life.gd';s=f.read_text();needle='"visit":visit';addition=needle
for source in ['clocks','seats','needs']:addition+=',"_owner_'+source+'":world.facts.get("waiting_life",{}).get("'+source+'",{}).get(str(visit.get("id","")),{})'
assert s.count(needle)>0;s=s.replace(needle,addition);f.write_text(s)
m=json.loads((b/'manifest.json').read_text());patch=[]
for rel,rec in m['files'].items():
 orig=(b/'original'/rel).read_text();text=(p/rel).read_text();restored=text.replace('\n\nconst _WH = preload("res://tools/performance/current/waiting_hot_observer.gd")','',1)
 restored=re.sub(r'^func (\w+)\(([^\n]*)\) -> ([^:\n]+):\n\tif not \([^\n]+\):\n.*?\nfunc _wh_original_\1\(',lambda q:'func '+q[1]+'(',restored,flags=re.M|re.S)
 assert restored==orig,rel
 rec['observer_sha256']=sha(p/rel);patch+=list(difflib.unified_diff(orig.splitlines(True),text.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
(b/'observer.patch').write_text(''.join(patch))
r=b/'REVIEW.md';r.write_text(r.read_text()+'''\n## Metadata correction before execution\n\nSummary includes ok, remaining_ticks, queued_ticks, start_ticks, retry_tick and related optional timing fields. These files use started_tick + configured seek_seconds for the need deadline, not a persisted retry_tick; no fabricated deadline is added. Existing actual deadline parameters are recorded where passed. For methods already holding visit, before/after context directly reads waiting_life.clocks/seats/needs by that visit's existing id, copying only the same small scalar summaries. No lookup method or full-World scan occurs. A deleted record becomes empty rather than retaining a stale argument-only view. Methods without visit inherit the nearest visit owner through parent links; no reverse actor→visit search is introduced.\n\nExclusive is specifically body_raw minus measured direct-child wrapper spans, not net production self CPU. Active gates, tiny post-F propagation and return overhead remain parent residual. Root flush remains part of outer step time.\n''')
m.update(helper_sha256=sha(h),patch_sha256=sha(b/'observer.patch'),prepare_sha256=sha(prep),review_sha256=sha(r),correction_sha256=sha(Path(__file__)))
(b/'manifest.json').write_text(json.dumps(m,indent=2));print('manifest',sha(b/'manifest.json'),'inverse PASS; no engine')
