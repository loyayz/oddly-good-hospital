from pathlib import Path
import shutil,json,hashlib,re,difflib,subprocess
B=Path(__file__).resolve().parent; ROOT=B.parent; P=ROOT/'waiting-boundary-plain-20261112'; R=ROOT/'oddly-good-hospital-cloud-recovery-20261112'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert subprocess.check_output(['git','-C',str(R),'rev-parse','HEAD'],text=True).strip()=='2220eb7a2f5c826aac89bb1ff7b9348b8dafe786'
identity=json.loads((P/'identity.json').read_text()); project=B/'project'
assert not project.exists();shutil.copytree(P/'project',project)
for rel,h in identity['inventory'].items(): assert sha(project/rel)==h,rel
shutil.copy2(P/'input.bin',B/'input.bin');shutil.copy2(P/'dependency-linux_guard_v2.py',B/'linux_guard_v2.py')
helper='''extends RefCounted
# Read-only observational state. No World/service query or retained business container.
static var stack: Array = []
static var rows: Array = []
static var serial: int = 0

static func active() -> bool:
\treturn not stack.is_empty()

static func summary(value: Variant) -> Variant:
\tif value is Dictionary:
\t\tvar out: Dictionary = {"size":value.size()}
\t\tfor key: String in ["id","actor_id","visit_id","ticket_id","facility_id","phase","purpose","public_purpose","mode","deadline","deadline_tick","started_tick","arrived_tick","next_need_tick","floor_id","travel_ticks","reason","code","accepted","reachable","cost","request_id","waiting_reason","kind","status","ok","remaining_ticks","queued_ticks","retry_tick","next_retry_tick","recheck_tick","next_check_tick","next_scan_tick","start_ticks","sequence","next_purpose"]:
\t\t\tif value.has(key) and (value[key] == null or typeof(value[key]) in [TYPE_BOOL,TYPE_INT,TYPE_FLOAT,TYPE_STRING]): out[key]=value[key]
\t\tfor key: String in ["cell","target","area"]:
\t\t\tif value.has(key):
\t\t\t\tvar item: Variant = value[key]
\t\t\t\tif item is Array and item.size()<=3: out[key]=item.duplicate()
\t\t\t\telif item is Dictionary: out[key]=summary(item)
\t\treturn out
\tif value is Array: return {"array_size":value.size()}
\tif value == null or typeof(value) in [TYPE_BOOL,TYPE_INT,TYPE_FLOAT,TYPE_STRING]: return value
\treturn {"type":typeof(value)}

static func context(values: Dictionary) -> Dictionary:
\tvar out: Dictionary = {}
\tfor key: String in values: out[key]=summary(values[key])
\treturn out

static func begin(label: String, tick: int, values: Dictionary, entered: int) -> Dictionary:
\tserial+=1
\tvar frame: Dictionary = {"id":serial,"parent":0 if stack.is_empty() else stack.back().id,"label":label,"world_tick":tick,"output_tick":tick+1,"before":context(values),"entered_us":entered,"child_wrapper_us":0,"descendant_handler_us":0}
\tstack.append(frame)
\tframe.body_start_us=Time.get_ticks_usec()
\treturn frame

static func finish(frame: Dictionary, values: Dictionary, result: Variant, body_end: int) -> void:
\tassert(stack.back()==frame)
\tframe.body_end_us=body_end
\tframe.after=context(values)
\tframe.result=summary(result)
\tframe.inclusive_raw_us=body_end-int(frame.body_start_us)
\tframe.exclusive_us=int(frame.inclusive_raw_us)-int(frame.child_wrapper_us)
\tframe.inclusive_less_descendant_handler_us=int(frame.inclusive_raw_us)-int(frame.descendant_handler_us)
\tstack.pop_back()
\trows.append(frame)
\tvar finished: int = Time.get_ticks_usec()
\tframe.wrapper_us=finished-int(frame.entered_us)
\tframe.own_handler_us=int(frame.body_start_us)-int(frame.entered_us)+finished-body_end
\tif not stack.is_empty():
\t\tstack.back().child_wrapper_us+=int(frame.wrapper_us)
\t\tstack.back().descendant_handler_us+=int(frame.own_handler_us)+int(frame.descendant_handler_us)
\telse:
\t\tvar flush_start: int = Time.get_ticks_usec()
\t\tvar path: String = "user://waiting-hot.ndjson"
\t\tvar file: FileAccess = FileAccess.open(path,FileAccess.READ_WRITE if FileAccess.file_exists(path) else FileAccess.WRITE)
\t\tassert(file!=null)
\t\tfile.seek_end()
\t\tfor row: Dictionary in rows: file.store_line(JSON.stringify(row))
\t\tfile.close()
\t\trows.clear()
\t\tprint("WAITING_OBSERVER_FLUSH world_tick=",frame.world_tick," elapsed_us=",Time.get_ticks_usec()-flush_start," path=",ProjectSettings.globalize_path(path))
'''
hp=project/'tools/performance/current/waiting_hot_observer.gd';hp.write_text(helper)
plans={
'game/life/waiting_life.gd':['dispatch','ensure','_dispatch_waiting','_dispatch_safety_wait','_dispatch_clinic_wait','_dispatch_public_seat','_begin_need','_dispatch_need','_dispatch_toilet_need','_dispatch_public_need','_public_need_choices','_facility_quote','_facility_quote_in_query','_wait_safely','_start_fallback','_complete_need','_wait_need','_release_seat','_request_need_move','_request_seat_move'],
'game/life/toilet_queue.gd':['observe'],
'game/life/public_areas.gd':['begin_wait_observation','end_wait_observation','select','arrival_point','waiting_point','safe_wait','current_area','should_recheck'],
'game/building/hospital_space.gd':['facility_quote','route_cost','begin_dynamic_route_query']}
records=[];patch=[]
for rel,names in plans.items():
 p=project/rel;original=p.read_text();text=original
 for name in names:
  pat=re.compile(r'^func '+re.escape(name)+r'\((.*)\) -> ([^:]+):$',re.M); matches=list(pat.finditer(text));assert len(matches)==1,(rel,name)
  m=matches[0]; params=m[1];ret=m[2];parts=re.split(r', (?=[A-Za-z_]\w*\s*:)',params) if params else [];args=[x.split(':',1)[0].strip() for x in parts];call='_wh_original_'+name+'('+', '.join(args)+')'
  root=rel.endswith('waiting_life.gd') and name=='dispatch';gate='world.sim_tick>=2881 and world.sim_tick<=2885' if root else '_WH.active()'
  vals=[a for a in args if a not in ['world','actor_index','geometry','fallback','selected_entries']];context='{'+','.join(json.dumps(a)+':'+a for a in vals)+'}'
  if "visit" in args and "world" in args:
   for source in ["clocks","seats","needs"]: context=context[:-1]+',"_owner_'+source+'":world.facts.get("waiting_life",{}).get("'+source+'",{}).get(str(visit.get("id","")),{})}'
  if ret=='void':disabled='\t\t'+call+'\n\t\treturn';body='\t'+call;result='null';ending=''
  else:disabled='\t\treturn '+call;body='\tvar _wh_result: '+ret+' = '+call;result='_wh_result';ending='\n\treturn _wh_result'
  tick='world.sim_tick' if 'world' in args else 'int(_WH.stack.back().world_tick)'
  wrapper=m[0]+'\n\tif not ('+gate+'):\n'+disabled+'\n\tvar _wh_entered: int = Time.get_ticks_usec()\n\tvar _wh_frame: Dictionary = _WH.begin('+json.dumps(rel+':'+name)+','+tick+','+context+',_wh_entered)\n'+body+'\n\tvar _wh_end: int = Time.get_ticks_usec()\n\t_WH.finish(_wh_frame,'+context+','+result+',_wh_end)'+ending+'\n\n'
  renamed=m[0].replace('func '+name+'(', 'func _wh_original_'+name+'(')
  text=text[:m.start()]+wrapper+renamed+text[m.end():]
  records.append({'file':rel,'function':name,'root':root,'args':args,'return':ret,'wrapper':wrapper,'renamed':renamed,'original_header':m[0]})
 text=text.replace('extends RefCounted','extends RefCounted\n\nconst _WH = preload("res://tools/performance/current/waiting_hot_observer.gd")',1)
 # Mechanical inversion proves every original body/return/call remains byte-for-byte.
 restored=text.replace('\n\nconst _WH = preload("res://tools/performance/current/waiting_hot_observer.gd")','',1)
 for r in reversed([r for r in records if r['file']==rel]):restored=restored.replace(r['wrapper']+r['renamed'],r['original_header'],1)
 assert restored==original,rel
 (B/'original'/rel).parent.mkdir(parents=True,exist_ok=True);(B/'original'/rel).write_bytes(p.read_bytes());p.write_text(text)
 patch+=list(difflib.unified_diff(original.splitlines(True),text.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
(B/'observer.patch').write_text(''.join(patch));(B/'scope.json').write_text(json.dumps([{k:v for k,v in r.items() if k not in ['wrapper','renamed','original_header']} for r in records],indent=2))
files={rel:{'original_sha256':sha(B/'original'/rel),'observer_sha256':sha(project/rel)} for rel in plans}
manifest={'head':identity['head'],'runtime':identity['runtime'],'plain_inventory_source':str(P/'identity.json'),'plain_identity_sha256':sha(P/'identity.json'),'input_sha256':sha(B/'input.bin'),'files':files,'helper_sha256':sha(hp),'patch_sha256':sha(B/'observer.patch'),'guard_sha256':sha(B/'linux_guard_v2.py'),'mechanical_inverse_pass':True,'engine_started':False,'window_world':[2881,2885],'window_output':[2882,2886],'prefix_steps':1000,'sample_steps':1253,'function_count':len(records)}
(B/'manifest.json').write_text(json.dumps(manifest,indent=2));print(json.dumps(manifest,indent=2))
