# Waiting hot-boundary observer, prepared only

No engine, parser, import, test or replay has been run by this preparer. The GDScript remains subject to validator parser qualification. No checkout files changed.

## Exact history and isolation

Copied the current plain project's entire prepared runtime, verified every entry against its immutable identity inventory, then instrumented four files only. HEAD provenance is 2220eb7a2f5c826aac89bb1ff7b9348b8dafe786; native and engine identities are inherited in manifest.json (the nested runtime's older source_gameplay_commit is runtime provenance, NOT this source revision). Original files are in original/. Added helper is tools/performance/current/waiting_hot_observer.gd. The project copy is NOT hardlinked. Restore by copying original/ files over the corresponding project paths and removing the helper; no repo restoration is needed.

Use original input.bin with prefix=1000 and sample=1253; do not move command submission. Window dispatch world.sim_tick=2881..2885 corresponds to output ticks 2882..2886. Nonwaiting and earlier-history calls pass through, without timer/context/output. They do have wrapper call and cheap enabled-check overhead; this is not literally zero observer overhead and is not an acceptance timing run.

## Scope and owner attribution

scope.json lists 32 wrappers. Waiting dispatch root: ensure, toilet observe, public begin/end observation; waiting lifecycle dispatch, safety, clinic/public seat, need begin/dispatch/toilet/public, need choices, facility quote inner/outer, wait/fallback/complete/release and request move. Nested public area select/arrival_point/waiting_point/safe_wait/current_area/should_recheck, space facility_quote/route_cost/begin_dynamic_route_query are counted and timed only while the root is active. No all-library hooks or geometry cache probes.

Each invocation has monotonic ID and parent ID. The owner is the nearest ancestor with an actual visit/need/intent argument. Record summaries copy only existing scalar fields and short cell arrays, never call World active lists, quote, path, cache, navigation or other business query. Before/after arguments preserve actual phase, IDs, request and deadlines where present. Return summaries preserve selected scalar fields or array cardinality, NOT entire routes. These records identify actual callees and owner transitions, not every internal source branch. Any unexplained exclusive residual is reported as such, not assigned a hypothetical cause.

## Transformation / early returns

Every selected original function is renamed _wh_original_<name>. Its exact signature, defaults and body are otherwise unchanged. A same-signature wrapper calls the original exactly once, records the existing result, and returns it unchanged. Void functions return after the original. All original early returns are consequently covered without rewriting returns. Python inverse transformation was asserted byte-for-byte against all four originals. Nested self calls intentionally go through wrappers. No return-expression evaluation is duplicated. Runtime errors are not turned into successes; guard retains logs and stops owned engine.

## Timing definitions, not double-counted totals

E=wrapper timestamp before building context. S=after observer begin, immediately before original call. B=after original call returns, before exit context/result summarization. F=finish timestamp after row insertion.

- inclusive_raw_us = B-S, includes descendant instrumentation.
- wrapper_us = F-E.
- own_handler_us = (S-E)+(F-B).
- descendant_handler_us = sum of each direct child's own_handler_us + descendant_handler_us.
- inclusive_less_descendant_handler_us = inclusive_raw_us-descendant_handler_us. This is a corrected estimate, not clean production timing.
- exclusive_us = inclusive_raw_us-sum(direct child wrapper_us).

Never sum all inclusive rows. Group exclusive rows for partition-style attribution; use root inclusive for total context. Timer call/return and tiny post-F parent bookkeeping tails remain in enclosing exclusive time. They cannot be perfectly subtracted with this mechanism and are explicitly residual, not claimed exact business-only CPU time. Raw timestamps and components are retained to audit arithmetic.

Rows flush only after root has completed; JSON/file output is outside the root recorded interval, but still delays the real production step. WAITING_OBSERVER_FLUSH records its wall microseconds/path in engine.log. Do not remove that delay from the step log or claim an unaffected timing observation. No World freeze is taken in this minimal version, so no freeze perturbation or warm-cache checkpoint claim.

## Handoff (do not launch until assigned serial slot)

Validator may import linux_guard_v2.py, set PROJECT to this project, LIBRARY_PATH from manifest.runtime.library_path. Its run directory must not exist; guard creates fresh HOME/XDG_DATA_HOME/XDG_CONFIG_HOME/XDG_CACHE_HOME/TMPDIR with OMP_NUM_THREADS=1 and owns/reaps its process group. Use the manifest engine with:

    --headless --path <this project> --script res://tools/performance/current/plain_v4.gd -- --input=<this input.bin> --output=<fresh observer/result.json> --steps=1253 --prefix-steps=1000 --expected-scenario=mixed160-clinical-ops-v1 --require-coverage --worker-tasks=4 --main-thread-policy=app --observed-floor=1

Guard timeout 1800; allowed exits 0,1 because deliberately truncated benchmark may not meet full coverage. Collect user://waiting-hot.ndjson beneath that run's isolated XDG location (path printed). Compare complete final binary/World/RNG/ordered events to the current plain1000+1253 baseline, plus non-timing per-step facts. Qualification must succeed before behavioral inference. Binary equality with Windows or a previous input is NOT requested.

Before execution: verify all original-source hashes against baseline, observed hashes/helper/guard/input against manifest, copied .so and locked runtime hashes, and current engine idleness. After execution: inventory changes, retain all traces and logs; restore the isolated source files only after their observed copies/patch/identities are archived. No source production change or publication is authorized by this preparation.

## Metadata correction before execution

Summary includes ok, remaining_ticks, queued_ticks, start_ticks, retry_tick and related optional timing fields. These files use started_tick + configured seek_seconds for the need deadline, not a persisted retry_tick; no fabricated deadline is added. Existing actual deadline parameters are recorded where passed. For methods already holding visit, before/after context directly reads waiting_life.clocks/seats/needs by that visit's existing id, copying only the same small scalar summaries. No lookup method or full-World scan occurs. A deleted record becomes empty rather than retaining a stale argument-only view. Methods without visit inherit the nearest visit owner through parent links; no reverse actor→visit search is introduced.

Exclusive is specifically body_raw minus measured direct-child wrapper spans, not net production self CPU. Active gates, tiny post-F propagation and return overhead remain parent residual. Root flush remains part of outer step time.
