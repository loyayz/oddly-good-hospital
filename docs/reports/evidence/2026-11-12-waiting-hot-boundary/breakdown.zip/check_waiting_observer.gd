extends SceneTree
const Check0=preload("res://game/building/hospital_space.gd")
const Check1=preload("res://game/life/public_areas.gd")
const Check2=preload("res://game/life/toilet_queue.gd")
const Check3=preload("res://game/life/waiting_life.gd")
const Check4=preload("res://tools/performance/current/waiting_hot_observer.gd")
