from pathlib import Path
import json,hashlib,shutil,re,ast
B=Path('/workspace/scratch/6962cc21ddf3/waiting-fallback-breakdown-20261112');OLD=B.parent/'waiting-hot-boundary-observer-20261112';P=B.parent/'waiting-boundary-plain-20261112';R=B.parent/'oddly-good-hospital-cloud-recovery-20261112';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((B/'manifest.json').read_text());assert sha(B/'manifest.json')=='2013ca09e66ab7e479f38b5ed3f21e06c63d0f3a82fd6942b98040c7eae21f94'
for name,key in [('prepare_overlay.py','prepare_sha256'),('REVIEW.md','review_sha256'),('qualified-to-overlay.patch','qualified_delta_sha256'),('production-to-overlay.patch','full_patch_sha256')]:assert sha(B/name)==m[key]
for rel,h in m['files'].items():
 assert sha(B/'overlay'/rel)==h['overlay_sha256'];assert sha(OLD/'observed'/rel)==h['previous_observer_sha256']
 if h['production_sha256']:assert sha(R/rel)==h['production_sha256']
# Independently reverse measured floor body using exact recorded insertion strings.
source=(B/'overlay/game/life/public_areas.gd').read_text();detail=re.search(r'^func _wh_detail_floor_waiting_point.*?(?=^func _wh_floor_safe)',source,re.M|re.S)[0]
node=next(n for n in ast.parse((B/'prepare_overlay.py').read_text()).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='changes' for t in n.targets));changes=ast.literal_eval(node.value)
for a,b in reversed(changes):assert detail.count(b)==1;detail=detail.replace(b,a,1)
detail=detail.replace('func _wh_detail_floor_waiting_point(world: WorldState, actor_id: String, _wh_owner: Dictionary)','func floor_waiting_point(world: WorldState, actor_id: String)',1)
original=re.search(r'^func floor_waiting_point.*?(?=^func room_exit_point)',(R/'game/life/public_areas.gd').read_text(),re.M|re.S)[0];assert detail==original
# Reverse extra floor wrapper/detail/shims, leaving previous qualified observer exactly.
a=source.index('func floor_waiting_point(');z=source.index('func _wh_original_floor_waiting_point(',a);q=source.index('func _wh_detail_floor_waiting_point(',z);end=source.index('func room_exit_point(',q)
undone=source[:a]+source[z:q].replace('func _wh_original_floor_waiting_point(','func floor_waiting_point(',1)+source[end:];assert undone==(OLD/'observed/game/life/public_areas.gd').read_text()
text=(B/'overlay/game/life/toilet_queue.gd').read_text();a=text.index('func leave(');z=text.index('func _wh_original_leave(',a);undo=text[:a]+text[z:].replace('func _wh_original_leave(','func leave(',1);assert undo==(OLD/'observed/game/life/toilet_queue.gd').read_text()
# Verify prior qualified wrappers invert to production too.
scope=json.loads((OLD/'scope.json').read_text())
for rel in set(x['file'] for x in scope):
 text=(OLD/'observed'/rel).read_text().replace('\n\nconst _WH = preload("res://tools/performance/current/waiting_hot_observer.gd")','',1)
 for row in [x for x in scope if x['file']==rel]:
  name=row['function'];a=text.index('func '+name+'(');z=text.index('func _wh_original_'+name+'(',a);text=text[:a]+text[z:].replace('func _wh_original_'+name+'(','func '+name+'(',1)
 assert text==(R/rel).read_text()
prior=json.loads((P/'identity.json').read_text());project=B/'project';assert not project.exists();shutil.copytree(P/'project',project)
for rel,digest in prior['inventory'].items():assert sha(project/rel)==digest
for rel in m['files']:shutil.copy2(B/'overlay'/rel,project/rel)
shutil.copy2(P/'input.bin',B/'input.bin');assert sha(B/'input.bin')=='75f5e1d922f39f12382c0ceb74806bda0293251189f68a1ac158842f65fa78ca'
(B/'preparation-verification.json').write_text(json.dumps({'inverse_exact':True,'original_wrappers_inverse_exact':True,'plain_identity_sha256':sha(P/'identity.json'),'runtime':prior['runtime'],'input_sha256':sha(B/'input.bin')},indent=2)+'\n')
print('independent inverse/identity passed')
