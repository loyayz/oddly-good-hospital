extends SceneTree
func _initialize()->void:
 var args:PackedStringArray=OS.get_cmdline_user_args();var output:String=args[0];var rows:Array=[];var all_ok:bool=true
 for i:int in range(1,args.size()):
  var f:FileAccess=FileAccess.open(args[i],FileAccess.READ);var d:Dictionary=f.get_var(false);f.close()
  var before:Array=d.points_before;var after:Array=d.points_after;var sorted:Array=before.duplicate();var origin:Vector2=Vector2(float(d.origin[0]),float(d.origin[1]));var typed:bool=true
  for point:Variant in before:typed=typed and typeof(point)==TYPE_VECTOR2I
  for point:Variant in after:typed=typed and typeof(point)==TYPE_VECTOR2I
  sorted.sort_custom(func(a:Vector2i,b:Vector2i)->bool:
   var da:float=origin.distance_squared_to(Vector2(a));var db:float=origin.distance_squared_to(Vector2(b))
   return da<db if da!=db else a.y<b.y if a.y!=b.y else a.x<b.x)
  var counts:Dictionary={}
  for point:Vector2i in before:counts[point]=int(counts.get(point,0))+1
  for point:Vector2i in after:counts[point]=int(counts.get(point,0))-1
  var permutation:bool=not counts.values().any(func(v:int)->bool:return v!=0)
  var idx:int=0;var expect_reach:bool=false;var success:bool=false;var valid:bool=true;var safe_count:int=0;var reach_count:int=0;var safe_false:int=0
  for attempt:Dictionary in d.attempts:
   if success or idx>=after.size():valid=false;break
   var point:Vector2i=after[idx];valid=valid and attempt.cell==[point.x,point.y]
   if expect_reach:
    valid=valid and attempt.kind=="reach";reach_count+=1;success=attempt.result;expect_reach=false
    if not success:idx+=1
   else:
    valid=valid and attempt.kind=="safe";safe_count+=1
    if attempt.result:expect_reach=true
    else:safe_false+=1;idx+=1
  valid=valid and not expect_reach
  if success:valid=valid and d.returned=={"floor_id":d.floor_id,"cell":[after[idx].x,after[idx].y]}
  else:valid=valid and idx==after.size() and d.returned.is_empty()
  var actor:Dictionary=d.facts.actors[d.actor_id]
  var checks:Dictionary={"typed_vector2i":typed,"complete_permutation":permutation and before.size()==after.size(),"exact_original_comparator_order":sorted==after,"short_circuit_first_success":valid,"actual_actor_origin":actor.location.floor_id==d.floor_id and Vector2(float(actor.location.cell[0]),float(actor.location.cell[1]))==origin,"world2883":d.world_tick==2883 and d.facts.sim_tick==2883}
  var ok:bool=not checks.values().has(false);all_ok=all_ok and ok
  rows.append({"actor":d.actor_id,"points":before.size(),"safe_attempts":safe_count,"safe_false":safe_false,"reach_attempts":reach_count,"returned":d.returned,"checks":checks,"ok":ok})
 var file:FileAccess=FileAccess.open(output,FileAccess.WRITE);file.store_string(JSON.stringify({"ok":all_ok and rows.size()==6,"rows":rows,"scope":"Read-only Variant decode and pure sorting/attempt checks. No simulation, World construction, public-point or path query. Completeness of enumeration also depends on verified exact original loop."},"\t"));file.close();quit(0 if all_ok and rows.size()==6 else 1)
