# Minimal fallback breakdown overlay (prepared, NOT run)

HEAD e538da4d02df88dd40d944df5fc3bd334c641af6. Overlay only: copy the five relative paths under overlay/ onto a fresh isolated runtime with production source identity verified. Never apply this overlay to the repository. Preserve and reuse the already-qualified original input, runtime/dependencies, worker policy, prefix=1000 and sample=1253. Reuse existing plain final; no baseline rerun is required. Previous observer files were hash-checked against their final qualified manifest before copying. Production files match the previous observer's original-source hashes.

## Scope

Reuse the already-qualified waiting observer hierarchy and world 2881..2885 window. Add toilets.leave wrapper (all actual calls within waiting only). Add detailed floor_waiting_point only for world 2883 and actors bench_patient_0003, 0026, 0011, 0012, 0027, 0059. Outside that gate the unchanged original floor method runs. The six-actor set is diagnostic selection, never a business gate. No arbitrary candidate truncation, budget, sort change, geometry change, added query or workload reduction.

The detailed copy preserves the original method body except explicit measurement boundaries and the two boolean operand shims. Python inverse transformation proves the detailed body's enumeration, comparator, loop, early non-floor return, successful return and empty return are byte-for-byte the original after removing those exact additions. Original floor method is retained untouched (name only changed) for pass-through. New toilet wrapper calls original once, preserving all original void/early returns.

## Actual measured boundaries

- floor.enumerate: the original complete floor_plots iteration, original public-point predicate, and original points.append. No per-public-point wrapper/log. This includes actual preparation inside those calls, not a reconstructed scan.
- floor.sort: exactly the original points.sort_custom callback with actual origin, squared distances and y/x tie breaks.
- floor.candidate.safe and floor.candidate.reach: each invokes its original query once. Source expression remains `if _wh_floor_safe(...) and _wh_floor_reach(...):` so the original short-circuit is preserved; can_reach is never called after false safe_wait. Ordinary safe_wait nested rows are retained for hierarchy, not summed again as independent totals.
- toilets.leave: whole original call for explicit inclusion/exclusion.

Each floor frame records floor_id, exact floating origin, candidate_count, safe_attempts, reach_attempts, returned dictionary and corpus path. Trial rows and corpus attempts retain actual candidate cell, kind, bool and call frame ID with raw/exclusive timing. Do not assert why a query returned false beyond the original returned value.

## Complete actual input corpus

At each selected actual floor call, before original body work, call world.freeze() once. It is facts.duplicate(true), not a service query. Every fact, RNG fact and ownership field is preserved. The six-call set is duplicate-guarded: repeated invocation of an actor fails diagnostic setup rather than silently adding snapshots or changing the business workload. No World snapshot is taken per candidate.

Save one Variant binary per selected call under isolated user://floor-corpus-<frame>-<actor>.bin:

- facts: full pre-call factual World;
- actor_id, world_tick, parent_frame;
- floor_id and origin;
- points_before: complete original enumeration order, copied once before sort;
- points_after: complete sorted order, copied once after sort;
- attempts: actual short-circuited safe/reach call sequence and results;
- returned: actual unchanged method result.

Typed Vector2i points remain exact in Variant binary, avoiding JSON formatting changes. Input corpus is not a standalone benchmark command envelope, does not include the plain driver's external ordered-event list, and is NOT a runtime-cache snapshot. The outer plain final comparison remains responsible for complete facts/RNG/ordered-event qualification.

## Observer cost accounting and limitations

Freeze, point-array copies, per-attempt record append, and result serialization/write are separate observer-only child frames. In the existing finish routine these frames charge their entire measured wrapper interval to own_handler_us (descendant_handler_us reset to zero, because the interval already includes any descendant). Parent inclusive_less_descendant_handler_us therefore removes their measured total once, not both body and handler twice. Their raw rows remain available and must be classified as observer-only, not business when aggregating exclusive times.

Business spans retain the established raw inclusive, descendant-handler-adjusted estimate, and exclusive=body_raw minus measured direct-child wrapper intervals. Tiny active gates, frame creation/propagation/return tails remain enclosing residual. These are not perfect production self-CPU figures. Root row JSON flush still occurs outside root measured body but inside outer step and is separately printed. Freeze/serialization/copy can alter allocator/CPU-cache state; numerical subtraction cannot remove that perturbation. Report it prominently and compare this attribution to the prior capture, not as a new uninstrumented performance result.

## Review / qualification handoff

- qualified-to-overlay.patch is the minimal change from the previous qualified observer; production-to-overlay.patch gives complete provenance.
- manifest.json lists production, previous-observer and final-overlay hashes.
- prepare_overlay.py is the reproducible transformation with strict anchors and inverse-body assertion.
- Only Python preparation and read-only source checks executed. GDScript parsing and actual observer qualification are pending.
- Validator owns engine slot and must perform parser qualification before the one observer replay. Use fresh isolated HOME/XDG/TMP and existing owned-process guard.
- Compare complete final binary to existing plain final, plus non-timing step facts. Check exact six corpus files/actors at world2883; candidate cardinality/order and short-circuit trial consistency; capture row counts; no errors. Retain all raw files and handler costs.
- No commit, publication, engine, test, baseline replay or checkout instrumentation was performed by this preparation.
