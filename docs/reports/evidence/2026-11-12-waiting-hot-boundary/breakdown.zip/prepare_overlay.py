from pathlib import Path
import json,hashlib,subprocess,difflib,re
B=Path(__file__).resolve().parent;O=B/'overlay';ROOT=B.parent;R=ROOT/'oddly-good-hospital-cloud-recovery-20261112';OLD=ROOT/'waiting-hot-boundary-observer-20261112'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert subprocess.check_output(['git','-C',str(R),'rev-parse','HEAD'],text=True).strip()=='e538da4d02df88dd40d944df5fc3bd334c641af6'
oldmanifest=json.loads((OLD/'manifest.json').read_text())
for rel,v in oldmanifest['files'].items():
 assert sha(R/rel)==v['original_sha256'],rel
 src=OLD/'observed'/rel;assert sha(src)==v['observer_sha256'],rel
 dst=O/rel;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(src.read_bytes())
helper_rel='tools/performance/current/waiting_hot_observer.gd';src=OLD/'observed'/helper_rel;assert sha(src)==oldmanifest['helper_sha256']
helper=src.read_text(); needle='\tif not stack.is_empty():\n\t\tstack.back().child_wrapper_us'
assert helper.count(needle)==1
helper=helper.replace(needle,'\tif frame.get("observer_only",false):\n\t\tframe.own_handler_us=frame.wrapper_us\n\t\tframe.descendant_handler_us=0\n'+needle)
helper+='''
# Six full factual inputs only, never service/cache snapshots.
static var floor_inputs: Dictionary = {}
static var captured_actors: Dictionary = {}
const FLOOR_ACTORS: Array[String] = ["bench_patient_0003","bench_patient_0026","bench_patient_0011","bench_patient_0012","bench_patient_0027","bench_patient_0059"]

static func detail_floor(tick: int, actor_id: String) -> bool:
\treturn active() and tick==2883 and actor_id in FLOOR_ACTORS

static func observer_begin(label: String, tick: int) -> Dictionary:
\tvar frame: Dictionary=begin(label,tick,{},Time.get_ticks_usec())
\tframe.observer_only=true
\treturn frame

static func floor_capture(world: Variant, actor_id: String, owner: Dictionary) -> void:
\tvar frame: Dictionary=observer_begin("observer.floor.freeze",world.sim_tick)
\tassert(not captured_actors.has(actor_id))
\tcaptured_actors[actor_id]=true
\tfloor_inputs[owner.id]={"facts":world.freeze(),"actor_id":actor_id,"world_tick":world.sim_tick,"parent_frame":owner.id,"attempts":[]}
\tfinish(frame,{},null,Time.get_ticks_usec())

static func floor_points(owner: Dictionary, key: String, points: Array, floor_id: int, origin: Vector2) -> void:
\tvar frame: Dictionary=observer_begin("observer.floor.copy_"+key,int(owner.world_tick))
\tfloor_inputs[owner.id][key]=points.duplicate()
\tfloor_inputs[owner.id].floor_id=floor_id
\tfloor_inputs[owner.id].origin=[origin.x,origin.y]
\towner.candidate_count=points.size()
\towner.floor_id=floor_id
\towner.origin=[origin.x,origin.y]
\tfinish(frame,{},null,Time.get_ticks_usec())

static func floor_attempt(owner: Dictionary, kind: String, cell: Array, result: bool, call_frame: Dictionary) -> void:
\tvar frame: Dictionary=observer_begin("observer.floor.record_attempt",int(owner.world_tick))
\tfloor_inputs[owner.id].attempts.append({"kind":kind,"cell":cell.duplicate(),"result":result,"frame_id":call_frame.id,"inclusive_raw_us":call_frame.inclusive_raw_us,"exclusive_us":call_frame.exclusive_us})
\towner[kind+"_attempts"]=int(owner.get(kind+"_attempts",0))+1
\tfinish(frame,{},null,Time.get_ticks_usec())

static func floor_save(owner: Dictionary, result: Dictionary) -> void:
\tvar frame: Dictionary=observer_begin("observer.floor.serialize_write",int(owner.world_tick))
\tvar payload: Dictionary=floor_inputs[owner.id]
\tpayload.returned=result.duplicate(true)
\tvar path: String="user://floor-corpus-"+str(owner.id)+"-"+str(payload.actor_id)+".bin"
\tvar file: FileAccess=FileAccess.open(path,FileAccess.WRITE)
\tassert(file!=null)
\tfile.store_var(payload)
\tfile.close()
\towner.corpus_path=ProjectSettings.globalize_path(path)
\tfloor_inputs.erase(owner.id)
\tfinish(frame,{},null,Time.get_ticks_usec())
'''
h=O/helper_rel;h.parent.mkdir(parents=True,exist_ok=True);h.write_text(helper)
# Original floor function remains the complete non-observed direct path.
rel='game/life/public_areas.gd';p=O/rel;s=p.read_text();match=re.search(r'^func floor_waiting_point\(.*?(?=^func room_exit_point)',s,re.M|re.S);assert match
original=match[0];detail=original.replace('func floor_waiting_point(world: WorldState, actor_id: String)', 'func _wh_detail_floor_waiting_point(world: WorldState, actor_id: String, _wh_owner: Dictionary)',1)
changes=[
 ('\tfor plot: Array in HospitalSpace.floor_plots(world,floor_id):','\tvar _wh_enum: Dictionary=_WH.begin("floor.enumerate",world.sim_tick,{},Time.get_ticks_usec())\n\tfor plot: Array in HospitalSpace.floor_plots(world,floor_id):'),
 ('\tpoints.sort_custom(', '\t_WH.finish(_wh_enum,{},null,Time.get_ticks_usec())\n\t_WH.floor_points(_wh_owner,"points_before",points,floor_id,origin)\n\tvar _wh_sort: Dictionary=_WH.begin("floor.sort",world.sim_tick,{},Time.get_ticks_usec())\n\tpoints.sort_custom('),
 ('\tfor point: Vector2i in points:', '\t_WH.finish(_wh_sort,{},null,Time.get_ticks_usec())\n\t_WH.floor_points(_wh_owner,"points_after",points,floor_id,origin)\n\tfor point: Vector2i in points:'),
 ('if safe_wait(world,actor_id,floor_id,cell) and space.can_reach(world,actor_id,floor_id,cell):', 'if _wh_floor_safe(world,actor_id,floor_id,cell,_wh_owner) and _wh_floor_reach(world,actor_id,floor_id,cell,_wh_owner):')]
for a,b in changes:assert detail.count(a)==1;detail=detail.replace(a,b)
restored=detail
for a,b in reversed(changes):restored=restored.replace(b,a,1)
restored=restored.replace('func _wh_detail_floor_waiting_point(world: WorldState, actor_id: String, _wh_owner: Dictionary)','func floor_waiting_point(world: WorldState, actor_id: String)',1);assert restored==original
wrapper='''func floor_waiting_point(world: WorldState, actor_id: String) -> Dictionary:
\tif not _WH.detail_floor(world.sim_tick,actor_id): return _wh_original_floor_waiting_point(world,actor_id)
\tvar frame: Dictionary=_WH.begin("game/life/public_areas.gd:floor_waiting_point",world.sim_tick,{"actor_id":actor_id},Time.get_ticks_usec())
\t_WH.floor_capture(world,actor_id,frame)
\tvar result: Dictionary=_wh_detail_floor_waiting_point(world,actor_id,frame)
\t_WH.floor_save(frame,result)
\t_WH.finish(frame,{"actor_id":actor_id},result,Time.get_ticks_usec())
\treturn result

'''
trials=''
for kind,call in [('safe','safe_wait'),('reach','space.can_reach')]:
 trials+=f'''func _wh_floor_{kind}(world: WorldState, actor_id: String, floor_id: int, cell: Array, owner: Dictionary) -> bool:
\tvar frame: Dictionary=_WH.begin("floor.candidate.{kind}",world.sim_tick,{{"actor_id":actor_id,"floor_id":floor_id,"cell":cell}},Time.get_ticks_usec())
\tvar result: bool={call}(world,actor_id,floor_id,cell)
\t_WH.finish(frame,{{}},result,Time.get_ticks_usec())
\t_WH.floor_attempt(owner,"{kind}",cell,result,frame)
\treturn result

'''
s=s[:match.start()]+wrapper+original.replace('func floor_waiting_point(', 'func _wh_original_floor_waiting_point(',1)+detail+trials+s[match.end():];p.write_text(s)
# Toilet release is measured as a whole; all original early returns remain.
rel='game/life/toilet_queue.gd';p=O/rel;s=p.read_text();header='func leave(world: WorldState, actor_id: String) -> void:';assert s.count(header)==1
wrapper='''func leave(world: WorldState, actor_id: String) -> void:
\tif not _WH.active():
\t\t_wh_original_leave(world,actor_id)
\t\treturn
\tvar frame: Dictionary=_WH.begin("game/life/toilet_queue.gd:leave",world.sim_tick,{"actor_id":actor_id},Time.get_ticks_usec())
\t_wh_original_leave(world,actor_id)
\t_WH.finish(frame,{"actor_id":actor_id},null,Time.get_ticks_usec())

''';s=s.replace(header,wrapper+header.replace('func leave(','func _wh_original_leave('));p.write_text(s)
manifest={'head':'e538da4d02df88dd40d944df5fc3bd334c641af6','baseline':'reuse waiting-boundary-plain-20261112 final; do not rerun','prefix_steps':1000,'sample_steps':1253,'old_observer_manifest_sha256':sha(OLD/'manifest.json'),'prepare_sha256':sha(Path(__file__)),'engine_run':False,'floor_body_inverse_verified':True,'short_circuit_preserved':True,'files':{}}
patch=[];delta=[]
for f in sorted(O.rglob('*.gd')):
 rel=str(f.relative_to(O));original=(R/rel).read_text() if (R/rel).exists() else '';prev=(OLD/'observed'/rel).read_text() if (OLD/'observed'/rel).exists() else ''
 manifest['files'][rel]={'production_sha256':sha(R/rel) if (R/rel).exists() else None,'previous_observer_sha256':sha(OLD/'observed'/rel) if (OLD/'observed'/rel).exists() else None,'overlay_sha256':sha(f)}
 patch+=list(difflib.unified_diff(original.splitlines(True),f.read_text().splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
 delta+=list(difflib.unified_diff(prev.splitlines(True),f.read_text().splitlines(True),fromfile='qualified/'+rel,tofile='overlay/'+rel))
(B/'production-to-overlay.patch').write_text(''.join(patch));(B/'qualified-to-overlay.patch').write_text(''.join(delta));(B/'manifest.json').write_text(json.dumps(manifest,indent=2));print({'manifest_sha256':sha(B/'manifest.json'),'files':len(manifest['files']),'inverse':True,'engine':False})
