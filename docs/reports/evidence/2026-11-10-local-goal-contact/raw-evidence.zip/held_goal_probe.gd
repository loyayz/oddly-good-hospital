extends SceneTree
func _initialize() -> void:call_deferred("_run")
func _run() -> void:
	var args: PackedStringArray=OS.get_cmdline_user_args()
	var content:=HospitalContent.new()
	var suite: RefCounted=load("res://tests/acceptance/space.gd").new();suite.content=content
	var sim: HospitalSimulation=suite._fixture()
	suite._add_actor(sim,"walker","S49",[40,70])
	suite._add_actor(sim,"blocker","S49",[43,70])
	var validation: String=sim.world.validate(content)
	var request: String=sim.space.request_move(sim.world,"walker",1,[43,70])
	var probe: RefCounted=load("res://tests/acceptance/movement_detour.gd").new()
	var errors: Array=[]
	var positions: Array=[]
	var locals: Array=[]
	for tick: int in 60:
		var error: String=probe._tick(suite,sim,["walker","blocker"])
		if not error.is_empty():errors.append(error);break
		if tick>=25:positions.append(sim.world.facts.actors.walker.location.cell.duplicate());locals.append(sim.world.facts.moves.get("walker",{}).get("local_move",{}).duplicate(true))
	var stable: bool=not positions.is_empty() and positions.all(func(p: Array)->bool:return p==positions[0])
	var release: String=sim.space.request_move(sim.world,"blocker",1,[43,67])
	for tick: int in 150:
		var error: String=probe._tick(suite,sim,["walker","blocker"])
		if not error.is_empty():errors.append(error);break
		if sim.world.facts.moves.is_empty():break
	var arrived: bool=sim.space.at(sim.world,"walker",1,[43,70]) and sim.space.at(sim.world,"blocker",1,[43,67]) and sim.world.facts.moves.is_empty()
	var result: Dictionary={"ok":validation.is_empty() and request.is_empty() and release.is_empty() and stable and arrived and errors.is_empty(),"initial_validation":validation,"errors":errors,"held_stable":stable,"both_arrived_after_real_release":arrived,"held_positions":positions,"local_intents":locals,"final_validation":sim.world.validate(content)}
	FileAccess.open(args[0],FileAccess.WRITE).store_string(JSON.stringify(result,"\t"))
	print(JSON.stringify({"stable":stable,"arrived":arrived,"errors":errors,"validation":validation}))
	sim.dispose();quit(0 if result.ok else 1)
