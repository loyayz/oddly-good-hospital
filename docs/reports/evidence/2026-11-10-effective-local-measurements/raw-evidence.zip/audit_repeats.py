"""Read-only independent audit of the three completed 30056f3 measurements."""
import hashlib
import json
import math
from pathlib import Path
import statistics
import subprocess


HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[1]
import sys
RUNS = Path(sys.argv[1]).resolve()


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def audit_run(number):
    stem = RUNS / f"r{number}.json"
    result = read(stem)
    assert result["complete"] and not result["errors"]
    assert result["all_completed_steps"] == 3000
    rows = [json.loads(line) for line in Path(str(stem) + ".steps.ndjson").read_text(encoding="utf-8").splitlines()]
    assert len(rows) == 6000
    samples = []
    for index in range(3000):
        enter, end = rows[index * 2:index * 2 + 2]
        assert enter["kind"] == "enter" and enter["index"] == index
        assert end["kind"] == "complete" and end["sample"]["index"] == index
        sample = end["sample"]
        assert enter["tick"] + 1 == sample["tick"] == result["initial"]["tick"] + index + 1
        if index >= 1000:
            samples.append(sample)
    elapsed = sorted(row["elapsed_us"] for row in samples)
    metrics = result["metrics"]
    assert len(elapsed) == metrics["count"] == 2000
    assert sum(elapsed) == metrics["sum_step_us"]
    assert statistics.mean(elapsed) == metrics["mean_step_us"]
    assert elapsed[-1] == metrics["max_us"]
    for percentile in [50, 95, 99]:
        assert elapsed[math.ceil(len(elapsed) * percentile / 100) - 1] == metrics[f"p{percentile}_us"]
    assert metrics["real_window_us_including_observation"] - sum(elapsed) == metrics["observation_logging_and_loop_wall_us"]
    assert metrics["observation_logging_and_loop_wall_us"] >= 0
    stage = read(Path(str(stem) + ".stages.json"))
    assert not stage["errors"] and stage["step_records_complete"]
    assert stage["steps"] == stage["complete_steps"] == 2000 and stage["incomplete_steps"] == 0
    assert len(stage["step_records"]) == 2000 and stage["partition_check_us"] == 0
    assert stage["profiled_whole_us"] == sum(elapsed)
    collected = {}
    for raw, item in zip(samples, stage["step_records"], strict=True):
        assert item["complete"] and item["tick"] == raw["tick"]
        assert item["outer_elapsed_us"] == raw["elapsed_us"]
        total = sum(value["total_us"] for value in item["stages"].values())
        assert total == item["root_stage_us"]
        assert total + item["observer_handler_us"] + item["residual_us"] == raw["elapsed_us"]
        assert item["residual_us"] >= 0 and item["observer_handler_us"] >= 0
        for name, value in item["stages"].items():
            previous = collected.setdefault(name, {"calls": 0, "total_us": 0, "max_us": 0})
            previous["calls"] += value["calls"]
            previous["total_us"] += value["total_us"]
            previous["max_us"] = max(previous["max_us"], value["max_us"])
    for entry in stage["root_stages"]:
        assert collected[entry["name"]] == {key: entry[key] for key in ["calls", "total_us", "max_us"]}
    assert sum(x["total_us"] for x in collected.values()) == stage["disjoint_root_stage_us"]
    assert sha(Path(str(stem) + ".final.bin")) == result["final_sha256"]
    execution = read(Path(str(stem) + ".execution.json"))
    policy = execution["main_thread_policy"]
    assert policy["applied"] and policy["reason"] == "performance_cores" and policy["error"] == 0
    assert policy["hybrid"] and policy["group"] == 0 and policy["mask_hex"] == "fc03"
    worker = execution["worker_samples"]
    assert execution["worker_tasks"] == 4 and execution["profile_stages"]
    assert worker["batches"] == 3000 and worker["jobs"] == 12000 and worker["failed_batches"] == 0
    assert worker["processed"] == worker["consumed"] and worker["coverage_fallback_calls"] == 0
    assert worker["last_batch"]["ok"] and worker["last_batch"]["all_results_consumed"]
    assert len(worker["last_batch"]["jobs"]) == 4
    assert len(worker["threads"]) > 1
    assert all(job["thread_id"] != worker["last_batch"]["main_thread_id"] for job in worker["last_batch"]["jobs"])
    assert not read(RUNS / f"r{number}.processes-before.json")
    log = (RUNS / f"r{number}.log").read_text(encoding="utf-8")
    assert "SCRIPT ERROR:" not in log and not any(line.startswith("ERROR:") for line in log.splitlines())
    slow = []
    for item in sorted(stage["step_records"], key=lambda row: row["outer_elapsed_us"], reverse=True)[:10]:
        ranked = sorted(item["stages"].items(), key=lambda pair: pair[1]["total_us"], reverse=True)[:3]
        slow.append({"tick": item["tick"], "whole_us": item["outer_elapsed_us"],
                     "largest_stages_us": {name: value["total_us"] for name, value in ranked}})
    return {"repeat": number, "raw_steps": 3000, "sample_steps": 2000, "metrics": metrics,
            "initialization_us": result["initialization_us"], "prefix_wall_us": result["prefix_wall_us"],
            "floor_static_preparation": result["floor_static_preparation"],
            "initial": result["initial"]["population"], "sample_start": result["sample_start_population"],
            "final": result["final"]["population"], "business": result["sample_business"],
            "final_sha256": result["final_sha256"], "main_thread_policy": policy,
            "workers": {key: worker[key] for key in ["batches", "jobs", "processed", "consumed", "failed_batches", "coverage_distinct_lookups", "coverage_native_calls", "coverage_fallback_calls"]},
            "worker_thread_ids": sorted(worker["threads"], key=int),
            "stages": [{"name": entry["name"], "mean_us": entry["total_us"] / 2000,
                        "share": entry["total_us"] / sum(elapsed), "max_us": entry["max_us"]} for entry in stage["root_stages"]],
            "observer_handler_us": stage["observer_handler_us"], "residual_us": stage["residual_us"],
            "nonblocking_invocations": sorted(set(item["nonblocking_invocations"] for item in stage["step_records"])),
            "slowest_steps": slow}


protocol=read(RUNS / "protocol.json")
assert protocol["prefix_steps"]==1000 and protocol["sample_steps"]==2000 and protocol["repeats"]==3
assert protocol["input_sha256"]=="ce56591c43fe1704abf76348dd5e67b0eae2a599143c03e045a780439a1bc15c"
assert read(RUNS / "status.json")["state"]=="complete"
rows=[audit_run(i) for i in range(1,4)]
assert all(r["final_sha256"]==rows[0]["final_sha256"] and r["business"]==rows[0]["business"] for r in rows)
source=read(RUNS / "source-identity.json")
head=subprocess.check_output(["git","-C",str(PROJECT),"rev-parse","HEAD"],text=True).strip()
current_checked=head==protocol["commit"] and subprocess.run(["git","-C",str(PROJECT),"diff","--quiet","HEAD","--"]).returncode==0
if current_checked:
    assert all(sha(PROJECT / n)==h for n,h in source.items())
values=[]
for i in range(1,4):
    for line in (RUNS / f"r{i}.json.steps.ndjson").read_text(encoding="utf-8").splitlines():
        r=json.loads(line)
        if r["kind"]=="complete" and r["sample"]["index"]>=1000:values.append(r["sample"]["elapsed_us"])
values.sort()
result={"verified":True,"commit":protocol["commit"],"source_count":len(source),"current_source_rechecked":current_checked,"controller_source_freeze_complete":True,"raw_steps":9000,"samples":6000,"pooled_mean_us":statistics.mean(values),"pooled_p95_us":values[math.ceil(len(values)*.95)-1],"pooled_p99_us":values[math.ceil(len(values)*.99)-1],"runs":rows}
with (RUNS / "raw-audit.json").open("x",encoding="utf-8") as f:json.dump(result,f,ensure_ascii=False,indent=2)
print(json.dumps({k:v for k,v in result.items() if k!="runs"},ensure_ascii=False))
