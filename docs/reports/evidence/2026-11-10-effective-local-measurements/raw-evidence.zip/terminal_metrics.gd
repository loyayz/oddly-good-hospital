extends SceneTree

func _initialize() -> void:
	var args: PackedStringArray=OS.get_cmdline_user_args()
	var input: FileAccess=FileAccess.open(args[1],FileAccess.READ)
	var envelope: Dictionary=input.get_var(false)
	input.close()
	var facts: Dictionary=envelope.facts
	var end: int=int(facts.sim_tick)
	var start: int=end-2000
	var events: Dictionary={}
	var departures: Array=[]
	var outcomes: Dictionary={}
	for event: Dictionary in envelope.events:
		var tick: int=int(event.sim_tick)
		var sampled: bool=tick>=start and tick<end
		if event.kind=="tick_completed": sampled=tick>start and tick<=end
		if not sampled: continue
		events[event.kind]=int(events.get(event.kind,0))+1
		if event.kind=="patient_departed":
			var result: String=str(event.details.get("result","missing"))
			outcomes[result]=int(outcomes.get(result,0))+1
			departures.append(event)
	var phases: Dictionary={}
	var guided: Dictionary={}
	var receipts: int=0
	var all_receipts: int=0
	for id: String in facts.floor_guidance.visits:
		var row: Dictionary=facts.floor_guidance.visits[id]
		phases[row.phase]=int(phases.get(row.phase,0))+1
		var actor_id: String=str(facts.visits.get(id,{}).get("actor_id",""))
		if not actor_id.is_empty(): guided[actor_id]=true
		for receipt: Dictionary in row.get("receipts",[]):
			all_receipts+=1
			if int(receipt.completed_tick)>=start and int(receipt.completed_tick)<end: receipts+=1
	var moves: Dictionary={"total":facts.moves.size(),"local":0,"local_waiting":0,"guidance_local_waiting":0,"route_pending":0}
	var waiting: Array=[]
	for id: String in facts.moves:
		var move: Dictionary=facts.moves[id]
		if move.get("route_pending",false): moves.route_pending+=1
		if move.has("local_move"): moves.local+=1
		if move.get("waiting_reason","")=="等待原路线局部连接空出":
			moves.local_waiting+=1
			if guided.has(id): moves.guidance_local_waiting+=1
			waiting.append({"id":id,"location":facts.actors[id].location,"cursor":move.cursor,"local":move.get("local_move",{}),"goal":move.target_cell})
	var result: Dictionary={"scope":"Read retained terminal facts and event journal only; zero simulation steps","input_sha256":FileAccess.get_sha256(args[1]),"ordinary_event_window_inclusive_exclusive":[start,end],"tick_completed_window_exclusive_inclusive":[start,end],"events":events,"departure_results":outcomes,"departures":departures,"guidance_phases":phases,"retained_sample_guidance_receipts":receipts,"retained_all_guidance_receipts":all_receipts,"moves":moves,"waiting":waiting}
	FileAccess.open(args[0],FileAccess.WRITE).store_string(JSON.stringify(result,"\t"))
	print(JSON.stringify({"events":events,"departure_results":outcomes,"moves":moves,"retained_sample_receipts":receipts}))
	quit()
