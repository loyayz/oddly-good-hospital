"""Read-only offline phase evidence, no engine or business-service imports."""
import argparse,json,hashlib
from pathlib import Path
WORKER='maintenance_contractor_00000226'
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def summarize(trace,result=None):
 rows=[json.loads(s) for s in Path(trace).read_text().splitlines() if s.strip()]
 assert rows and all(b['tick']==a['tick']+1 for a,b in zip(rows,rows[1:])), 'Non-contiguous states'
 start=rows[0]['tick']
 def pos(r):return r.get('worker',{}).get('location',{})
 def marker(r):return None if r is None else {'tick':r['tick'],'transitions_from_start':r['tick']-start,'states_through_boundary':r['tick']-start+1}
 def snap(r):
  m=r.get('movement',{});return {'tick':r['tick'],'location':pos(r),'ticket':m.get('transit_ticket',{}),'transit_wait':m.get('transit_wait','unavailable'),'assigned_actor_id':r.get('lift',{}).get('assigned_actor_id',''),'lift':r.get('lift',{})}
 def at(r,floor,cell):
  p=pos(r);return p.get('kind')=='floor' and p.get('floor_id')==floor and p.get('cell')==cell
 def boarding(r):
  l=r.get('lift',{});return (l.get('phase')=='boarding' and (l.get('primary_actor_id')==WORKER or WORKER in l.get('riders',[])))
 def transit(r):return pos(r).get('kind')=='transit'
 def riding_evidence(r):
  l=r.get('lift',{});return transit(r) or (l.get('phase') in ['boarding','riding','alighting'] and WORKER in l.get('riders',[])) or boarding(r)
 first=lambda fn:next((r for r in rows if fn(r)),None)
 episodes=[];active=None;last=None;changes=0;first_work=None
 for r in rows:
  m=r.get('movement',{});t=m.get('transit_ticket',{});key=(t.get('connector_id'),t.get('sequence')) if t else None
  if last:
   changes+=pos(last)!=pos(r)
   before=last['order'].get('remaining_milli');after=r['order'].get('remaining_milli')
   if first_work is None and isinstance(before,(int,float)) and isinstance(after,(int,float)) and after<before:first_work=r
  if active and key!=active['key']:
   active['disappearance']=snap(r)
   support=[snap(x) for x in [last,r] if x and riding_evidence(x)]
   active['classification']='normal_consumption_supported' if support else 'unexplained_disappearance'
   active['consumption_support']=support;active=None
  if key:
   if active is None:
    active={'key':key,'first':snap(r),'last':snap(r),'classification':'still_present_at_trace_end','disappearance':None};episodes.append(active)
   active['last']=snap(r)
  last=r
 first_anchor=first(lambda r:at(r,1,r.get('lift',{}).get('anchor')))
 first_ticket=first(lambda r:bool(r.get('movement',{}).get('transit_ticket')))
 target=rows[0]['order'];floor=target.get('work_floor');cell=target.get('work_cell')
 old_receipts=rows[0].get('lift',{}).get('use_receipts',{});new_receipts=rows[-1].get('lift',{}).get('use_receipts',{})
 data={'trace_sha256':digest(trace),'start_tick':start,'end_tick':rows[-1]['tick'],'state_count':len(rows),'transition_count':len(rows)-1,'first_exact_floor1_anchor':marker(first_anchor),'first_ticket':marker(first_ticket),'ticket_episodes':episodes,'ticket_disappearance_count':sum(e['disappearance'] is not None for e in episodes),'first_boarding':marker(first(boarding)),'first_actor_transit':marker(first(transit)),'first_actual_target_floor':marker(first(lambda r:pos(r).get('kind')=='floor' and pos(r).get('floor_id')==floor)),'first_exact_work_cell':marker(first(lambda r:at(r,floor,cell))),'first_positive_work':marker(first_work),'adjacent_location_changes':changes,'lift_receipt_counts':{'initial':len(old_receipts),'final':len(new_receipts),'new_keys':len(set(new_receipts)-set(old_receipts))},'new_lift_receipts':{k:v for k,v in new_receipts.items() if k not in old_receipts},'limits':['Exact exported coordinates only, not space.at/full-body eligibility.','Post-step states can miss intra-step create/cancel transitions.','No other actor ticket order inferred. Lift receipts are all-traffic, not target-worker completion.','Missing optional fields reported unavailable, never reconstructed.','Normal ticket consumption requires target-worker evidence; all other disappearance remains unexplained.']}
 if result:
  d=json.loads(Path(result).read_text());data['result']={'sha256':digest(result),'ok':d.get('ok'),'stop_reason':d.get('stop_reason'),'end_tick':d.get('end_tick'),'work_milli':d.get('work_milli'),'completed_assertion':d.get('checks',{}).get('completed'),'receipt':d.get('receipt'),'order':d.get('order')}
 else:data['result']='unavailable; completion/receipt not inferred'
 return data
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('trace');p.add_argument('--result');p.add_argument('--old-trace');p.add_argument('--old-result');a=p.parse_args()
 out={'current':summarize(a.trace,a.result)}
 if a.old_trace:out['old']=summarize(a.old_trace,a.old_result)
 print(json.dumps(out,indent=2,ensure_ascii=False))
