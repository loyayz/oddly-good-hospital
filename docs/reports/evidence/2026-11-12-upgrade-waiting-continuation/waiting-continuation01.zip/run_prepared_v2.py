from pathlib import Path
import sys,json,hashlib,os,platform,importlib.util,traceback,subprocess
B=Path(__file__).resolve().parent;root=B.parent;R=root/'oddly-good-hospital-cloud-recovery-20261112'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,v):Path(p).write_text(json.dumps(v,indent=2))
def host():
 d={'node_sha256':hashlib.sha256(platform.node().encode()).hexdigest(),'cpu_count':os.cpu_count(),'affinity':sorted(os.sched_getaffinity(0))}
 for path in ['/proc/meminfo','/proc/stat','/sys/fs/cgroup/cpu.max','/sys/fs/cgroup/cpu.stat','/sys/fs/cgroup/memory.max','/sys/fs/cgroup/memory.current']:
  try:d[path]=Path(path).read_text()
  except OSError:d[path]='unavailable'
 return d
# No current HEAD or mutable source can authorize this run.
assert len(sys.argv)==5 and sys.argv[4]=='PARENT_RELEASED', 'Requires mode, fresh run ID, explicitly supplied release SHA and later parent authorization'
mode,runid,release_sha=sys.argv[1:4]
assert mode in ['parse','continue'] and Path(runid).name==runid and runid not in ['.','..']
release_path=B/'final-release.json'
assert release_path.is_file(), 'No frozen final-release identity; execution forbidden'
assert sha(release_path)==release_sha, 'Release identity hash mismatch'
identity=json.loads(release_path.read_text())
assert identity['status']=='released' and mode in identity['allowed_modes'] and identity['run_id']==runid
assert identity['wrapper_sha256']==sha(__file__)
assert identity['input_sha256']=='964698a71036e34c5000b0ea4aa0035e2d875ba572bfc204564ce67811dac6fb'
assert identity['sources']['tests/acceptance/run_upgrade_continuation.gd']=='3f8d8a5d4ed09e10589d78b8ca708789336c7a470f0d8f53036f9b56907dcc55'
required={'game/building/hospital_movement.gd','game/building/hospital_transit.gd','game/sim/world_state.gd','game/clinic/clinical_runtime.gd','tests/acceptance/run_upgrade_continuation.gd','tests/acceptance/run_upgrade_handoff.gd','game/operations/maintenance_service.gd','game/economy/ledger.gd','game/economy/ledger_entry.gd'}
assert required<=set(identity['sources']), 'Incomplete final source lock'
prior=identity['previous_raw_durable_receipt']
assert prior['readback_verified'] is True and prior['archive_sha256']=='2d8188085e036313cc10825e84758c1e2919aa80e7097e56c28fa14c6edb69b1'
actual_native=R/'game/platform/linux/bin/oddly_good_platform.linux.x86_64.so'
assert actual_native.is_file() and not actual_native.is_symlink()
assert sha(actual_native)==identity['actual_project_native_sha256']
cfg=json.loads((root/'root-stage-recovery-20261112/config.json').read_text())
for p,h in cfg['locked_files'].items():assert sha(p)==h,p
for proc in Path('/proc').iterdir():
 if proc.name.isdigit():
  try:comm=(proc/'comm').read_text().strip()
  except OSError:continue
  assert not comm.lower().startswith('godot'),f'engine slot busy: {proc.name}'
spec=importlib.util.spec_from_file_location('safe_lifecycle_guard',root/'root-stage-recovery-20261112/linux_guard_v2.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g);g.PROJECT=R;g.LIBRARY_PATH=cfg['library_path']
for rel,digest in identity['sources'].items():assert sha(R/rel)==digest,rel
assert sha(identity['input'])==identity['input_sha256']
extra=[identity['input']] if mode=='continue' else []
out=B/runid;out.mkdir(exist_ok=False)
import shutil
for rel,digest in identity['sources'].items():
 dest=out/'sources'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/rel,dest);assert sha(dest)==digest
shutil.copy2(release_path,out/'final-release.json')
shutil.copy2(__file__,out/'run_prepared.py')
shutil.copy2(spec.origin,out/'linux_guard_v2.py')
shutil.copy2(identity['input'],out/'input.bin')
extra=[str(out/'input.bin')] if mode=='continue' else []
write(out/'identity.json',{'engine':cfg['engine'],'locked_files':cfg['locked_files'],'test_sha':sha(R/'tests/acceptance/run_upgrade_continuation.gd'),'guard_sha':sha(spec.origin),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'clinical_source_sha':sha(R/'game/clinic/clinical_runtime.gd')})
cmd=[cfg['engine'],'--headless','--path',str(R),'--script','res://tests/acceptance/run_upgrade_continuation.gd']
cmd+=['--check-only'] if mode=='parse' else ['--',mode,str(out),*extra]
assert sha(actual_native)==identity['actual_project_native_sha256']
write(out/'actual-native-before.json',{'path':str(actual_native),'sha256':sha(actual_native),'symlink':False,'verified_before_engine':True})
write(out/'host-before.json',host())
try:g.run(cmd,out/'engine',timeout=600,allowed_exits=(0,1))
except BaseException:write(out/'error.json',{'traceback':traceback.format_exc()});raise
finally:
 write(out/'host-after.json',host())
 post={'path':str(actual_native),'sha256':sha(actual_native),'symlink':actual_native.is_symlink()}
 post['matches_release']=post['sha256']==identity['actual_project_native_sha256'] and not post['symlink']
 write(out/'actual-native-after.json',post)
 source_after={rel:sha(R/rel) for rel in identity['sources']}
 write(out/'source-after.json',source_after)
 assert post['matches_release'], 'Actual project native changed'
 assert source_after==identity['sources'], 'Released source changed' 
print(mode,json.loads((out/'engine/process.json').read_text())['returncode'])
