# Preparation only: no release, no engine run

New wrapper preserves the958762 dedicated continuation runner semantics. No candidate production sources have been read/copied or assigned hashes. final-release.json intentionally does not exist. Parent must freeze candidate sources, supply exact source hashes, actual project native SHA, input path/SHA, prior raw durable receipt, permitted mode/run ID and this wrapper SHA, then explicitly authorize execution. CLI additionally binds the full final-release SHA, not current HEAD. HEAD is recorded descriptively only.

Runtime cfg continues verifying engine/native/dependency locks; actual --path native is additionally explicitly hashed before and after engine and must equal release identity, non-symlink. Source copies are made only after release verification, checked immediately and again after run. Safe host whitelist contains CPU/memory/affinity/quota statistics and node hash; never mounts or cgroup identity mapping.

Invocation after separate authorization: python -B run_prepared_v2.py parse|continue fresh-run-id FINAL_RELEASE_SHA PARENT_RELEASED. One run per fresh directory;600s owned guard; original4046 complete input SHA964698a..., no new commands, .1s full simulation through actual completion or7633. No extra prefix test. Partial actual-work restore remains explicit; not original7000-step trajectory. Failures retained, no automatic rerun. Each complete raw batch must be durably published/read back before another long run. Old directories remain immutable.

Only Python compile syntax check performed during preparation. Godot parse and all execution remain unauthorized. Packager/remote publication remains parent-coordinated after a specifically released run.

Log-only update: runner SHA 3f8d8a5d4ed09e10589d78b8ca708789336c7a470f0d8f53036f9b56907dcc55. Only _phase_facts changed: complete226 movement (actual path), compatible projected defaults, assigned order worker actor/move. No query/step/assertion changes. Previous958762 body outside that function is byte-identical. Wrapper pins new runner; no final-release.json or candidate production locks were created. Pending parent-authorized parse.
