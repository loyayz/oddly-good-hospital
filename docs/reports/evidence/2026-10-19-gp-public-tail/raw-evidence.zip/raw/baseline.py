from pathlib import Path
import subprocess, json
out=Path(__file__).resolve().parent
root=out.parents[1]
project=out/'before-project'
def run(args, name):
    result=subprocess.run(args,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf8',errors='replace')
    (out/(name+'.console.log')).write_text(result.stdout,encoding='utf8')
    print(json.dumps({'batch':name,'exit_code':result.returncode}),flush=True)
    if result.returncode: raise SystemExit(result.returncode)
run(['pwsh','-NoProfile','-File',str(root/'tools/performance/prepare.ps1'),'-Output',str(project)],'before-prepare')
def probe(name, steps, source, mode='plain', timeout=500):
    run(['python','-X','utf8',str(out/'run_engine.py'),str(project),name,str(timeout),f'--input={source}',f'--output={out/(name+".json")}',f'--steps={steps}',f'--profile={mode}'],name)
for i in range(1,4): probe(f'before-gp-{i}',80,out/'gp.input.bin')
probe('before-public-prefix',277,out/'public-v6.input.bin')
run(['python','-X','utf8',str(out/'run_engine.py'),str(project),'before-public-resume','90','script=res://tools/performance/resume_representative.gd',f'--source={out/"public-v6.input.bin"}',f'--final={out/"before-public-prefix.json.final.bin"}',f'--output={out/"tick2900.input.bin"}'],'before-public-resume')
probe('before-tail-nested',1,out/'tick2900.input.bin','nested',300)
