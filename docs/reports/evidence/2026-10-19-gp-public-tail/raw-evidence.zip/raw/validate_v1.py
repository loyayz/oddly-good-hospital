from pathlib import Path
import subprocess,json
out=Path(__file__).resolve().parent
root=out.parents[1]
project=out/'after-v1-project'
def run(args,name,diagnostic=False):
    result=subprocess.run(args,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf8',errors='replace')
    (out/(name+'.console.log')).write_text(result.stdout,encoding='utf8')
    okay=result.returncode==0
    if diagnostic and result.returncode==1:
        r=json.loads((out/(name+'.json')).read_text(encoding='utf8'))
        m=json.loads((out/(name+'.run.json')).read_text(encoding='utf8'))
        okay=r['complete'] and not r['errors'] and not m['engine_errors'] and not m['timed_out'] and all(v for k,v in r['qualification'].items() if k!='actual_clinical_work')
    print(json.dumps({'batch':name,'exit_code':result.returncode,'expected_diagnostic_nonwork':diagnostic and result.returncode==1,'batch_ok':okay}),flush=True)
    if not okay: raise SystemExit(result.returncode or 2)
cases='STAFF-30,STAFF-41,STAFF-42,STAFF-45,STAFF-46,STAFF-47,STAFF-48,STAFF-49,STAFF-50,STAFF-51,STAFF-52,STAFF-53,STAFF-57,STAFF-61,STAFF-62,STAFF-63,STAFF-64,STAFF-65,STAFF-68,SPACE-08,SPACE-48,SPACE-49,SPACE-50,SPACE-53,OPS-44,CLIN-15,CLIN-30,CLIN-33,CLIN-35'
run(['pwsh','-NoProfile','-File',str(root/'tests/run-acceptance.ps1'),'-Case',cases],'v1-regression')
run(['pwsh','-NoProfile','-File',str(root/'tools/performance/prepare.ps1'),'-Output',str(project)],'v1-prepare')
for name,steps,source,mode,diagnostic in [('v1-gp-1',80,'gp.input.bin','plain',False),('v1-tail-nested',1,'tick2900.input.bin','nested',True)]:
    run(['python','-X','utf8',str(out/'run_engine.py'),str(project),name,'300',f'--input={out/source}',f'--output={out/(name+".json")}',f'--steps={steps}',f'--profile={mode}'],name,diagnostic)
