from pathlib import Path
import subprocess,json
out=Path(__file__).resolve().parent
root=out.parents[1]
project=out/'after-v2-project'
def run(args,name,diagnostic=False):
    result=subprocess.run(args,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf8',errors='replace')
    (out/(name+'.console.log')).write_text(result.stdout,encoding='utf8')
    okay=result.returncode==0
    if diagnostic and result.returncode==1:
        r=json.loads((out/(name+'.json')).read_text(encoding='utf8'))
        m=json.loads((out/(name+'.run.json')).read_text(encoding='utf8'))
        okay=r['complete'] and not r['errors'] and not m['engine_errors'] and not m['timed_out'] and all(v for k,v in r['qualification'].items() if k!='actual_clinical_work')
    print(json.dumps({'batch':name,'exit_code':result.returncode,'expected_diagnostic_nonwork':diagnostic and result.returncode==1,'batch_ok':okay}),flush=True)
    if not okay: raise SystemExit(result.returncode or 2)
def probe(name,target,steps,source,mode='plain',diagnostic=False):
    run(['python','-X','utf8',str(out/'run_engine.py'),str(target),name,'900',f'--input={out/source}',f'--output={out/(name+".json")}',f'--steps={steps}',f'--profile={mode}'],name,diagnostic)
def equal(a,b):
    ra=json.loads((out/(a+'.json')).read_text(encoding='utf8'))
    rb=json.loads((out/(b+'.json')).read_text(encoding='utf8'))
    okay=ra['final_binary_sha256']==rb['final_binary_sha256']
    print(json.dumps({'comparison':[a,b],'facts_and_events_sha_equal':okay}),flush=True)
    if not okay: raise SystemExit(3)
cases='STAFF-30,STAFF-41,STAFF-42,STAFF-45,STAFF-46,STAFF-47,STAFF-48,STAFF-49,STAFF-50,STAFF-51,STAFF-52,STAFF-53,STAFF-57,STAFF-61,STAFF-62,STAFF-63,STAFF-64,STAFF-65,STAFF-68,SPACE-08,SPACE-48,SPACE-49,SPACE-50,SPACE-53,OPS-44,CLIN-15,CLIN-30,CLIN-33,CLIN-35'
run(['pwsh','-NoProfile','-File',str(root/'tests/run-acceptance.ps1'),'-Case',cases],'v2-regression')
run(['pwsh','-NoProfile','-File',str(root/'tools/performance/prepare.ps1'),'-Output',str(project)],'v2-prepare')
probe('v2-tail-nested',project,1,'tick2900.input.bin','nested',True)
equal('before-tail-nested','v2-tail-nested')
for scene,steps,source in [('gp',80,'gp.input.bin'),('op',40,'op.input.bin')]:
    for i in range(1,4):
        before=f'before-{scene}-pair{i}'
        after=f'v2-{scene}-{i}'
        probe(before,out/'before-project',steps,source)
        probe(after,project,steps,source)
        equal(before,after)
probe('v2-gp-nested',project,80,'gp.input.bin','nested')
equal('v2-gp-1','v2-gp-nested')
probe('v2-public-plain',project,300,'public-v6.input.bin')
equal('before-public-plain','v2-public-plain')
probe('v2-public-root',project,300,'public-v6.input.bin','root')
equal('v2-public-plain','v2-public-root')
