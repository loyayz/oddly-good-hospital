extends "res://game/life/waiting_life.gd"
var _step_profile_observer: RefCounted

func dispatch(world: WorldState) -> void:
	_step_profile_observer.enter_call("waiting.dispatch")
	super.dispatch(world)
	_step_profile_observer.exit_call("waiting.dispatch")

func advance(world: WorldState) -> void:
	_step_profile_observer.enter_call("waiting.advance")
	super.advance(world)
	_step_profile_observer.exit_call("waiting.advance")

func seat_candidates(world: WorldState, visit_id: String) -> Array:
	_step_profile_observer.enter_call("waiting.seat_candidates")
	var _step_profile_result: Variant = super.seat_candidates(world,visit_id)
	_step_profile_observer.exit_call("waiting.seat_candidates")
	return _step_profile_result

func _manual_seat_quote(world: WorldState, visit: Dictionary, facility_id: String) -> Dictionary:
	_step_profile_observer.enter_call("waiting._manual_seat_quote")
	var _step_profile_result: Variant = super._manual_seat_quote(world,visit,facility_id)
	_step_profile_observer.exit_call("waiting._manual_seat_quote")
	return _step_profile_result

func _dispatch_public_seat(world: WorldState, visit: Dictionary, intent: Dictionary) -> void:
	_step_profile_observer.enter_call("waiting._dispatch_public_seat")
	super._dispatch_public_seat(world,visit,intent)
	_step_profile_observer.exit_call("waiting._dispatch_public_seat")

func facility_availability(world: WorldState, actor_id: String, facility_id: String) -> Dictionary:
	_step_profile_observer.enter_call("waiting.facility_availability")
	var _step_profile_result: Variant = super.facility_availability(world,actor_id,facility_id)
	_step_profile_observer.exit_call("waiting.facility_availability")
	return _step_profile_result

func _seat_quote(world: WorldState, visit: Dictionary, facility_id: String, actor_index: Variant = null) -> Dictionary:
	_step_profile_observer.enter_call("waiting._seat_quote")
	var _step_profile_result: Variant = super._seat_quote(world,visit,facility_id,actor_index)
	_step_profile_observer.exit_call("waiting._seat_quote")
	return _step_profile_result

func _facility_quote(world: WorldState, visit: Dictionary, facility_id: String) -> Dictionary:
	_step_profile_observer.enter_call("waiting._facility_quote")
	var _step_profile_result: Variant = super._facility_quote(world,visit,facility_id)
	_step_profile_observer.exit_call("waiting._facility_quote")
	return _step_profile_result

func _facility_quote_in_query(world: WorldState, visit: Dictionary, facility_id: String) -> Dictionary:
	_step_profile_observer.enter_call("waiting._facility_quote_in_query")
	var _step_profile_result: Variant = super._facility_quote_in_query(world,visit,facility_id)
	_step_profile_observer.exit_call("waiting._facility_quote_in_query")
	return _step_profile_result

func _dispatch_public_need(world: WorldState, visit: Dictionary, need: Dictionary) -> void:
	_step_profile_observer.enter_call("waiting._dispatch_public_need")
	super._dispatch_public_need(world,visit,need)
	_step_profile_observer.exit_call("waiting._dispatch_public_need")

func _condition_actor_index(world: WorldState) -> Dictionary:
	_step_profile_observer.enter_call("waiting._condition_actor_index")
	var _step_profile_result: Variant = super._condition_actor_index(world)
	_step_profile_observer.exit_call("waiting._condition_actor_index")
	return _step_profile_result

func _conditions(world: WorldState, visit: Dictionary, facility: Dictionary, cell: Array, observation: Dictionary, actor_index: Variant = null) -> Dictionary:
	_step_profile_observer.enter_call("waiting._conditions")
	var _step_profile_result: Variant = super._conditions(world,visit,facility,cell,observation,actor_index)
	_step_profile_observer.exit_call("waiting._conditions")
	return _step_profile_result

func _environment(world: WorldState, actor_id: String, floor_id: int, cell: Array) -> Dictionary:
	_step_profile_observer.enter_call("waiting._environment")
	var _step_profile_result: Variant = super._environment(world,actor_id,floor_id,cell)
	_step_profile_observer.exit_call("waiting._environment")
	return _step_profile_result
