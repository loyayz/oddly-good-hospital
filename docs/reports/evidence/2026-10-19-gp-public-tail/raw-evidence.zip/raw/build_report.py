from pathlib import Path
import json
root=Path(__file__).resolve().parents[2]
evidence=root/'docs/reports/evidence/2026-10-19-gp-public-tail'
s=json.loads((evidence/'quick-summary.json').read_text(encoding='utf8'))
r=s['runs']; pairs=s['pairs']
ms=lambda v:f'{v/1000:,.3f}'
pct=lambda a,b:f'{(b/a-1)*100:+.2f}%'
def pairrow(scene,label):
    a=pairs[scene]['before']['median']; b=pairs[scene]['after']['median']
    return '| '+label+' | '+' | '.join(ms(a[k])+' → '+ms(b[k]) for k in ['mean_us','p50_us','p95_us','cold_first_us','following_mean_us'])+' | '+pct(a['mean_us'],b['mean_us'])+' |'
b=r['before-public-plain']; a=r['v2-public-plain']; diag_b=r['before-tail-nested']; diag_a=r['v2-tail-nested']
step_b=s['public_step_details']['before-public-plain']['step277']['elapsed_us']
step_a=s['public_step_details']['v2-public-plain']['step277']['elapsed_us']
root_stages=r['v2-public-root']['profile']['root_stages']
stages='；'.join(x['name']+' '+f'{x["total_us"]/1000000:.3f}'+'秒（'+f'{x["profiled_whole_share"]*100:.2f}'+'%）' for x in root_stages[:5])
calls_b={x['name']:x for x in diag_b['profile']['nested_calls']}; calls_a={x['name']:x for x in diag_a['profile']['nested_calls']}
gp_b={x['name']:x for x in r['before-gp-nested']['profile']['nested_calls']}; gp_a={x['name']:x for x in r['v2-gp-nested']['profile']['nested_calls']}
calls='\n'.join('| '+name+' | '+str(calls_b[name]['calls'])+' → '+str(calls_a[name]['calls'])+' |' for name in ['space.route','space._floor_route','navigation.floor_source','public_areas.waiting_point'])
pub=a['public']; historical=58551.6375
text=f'''# GP退化与公共设施68秒长尾：160人快速性能闭环

基线为 `dev@960140b4d25843050324e3ecde00b314d5e604b0`。最终实现及测量工程以[源码身份](evidence/2026-10-19-gp-public-tail/final-source-identity.json)中的逐文件SHA-256为准。GP80步全窗均值中位数 **{ms(pairs['gp']['before']['median']['mean_us'])}ms → {ms(pairs['gp']['after']['median']['mean_us'])}ms（{pairs['gp']['mean_change_percent']:+.2f}%）**；公共竞争第277步 **{ms(step_b)}ms → {ms(step_a)}ms（{pct(step_b,step_a)}）**。完整300步均值 **{ms(b['metrics']['mean_us'])}ms → {ms(a['metrics']['mean_us'])}ms（{pct(b['metrics']['mean_us'],a['metrics']['mean_us'])}）**。

这是同源Godot 4.7.2 Debug/Headless普通完整模拟步的快速验证。**正式Release性能验收继续暂停，未宣称性能阈值达标。**

## 固定输入和有效性

三个原输入文件直接复用，未重建、删人、缩短既定窗口或重新摆放人物：120患者、32员工、8真实亲友，共160人；64房间、1,336设施、4层。初始化、观察及证据写盘位于普通 `HospitalSimulation.step()` 计时之外。每轮重新建立运行时服务，保留冷首步，不序列化服务缓存；引擎进程串行执行。

| 场景 | 固定窗口 | 输入SHA-256 |
| --- | --- | --- |
| GP实际诊疗 | tick823→903，80步 | `14bfa213c792d0da30bbf48cb39b360166cff6ecb7f8e46e17ff9bddf37bb0b0` |
| 门诊、清洁及已付待工单 | tick1151→1191，40步 | `dcd41d686a06d0571ae0ad81d83332ce7ca331d4d810de7c5d2b14dede7dcdd3` |
| 公共设施竞争 | tick2623→2923，300步 | `56ea8338361470fee88659ed806d412aa49927c0709c30d4fbdf536a20eb4f76` |

公共输入是此前声明并校验的合法临界前提，不是三个窗口连续游玩的证明。原前提、身份、随机流、票序、账目、承诺、完整身体和冻结日计划依据均保留在原始包。冻结日计划复用不表示重新完成742病例容量求解。门诊40步仍不证明全部治疗完成或装修实际施工；医院没有装修工/工具，待工单没有被算作施工工时。

GP和运营各做三组交替before/after；公共窗口各做一次完整plain，最终源码另做一次300步root。全部完整窗口人数始终160、人物集合不变、世界合法且有实际临床工时；各组**最终完整事实、随机流及有序事件二进制SHA完全相同**。GP保留55个GP、25个会诊工作tick；运营保留40个门诊、120个接待工作tick和16处地污实际派工/行走/清洁。GP实际坐椅人物仍为8，运营为9，没有删除新行为换取收益。

## 诊断及采纳的修复

历史第277步68.096秒中，候诊分派占67.204秒（98.69%），临床分派仅0.746秒，不能把该步归因于后段临床报价。重新从原输入实际执行前277步，得到tick2900完整边界，再执行单步nested：原整步84.232秒中，`dispatch.waiting`为74.660秒；26,742次行程报价、134,008次楼层路线调用和1,317,206次楼层来源读取暴露了入口枚举的放大。

| 修复 | 当前行为及边界 | 证据结论 |
| --- | --- | --- |
| 跨层无完整落点估计时结束本次入口搜索 | 完整跨层路线必先到达目标层某连接器anchor。所有anchor均无完整估计时，不再向同一区域每格重复报价；有限anchor与unknown共存仍搜索。出口改变后的新查询重新读取，不缓存为永久不可达。 | 第277步路线请求由26,763降至117；完整窗口最终事实和事件相同。 |
| 同世界动态子查询复用 | 嵌套实际查询保留父级routes、exits及transport；投影世界独立，名义容量reference不冒充实际身体/交通许可。 | 中间版候选连接检查88,737→36，但仍26,676次路线，单独不足以消除长尾。 |
| 严格支配上界 | 非生活需求保留本区优先；其他区域以当前最佳行程约束。厕所/饮水以最佳开始时刻减本区等待估计约束，逐个校验组员，保留同值及原稳定排序。 | 相关边界与完整窗口通过；不独立宣称该项加速比例。 |
| 立即复用选区入口 | 同步选区已得到的精确floor/cell直接用于本次患者候诊或生活出发；跨步仍读当前事实。 | 不新增远程设施预约，不省实际到场和取位校验。 |
| 局部候选及饮水观察复用 | 先取本区设施，按原累计30秒剩余额度作保守下界；一次只读选座内复用环境观察与同人同水设施完整可用性报价。 | 身体到来后的新查询与全新服务冷查询一致；不跨人/世界/提交保存结果。 |
| 精确投影几何来源 | 临床预约及公共去返投影复用未变的楼层、房间、设施、连接器来源，仅复制已声明的适配足迹差量；重新采集完整occupancy，权限变化更新version。动态身体索引、交通前缀、出口证明和路线均独立。 | 扩张、收缩、反向位置、同足迹换owner均与独立完整capture相等；GP和运营整步及后续步有收益。 |

当某普通格存在完整跨层估计时，其最后入层anchor的已知到达时刻不晚于该格；两者使用同一交通节点、站层和FIFO时间函数。anchor在此前遇到的未知前缀也必在更晚的普通格终点前被展开，因此“无任何完整anchor但有完整普通格”在当前算法中不成立。该必要条件不修改未知交通的业务含义，也不截断合法远端候选。

患者/员工/亲友实际取位仍检查当前身体、预约、全部出口和往返路线；原45秒额度、8秒使用、正常公共排队、手动固定设施及医疗预约不变。个人床归属与分配规则不变。

## 整步实测

下表为三个固定窗口对应指标的中位数，单位ms；不是合并样本后重新计算的分位数。收益由plain完整步证明，nested只用于归因。

| 窗口 | 全窗均值 前→后 | P50 前→后 | P95 前→后 | 冷首步 前→后 | 后续步均值 前→后 | 全窗变化 |
| --- | --- | --- | --- | --- | --- | --- |
{pairrow('gp','GP80')}
{pairrow('op','门诊/清洁40')}

GP的同源nested中，楼层来源读取次数均为{gp_b['navigation.floor_source']['calls']:,}，排除子调用耗时由{ms(gp_b['navigation.floor_source']['exclusive_us'])}ms降至{ms(gp_a['navigation.floor_source']['exclusive_us'])}ms；楼层路线调用仍为{gp_a['space._floor_route']['calls']:,}，对应耗时{ms(gp_b['space._floor_route']['exclusive_us'])}ms→{ms(gp_a['space._floor_route']['exclusive_us'])}ms。收益来自消除相同几何的重复扫描，未减少必须执行的路线或实际诊疗；投影准备的完整成本仍包含在整步计时内。

| 公共300步，n=1完整plain | 前 | 后 | 变化 |
| --- | --- | --- | --- |
| 总耗时秒 | {b['metrics']['total_us']/1000000:.3f} | {a['metrics']['total_us']/1000000:.3f} | {pct(b['metrics']['total_us'],a['metrics']['total_us'])} |
| 均值ms | {ms(b['metrics']['mean_us'])} | {ms(a['metrics']['mean_us'])} | {pct(b['metrics']['mean_us'],a['metrics']['mean_us'])} |
| P50 ms | {ms(b['metrics']['p50_us'])} | {ms(a['metrics']['p50_us'])} | {pct(b['metrics']['p50_us'],a['metrics']['p50_us'])} |
| P95 ms | {ms(b['metrics']['p95_us'])} | {ms(a['metrics']['p95_us'])} | {pct(b['metrics']['p95_us'],a['metrics']['p95_us'])} |
| 最大步ms | {ms(b['metrics']['max_us'])} | {ms(a['metrics']['max_us'])} | {pct(b['metrics']['max_us'],a['metrics']['max_us'])} |
| 第277步ms | {ms(step_b)} | {ms(step_a)} | {pct(step_b,step_a)} |

公共检查7/7通过：手动请求真实接受、实际排队、至少两次真实开用、跨区域实际使用、实际完成、前人完整身体退出后复用及无观察规则错误。前后均有{len(pub['actual_use_starts'])}次开用、{len(pub['actual_use_completions'])}次完成、{len(pub['used_regions'])}个实际使用区域、{pub['actual_use_ticks']}个使用tick、{pub['actual_exit_then_reuse_count']}次实际退出后复用，队列峰值{pub['queue_peak']}、累计{pub['queue_actor_ticks']}个人物tick；没有用“取消排队”制造收益。临床工作保持GP55、会诊81、接待60tick。

单步nested为84.232秒→{diag_a['metrics']['mean_us']/1000000:.3f}秒，包含观测开销，不能与plain混合计算加速。调用次数如下：

| 同tick2900诊断 | 前→后 |
| --- | --- |
{calls}

最终完整root主要阶段：{stages}。完整阶段、包含/排除子调用时间、次数和占比均在[快速摘要](evidence/2026-10-19-gp-public-tail/quick-summary.json)，逐步记录与生成插桩源码在原始包。

## 相关回归与未产生收益的结果

最终29项受影响用例全部通过，无脚本错误或未解决相关断言。前提来源、生成/读取耗时、实际断言耗时和完成状态见[逐项功能摘要](evidence/2026-10-19-gp-public-tail/functional-summary.json)。这不是全量功能回归。

- STAFF-30、41、42：30秒/12秒/环境带、完整去返及饮水新身体/投影世界隔离。
- STAFF-45～53、57、61～65、68：区域与固定目标、真实到场竞争/让位、保存、床主边界、45秒/8秒、队序及临床接续。
- SPACE-08、48、49、50、53、OPS-44：出口、精确几何投影、身体/权限边界、动态嵌套路线及新障碍失效。
- CLIN-15、30、33、35：原资源承诺、暂停恢复、真实到齐所有权及重复查询的独立对照。

STAFF-61继续穷举全部合法入口作为独立预期，补充实际出口被占用、实际走开后恢复、故障电梯向下缓降保留与向上拒绝。MixedEntryKnowledge是“已有有限落点再附加保守unknown”的合成控制，不冒充两个真实连接器的混合交通实测。STAFF-42使用同一温热服务结束查询后新增真实身体，再与全新服务读取同一事实比较，避免两边共享缓存而共同出错。SPACE-48直接完整capture推导预期。

| 保留结果/未采用方向 | 结论与理由 |
| --- | --- |
| 第一批查询复用和上界优化 | 29项回归通过且事实/事件相同；GP单轮82.973ms对初始基线三轮均值中位数80.512ms，没有收益。长尾nested仍76.894秒，不能宣称完成。原始全部保留，再以实际空落点条件和精确投影完成闭环。 |
| 单步进程退出1 | before/v1/v2均完整、160人且世界合法，但该步无实际诊疗工时，qualified=false。第一次机械批因此非零结束；后续仅识别这种完整的诊断性否定，不修改门槛。三份原结果均保留，不当作合格代表窗口。 |
| 起点静态非法的快速拒绝 | 理论必要条件成立，但实际追踪各长尾起点均合法，不能解释当前长尾，未加入生产代码。 |
| 新增全图BFS/连通位图 | 未采用。当前病灶由更小的跨层落点必要条件消除，未建立增加位图、内存和图刷新失效链的额外收益依据。没有执行的方向不编造前后指标。 |
| 只做静态适配或共享全部投影世界缓存 | 不采用。会遗漏当前身体、预约/退出权限和第三方交通出口依赖；几何相同不等于人物/交通许可相同。 |

入口追踪额外读取静态图，只用于排除非法起点假设；其计时不列入生产收益。没有截尾均值、删除失败或用较短公共窗口替换300步。900秒看门狗仅是采集保护，不是性能阈值。

## 当前限制与未完成项

1. 相对本轮最新dev基线，GP整步和后续步均有改善；相对功能改造前58.552ms历史参考，当前仍高{(pairs['gp']['after']['median']['mean_us']/historical-1)*100:.2f}%。历史版没有同样的8名亲友实际坐椅结果，不能用少做业务的历史数值证明已完全恢复，也不能宣称GP普遍达标。P95变化单独保留。
2. 公共300步仍有最大{ms(a['metrics']['max_us'])}ms及P95 {ms(a['metrics']['p95_us'])}ms的长步。第277步病灶已明显压低，其余临床方案/床位报价、实际楼层路线和出口保护仍有成本；根阶段数据定义当前瓶颈，不以减少合法服务消除成本。
3. 个人床首次分配此前约28～30秒，本批没有重新测量首次分配；已有归属前提的快速窗口不能代替该证据。持续缺配且有无主床的规模成本仍无完整结论。
4. Release正式矩阵、同源Release导出、完整742病例容量计算与内存、最大房间预览、实际渲染比例/GPU、最低参考实机及两小时稳定性继续暂停，均未执行/未验收。工程导入、29项功能回归及快速完整步不替代正式验收。

## 证据与重放

[快速逐轮摘要](evidence/2026-10-19-gp-public-tail/quick-summary.json)、[功能逐例摘要](evidence/2026-10-19-gp-public-tail/functional-summary.json)、[最终源码身份](evidence/2026-10-19-gp-public-tail/final-source-identity.json)、[原始证据包](evidence/2026-10-19-gp-public-tail/raw-evidence.zip)、[归档哈希与清单](evidence/2026-10-19-gp-public-tail/evidence-manifest.json)。前后引擎及原生DLL哈希相同。

原始包保留固定完整输入、原前提说明、真实277步前缀及续接输入、所有plain/root/nested结果、无收益中间版、非零退出、逐步enter/complete、最终完整事实/有序事件、插桩源码、工程源身份及回归日志。解压raw至仓库`.cache/gp-public-tail-20261019/`，按run.json命令及before/final逐文件身份重建冻结工程，输出使用新路径。真实世界续接规则和测量边界见[工具说明](../../tools/performance/REPRESENTATIVE.md)。
'''
(root/'docs/reports/2026-10-19-gp-public-tail-performance.md').write_text(text,encoding='utf8',newline='\n')
print('REPORT_WRITTEN')
