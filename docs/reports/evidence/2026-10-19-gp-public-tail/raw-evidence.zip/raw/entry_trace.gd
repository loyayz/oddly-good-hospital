extends SceneTree

const Clinical = preload("res://tools/performance/representative_clinical.gd")
class EntryTrace extends HospitalPublicAreas:
	var output: FileAccess
	func _waiting_point(world: WorldState, actor_id: String, reference: Dictionary, maximum_travel_ticks: int) -> Dictionary:
		var actor: Dictionary = world.facts.actors[actor_id]
		var point: Vector2i = Vector2i(roundi(actor.location.cell[0]),roundi(actor.location.cell[1]))
		var graph: FloorNavigation = space._navigation.graph(space,world,int(actor.location.floor_id),actor,[],{})
		var record: Dictionary = {"actor_id":actor_id,"species":actor.species_id,"location":actor.location.duplicate(true),"posture":actor.posture,"support":actor.get("support_facility_id",""),"area":reference,"maximum_ticks":maximum_travel_ticks,"origin_static_enabled":FloorNavigation._inside(point) and graph.has_point(FloorNavigation._id(point)) and not graph.is_point_disabled(FloorNavigation._id(point))}
		output.store_line(JSON.stringify({"kind":"enter","entry":record}))
		output.flush()
		var result: Dictionary = super._waiting_point(world,actor_id,reference,maximum_travel_ticks)
		output.store_line(JSON.stringify({"kind":"complete","entry":record,"result":result}))
		output.flush()
		return result

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var options: Dictionary = {}
	for argument: String in OS.get_cmdline_user_args():
		if argument.begins_with("--") and "=" in argument: options[argument.trim_prefix("--").get_slice("=",0)] = argument.substr(argument.find("=")+1)
	var content: HospitalContent = HospitalContent.new()
	var clinical: RefCounted = Clinical.new(content,options.input)
	var trace: EntryTrace = EntryTrace.new(clinical.simulation.space)
	trace.output = FileAccess.open(options.output,FileAccess.WRITE)
	clinical.simulation.space.public_areas = trace
	var result: TickResult = clinical.simulation.step()
	trace.output.close()
	var events: Array = []
	if result!=null:
		for event: SimEvent in result.facts: events.append(event.to_record())
	var final: FileAccess = FileAccess.open(options.output+".final.bin",FileAccess.WRITE)
	final.store_var({"facts":clinical.world.freeze(),"events":events})
	final.close()
	print("ENTRY_TRACE="+JSON.stringify({"diagnostic_only":true,"extra_geometry_observation":true,"complete":result!=null,"present":clinical.world.present_actor_count(),"validation":clinical.world.validate(content),"final_sha256":FileAccess.get_sha256(options.output+".final.bin")}))
	clinical.dispose()
	quit(0 if result!=null else 2)
