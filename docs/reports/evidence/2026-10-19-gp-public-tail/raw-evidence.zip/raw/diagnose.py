from pathlib import Path
import subprocess,json,shutil
out=Path(__file__).resolve().parent
root=out.parents[1]
def run(args,name):
    result=subprocess.run(args,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf8',errors='replace')
    (out/(name+'.console.log')).write_text(result.stdout,encoding='utf8')
    print(json.dumps({'batch':name,'exit_code':result.returncode}),flush=True)
    if result.returncode: raise SystemExit(result.returncode)
for name,project in [('before-gp-nested',out/'before-project'),('v1-gp-nested',out/'after-v1-project')]:
    run(['python','-X','utf8',str(out/'run_engine.py'),str(project),name,'300',f'--input={out/"gp.input.bin"}',f'--output={out/(name+".json")}', '--steps=80','--profile=nested'],name)
project=out/'after-v1-project'
shutil.copy2(out/'entry_trace.gd',project/'tools/performance/entry_trace.gd')
run(['python','-X','utf8',str(out/'run_engine.py'),str(project),'v1-entry-trace','300','script=res://tools/performance/entry_trace.gd',f'--input={out/"tick2900.input.bin"}',f'--output={out/"v1-entry-trace.ndjson"}'],'v1-entry-trace')
run(['python','-X','utf8',str(out/'run_engine.py'),str(out/'before-project'),'before-public-plain','900',f'--input={out/"public-v6.input.bin"}',f'--output={out/"before-public-plain.json"}','--steps=300','--profile=plain'],'before-public-plain')
