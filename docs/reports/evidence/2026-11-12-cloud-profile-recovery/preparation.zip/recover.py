import pathlib,subprocess,json,hashlib,time,datetime,os,zipfile,tarfile,sys
W=pathlib.Path('/workspace/scratch/6962cc21ddf3/cloud-validation-recovery-20261112')
P=pathlib.Path('/workspace/scratch/6962cc21ddf3/oddly-good-hospital-cloud-recovery-20261112')
for d in ['logs','engine','cache/downloads','cache/deps','cache/prefix','prior-evidence','state/home','state/config','state/cache','state/data']: (W/d).mkdir(parents=True,exist_ok=True)
records=[]
def utc(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def rec(p):
 p=pathlib.Path(p).resolve();return {'path':str(p),'sha256':hashlib.file_digest(p.open('rb'),'sha256').hexdigest(),'bytes':p.stat().st_size}
def stage(name,fn):
 row={'stage':name,'start_utc':utc()};start=time.monotonic();records.append(row);print('START',name,flush=True)
 try: fn();row['status']='passed'
 except Exception as e: row['status']='failed';row['error']=str(e);raise
 finally:
  row.update(end_utc=utc(),elapsed_seconds=time.monotonic()-start);(W/'timings.json').write_text(json.dumps(records,indent=2)+'\n');print('END',name,row['status'],round(row['elapsed_seconds'],3),flush=True)
def run(name,cmd,cwd=P,env=None):
 with (W/'logs'/f'{name}.log').open('w') as f: subprocess.run([str(c) for c in cmd],cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
with zipfile.ZipFile(P/'docs/reports/evidence/2026-11-12-cloud-continuation/preparation.zip') as z:z.extractall(W/'prior-evidence')
old=json.loads((W/'prior-evidence/provisioning-manifest.json').read_text());lock=json.loads((P/'tools/linux/dependencies.lock.json').read_text());assert lock==old['dependencies']
prov={'start_utc':utc(),'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=P,text=True).strip(),'old_artifacts_reused':False,'dependencies':lock,'host_tools':[],'host_gmp':[]}
for p in ['/usr/bin/gcc','/usr/bin/g++','/usr/bin/ar','/usr/bin/readelf']:
 item=rec(p);item['version']=subprocess.check_output([p,'--version'],text=True).splitlines()[0];prov['host_tools'].append(item)
for item in old['host_gmp']['files']:
 new=rec(item['path']);new['matches_prior']=new['sha256']==item['sha256'];prov['host_gmp'].append(new)
(W/'provisioning-manifest.json').write_text(json.dumps(prov,indent=2)+'\n')
def dl(name,url,p,sha):
 run('download-'+name,['curl','-fL','--retry','2','--max-time','240',url,'-o',p]);assert rec(p)['sha256']==sha, name+' SHA mismatch'
stage('download-engine',lambda:dl('engine',old['engine_download_url'],W/'engine/godot.zip',old['engine_archive']['sha256']))
def engine():
 with zipfile.ZipFile(W/'engine/godot.zip') as z:z.extractall(W/'engine')
 b=W/'engine/Godot_v4.7.2-stable_linux.x86_64';assert rec(b)['sha256']==old['engine']['sha256'];b.chmod(0o755)
 assert subprocess.check_output([b,'--version'],text=True).strip()==old['engine_version']
stage('verify-engine',engine)
for n,v in lock.items():stage('download-'+n,lambda n=n,v=v:dl(n,v['url'],W/'cache/downloads'/n,v['sha256']))
stage('install-tools',lambda:run('build-tools-install',[sys.executable,'-m','pip','install','--target',W/'build-tools','cmake==4.4.4','ninja==1.13.2']))
def extract():
 for n in lock:
  p=W/'cache/downloads'/n
  if n.endswith('.zip'):
   with zipfile.ZipFile(p) as z:z.extractall(W/'cache/deps')
  elif n.endswith('.zst'):run('extract-mpfr',['tar','--zstd','-xf',p,'-C',W/'cache/deps'])
  else:
   with tarfile.open(p) as t:t.extractall(W/'cache/deps',filter='data')
 p=W/'cache/deps/mingw-w64-mpfr/mpfr-4.2.2.tar.xz';assert rec(p)['sha256']=='b67ba0383ef7e8a8563734e2e889ef5ec3c3b898a01d00fa0a6869ad81c6ce01'
 with tarfile.open(p) as t:t.extractall(W/'cache/deps',filter='data')
stage('extract',extract)
mpfr=W/'cache/deps/mpfr-4.2.2';boost=W/'cache/deps/boost_1_92_0'
stage('mpfr-configure',lambda:run('mpfr-configure',['./configure','--prefix='+str(W/'cache/prefix'),'--with-pic','--enable-shared','--disable-static','CFLAGS=-O2 -fPIC -ffile-prefix-map='+str(W)+'=cloud-build'],mpfr))
stage('mpfr-build',lambda:run('mpfr-build',['make','-j2'],mpfr))
stage('mpfr-install',lambda:run('mpfr-install',['make','install'],mpfr))
stage('boost-bootstrap',lambda:run('boost-bootstrap',['./bootstrap.sh','--with-libraries=headers','--prefix='+str(W/'cache/prefix')],boost))
stage('boost-install',lambda:run('boost-install',['./b2','--with-headers','install','--prefix='+str(W/'cache/prefix'),'-j2'],boost))
stage('dependencies-build',lambda:run('dependencies-build',['bash','tools/linux/build-dependencies.sh',W/'cache',W/'build-tools/cmake/data/bin/cmake',W/'build-tools/bin/ninja','2']))
stage('cache-capture',lambda:run('cache-capture',[sys.executable,'tools/build-platform-linux.py','capture-cache','--cache',W/'cache','--output',W/'linux-dependency-inputs.json']))
G=W/'engine/Godot_v4.7.2-stable_linux.x86_64'
stage('native-build',lambda:run('native-build',[sys.executable,'tools/build-platform-linux.py','build','--inputs',W/'linux-dependency-inputs.json','--godot',G,'--build-dir',W/'native-build']))
env=dict(os.environ,HOME=str(W/'state/home'),XDG_CONFIG_HOME=str(W/'state/config'),XDG_CACHE_HOME=str(W/'state/cache'),XDG_DATA_HOME=str(W/'state/data'),LD_LIBRARY_PATH=str(W/'cache/prefix/lib'))
(W/'native_load_probe.gd').write_bytes((W/'prior-evidence/native_load_probe.gd').read_bytes())
stage('native-load',lambda:run('native-load',['timeout','60',G,'--headless','--path',P,'--script',W/'native_load_probe.gd'],env=env))
stage('import',lambda:run('import',['timeout','120',G,'--headless','--path',P,'--editor','--import','--quit'],env=env))
for n in ['native-load','import']:
 assert not any(x in (W/'logs'/f'{n}.log').read_text() for x in ['ERROR:','SCRIPT ERROR:','Parse Error']),n+' emitted error'
m=json.loads((W/'native-build/build-manifest.json').read_text());assert m['status']=='built';assert rec(m['artifact']['path'])==m['artifact'];prior=json.loads((W/'prior-evidence/native-build/build-manifest.json').read_text())
changed=[]
for a in m['sources']:
 rel=str(pathlib.Path(a['path']).relative_to(P));match=[b for b in prior['sources'] if b['path'].endswith('/'+rel)]
 if not match or match[0]['sha256']!=a['sha256']:changed.append(rel)
summary={'status':'built-loaded-imported','source_head':prov['source_head'],'native':m['artifact'],'native_matches_prior':m['artifact']['sha256']==prior['artifact']['sha256'],'engine':rec(G),'engine_version':old['engine_version'],'source_changes_vs_prior_build':changed,'abi_comparison':[], 'tracked_diff':subprocess.check_output(['git','diff','--name-only'],cwd=P,text=True).splitlines(),'generated_untracked':subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=P,text=True).splitlines(),'dynamic_resolution':subprocess.check_output(['ldd',m['artifact']['path']],env=env,text=True),'timings':records,'unrun':['gameplay','snapshot restore','profiling','release export']}
for n in ['extension_api.json','gdextension_interface.h','platform_guard_abi.h']:summary['abi_comparison'].append({'file':n,'matches_prior':rec(W/'native-build'/n)['sha256']==rec(W/'prior-evidence/native-build'/n)['sha256'],'current':rec(W/'native-build'/n)})
(W/'preparation-result.json').write_text(json.dumps(summary,indent=2)+'\n');print('COMPLETE',json.dumps({k:summary[k] for k in ['status','native','native_matches_prior','source_changes_vs_prior_build','tracked_diff']}),flush=True)
