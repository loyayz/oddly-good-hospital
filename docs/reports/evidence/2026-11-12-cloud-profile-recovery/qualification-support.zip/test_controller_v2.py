"""Pure synthetic controller checks; no engine, fixture simulation, or subprocess."""
import copy, unittest
import controller_v2 as c
class Checks(unittest.TestCase):
    def test_identity(self):
        good={'config_sha256':'a','controller_sha256':'b','guard_sha256':'c','input_sha256':'d','locked_files':{'native.so':'e'},'project_inventory':{'game.gd':'f'}}
        c.match_identity(good,copy.deepcopy(good))
        for key in good:
            bad=copy.deepcopy(good);bad[key]='different'
            with self.assertRaises(AssertionError): c.match_identity(good,bad)
    def test_stage_rows(self):
        rows=[{'tick':10,'elapsed_us':1},{'tick':11,'elapsed_us':2},{'tick':12,'elapsed_us':3}]
        records=[{'tick':11,'outer_elapsed_us':2},{'tick':12,'outer_elapsed_us':3}]
        c.stage_records_match(records,rows,1)
        with self.assertRaises(AssertionError):c.stage_records_match(records[:-1],rows,1)
        bad=copy.deepcopy(records);bad[0]['tick']=10
        with self.assertRaises(AssertionError):c.stage_records_match(bad,rows,1)
        bad=copy.deepcopy(records);bad[0]['outer_elapsed_us']=999
        with self.assertRaises(AssertionError):c.stage_records_match(bad,rows,1)
    def test_no_false_acceptance(self):
        r={'all_completed_steps':2,'requested_sample_steps':2,'requested_prefix_steps':0,'complete':True,'sample_business':{'comprehensive':{'coverage_pass':False}},'performance_pass':None}
        s=c.pair_status(r,r)
        self.assertTrue(s['execution_complete']);self.assertFalse(s['business_coverage_pass']['plain'])
        self.assertIsNone(s['performance_pass_reported']['plain']);self.assertNotIn('acceptance_pass',s)
        self.assertFalse(s['three_repeat_acceptance_established'])
        r['complete']=False;r['performance_pass']=False
        s=c.pair_status(r,r);self.assertTrue(s['execution_complete']);self.assertFalse(s['raw_complete']['plain']);self.assertFalse(s['performance_pass_reported']['plain'])
        r['all_completed_steps']=1;self.assertFalse(c.pair_status(r,r)['execution_complete'])
if __name__=='__main__':unittest.main()
