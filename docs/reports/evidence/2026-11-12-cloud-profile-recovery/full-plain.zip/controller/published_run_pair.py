import os,sys,json,hashlib,subprocess,time,signal,datetime,runpy
from pathlib import Path
BASE=Path(__file__).parent
PROJECT=BASE/'project'
ENGINE=BASE.parent/'cloud-validation-20261112/engine/Godot_v4.7.2-stable_linux.x86_64'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2))
def run(command,directory,timeout=180,expect_timeout=False):
 directory.mkdir(exist_ok=False)
 env=dict(os.environ,OMP_NUM_THREADS='1',PYTHONUTF8='1',LD_LIBRARY_PATH='/workspace/scratch/6962cc21ddf3/cloud-validation-20261112/cache/prefix/lib')
 for key,name in [('HOME','home'),('XDG_DATA_HOME','data'),('XDG_CONFIG_HOME','config'),('XDG_CACHE_HOME','cache'),('TMPDIR','tmp')]:
  p=directory/name;p.mkdir();env[key]=str(p)
 record={'command':command,'cwd':str(PROJECT),'environment':{k:env[k] for k in ['HOME','XDG_DATA_HOME','XDG_CONFIG_HOME','XDG_CACHE_HOME','TMPDIR','OMP_NUM_THREADS','LD_LIBRARY_PATH']},'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'guard_sha256':sha(Path(__file__))}
 started=time.monotonic();timedout=False
 with (directory/'engine.log').open('wb') as log:
  p=subprocess.Popen(command,cwd=PROJECT,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);record['owned_pid']=p.pid;write(directory/'process.json',record)
  try:
   while p.poll() is None:
    time.sleep(.1)
    raw=(directory/'engine.log').read_bytes()
    if b'SCRIPT ERROR:' in raw or b'\nERROR:' in b'\n'+raw:raise RuntimeError('engine errors; inspect preserved log')
    if time.monotonic()-started>timeout:timedout=True;raise TimeoutError('owned process timeout')
  except TimeoutError:
   if not expect_timeout:raise
  finally:
   if p.poll() is None:
    os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=5)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
   record.update(returncode=p.returncode,timed_out=timedout,reaped=p.poll() is not None,wall_seconds=time.monotonic()-started,log_sha256=sha(directory/'engine.log'));write(directory/'process.json',record)
 assert record['reaped'] and (timedout if expect_timeout else p.returncode==0)
 return record
if __name__=='__main__':
 if sys.argv[1:]==['guard-proof']:
  print(run([sys.executable,'-c','import time;time.sleep(60)'],BASE/'guard-proof',timeout=.3,expect_timeout=True));sys.exit()
 assert sys.argv[1:]==['execute-pair']
 assert sha(ENGINE)=='8d106cbe6144c2dc7e881d61d2429c1a8a76e6b22ef48bd5e48dcf934953f71e'
 assert sha(PROJECT/'game/platform/linux/bin/oddly_good_platform.linux.x86_64.so')=='3e97c961acf01e178046efc14b5dff786a83b4e91f09638528ccf531b248d379'
 identity=json.loads((BASE/'identity.json').read_text())
 for rel,h in identity['files'].items():assert sha(PROJECT/rel)==h,rel
 assert sha(BASE/'input59570f.bin')==identity['input_sha256']
 # Parent must explicitly release the serial slot before this command is used.
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:name=(p/'comm').read_text().strip()
  except (OSError,ProcessLookupError):continue
  assert not name.lower().startswith(('godot','cc1','clang','ninja','cmake')),('occupied serial slot',p.name,name)
 hooks=runpy.run_path(str(BASE/'hooks.py'));patches=hooks['patches'];write(BASE/'overlay.json',{k:v.checked() for k,v in patches.items()})
 write(BASE/'execution-identity.json',{'engine':str(ENGINE),'engine_sha256':sha(ENGINE),'native_sha256':sha(PROJECT/'game/platform/linux/bin/oddly_good_platform.linux.x86_64.so'),'input_sha256':sha(BASE/'input59570f.bin')})
 def command(folder):return [str(ENGINE),'--headless','--path',str(PROJECT),'--script','res://tools/performance/current/plain_v4.gd','--','--input='+str(BASE/'input59570f.bin'),'--output='+str(BASE/folder/'result.json'),'--steps=1','--prefix-steps=0','--worker-tasks=4','--main-thread-policy=app']
 run(command('plain1'),BASE/'plain1')
 try:
  for p in patches.values():p.path.write_bytes(p.text.encode())
  run(command('trace1'),BASE/'trace1')
 finally:
  for p in patches.values():p.path.write_bytes(p.original)
  for rel,h in identity['files'].items():assert sha(PROJECT/rel)==h,rel
 a=json.loads((BASE/'plain1/result.json').read_text());b=json.loads((BASE/'trace1/result.json').read_text())
 assert a['complete'] and b['complete'] and a['all_completed_steps']==b['all_completed_steps']==1
 x=(BASE/'plain1/result.json.final.bin').read_bytes();y=(BASE/'trace1/result.json.final.bin').read_bytes();assert x==y
 write(BASE/'comparison.json',{'complete_world_rng_ordered_events_equal':True,'steps':1,'input_sha256':identity['input_sha256'],'final_sha256':hashlib.sha256(x).hexdigest(),'source_restored':True})
 print('One-step pair complete, equal and restored')
