"""Recovery controller v2.1. Three explicit phases; never chains full windows.
Config is populated only after new runtime qualification. No engine on import.
"""
import argparse, hashlib, json, os, traceback, zipfile
from pathlib import Path
import linux_guard_v2 as guard
BASE=Path(__file__).resolve().parent
INPUT_SHA='75f5e1d922f39f12382c0ceb74806bda0293251189f68a1ac158842f65fa78ca'
TOOLS={'tools/performance/current/plain_v4.gd':'a6ca441d0bc67153673adf5279ea2b100286b4834f9cceeb7907cb21acfc5506','tools/performance/step_profile.gd':'fa164577cb8c9e2bdd251f1231fc36a3bd97d3f31d343ed2da0741e906b2b60e'}
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p): return json.loads(Path(p).read_text())
def write(p,v): Path(p).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
def inventory(project):
    return {str(p.relative_to(project)):sha(p) for p in sorted(project.rglob('*')) if p.is_file() and '.cache' not in p.relative_to(project).parts and '.git' not in p.relative_to(project).parts}
def idle():
    for p in Path('/proc').iterdir():
        if not p.name.isdigit(): continue
        try: name=(p/'comm').read_text().strip().lower()
        except OSError: continue
        assert not name.startswith(('godot','cc1','clang','ninja','cmake')), ('serial slot occupied',p.name,name)
def verify(cfg):
    project=Path(cfg['project']); assert project.is_dir()
    assert sha(BASE/'mixed160.input.bin')==INPUT_SHA
    for rel,h in TOOLS.items(): assert sha(project/rel)==h,rel
    assert cfg['locked_files'] and str(Path(cfg['engine'])) in cfg['locked_files']
    assert any(p.endswith('.so') for p in cfg['locked_files']), 'native identity missing'
    for p,h in cfg['locked_files'].items(): assert sha(p)==h,p
    assert inventory(project)==cfg['project_inventory'], 'project/imported cache differs'
    return project

def phase_identity(cfg):
    return {'config_sha256':sha(BASE/'config.json'),'controller_sha256':sha(__file__),
            'guard_sha256':sha(BASE/'linux_guard_v2.py'),'input_sha256':INPUT_SHA,
            'locked_files':cfg['locked_files'],'project_inventory':cfg['project_inventory']}
def match_identity(saved,current):
    assert saved==current, 'qualification identity differs from current config/controller/guard/source/native/cache'

def stage_records_match(records,completed,prefix):
    measured=completed[prefix:]
    assert len(records)==len(measured), 'stage/sample record count mismatch'
    for record,row in zip(records,measured):
        assert record['tick']==row['tick'], 'stage/sample tick mismatch'
        assert record['outer_elapsed_us']==row['elapsed_us'], 'stage/sample elapsed mismatch'

def pair_status(x,y):
    return {'execution_complete':all(r['all_completed_steps']==r['requested_sample_steps']+r['requested_prefix_steps'] for r in (x,y)),
            'raw_complete':{'plain':x['complete'],'stages':y['complete']},
            'business_coverage_pass':{k:r['sample_business']['comprehensive']['coverage_pass'] for k,r in [('plain',x),('stages',y)]},
            'performance_pass_reported':{k:r.get('performance_pass') for k,r in [('plain',x),('stages',y)]},
            'performance_status_note':'null means raw driver did not evaluate a performance pass; it is not true',
            'three_repeat_acceptance_established':False,
            'purpose':'diagnostic equality only, including 0+2 qualification; not three-repeat acceptance'}

def result_checks(folder,count,profile):
    r=read(folder/'result.json'); assert r['all_completed_steps']==count
    assert sha(folder/'result.json.final.bin')==r['final_sha256']
    rows=[json.loads(line) for line in (folder/'result.json.steps.ndjson').read_text().splitlines()]
    completed=[x['sample'] for x in rows if x['kind']=='complete']
    assert len(completed)==count and [x['index'] for x in completed]==list(range(count))
    assert r['source_input_sha256']==INPUT_SHA
    assert read(folder/'process.json')['returncode']==(0 if r['complete'] else 1)
    if profile:
        s=read(folder/'result.json.stages.json'); expected=2 if count==2 else 6000
        assert s['steps']==s['complete_steps']==expected and s['incomplete_steps']==0
        assert not s['errors'] and s['step_records_complete'] and len(s['step_records'])==expected
        assert s['partition_check_us']==0 and not s['nested_calls']
        stage_records_match(s['step_records'],completed,0 if count==2 else 1000)
        assert s['sources']['root_method_preserved'] and s['sources']['attach_world_unchanged'] and s['sources']['nested_enabled']==False
        for x in s['step_records']:
            assert x['complete'] and not x['calls'] and x['nested_call_edges']==0
            assert x['root_stage_us']==sum(y['total_us'] for y in x['stages'].values())
            assert x['outer_elapsed_us']==x['root_stage_us']+x['observer_handler_us']+x['residual_us']
    return r

def pair(a,b):
    x=read(a/'result.json'); y=read(b/'result.json')
    assert (a/'result.json.final.bin').read_bytes()==(b/'result.json.final.bin').read_bytes()
    for k in ['source_input_sha256','prefix_business','sample_business','business','errors','complete','all_completed_steps']:
        assert x[k]==y[k],k
    return {'complete_world_rng_ordered_events_equal':True,'business_and_failure_status_equal':True,'final_sha256':x['final_sha256'],'status':pair_status(x,y)}

def checkpoint(phase_dir,cfg):
    # Called only after engine has exited; no compression within measured work.
    files={str(p.relative_to(phase_dir)):p for p in sorted(phase_dir.rglob('*')) if p.is_file()}
    for p in [BASE/'controller_v2.py',BASE/'linux_guard_v2.py',BASE/'published_run_pair.py',BASE/'mixed160.input.bin',BASE/'config.json']:
        files['controller/'+p.name]=p
    for rel in TOOLS: files['sources/'+rel]=Path(cfg['project'])/rel
    generated=Path(cfg['project'])/'.cache/performance160-profile-sources'
    if generated.exists():
        for p in sorted(generated.rglob('*')):
            if p.is_file(): files['generated-profile-sources/'+str(p.relative_to(generated))]=p
    for p in cfg.get('provenance_files',[]): files['provenance/'+Path(p).name]=Path(p)
    members={n:{'size':p.stat().st_size,'sha256':sha(p)} for n,p in files.items()}
    manifest=phase_dir.with_suffix('.members.json'); write(manifest,members)
    archive=phase_dir.with_suffix('.zip')
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for n,p in files.items(): z.write(p,n)
        z.write(manifest,'MEMBERS.json')
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for n,v in members.items():
            b=z.read(n); assert len(b)==v['size'] and hashlib.sha256(b).hexdigest()==v['sha256']
    write(phase_dir.with_suffix('.checkpoint.json'),{'archive':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(members),'local_readback_verified':True,'durable_publication_verified':False})

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('phase',choices=['qualification','full-plain','full-stages']); ap.add_argument('--release',required=True); args=ap.parse_args()
    cfg=read(BASE/'config.json'); release=read(args.release)
    assert release['phase']==args.phase and release['controller_sha256']==sha(__file__) and release['config_sha256']==sha(BASE/'config.json')
    current_identity=phase_identity(cfg)
    if args.phase!='qualification':
        assert read(BASE/'qualification/comparison.json')['complete_world_rng_ordered_events_equal']
        match_identity(read(BASE/'qualification/phase-identity.json'),current_identity)
    if args.phase=='full-stages':
        receipt=release['plain_durable_receipt']; saved=read(BASE/'full-plain.checkpoint.json')
        assert receipt['readback_verified'] is True and receipt['archive_sha256']==saved['sha256'] and receipt['destination']
        assert sha(BASE/'full-plain.zip')==saved['sha256']
    project=verify(cfg); idle(); phase_dir=BASE/args.phase; phase_dir.mkdir(exist_ok=False)
    write(phase_dir/'phase-identity.json',current_identity)
    guard.PROJECT=project; guard.LIBRARY_PATH=cfg['library_path']
    try:
        modes=[('plain',False),('stages',True)] if args.phase=='qualification' else [('run',args.phase=='full-stages')]
        for name,profile in modes:
            verify(cfg); idle(); folder=phase_dir/name; short=args.phase=='qualification'
            cmd=[cfg['engine'],'--headless','--path',str(project),'--script','res://tools/performance/current/plain_v4.gd','--','--input='+str(BASE/'mixed160.input.bin'),'--output='+str(folder/'result.json'),'--prefix-steps='+('0' if short else '1000'),'--steps='+('2' if short else '6000'),'--observed-floor=1','--worker-tasks=4','--main-thread-policy=app','--expected-scenario=mixed160-clinical-ops-v1']
            if not short: cmd.append('--require-coverage')
            if profile: cmd.append('--profile-stages')
            guard.run(cmd,folder,timeout=180 if short else 3600,allowed_exits=(0,1))
            verify(cfg); result_checks(folder,2 if short else 7000,profile)
        if args.phase=='qualification':
            for name,_ in modes: assert read(phase_dir/name/'result.json')['complete']
            write(phase_dir/'comparison.json',pair(phase_dir/'plain',phase_dir/'stages'))
        elif args.phase=='full-stages': write(phase_dir/'comparison.json',pair(BASE/'full-plain/run',phase_dir/'run'))
        write(phase_dir/'controller-status.json',{'execution_and_evidence_checks':'passed','business_acceptance':'see unchanged result.json; not overridden'})
    except BaseException:
        write(phase_dir/'controller-error.json',{'traceback':traceback.format_exc()}); raise
    finally:
        restored=True
        try: verify(cfg); write(phase_dir/'restoration.json',{'locked_sources_and_cache_unchanged':True,'production_hooks_installed':False})
        except BaseException:
            restored=False
            write(phase_dir/'restoration.json',{'locked_sources_and_cache_unchanged':False,'error':traceback.format_exc()})
        checkpoint(phase_dir,cfg)
        assert restored, 'source/cache identity failed; preserved failure archive'
if __name__=='__main__': main()
