from pathlib import Path
import sys,shutil,traceback
BASE=Path(__file__).resolve().parent;REPO=BASE.parent/'oddly-good-hospital-cloud-recovery-20261112';ROOT=BASE.parent/'root-stage-recovery-20261112';N=BASE.parent/'movement-stage-recovery-20261112'
sys.path.insert(0,str(N));import full_narrow_v1 as h
c=h.c;g=h.g;case,runid=sys.argv[1:];out=BASE/runid;assert not out.exists();out.mkdir();cfg=c.read(ROOT/'config.json');c.verify(cfg);c.idle();g.PROJECT=REPO;g.LIBRARY_PATH=cfg['library_path']
inv=c.inventory(REPO);c.write(out/'identity.json',{'source_inventory':inv,'runtime':cfg,'case':case})
for rel in ['game/building/navigation_cache.gd','game/building/hospital_navigation.gd','tests/acceptance/structural_body_resident.gd','tests/acceptance/run_structural_cache_selected.gd']:
 shutil.copy2(REPO/rel,out/Path(rel).name)
cmd=[cfg['engine'],'--headless','--path',str(REPO),'--script','res://tests/acceptance/run_structural_cache_selected.gd']
if case=='parse':cmd+=['--check-only']
else:cmd+=['--',case,str(out/'result.json')]
c.write(out/'host-before.json',h.host())
try:
 g.run(cmd,out/'engine',timeout=300,allowed_exits=(0,1))
 if case!='parse':
  r=c.read(out/'result.json');assert r['ok'],r
except BaseException:c.write(out/'error.json',{'traceback':traceback.format_exc()});raise
finally:c.write(out/'host-after.json',h.host())
