from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import zipfile

REPO = Path(__file__).resolve().parent.parent
ROOT = REPO/'.cache/waiting-phase-f4207fb-20261023'
OUT = REPO/'docs/reports/evidence/2026-10-23-waiting-cost-and-reverse-field'
BASE = REPO/'.cache/worker-production-20261023/production-project'
read = lambda p: json.loads(Path(p).read_text(encoding='utf-8-sig'))
digest = lambda b: hashlib.sha256(b).hexdigest()
sha = lambda p: digest(Path(p).read_bytes())
relative = lambda p: str(Path(p).relative_to(REPO)).replace('\\','/')

def write(path,value):
    Path(path).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

assert not OUT.exists()
prior = REPO/'docs/reports/evidence/2026-10-22-worker-pool-environment/raw-evidence.zip'
assert sha(prior)=='aee05728e481d710ef1ee1c05b6bbdb96288bdda5b0aa88e38129ad7f3d93609'
baseline = read(REPO/'.cache/worker-production-20261023/production-source-identity.json')
current = read(ROOT/'reverse-identity.json')
changed = {x['path'] for x in current['changed_production_sources']}
assert changed=={'game/building/navigation_cache.gd','game/building/hospital_navigation.gd'}
for row in baseline['production_sources']:
    path = row['path']
    assert sha(BASE/path)==row['sha256'],path
    if path not in changed|{'project.godot','export_presets.cfg'}: assert sha(REPO/path)==row['sha256'],path
for row in current['sources']:
    path = row['path']
    assert sha(ROOT/'reverse-project'/path)==row['sha256'],path
    if path not in ['project.godot','export_presets.cfg']: assert sha(REPO/path)==row['sha256'],path
doc_changes = []
for row in current['actual_tests']:
    path = row['path']
    assert sha(ROOT/'reverse-project'/path)==row['sha256'],path
    if sha(REPO/path)!=row['sha256']:
        assert path=='tests/acceptance/space.md',path
        doc_changes.append(dict(path=path,measured_sha256=row['sha256'],delivery_sha256=sha(REPO/path),documentation_only=True))

members = {}
def add(path,name=None):
    path = Path(path)
    if not path.is_file(): return
    name = name or relative(path)
    data = path.read_bytes()
    if name in members: assert members[name]==data,name
    members[name] = data

for path in ROOT.iterdir():
    if path.is_file() and not path.name.endswith('.final.bin'): add(path)
for path in ROOT.glob('*.sources/*.gd'): add(path)
for project in ['probe-project','probe-project-02','probe-project-03']:
    for path in ['game/life/waiting_life.gd','game/life/public_areas.gd']: add(ROOT/project/path)
add(ROOT/'after-project/game/life/public_areas.gd')
for path in sorted(changed|{'tests/acceptance/reference_route_permissions.gd','tests/acceptance/navigation_key_scope.gd'}):
    add(BASE/path,'baseline-source/'+path)
    add(REPO/path,'delivery-source/'+path)
add(REPO/'tests/acceptance/space.md','delivery-source/tests/acceptance/space.md')
add(REPO/'.cache/waiting_probe_f4207fb.py')
add(Path(__file__))
add(BASE/'tools/performance/representative_worker.gd','runner-source/representative_worker.gd')
for name in ['public-v6.input.bin','gp.input.bin','op.input.bin']: add(REPO/'.cache/task-navigation-20261019'/name)

aliases = []
for path in ROOT.glob('*.final.bin'):
    data = path.read_bytes()
    name = 'final-states/'+digest(data)+'.bin'
    if name in members: assert members[name]==data
    members[name] = data
    aliases.append(dict(original=relative(path),member=name,size=len(data),sha256=digest(data)))

labels = ['a-gp80','probe02-gp80','probe03-gp80','a-public360','b-public360','b-gp80','r1-gp80','r2-gp80','r2-public360','a2-gp80','a2-public360','r2-operations40','a2-operations40']
runs = {}
for label in labels:
    result = read(ROOT/(label+'.json'))
    launch = read(ROOT/(label+'.launch.json'))
    assert result['complete'] and result['qualified'] and not result['errors']
    assert launch['exit_code']==0 and not launch['timed_out'] and not launch['errors']
    assert len(result['samples'])==result['requested_steps']
    assert all(x['present']==160 and x['complete'] for x in result['samples'])
    window = next(x for x in ['public360','gp80','operations40'] if label.endswith(x))
    expected = read(REPO/'.cache/worker-production-20261023'/('b3-'+window+'.json'))
    for key in ['source_input_sha256','initial','final','qualification','operations','event_records','final_binary_sha256']:
        assert result.get(key)==expected.get(key),(label,key)
    assert [{k:v for k,v in x.items() if k!='elapsed_us'} for x in result['samples']]==[{k:v for k,v in x.items() if k!='elapsed_us'} for x in expected['samples']]
    actual_public,expected_public = result['public'].copy(),expected['public'].copy()
    ac,ec = actual_public.pop('query_counts'),expected_public.pop('query_counts')
    assert actual_public==expected_public
    differences = {k:dict(actual=ac.get(k),baseline=ec.get(k)) for k in ac.keys()|ec.keys() if ac.get(k)!=ec.get(k)}
    allowed = {'distance_field_builds','distance_field_hits','static_path_builds','static_path_hits','structural_reverse_field_lookups','structural_reverse_field_hits'} if label.startswith(('r1-','r2-')) else set()
    assert all(k.startswith('diag_wait/') or k in allowed for k in differences),label
    assert sha(ROOT/(label+'.json.final.bin'))==result['final_binary_sha256'],label
    runs[label] = dict(metrics_us=result['metrics'],steps=len(result['samples']),all_business_events_rng_non_time_samples_equal=True,query_count_differences=differences,
        wall_ms=launch['wall_ms'],cpu_ms=launch['child_cpu_ms'],input_sha256=result['source_input_sha256'],final_binary_sha256=result['final_binary_sha256'])

final_cases = read(ROOT/'reverse-functional-04.acceptance-results.json')
assert final_cases['completed'] and final_cases['checks']==3 and final_cases['failed']==0
assert sorted(final_cases['results'])==['SPACE-51','STAFF-57','STAFF-61']
failed_cases = read(ROOT/'reverse-functional-02.acceptance-results.json')
assert failed_cases['failed']==1 and not failed_cases['results']['SPACE-51']['passed']
assert failed_cases['results']['SPACE-51']['details']['reference_permissions']['reverse_structural_fields']['ok']

def pair(before,after):
    a,b = runs[before]['metrics_us'],runs[after]['metrics_us']
    return {k:dict(before_us=a[k],after_us=b[k],change_percent=(b[k]/a[k]-1)*100) for k in ['mean_us','p50_us','p95_us','p99_us','cold_first_us','max_us']}

summary = dict(schema_version=1,diagnostic_only=True,formal_pass=False,generated_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    baseline_commit='f4207fb8d829ad833a744dbd08629563f9f8c8fa',current_workspace_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip(),
    adopted='Structural reverse cost field with original warmup, budget, graph proof and AStar failure fallback',
    rejected='Flattened queue signature: no established whole-step benefit; both P99 samples regressed',
    fixed_load=dict(actors=160,patients=120,staff=32,visitors=8,floors=4,rooms=64,facilities=1336,tick_seconds=.1),
    performance_successful_windows=len(runs),performance_steps=sum(x['steps'] for x in runs.values()),runs=runs,
    final_vs_nearby_serial=dict(public360=pair('a2-public360','r2-public360'),gp80=pair('a2-gp80','r2-gp80'),operations40=pair('a2-operations40','r2-operations40')),
    final_vs_earlier_serial=dict(public360=pair('a-public360','r2-public360'),gp80=pair('a-gp80','r2-gp80')),
    flattened_signature=dict(public360=pair('a-public360','b-public360'),gp80=pair('a-gp80','b-gp80')),
    selected_final_functional={k:dict(passed=v['passed'],body_ms=v['body_ms'],setup_ms=v['setup_ms']) for k,v in final_cases['results'].items()},
    actual_baseline_source_rows_checked=len(baseline['production_sources']),actual_final_runtime_source_rows_checked=len(current['sources']),actual_final_test_rows_checked=len(current['actual_tests']),
    documentation_only_changes_since_functional=doc_changes,all_current_runtime_and_test_gd_files_match_final_execution=True,
    reused_complete_baseline=dict(path=relative(prior),sha256=sha(prior),scope='Original engine, native library, complete prepared runtime/assets; this archive adds actual final 485-row identity, changed sources and inverse diagnostic transformations.'),
    final_binary_aliases=aliases,
    limitations=['Root and selected inline spans are diagnostics, include residual observer effects and overlap. No observer subtraction estimates plain CPU.',
        'probe02 select events incorrectly included lambda returns and are rejected. Its complete raw window is retained.',
        'Prototype r1 precedes the final failed-result schema fallback; only r2 is final production measurement.',
        'A1/B/A2 controls show drift. Nearby public mean is flat and operations mean regressed; all retained.',
        'No Release, full capacity, rendering, allocation measurement or two-hour run. Formal acceptance has not passed.',
        'No diagnostic public360 window was executed although its selected tick conditions were prepared.'],
    failures=['First read-only Python display used Windows default encoding; fixed to explicit UTF-8.',
        'First inline generator included following static function and failed parsing; actual source and engine logs retained.',
        'probe02 completed but tool summary looked up wrong root stage; select lambda return instrumentation invalidated select timing.',
        'reverse-functional initial SPACE-51 test had too many facade arguments; same run STAFF-57/61 passed.',
        'reverse-functional-02 failed old distance-key schema assertion; actual reverse contract and other business checks passed.',
        'Final canonical structural reverse mode test and complete three-case regression passed.'])

OUT.mkdir(parents=True)
archive = OUT/'raw-evidence.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name,data in sorted(members.items()): z.writestr(name,data)
rows = []
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist())==len(members)
    for name,data in sorted(members.items()):
        stored = z.read(name)
        assert stored==data,name
        rows.append(dict(path=name,size=len(stored),sha256=digest(stored)))
manifest = dict(schema_version=1,archive=archive.name,size=archive.stat().st_size,sha256=sha(archive),members=len(rows),files=rows,
    final_binary_aliases=aliases,reused_complete_baseline=summary['reused_complete_baseline'],no_engine_build_or_test_during_freeze=True)
summary['raw_archive'] = {k:manifest[k] for k in ['archive','size','sha256','members']}
write(OUT/'summary.json',summary)
write(OUT/'raw-manifest.json',manifest)
print(json.dumps(dict(archive=relative(archive),sha256=sha(archive),bytes=archive.stat().st_size,members=len(rows),windows=len(runs),steps=summary['performance_steps'],pairs=summary['final_vs_nearby_serial'])),flush=True)
