"""Verify and freeze the existing route-tail diagnostic; never run the engine."""
from __future__ import annotations

from collections import Counter
from datetime import datetime, timezone
import importlib.util
import json
from pathlib import Path
import sys
import time
import uuid

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
PRIOR = REPO / ".cache/wait-signature-031e1f7-20261022"
PRIOR_OUT = REPO / "docs/reports/evidence/2026-10-22-wait-dependency-batch"
SOURCE = PRIOR / "after-project"
PROJECT = ROOT / "probe-project"
OUT = REPO / "docs/reports/evidence/2026-10-22-route-tail-queries"
SOURCE_HEAD = "d5f048e1fe918bd764f3607db49a3c2f360be89a"
OUTPUTS = ("summary.json", "source-check.json", "functional-summary.json", "raw-manifest.json", "raw-evidence.zip")

# Reuse the already published verifier's byte hashes, archive reread, and full
# ordinary-window validation. Importing it performs no measurement or mutation.
spec = importlib.util.spec_from_file_location("wait_evidence", PRIOR / "summarize.py")
lib = importlib.util.module_from_spec(spec)
spec.loader.exec_module(lib)
read, encoded, digest, require, relative = lib.read, lib.encoded, lib.digest, lib.require, lib.relative
uncached_sha = lib.sha
hashes = {}


def sha(path):
    path = Path(path).resolve()
    before = path.stat()
    key = (path, before.st_size, before.st_mtime_ns)
    if key not in hashes:
        hashes[key] = uncached_sha(path)
        after = path.stat()
        require((before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns), (path, "Changed while hashing"))
    return hashes[key]


lib.sha = sha


def evidence_ref(path):
    return {"path": relative(path), "size": path.stat().st_size, "sha256": sha(path)}


def source_check(archive):
    head = lib.git("rev-parse", "HEAD").decode().strip()
    prior_check = read(PRIOR_OUT / "source-check.json")
    prior_manifest = read(PRIOR_OUT / "raw-manifest.json")
    prior_files = {row["path"]: row for row in prior_manifest["files"]}
    reused_documents = [PRIOR_OUT / name for name in ("source-check.json", "raw-manifest.json", "functional-summary.json")]
    committed = lib.git_blobs(head, [relative(path) for path in reused_documents])
    for path in reused_documents:
        require(digest(committed[relative(path)]) == sha(path), (path, "Reused evidence differs from committed document"))
    require(prior_check["fix_commit"] == SOURCE_HEAD, "Wrong reused source head")
    prior_after = next(row for row in prior_check["source_snapshots"] if row["side"] == "after")
    require(prior_after["all_source_rows_checked_against_actual_files_and_committed_blobs"] is True, "Missing prior complete verification")
    require(sha(PRIOR_OUT / "source-check.json") == prior_files[relative(PRIOR_OUT / "source-check.json")]["sha256"], "Reused verification differs from its ZIP manifest")
    identity = read(SOURCE / "source-identity.json")
    expected = lib.identity_rows(identity)
    require(identity["head"] == SOURCE_HEAD and len(expected) == 484, "Unexpected frozen identity")
    require(sha(SOURCE / "source-identity.json") == prior_after["source_identity_sha256"], "Reused source identity changed")
    old_rows = {row["path"]: row for row in prior_after["files"]}
    require(set(old_rows) == set(expected), "Reused complete inventory differs")
    require(all(old_rows[path]["committed_original_sha256"] == value for path, value in expected.items()), "Reused source hashes differ")
    committed_changes = set(lib.git("-c", "core.quotepath=false", "diff", "--name-only", SOURCE_HEAD, head).decode("utf-8").splitlines())
    workspace_changes = set(lib.git("-c", "core.quotepath=false", "diff", "--name-only", "HEAD").decode("utf-8").splitlines())
    require(not committed_changes.intersection(expected), "Production source changed since measured d5")
    require(not workspace_changes.intersection(expected), "Workspace production source is modified")

    proof = read(ROOT / "source-proof.json")
    require(proof["source_head"] == SOURCE_HEAD and proof["source_identity_sha256"] == sha(SOURCE / "source-identity.json"), "Wrong diagnostic source origin")
    require(Path(proof["source_project"]).resolve() == SOURCE and Path(proof["project"]).resolve() == PROJECT, "Wrong diagnostic project")
    changed = {row["path"]: row for row in proof["files"]}
    require(len(changed) == len(proof["files"]) == 4, "Expected four inline files")
    original_blobs = lib.git_blobs(SOURCE_HEAD, list(changed))
    checked, inverse = [], []
    for path, original_sha in expected.items():
        if Path(path).suffix not in {".gd", ".json", ".py"}:
            continue
        original = (SOURCE / path).read_bytes()
        require(digest(original) == original_sha == sha(REPO / path), (path, "Frozen or delivered original differs"))
        actual = (PROJECT / path).read_bytes()
        if path in changed:
            row = changed[path]
            require(row["original_sha256"] == original_sha and digest(original_blobs[path]) == original_sha, (path, "Inline original identity differs"))
            require(digest(actual) == row["generated_sha256"], (path, "Generated file differs"))
            text = actual.decode("utf-8")
            for change in reversed(row["changes"]):
                require(text.count(change["new"]) == 1, (path, change["name"], "Inverse token is not unique"))
                text = text.replace(change["new"], change["old"], 1)
            recovered = text.encode("utf-8")
            require(recovered == original == original_blobs[path], (path, "Independent inverse failed"))
            archive.virtual("verification-proofs/independent-inverse/" + path + ".txt", recovered, "independent-inline-inverse")
            archive.add(SOURCE / path, "four-original-inline-source-files")
            archive.add(PROJECT / path, "four-generated-inline-source-files")
            inverse.append({"path": path, "original_sha256": original_sha, "actual_generated_sha256": digest(actual), "replacement_count": len(row["changes"]), "independent_inverse_byte_equal": True})
        else:
            require(digest(actual) == original_sha, (path, "Non-instrumented diagnostic source changed"))
        checked.append({"path": path, "original_sha256": original_sha, "actual_diagnostic_sha256": digest(actual), "actual_frozen_original_and_workspace_equal": True, "inline_modified": path in changed})
    require(len(checked) == 253, "Unexpected checked script/content count")
    require(len(inverse) == 4, "Missing independent inverse")
    for row in proof["new_files"]:
        require(sha(PROJECT / row["path"]) == row["sha256"], "Diagnostic helper differs")
        archive.add(PROJECT / row["path"], "new-diagnostic-helper-only")
    require(len(proof["new_files"]) == 1 and sha(ROOT / "route_tail_probe.gd") == proof["new_files"][0]["sha256"], "Helper source copy differs")
    copied_configs = []
    for path in ("project.godot", "export_presets.cfg"):
        require(sha(PROJECT / path) == sha(SOURCE / path), (path, "Copied prepared config differs"))
        copied_configs.append({"path": path, "actual_sha256": sha(PROJECT / path), "copied_prepared_config_equal": True})
        archive.add(PROJECT / path, "copied-isolated-runtime-config")
    archive.add(SOURCE / "source-identity.json", "reused-complete-484-source-identity")
    dependency = lib.dependency_proof(identity, PROJECT, match_workspace=True)
    receipt = read(ROOT / "prepare-receipt.json")
    native = next(row for row in dependency["actual_native_files"] if row["path"].endswith("oddly_good_platform.windows.x86_64.dll"))
    require(native["sha256"] == proof["native_identity"]["actual_sha256"] == receipt["native"]["actual_sha256"] == identity["native_sha256"].lower(), "Native identity differs")
    require(receipt["engine_started"] is False and receipt["build_started"] is False, "Preparation claims unexpected execution")
    native_provenance = []
    for name in ("native-build-identity.json", "native-build-absolute.receipt.json"):
        path = PRIOR / name
        require(sha(path) == prior_files[relative(path)]["sha256"], (path, "Reused native provenance differs"))
        native_provenance.append(evidence_ref(path))
    reused_paths = sorted(set(expected) - {row["path"] for row in checked})
    return {"schema_version": 1, "diagnostic_only": True, "formal_pass": False,
            "source_commit": SOURCE_HEAD, "current_commit": head,
            "current_commit_changed_only_outside_484_source_inventory": True,
            "current_workspace_source_inventory_has_no_tracked_modifications": True,
            "prior_committed_source_verification": [evidence_ref(path) for path in reused_documents],
            "prior_archive_sha256": prior_manifest["archive_sha256"],
            "source_identity": evidence_ref(SOURCE / "source-identity.json"),
            "complete_source_inventory_count": len(expected),
            "actual_script_content_rows_checked_this_freeze": len(checked),
            "actual_script_content_rows": checked,
            "four_independent_inline_inverses": inverse,
            "additional_copied_prepared_configs_checked": copied_configs,
            "remaining_source_rows_reusing_previous_actual_verification": len(reused_paths),
            "remaining_reused_source_paths": reused_paths,
            "all_484_actual_rows_rehashed_this_freeze": False,
            "new_helper": proof["new_files"], "actual_native_and_engine_dependencies": dependency,
            "native_build_this_diagnostic": False, "native_payload_rearchived": False,
            "native_provenance": native_provenance,
            "scope_note": "253 script/content rows, four independent inverses, two copied runtime configs and actual native/engine identities checked now. The other 231 inventory rows reuse committed d5 after verification; they were not all rehashed in this diagnostic. No complete source tree or native DLL payload is repackaged."}


def verify_hotspot_summary(data, summary):
    probe = data["route_tail_probe"]
    require(probe["diagnostic_only"] and probe["formal_pass"] is False and not probe["errors"], "Invalid route-tail diagnostic")
    require(probe["selected_ticks"] == [851, 867], "Unexpected selected ticks")
    require({row["tick"] for row in probe["events"]} == {851, 867}, "Unplanned event sampling")
    require(summary["diagnostic_only"] and summary["formal_pass"] is False and summary["not_plain_timing"], "Summary timing status differs")
    require(set(summary["ticks"]) == {"851", "867"}, "Missing selected tick summary")
    for tick in (851, 867):
        events = [row for row in probe["events"] if row["tick"] == tick]
        legs = {row["id"]: row for row in events if row["kind"] == "floor_route"}
        searches = [row for row in events if row["kind"] == "astar"]
        graphs = [row for row in events if row["kind"] == "graph"]
        row = summary["ticks"][str(tick)]
        checks = {"event_counts": dict(Counter(x["kind"] for x in events)),
                  "floor_route_calls": len(legs), "actual_astar_calls": len(searches),
                  "actual_astar_us": sum(x["elapsed_us"] for x in searches),
                  "graph_modes": dict(Counter(x["mode"] for x in graphs)),
                  "forward_field_served": sum(x.get("solver") == "forward_field" for x in legs.values()),
                  "path_cache_outcomes": dict(Counter(x.get("path_cache_outcome", "not_attempted") for x in legs.values())),
                  "actual_existing_field_backend_calls": [x for x in events if x["kind"] == "field_backend"],
                  "step_sample_is_diagnostic": next(x for x in data["samples"] if x["tick"] == tick)}
        for key, value in checks.items():
            require(row[key] == value, (tick, key, "Summary differs from raw events"))
        for key, entries in (("graph_phases_us", graphs), ("floor_route_phases_us", list(legs.values()))):
            totals = Counter()
            for event in entries:
                totals.update(event["phases_us"])
            require(row[key] == dict(totals), (tick, key, "Phase totals differ"))
        grouped_ids = []
        for group in row["same_graph_goal_groups"]:
            members = [legs[x] for x in group["request_ids"]]
            grouped_ids.extend(group["request_ids"])
            for member in members:
                require(all(member[key] == value for key, value in group["identity"].items()), "Group mixes graph/goal identities")
            eligible = [x for x in members if x["caller"] == "connector_approach" and x["structural_only"] and x["cost_only"] and x["ignore_people"] and not x["members_count"] and not x["offsets_count"] and not x.get("navigation_query", True) and not x.get("overlay", True) and not x.get("bases_count", 1) and not x.get("shifts_count", 1)]
            eligible_ids = {x["id"] for x in eligible}
            opportunity_ids = {x["id"] for x in eligible[11:]}
            eligible_searches = [x for x in searches if x["leg_id"] in eligible_ids]
            opportunity_searches = [x for x in eligible_searches if x["leg_id"] in opportunity_ids]
            for key, value in {"connector_eligible_requests": len(eligible), "connector_eligible_actual_astar_calls": len(eligible_searches), "connector_eligible_actual_astar_us": sum(x["elapsed_us"] for x in eligible_searches), "after_first_11_eligible_requests_actual_astar_calls": len(opportunity_searches), "after_first_11_eligible_requests_actual_astar_us": sum(x["elapsed_us"] for x in opportunity_searches)}.items():
                require(group[key] == value, (tick, key, "Group calculation differs"))
        require(len(grouped_ids) == len(set(grouped_ids)), "Duplicate group membership")
        require(len(grouped_ids) + row["scope_hits_or_external_graphs_without_fresh_graph_identity"] == len(legs), "Incomplete group coverage")
    assessment = summary["candidate_assessment"]
    anchors = [x for x in summary["ticks"]["851"]["same_graph_goal_groups"] if x["connector_eligible_requests"]]
    for key in ("after_first_11_eligible_requests_actual_astar_calls", "after_first_11_eligible_requests_actual_astar_us"):
        require(assessment[key] == sum(x[key] for x in anchors), (key, "Candidate total differs"))
    require(assessment["reverse_build_or_lookup_cpu_measured"] is False, "Unmeasured proposed cost reported as measured")
    fields = [x for x in probe["events"] if x["tick"] == 851 and x["kind"] == "field_lookup" and x.get("built")]
    require(assessment["actual_existing_built_fields"]["record_charge_sum_bytes"] == sum(x["charge"] for x in fields), "Field allowance total differs")
    return {"both_selected_tick_totals_recomputed_from_raw_events": True,
            "group_graph_goal_identity_and_eligible_search_totals_recomputed": True,
            "event_count": len(probe["events"]), "selected_ticks": [851, 867],
            "candidate_opportunity_starts_at_eligible_request": 12,
            "candidate_opportunity_includes_trigger_request": True,
            "first_11_requests_precede_the_potential_trigger": True,
            "raw_unchanged_warmup_requests_field_means_trigger_threshold_not_unchanged_search_count": 12,
            "original_reverse_field_build_or_lookup_cost_measured": False,
            "other_78_steps_have_no_parameter_or_event_samples": True,
            "nested_times_must_not_be_added_or_subtracted_to_reconstruct_plain": True}


def main():
    started = time.perf_counter()
    OUT.mkdir(parents=True, exist_ok=True)
    require(not any((OUT / name).exists() for name in OUTPUTS), "Refusing to overwrite existing frozen outputs")
    staging = OUT / (".route-tail-staging-" + uuid.uuid4().hex)
    staging.mkdir()
    archive = lib.Archive()
    source = source_check(archive)
    raw_summary_sha = sha(ROOT / "summary.json")
    raw_summary = read(ROOT / "summary.json")
    lib.ROOT = ROOT
    diagnostic, data, progress = lib.measured("probe", "gp80", "after", "plain", archive, project_override=PROJECT)
    summary_validation = verify_hotspot_summary(data, raw_summary)
    comparisons, references = [], []
    for label in ("b", "c"):
        lib.ROOT = PRIOR
        reference, original, unused = lib.measured(label, "gp80", "after", "plain", lib.Archive(), project_override=SOURCE)
        archive.add(PRIOR / (label + "-gp80.json"), "reused-complete-plain-reference-json")
        comparison = lib.compare_semantics(original, data, "probe-vs-" + label)
        require(original["public"]["query_counts"] == data["public"]["query_counts"], (label, "Original aggregate query counts differ"))
        require([{k: v for k, v in row.items() if k != "elapsed_us"} for row in original["samples"]] == [{k: v for k, v in row.items() if k != "elapsed_us"} for row in data["samples"]], (label, "80 complete sample semantics differ"))
        comparison.update({"all_80_sample_semantic_fields_equal_except_elapsed_us": True,
                           "all_original_aggregate_query_count_fields_equal": True,
                           "per_step_query_count_deltas_recorded": False,
                           "input_and_final_binary_actual_hashes_checked": True})
        comparisons.append(comparison)
        reference["role"] = "reused_plain_reference_from_prior_round_not_new_measurement"
        references.append(reference)
    lib.ROOT = ROOT
    semantic = read(ROOT / "semantic-check.json")
    require(semantic["same_complete_world_events_work_queues_and_final_binary"] and semantic["query_counts_equal"] and semantic["reference_sha256"] == sha(PRIOR / "b-gp80.json"), "Original semantic receipt differs")
    require(len(data["samples"]) == 80 and data["samples"][0]["tick"] == 824 and data["samples"][-1]["tick"] == 903, "Wrong complete window")
    source["summary_raw_event_validation"] = summary_validation
    source["single_completed_engine_run"] = diagnostic["launch"]
    source["new_engine_build_test_runs_by_this_freezer"] = 0
    receipt = read(ROOT / "prepare-receipt.json")
    tool_failures = [{"scope": "probe preparation", "attempt": row["attempt"], "classification": "diagnostic generator token mismatch", "reason": row["reason"], "game_or_engine_failure": False} for row in receipt["attempts"] if row["status"].startswith("failed")]
    tool_failures.append({"scope": "read-only evidence inspection", "classification": "UTF-8 read default-codec error and empty-list display error", "log": relative(ROOT / "freeze-inspection-errors.log"), "game_or_engine_failure": False})
    functional = {"schema_version": 1, "diagnostic_only": True, "formal_pass": False,
                  "production_changes_this_diagnostic": [], "new_selected_acceptance_cases": [],
                  "new_game_or_engine_failures": [], "single_gp80_complete_and_qualified": True,
                  "semantic_comparisons_against_both_prior_plain_runs": comparisons,
                  "input": evidence_ref(REPO / ".cache/task-navigation-20261019/gp.input.bin"),
                  "initial_tick": data["initial"]["tick"], "final_tick": data["final"]["tick"],
                  "original_complete_window_query_counts": data["public"]["query_counts"],
                  "query_counts_scope": "All original aggregate counters for the complete 80-step window. Per-step query-count deltas were not recorded.",
                  "full_final_work_ticks": data["final"]["work_ticks_by_kind"],
                  "original_semantic_receipt": semantic, "tool_failures": tool_failures,
                  "business_correctness_basis": "This diagnostic compares every recorded initial/final world observation, lifecycle/event/work/public/operations/queue field and all complete sample semantics with both prior plain runs. Prior requirements-based selected cases are referenced, not rerun. Final binary equality is auxiliary identity evidence."}
    summary = dict(raw_summary)
    summary.update({"schema_version": 1, "source_commit": SOURCE_HEAD,
                    "current_commit_at_freeze": source["current_commit"],
                    "source_check": "source-check.json", "functional_summary": "functional-summary.json",
                    "original_summary": evidence_ref(ROOT / "summary.json"),
                    "validation": summary_validation, "complete_diagnostic_run": diagnostic,
                    "complete_plain_references": references,
                    "prior_committed_evidence_directory": relative(PRIOR_OUT),
                    "preparation": receipt,
                    "timing_scope": {"input_read_and_runtime_initialization_ms": data["initialization_elapsed_us"] / 1000,
                                     "ordinary_diagnostic_steps_ms": data["metrics"]["total_us"] / 1000,
                                     "process_wall_ms": diagnostic["launch"]["wall_ms"],
                                     "child_cpu_ms": diagnostic["launch"]["child_cpu_ms"],
                                     "copy_elapsed_ms": None, "pure_input_file_read_ms": None,
                                     "note": "Initialization and step time are within process wall; these columns are not additive. Input was reused, not regenerated. Selected-tick diagnostic times are not plain times."},
                    "formal_acceptance_passed": False, "new_production_build_or_functional_test": False})
    for path in sorted(ROOT.iterdir()):
        if path.is_file() and (path.suffix in {".json", ".py", ".gd", ".md", ".log"} or path.name.endswith(".ndjson")):
            if path.name.startswith("freeze-") and path.suffix == ".log" and path.stat().st_size == 0:
                continue
            archive.add(path, "original-route-tail-evidence-or-freezer-tool")
    archive.add(PRIOR / "summarize.py", "reused-verification-and-zip-helper-source")
    archive.add(REPO / ".cache/task-navigation-20261019/gp.input.bin", "unchanged-read-only-input")
    documents = {"summary.json": summary, "source-check.json": source, "functional-summary.json": functional}
    for name, value in documents.items():
        raw = encoded(value)
        (staging / name).write_bytes(raw)
        require(json.loads(raw) == value, (name, "JSON roundtrip failed"))
        archive.virtual(relative(OUT / name), raw, "frozen-derived-summary")
    manifest = archive.write_and_verify(staging / "raw-evidence.zip")
    manifest.update({"generated_at_utc": datetime.now(timezone.utc).isoformat(),
                     "excluded_binary_payloads": ["Godot executables", "entire .godot/assets tree", "production DLL payloads", "unchanged 484-file snapshot tree"],
                     "binary_identity_note": "Actual native and engine hashes were checked now. Full 484-row source identity verification is reused from the committed prior after evidence; this freeze independently checks 253 script/content rows and four inverses. Hashes do not define business correctness."})
    (staging / "raw-manifest.json").write_bytes(encoded(manifest))
    require(sha(ROOT / "summary.json") == raw_summary_sha, "Hotspot summary changed during freeze")
    for name in OUTPUTS:
        (staging / name).replace(OUT / name)
    staging.rmdir()
    print(json.dumps({"completed": True, "output": relative(OUT), "files": [evidence_ref(OUT / name) for name in OUTPUTS], "zip_members": manifest["member_count"], "zip_size": manifest["archive_size"], "zip_sha256": manifest["archive_sha256"], "independent_script_content_rows": 253, "independent_inline_inverses": 4, "remaining_source_rows_reused": 231, "semantic_comparisons": len(comparisons), "all_80_steps_complete": True, "freeze_elapsed_ms": (time.perf_counter() - started) * 1000}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
