extends RefCounted

# Diagnostic state is separate from WorldState and every production cache.
static var active: bool = false
static var tick: int = -1
static var events: Array = []
static var graph_metadata: Dictionary = {}
static var errors: Array[String] = []
static var _legs: Array[int] = []
static var _callers: Array[String] = []
static var handler_us: int = 0

static func _event(kind: String, values: Dictionary) -> int:
	var id: int = events.size()
	values["id"] = id
	values["kind"] = kind
	values["tick"] = tick
	values["leg_id"] = _legs.back() if not _legs.is_empty() else -1
	values["phases_us"] = {}
	events.append(values)
	return id

static func event(kind: String, values: Dictionary) -> int:
	var started: int = Time.get_ticks_usec()
	var id: int = _event(kind,values)
	handler_us += Time.get_ticks_usec()-started
	return id

static func begin_leg(values: Dictionary) -> int:
	var started: int = Time.get_ticks_usec()
	values["caller"] = _callers.back() if not _callers.is_empty() else "other"
	var id: int = _event("floor_route",values)
	_legs.append(id)
	handler_us += Time.get_ticks_usec()-started
	return id

static func finish_leg(id: int, mode: String, result: Dictionary = {}) -> void:
	var started: int = Time.get_ticks_usec()
	events[id]["return_mode"] = mode
	if not result.is_empty():
		events[id]["ok"] = bool(result.get("ok",false))
		events[id]["status"] = str(result.get("status",""))
		events[id]["walking_distance"] = result.get("walking_distance",-1)
	if _legs.is_empty() or _legs.back()!=id: errors.append("Unbalanced floor route: "+str(id))
	else: _legs.pop_back()
	handler_us += Time.get_ticks_usec()-started

static func phase(id: int, name: String, elapsed: int) -> void:
	var started: int = Time.get_ticks_usec()
	events[id].phases_us[name] = int(events[id].phases_us.get(name,0))+elapsed
	handler_us += Time.get_ticks_usec()-started

static func values(id: int, fields: Dictionary) -> void:
	var started: int = Time.get_ticks_usec()
	events[id].merge(fields,true)
	if events[id].kind=="floor_route" and fields.has("geometry_id") and graph_metadata.has(fields.geometry_id):
		events[id].merge(graph_metadata[fields.geometry_id],true)
	handler_us += Time.get_ticks_usec()-started

static func current_leg(fields: Dictionary) -> void:
	var started: int = Time.get_ticks_usec()
	if not _legs.is_empty(): events[_legs.back()].merge(fields,true)
	handler_us += Time.get_ticks_usec()-started

static func graph(geometry_id: int, key: String, version: int, floor_id: int) -> void:
	var started: int = Time.get_ticks_usec()
	graph_metadata[geometry_id] = {"graph_key":key,"static_version":version,"floor_id":floor_id}
	if not _legs.is_empty(): events[_legs.back()].merge({"geometry_id":geometry_id,"graph_key":key,"static_version":version},true)
	handler_us += Time.get_ticks_usec()-started

static func push_caller(name: String) -> void:
	_callers.append(name)

static func pop_caller() -> void:
	if _callers.is_empty(): errors.append("Unbalanced caller stack")
	else: _callers.pop_back()

static func end_step() -> void:
	if not _legs.is_empty() or not _callers.is_empty(): errors.append("Unbalanced stacks at tick "+str(tick))

static func report() -> Dictionary:
	return {"diagnostic_only":true,"formal_pass":false,"selected_ticks":[851,867],"events":events.duplicate(true),"graph_metadata":graph_metadata.duplicate(true),"errors":errors.duplicate(),"handler_body_us":handler_us,"semantics":"Inline timestamps and selected-tick event allocation perturb these steps. Handler body time excludes call entry and dictionary construction; never subtract it to reconstruct plain CPU time. No extra graph, path, or distance-field search is issued."}
