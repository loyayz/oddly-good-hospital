from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import datetime
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import shutil
import time

CACHE = Path(__file__).resolve().parent
REPO = CACHE.parents[1]
PRIOR = REPO / '.cache/wait-signature-031e1f7-20261022'
SOURCE = PRIOR / 'after-project'
PROJECT = CACHE / 'probe-project'
HEAD = 'd5f048e1fe918bd764f3607db49a3c2f360be89a'
MARK = ' # route-tail-inline-diagnostic'
PROOF = CACHE / 'source-proof.json'
HELPER = 'tools/performance/route_tail_probe.gd'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def dump(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')


def marked(lines):
    return ''.join(line + MARK + '\n' for line in lines.splitlines())


def before(body, token, lines):
    pattern = re.compile('^' + re.escape(token), re.MULTILINE)
    assert len(list(pattern.finditer(body))) == 1, (token, len(list(pattern.finditer(body))))
    return pattern.sub(lambda match: marked(lines) + match.group(), body, count=1)


def after(body, token, lines):
    pattern = re.compile('^' + re.escape(token), re.MULTILINE)
    assert len(list(pattern.finditer(body))) == 1, (token, len(list(pattern.finditer(body))))
    return pattern.sub(lambda match: match.group() + marked(lines), body, count=1)


def phase(body, token, label, indent='\t', event='_rt_id'):
    return before(body, token, f'{indent}if {event}>=0:\n{indent}\t_RouteTailDiag.phase({event},"{label}",Time.get_ticks_usec()-_rt_mark)\n{indent}\t_rt_mark = Time.get_ticks_usec()')


class Editor:
    def __init__(self, path):
        self.path = Path(path)
        self.original = self.path.read_bytes()
        self.text = self.original.decode('utf-8')
        assert '\r\n' not in self.text, 'Frozen project must retain its original LF source bytes'
        self.changes = []

    def replace(self, old, new, name):
        assert self.text.count(old) == 1, (self.path, name, self.text.count(old))
        self.text = self.text.replace(old, new, 1)
        self.changes.append({'name': name, 'old': old, 'new': new})

    def function(self, name, transform):
        start = self.text.index('func ' + name + '(')
        end = self.text.find('\nfunc ', start + 1)
        if end < 0:
            end = len(self.text)
        old = self.text[start:end]
        new = transform(old)
        assert old != new, name
        self.replace(old, new, name)

    def helper(self):
        first = next(line for line in self.text.splitlines(keepends=True) if line.startswith('extends '))
        self.replace(first, first + marked('const _RouteTailDiag = preload("res://' + HELPER + '")'), 'helper preload')

    def write(self):
        reversed_text = self.text
        for change in reversed(self.changes):
            assert reversed_text.count(change['new']) == 1, change['name']
            reversed_text = reversed_text.replace(change['new'], change['old'], 1)
        assert reversed_text.encode('utf-8') == self.original
        self.path.write_bytes(self.text.encode('utf-8'))
        return {'path': self.path.relative_to(PROJECT).as_posix(), 'original_sha256': hashlib.sha256(self.original).hexdigest(), 'generated_sha256': sha(self.path), 'inverse_byte_equal': True, 'changes': self.changes}


def floor_route(body):
    body = before(body, '\t_observe_floor(', '''\tvar _rt_id: int = -1
\tvar _rt_mark: int = 0
\tif _RouteTailDiag.active:
\t\t_rt_id = _RouteTailDiag.begin_leg({"actor_id":str(actor.id),"world_id":world.get_instance_id(),"floor_id":floor_id,"start":[start.x,start.y],"goal":[goal.x,goal.y],"zero_leg":start==goal,"members_count":members.size(),"offsets_count":offsets.size(),"ignore_people":ignore_people,"structural_only":structural_only,"cost_only":cost_only})
\t\t_rt_mark = Time.get_ticks_usec()''')
    body = before(body, '\t\tspace.query_counts.floor_route_hits += 1', '''\t\tif _rt_id>=0:
\t\t\t_RouteTailDiag.phase(_rt_id,"scope_lookup",Time.get_ticks_usec()-_rt_mark)
\t\t\t_RouteTailDiag.finish_leg(_rt_id,"scope_endpoint_hit",routes[key])''')
    body = phase(body, '\tspace.query_counts.floor_route_builds += 1', 'scope_lookup')
    body = phase(body, '\tvar query: RouteClearance', 'graph_acquire')
    body = before(body, '\tvar query: RouteClearance', '''\tif _rt_id>=0:
\t\t_RouteTailDiag.values(_rt_id,{"geometry_id":graph.geometry.get_instance_id(),"graph_id":graph.get_instance_id(),"navigation_query":navigation.has("query"),"overlay":bool(navigation.get("overlay",false)),"bases_count":navigation.bases.size(),"shifts_count":navigation.shifts.size()})
\t\t_rt_mark = Time.get_ticks_usec()''')
    body = phase(body, '\tvar result: Dictionary', 'clearance_prepare')
    body = phase(body, '\tif repeated.get("ready",false):', 'forward_field')
    for token, solver in [('\t\tspace.query_counts["distance_field_hits"]', 'forward_field'), ('\t\tresult = space._navigation.cached_floor_path(', 'path_cache'), ('\t\tresult = graph.find_path(', 'direct_astar')]:
        body = before(body, token, f'\t\tif _rt_id>=0: _RouteTailDiag.values(_rt_id,{{"solver":"{solver}"}})')
    body = phase(body, '\tif result.ok and people.is_valid() and not cost_only:', 'solver')
    body = phase(body, '\treturn result', 'postprocess')
    body = before(body, '\treturn result', '\tif _rt_id>=0: _RouteTailDiag.finish_leg(_rt_id,"computed",result)')
    return body


def callsite(body, line, label):
    assert body.count(line) == 1, line
    indent = line[:len(line) - len(line.lstrip('\t'))]
    return body.replace(line, marked(indent + 'if _RouteTailDiag.active: _RouteTailDiag.push_caller("' + label + '")') + line + marked(indent + 'if _RouteTailDiag.active: _RouteTailDiag.pop_caller()'), 1)


def nav_graph(body):
    body = before(body, '\tvar current: Dictionary', '''\tvar _rt_id: int = -1
\tvar _rt_mark: int = 0
\tif _RouteTailDiag.active:
\t\t_rt_id = _RouteTailDiag.event("graph",{"actor_id":str(actor.id),"world_id":world.get_instance_id(),"floor_id":floor_id,"members_count":members.size(),"offsets_count":offsets.size(),"mode":"warm"})
\t\t_rt_mark = Time.get_ticks_usec()''')
    body = phase(body, '\tvar key: String', 'floor_source')
    body = phase(body, '\tvar source_record: Dictionary', 'graph_key')
    body = phase(body, '\tif entry.is_empty() or int(source_record.graphs.get(key,0))', 'entry_lookup')
    body = before(body, '\t\tvar source: Dictionary', '\t\tif _rt_id>=0: _RouteTailDiag.values(_rt_id,{"mode":"compare_equal"})')
    body = before(body, '\t\t\tentry = _refresh_graph(', '\t\t\tif _rt_id>=0: _RouteTailDiag.values(_rt_id,{"mode":"cold" if entry.is_empty() else "refresh"})')
    body = phase(body, '\tentry.used = _used', 'source_proof_refresh')
    body = before(body, '\tentry.used = _used', '''\tif _rt_id>=0:
\t\t_RouteTailDiag.values(_rt_id,{"graph_key":key,"static_version":int(source_record.static_version),"geometry_id":entry.graph.geometry.get_instance_id(),"graph_id":entry.graph.get_instance_id(),"charged_before_trim":_charged,"query_charged_before_trim":_query_charged})
\t\t_RouteTailDiag.graph(entry.graph.geometry.get_instance_id(),key,int(source_record.static_version),floor_id)
\t\t_rt_mark = Time.get_ticks_usec()''')
    body = phase(body, '\t_trim(', 'lru_touch')
    body = phase(body, '\treturn result', 'trim')
    body = before(body, '\treturn result', '\tif _rt_id>=0: _RouteTailDiag.values(_rt_id,{"resident_after_trim":_entries.has(key),"charged_after_trim":_charged,"query_charged_after_trim":_query_charged})')
    return body


def refresh_graph(body):
    body = before(body, '\tvar geometry: RouteClearance', '''\tvar _rt_id: int = -1
\tvar _rt_mark: int = 0
\tif _RouteTailDiag.active:
\t\t_rt_id = _RouteTailDiag.event("graph_refresh",{"floor_id":floor_id,"actor_id":str(actor.id),"cold":entry.is_empty()})
\t\t_rt_mark = Time.get_ticks_usec()''')
    body = phase(body, '\tvar floor_graph: FloorNavigation', 'geometry')
    body = phase(body, '\t# Capacity charge', 'graph_build_or_repair')
    body = phase(body, '\treturn entry', 'allowance_entry')
    body = before(body, '\treturn entry', '\tif _rt_id>=0: _RouteTailDiag.values(_rt_id,{"geometry_id":geometry.get_instance_id(),"charge":charge})')
    return body


def trim_events(body):
    body = before(body, '\tcounts["cache_trims"]', '\tif _RouteTailDiag.active: _RouteTailDiag.event("trim",{"target":target,"charged":_charged,"query_charged":_query_charged})')
    body = before(body, '\t\t\t_query_charged -=', '\t\t\tif _RouteTailDiag.active: _RouteTailDiag.event("query_clear",{"graph_key":key,"geometry_id":entry.graph.geometry.get_instance_id(),"query_charge":int(entry.get("query_charge",0)),"estimate_count":entry.get("estimates",{}).size()})')
    body = before(body, '\t\t_entries.erase(key)', '\t\tif _RouteTailDiag.active: _RouteTailDiag.event("graph_evict",{"graph_key":key,"geometry_id":entry.graph.geometry.get_instance_id(),"charge":int(entry.charge),"query_charge":int(entry.get("query_charge",0))})')
    return body


def path_cache(body):
    body = before(body, '\tvar key: String', '\tvar _rt_mark: int = Time.get_ticks_usec() if _RouteTailDiag.active else 0\n\tvar _rt_id: int = -1')
    body = before(body, '\tvar entry: Dictionary', '\tif _RouteTailDiag.active: _rt_id = _RouteTailDiag.event("path_cache",{"graph_key":key,"geometry_id":graph.geometry.get_instance_id(),"actor_id":str(actor.id),"start":[start.x,start.y],"goal":[goal.x,goal.y],"cost_only":cost_only,"structural":query==graph.geometry})')
    for token, outcome, indent in [('\t\treturn graph.find_path(', 'uncacheable', '\t\t'), ('\t\treturn result', 'hit', '\t\t'), ('\tvar result: Dictionary = graph.find_path(', 'miss', '\t')]:
        body = before(body, token, f'{indent}if _rt_id>=0:\n{indent}\t_RouteTailDiag.values(_rt_id,{{"outcome":"{outcome}","lookup_us":Time.get_ticks_usec()-_rt_mark}})\n{indent}\t_RouteTailDiag.current_leg({{"path_cache_outcome":"{outcome}"}})')
    return body


def distance_lookup(body):
    body = before(body, '\t# Only a structural query', '\tvar _rt_mark: int = Time.get_ticks_usec() if _RouteTailDiag.active else 0\n\tvar _rt_id: int = -1')
    body = before(body, '\tif not _entries.has(key): return', '\tif _RouteTailDiag.active and not _entries.has(key): _RouteTailDiag.event("field_lookup",{"graph_key":key,"geometry_id":current.geometry.get_instance_id(),"outcome":"no_resident","elapsed_us":Time.get_ticks_usec()-_rt_mark})')
    body = after(body, '\tvar record: Dictionary = entry.estimates.get(destination,{})\n', '\tif _RouteTailDiag.active: _rt_id = _RouteTailDiag.event("field_lookup",{"graph_key":key,"geometry_id":current.geometry.get_instance_id(),"actor_id":str(actor.id),"floor_id":floor_id,"start":[start.x,start.y],"goal":[goal.x,goal.y],"destination_key":destination,"forward":forward,"structural_only":structural_only,"prior_hits":int(record.get("hits",0)),"prior_ready":bool(record.get("ready",false)),"reset":false,"built":false})')
    body = before(body, '\t\tvar old_charge: int', '\t\tif _rt_id>=0: _RouteTailDiag.values(_rt_id,{"reset":true,"empty_record":record.is_empty()})')
    body = after(body, '\trecord.hits += 1\n', '\tif _rt_id>=0: _RouteTailDiag.values(_rt_id,{"hits":int(record.hits),"ready_before_build":bool(record.ready),"lookup_before_build_us":Time.get_ticks_usec()-_rt_mark})')
    body = before(body, '\t\tvar query: RouteClearance', '\t\tif _rt_id>=0: _RouteTailDiag.values(_rt_id,{"build_attempt":true})')
    # Original failure body is one indentation deeper than the success block.
    body = before(body, '\t\t\tspace.query_counts["distance_field_failures"]', '\t\t\tif _rt_id>=0: _RouteTailDiag.values(_rt_id,{"field_failure":true})')
    body = after(body, '\t\trecord.ready = true\n', '\t\tif _rt_id>=0: _RouteTailDiag.values(_rt_id,{"built":true,"distances_count":record.distances.size(),"successors_count":record.successors.size()})')
    body = before(body, '\tif not record.ready: return', '\tif _rt_id>=0: _RouteTailDiag.values(_rt_id,{"ready":bool(record.ready),"hits":int(record.hits),"charge":int(record.charge),"elapsed_through_trim_us":Time.get_ticks_usec()-_rt_mark})')
    return body


def engine_search(body):
    token = '\tvar ids: PackedInt64Array = get_id_path(_id(start),_id(goal),partial)\n'
    body = before(body, token, '\tvar _rt_started: int = Time.get_ticks_usec() if _RouteTailDiag.active else 0')
    return after(body, token, '\tvar _rt_ended: int = Time.get_ticks_usec() if _RouteTailDiag.active else 0\n\tif _RouteTailDiag.active: _RouteTailDiag.event("astar",{"geometry_id":geometry.get_instance_id(),"start":[start.x,start.y],"goal":[goal.x,goal.y],"elapsed_us":_rt_ended-_rt_started,"ids_count":ids.size(),"partial":partial,"cost_only":cost_only,"query_is_geometry":query==geometry,"overlay":overlay,"bases_count":bases.size(),"people_filter":people.is_valid()})')


def engine_field(body):
    token = '\tvar result: Dictionary = PlatformArrivalMath.grid_distance_field(enabled,_edges,query.reservation_mask(),{"root":_id(origin) if _inside(origin) else -1,"reverse":reverse})\n'
    body = before(body, token, '\tvar _rt_started: int = Time.get_ticks_usec() if _RouteTailDiag.active else 0')
    return after(body, token, '\tvar _rt_ended: int = Time.get_ticks_usec() if _RouteTailDiag.active else 0\n\tif _RouteTailDiag.active: _RouteTailDiag.event("field_backend",{"geometry_id":geometry.get_instance_id(),"root":[origin.x,origin.y],"reverse":reverse,"maximum_distance":maximum_distance,"elapsed_us":_rt_ended-_rt_started,"ready":bool(result.get("ok",false)),"distances_count":result.get("distances",PackedInt32Array()).size(),"successors_count":result.get("successors",PackedInt32Array()).size()})')


def runner(body):
    body = before(body, '\t\tvar started: int = Time.get_ticks_usec()', '''\t\t_RouteTailDiag.tick = clinical.world.sim_tick+1
\t\t_RouteTailDiag.active = _RouteTailDiag.tick==851 or _RouteTailDiag.tick==867
\t\tif _RouteTailDiag.active: _RouteTailDiag.event("step_before",{"charged":clinical.simulation.space._navigation._charged,"query_charged":clinical.simulation.space._navigation._query_charged})''')
    body = after(body, '\t\tvar elapsed: int = Time.get_ticks_usec()-started\n', '''\t\tif _RouteTailDiag.active:
\t\t\t_RouteTailDiag.event("step_after",{"charged":clinical.simulation.space._navigation._charged,"query_charged":clinical.simulation.space._navigation._query_charged})
\t\t\t_RouteTailDiag.end_step()
\t\t_RouteTailDiag.active = false''')
    return before(body, '\t_write(str(options.output),report)', '\treport.route_tail_probe = _RouteTailDiag.report()')


def prepare(resume_copy=False):
    assert not PROJECT.exists() or resume_copy, PROJECT
    assert PROJECT.resolve().is_relative_to(CACHE.resolve())
    identity = read(SOURCE / 'source-identity.json')
    assert identity['head'] == HEAD
    assert not (SOURCE / 'all-instance-profile-identity.json').exists()
    ref = read(PRIOR / 'b-gp80.json')
    assert ref['complete'] and ref['qualified'] and ref['mode'] == 'plain'
    assert ref['samples'][0]['tick'] == 824 and ref['samples'][-1]['tick'] == 903
    median_sample = next(x for x in ref['samples'] if x['tick'] == 867)
    assert median_sample['elapsed_us'] == ref['metrics']['p50_us'] == 40109
    if resume_copy:
        assert PROJECT.exists() and not PROOF.exists()
        for row in identity['source']:
            if Path(row['path']).suffix in ['.gd', '.json', '.py']:
                assert sha(PROJECT / row['path']) == row['sha256'], row['path']
    else:
        shutil.copytree(SOURCE, PROJECT)
    proofs = []
    staged = []
    for relative in ['game/building/hospital_navigation.gd', 'game/building/navigation_cache.gd', 'game/building/floor_navigation.gd', 'tools/performance/representative.gd']:
        editor = Editor(PROJECT / relative)
        expected = next(x['sha256'] for x in identity['source'] if x['path'] == relative)
        assert hashlib.sha256(editor.original).hexdigest() == expected
        editor.helper()
        if relative.endswith('/hospital_navigation.gd'):
            editor.function('_floor_route', floor_route)
            editor.function('_point_route', lambda b: callsite(b, '\t\tdirect = _floor_route(world,actor,source_floor,start,goal,members,offsets,true,{},true,distance_only)\n', 'same_floor_direct'))
            editor.function('_source_quote', lambda b: callsite(b, '\t\tvar finish: Dictionary = _floor_route(world,actor,int(node.floor_id),node.cell,context.goal,[],{},true,{},true,true)\n', 'target_finish'))
            editor.function('_point_edges', lambda b: callsite(b, '\t\tvar finish: Dictionary = context.direct if id=="start" and int(context.source_floor)==target_floor else _floor_route(world,actor,target_floor,node.cell,context.goal,members,offsets,true,{},true,distance_only)\n', 'target_finish'))
            editor.function('_connector_edges', lambda b: callsite(b, '\t\tvar before: Dictionary = _floor_route(world,actor,floor_id,node.cell,anchor,members,offsets,true,{},true,distance_only)\n', 'connector_approach'))
        elif relative.endswith('/navigation_cache.gd'):
            editor.function('graph', nav_graph)
            editor.function('_refresh_graph', refresh_graph)
            editor.function('_trim', trim_events)
            editor.function('cached_floor_path', path_cache)
            editor.function('_travel_distance', distance_lookup)
        elif relative.endswith('/floor_navigation.gd'):
            editor.function('find_path', engine_search)
            editor.function('distance_field', engine_field)
        else:
            editor.function('_run', runner)
        staged.append(editor)
    # Validate every exact token before writing any generated source file.
    for editor in staged:
        proofs.append(editor.write())
    shutil.copy2(CACHE / 'route_tail_probe.gd', PROJECT / HELPER)
    proof = {'diagnostic_only': True, 'formal_pass': False, 'source_project': str(SOURCE), 'project': str(PROJECT), 'source_head': HEAD, 'source_identity_sha256': sha(SOURCE / 'source-identity.json'), 'profile': 'plain; selected-tick inline instrumentation only; no wrappers', 'selected_ticks': [851, 867], 'tick_selection': {'tail_tick': 851, 'ordinary_tick': 867, 'ordinary_basis': str(PRIOR / 'b-gp80.json'), 'sample': median_sample, 'p50_us': ref['metrics']['p50_us']}, 'source_input': ref['source_input'], 'source_input_sha256': ref['source_input_sha256'], 'reference_final_binary_sha256': ref['final_binary_sha256'], 'first_tick': 824, 'last_tick': 903, 'steps': 80, 'files': proofs, 'new_files': [{'path': HELPER, 'sha256': sha(PROJECT / HELPER)}], 'inverse_byte_equal': all(x['inverse_byte_equal'] for x in proofs), 'native_identity': {'sha256': identity['native_sha256'], 'verification': 'Inherited frozen source identity; native binary copied, not rebuilt or rehashed during probe preparation.'}, 'warnings': ['All recorded time is diagnostic; no observer subtraction reconstructs plain time.', 'No extra distance field is built to estimate a proposed reverse cache.', 'Graph acquisition count is distinct from cold graph build count.', 'Parameters use already-computed keys and source versions, never a second envelope/source serialization.']}
    dump(PROOF, proof)
    verify()
    print(json.dumps({'project': str(PROJECT), 'proof': str(PROOF), 'modified_files': len(proofs), 'inverse_byte_equal': True, 'selected_ticks': [851, 867]}, ensure_ascii=False))


def verify():
    proof = read(PROOF)
    assert proof['source_head'] == HEAD
    changed = {x['path']: x for x in proof['files']}
    checked = 0
    for row in read(SOURCE / 'source-identity.json')['source']:
        relative = row['path']
        if Path(relative).suffix not in ['.gd', '.json', '.py']:
            continue
        assert sha(SOURCE / relative) == row['sha256'], relative
        if relative in changed:
            file = changed[relative]
            assert sha(PROJECT / relative) == file['generated_sha256'], relative
            text = (PROJECT / relative).read_bytes().decode('utf-8')
            for change in reversed(file['changes']):
                assert text.count(change['new']) == 1, (relative, change['name'])
                text = text.replace(change['new'], change['old'], 1)
            assert text.encode('utf-8') == (SOURCE / relative).read_bytes(), relative
        else:
            assert sha(PROJECT / relative) == row['sha256'], relative
        checked += 1
    for row in proof['new_files']:
        assert sha(PROJECT / row['path']) == row['sha256']
    assert not (PROJECT / 'all-instance-profile-identity.json').exists()
    return checked


def finalize_prepare():
    started = time.perf_counter()
    proof = read(PROOF)
    backup = CACHE / 'source-proof-before-immediate-stop.json'
    assert not backup.exists()
    dump(backup, proof)
    for file in proof['files']:
        if file['path'] != 'game/building/floor_navigation.gd':
            continue
        path = PROJECT / file['path']
        text = path.read_text(encoding='utf-8')
        for change in file['changes']:
            transform = {'find_path': engine_search, 'distance_field': engine_field}.get(change['name'])
            if transform is not None:
                replacement = transform(change['old'])
                assert text.count(change['new']) == 1
                text = text.replace(change['new'], replacement, 1)
                change['new'] = replacement
        path.write_text(text, encoding='utf-8', newline='\n')
        file['generated_sha256'] = sha(path)
    dump(PROOF, proof)
    verify_started = time.perf_counter()
    checked = verify()
    verify_ms = (time.perf_counter() - verify_started) * 1000
    native = PROJECT / 'game/platform/windows/bin/oddly_good_platform.windows.x86_64.dll'
    native_started = time.perf_counter()
    actual_native = sha(native)
    native_ms = (time.perf_counter() - native_started) * 1000
    assert actual_native == read(SOURCE / 'source-identity.json')['native_sha256'].lower()
    checked_at = datetime.datetime.now(datetime.timezone.utc).isoformat()
    proof['native_identity'] = {'path': str(native), 'size': native.stat().st_size, 'actual_sha256': actual_native, 'expected_frozen_sha256': read(SOURCE / 'source-identity.json')['native_sha256'].lower(), 'equal': True, 'checked_at_utc': checked_at, 'verification': 'Actual copied native DLL SHA256 checked against frozen d5 identity after preparation; no native build was started.'}
    dump(PROOF, proof)
    receipt = {'diagnostic_only': True, 'formal_pass': False, 'engine_started': False, 'build_started': False, 'completed_at_utc': checked_at, 'attempts': [{'attempt': 1, 'action': 'prepare', 'status': 'failed_after_copy_before_instrumented_write', 'exec_command_wall_ms': 1133.2194, 'clock_source': 'exec_command.wall_time_seconds', 'copy_completed': True, 'copy_elapsed_ms': None, 'copy_timing_note': 'Copy was inside the failed 1133.2194 ms preparation command; it was not separately timed. No inferred copy duration is reported.', 'reason': 'Exact-token assertion for the conditional target-finish statement', 'log': str(CACHE / 'prepare-attempt-1.log')}, {'attempt': 2, 'action': 'prepare --resume-copy', 'status': 'complete', 'exec_command_wall_ms': 681.6187, 'clock_source': 'exec_command.wall_time_seconds', 'reused_raw_copy': True, 'original_hashes_verified_before_staging': True}], 'finalization': {'elapsed_ms': (time.perf_counter() - started) * 1000, 'script_verification_ms': verify_ms, 'verified_script_files': checked, 'inverse_byte_equal': True, 'native_sha256_elapsed_ms': native_ms}, 'source_proof': str(PROOF), 'native': proof['native_identity']}
    dump(CACHE / 'prepare-receipt.json', receipt)
    print(json.dumps({'ready': True, 'source_proof': str(PROOF), 'prepare_receipt': str(CACHE / 'prepare-receipt.json'), 'verified_script_files': checked, 'actual_native_sha256': actual_native}, ensure_ascii=False))


def run():
    verify()
    proof = read(PROOF)
    assert sha(proof['native_identity']['path']) == proof['native_identity']['actual_sha256']
    output = CACHE / 'probe-gp80.json'
    assert not output.exists()
    spec = importlib.util.spec_from_file_location('plain_launcher', PRIOR / 'run.py')
    launcher = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(launcher)
    launcher.ROOT = CACHE
    source_input = REPO / '.cache/task-navigation-20261019/gp.input.bin'
    launcher.launch(['--headless', '--path', PROJECT, '--script', 'res://tools/performance/representative.gd', '--', '--input=' + str(source_input), '--output=' + str(output), '--steps=80', '--profile=plain'], output)
    actual = read(output)
    expected = read(PRIOR / 'b-gp80.json')
    assert actual['complete'] and actual['qualified'] and not actual['errors']
    for key in ['source_input_sha256', 'initial', 'final', 'operations', 'qualification', 'public', 'public_checks', 'event_records', 'final_binary_sha256']:
        assert actual.get(key) == expected.get(key), key
    assert not actual['route_tail_probe']['errors']
    assert {x['tick'] for x in actual['route_tail_probe']['events']} == {851, 867}
    for index, sample in enumerate(actual['samples']):
        original = expected['samples'][index]
        assert {k: v for k, v in sample.items() if k != 'elapsed_us'} == {k: v for k, v in original.items() if k != 'elapsed_us'}
    dump(CACHE / 'semantic-check.json', {'diagnostic_only': True, 'formal_pass': False, 'steps': len(actual['samples']), 'first_tick': actual['samples'][0]['tick'], 'last_tick': actual['samples'][-1]['tick'], 'same_complete_world_events_work_queues_and_final_binary': True, 'reference': str(PRIOR / 'b-gp80.json'), 'reference_sha256': sha(PRIOR / 'b-gp80.json'), 'reference_plain_c': str(PRIOR / 'c-gp80.json'), 'final_binary_sha256': actual['final_binary_sha256'], 'query_counts_equal': actual['public']['query_counts'] == expected['public']['query_counts'], 'selected_ticks': [851, 867], 'not_plain_timing': True})
    print(json.dumps({'output': str(output), 'semantics_equal': True, 'metrics_are_diagnostic': True}, ensure_ascii=False))


def summarize():
    data = read(CACHE / 'probe-gp80.json')
    probe = data['route_tail_probe']
    result = {'diagnostic_only': True, 'formal_pass': False, 'not_plain_timing': True, 'plain_references': [str(PRIOR / 'b-gp80.json'), str(PRIOR / 'c-gp80.json')], 'source_proof': str(PROOF), 'ticks': {}, 'warnings': ['Selected-tick event allocation and nested instrumentation perturb timing; do not subtract observer time to claim plain CPU.', 'Graph phase times include their child operations; graph_refresh/field/A* events are separate detail, not additive totals.', 'Actual A* time measures only each original get_id_path call, with stop timestamp before event dictionary construction.', 'Field backend time includes original reservation-mask argument evaluation and Variant/native adapter; no extra field was built.', 'Only observed same-identity, same-goal, uncached searches support a proposed reverse reuse. Counts do not prove its net whole-step gain.']}
    for tick in [851, 867]:
        events = [x for x in probe['events'] if x['tick'] == tick]
        legs = {x['id']: x for x in events if x['kind'] == 'floor_route'}
        astar = [x for x in events if x['kind'] == 'astar']
        by_leg = defaultdict(list)
        for event in astar:
            by_leg[event['leg_id']].append(event)
        groups = {}
        missing_identity = 0
        for leg in legs.values():
            identity_fields = ['floor_id', 'static_version', 'graph_key', 'geometry_id', 'goal']
            if any(k not in leg for k in identity_fields):
                missing_identity += 1
                continue
            key = (leg['floor_id'], leg['static_version'], leg['graph_key'], leg['geometry_id'], tuple(leg['goal']))
            group = groups.setdefault(key, {'identity': dict(zip(identity_fields, [*key[:4], list(key[4])])), 'legs': [], 'astar': []})
            group['legs'].append(leg)
            group['astar'].extend(by_leg[leg['id']])
        rows = []
        for group in groups.values():
            members = group['legs']
            searches = group['astar']
            eligible = [x for x in members if x['caller'] == 'connector_approach' and x['structural_only'] and x['cost_only'] and x['ignore_people'] and not x['members_count'] and not x['offsets_count'] and not x.get('navigation_query', True) and not x.get('overlay', True) and not x.get('bases_count', 1) and not x.get('shifts_count', 1)]
            eligible_ids = {x['id'] for x in eligible}
            eligible_searches = [x for x in searches if x['leg_id'] in eligible_ids]
            after_warmup_ids = {x['id'] for x in eligible[11:]}
            after_warmup_searches = [x for x in eligible_searches if x['leg_id'] in after_warmup_ids]
            rows.append({'identity': group['identity'], 'floor_route_calls': len(members), 'actors': sorted({x['actor_id'] for x in members}), 'unique_actors': len({x['actor_id'] for x in members}), 'starts': sorted({tuple(x['start']) for x in members}), 'unique_starts': len({tuple(x['start']) for x in members}), 'caller_counts': dict(Counter(x['caller'] for x in members)), 'solver_counts': dict(Counter(x.get('solver', x['return_mode']) for x in members)), 'path_cache_counts': dict(Counter(x.get('path_cache_outcome', 'not_attempted') for x in members)), 'zero_legs': sum(x['zero_leg'] for x in members), 'actual_astar_calls': len(searches), 'actual_astar_us': sum(x['elapsed_us'] for x in searches), 'connector_eligible_requests': len(eligible), 'connector_eligible_unique_actors': len({x['actor_id'] for x in eligible}), 'connector_eligible_unique_starts': len({tuple(x['start']) for x in eligible}), 'connector_eligible_actual_astar_calls': len(eligible_searches), 'connector_eligible_actual_astar_us': sum(x['elapsed_us'] for x in eligible_searches), 'after_first_11_eligible_requests_actual_astar_calls': len(after_warmup_searches), 'after_first_11_eligible_requests_actual_astar_us': sum(x['elapsed_us'] for x in after_warmup_searches), 'upper_bound_note': 'Observed original searches from eligible request 12 onward; does not deduct an unmeasured proposed reverse-field build or lookup cost, and is not a measured optimization gain.', 'request_ids': [x['id'] for x in members]})
        rows.sort(key=lambda x: x['connector_eligible_actual_astar_us'], reverse=True)
        graph_events = [x for x in events if x['kind'] == 'graph']
        graph_phases = Counter()
        leg_phases = Counter()
        for event in graph_events:
            graph_phases.update(event['phases_us'])
        for event in legs.values():
            leg_phases.update(event['phases_us'])
        result['ticks'][str(tick)] = {'step_sample_is_diagnostic': next(x for x in data['samples'] if x['tick'] == tick), 'event_counts': dict(Counter(x['kind'] for x in events)), 'floor_route_calls': len(legs), 'scope_endpoint_hits': sum(x['return_mode'] == 'scope_endpoint_hit' for x in legs.values()), 'forward_field_served': sum(x.get('solver') == 'forward_field' for x in legs.values()), 'path_cache_outcomes': dict(Counter(x.get('path_cache_outcome', 'not_attempted') for x in legs.values())), 'scope_hits_or_external_graphs_without_fresh_graph_identity': missing_identity, 'floor_route_phases_us': dict(leg_phases), 'graph_modes': dict(Counter(x['mode'] for x in graph_events)), 'graph_phases_us': dict(graph_phases), 'actual_astar_calls': len(astar), 'actual_astar_us': sum(x['elapsed_us'] for x in astar), 'actual_astar_outside_floor_route_calls': sum(x['leg_id'] not in legs for x in astar), 'actual_existing_field_backend_calls': [x for x in events if x['kind'] == 'field_backend'], 'cache_lifecycle_events': [x for x in events if x['kind'] in ['trim', 'query_clear', 'graph_evict']], 'same_graph_goal_groups': rows}
    anchor_groups = [x for x in result['ticks']['851']['same_graph_goal_groups'] if x['connector_eligible_requests']]
    original_search_us = sum(x['connector_eligible_actual_astar_us'] for x in anchor_groups)
    post_warmup_search_us = sum(x['after_first_11_eligible_requests_actual_astar_us'] for x in anchor_groups)
    built_fields = [x for x in probe['events'] if x['tick'] == 851 and x['kind'] == 'field_lookup' and x.get('built')]
    result['candidate_assessment'] = {'scope': 'Only the measured GP851 same-graph same-anchor connector-approach groups; the other 78 steps have no parameter/event sampling.', 'same_graph_goal_groups': len(anchor_groups), 'original_eligible_astar_calls': sum(x['connector_eligible_actual_astar_calls'] for x in anchor_groups), 'original_eligible_astar_us': original_search_us, 'unchanged_warmup_requests': 12, 'after_first_11_eligible_requests_actual_astar_calls': sum(x['after_first_11_eligible_requests_actual_astar_calls'] for x in anchor_groups), 'after_first_11_eligible_requests_actual_astar_us': post_warmup_search_us, 'observed_group_upper_bound_amortized_over_80_steps_us': post_warmup_search_us / 80, 'reverse_build_or_lookup_cpu_measured': False, 'upper_bound_excludes_proposed_build_lookup_metadata_cost': True, 'actual_existing_built_fields': {'count': len(built_fields), 'all_forward': all(x['forward'] for x in built_fields), 'all_successors_empty': all(x['successors_count'] == 0 for x in built_fields), 'all_built_on_original_request_12': all(x['hits'] == 12 for x in built_fields), 'record_charge_sum_bytes': sum(x['charge'] for x in built_fields), 'array_allowance_sum_bytes': sum((x['distances_count'] + x['successors_count']) * 16 for x in built_fields)}, 'proposed_reverse_allowance': {'array_charge_per_full_field_bytes': 9216 * 2 * 16, 'three_field_array_charge_bytes': 3 * 9216 * 2 * 16, 'additional_metadata': 'Existing 512 + destination.length()*8 + var_to_bytes(stamp).size()*8 per record; do not introduce a separate budget.', 'budget': 'Original shared 128 MiB graph/query target and query target/4 clearing remain required.', 'allocation_measurement': False}, 'recommendation': 'Do not begin another production change from this evidence alone. Repetition and unit-cost semantics are proven, but the measured group offers at most 10.128 ms at GP851 before unmeasured reverse costs, or 0.1266 ms/step amortized over GP80; ordinary representative tick867 performs no route query. This is a bounded later candidate, not evidence of a larger ordinary-step or primary tail improvement.'}
    dump(CACHE / 'summary.json', result)
    print(json.dumps({'summary': str(CACHE / 'summary.json'), 'ticks': {tick: {'actual_astar_calls': row['actual_astar_calls'], 'actual_astar_us': row['actual_astar_us'], 'graph_modes': row['graph_modes'], 'graph_phases_us': row['graph_phases_us'], 'top_anchor_groups': row['same_graph_goal_groups'][:3]} for tick, row in result['ticks'].items()}}, ensure_ascii=False))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['prepare', 'verify', 'finalize-prepare', 'run', 'summarize'])
    parser.add_argument('--resume-copy', action='store_true')
    args = parser.parse_args()
    if args.action == 'prepare':
        prepare(args.resume_copy)
    elif args.action == 'verify':
        print(json.dumps({'verified_script_files': verify(), 'inverse_byte_equal': True}))
    elif args.action == 'finalize-prepare':
        finalize_prepare()
    elif args.action == 'summarize':
        summarize()
    else:
        run()
