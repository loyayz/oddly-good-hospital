诊断使用已冻结的 d5f048e 工程副本与同一合法160人 GP 输入，从 tick823 完整推进80步至 tick903。记录 tick851 长尾与 tick867 普通代表步；tick867 来自 d5 首组 plain b 的 index43，40.109ms，等于该窗口 P50。已有 b/c plain 保留为整步对照，插桩窗口的耗时只作诊断。

四个文件添加可逆内联时间戳与事件：HospitalNavigation 的层内查询和调用来源、NavigationCache 的图获取/刷新/缓存与距离场记录、FloorNavigation 原有 AStar 和距离场调用、代表窗口的启停与测量外导出。原有函数不加包装，不新增图、搜索或距离场调用。其余78步只保留条件分支和标量初始化；事件只在两个选定 tick 分配。

分组使用已计算的64位楼层、完整图键、静态来源版本、几何实例身份和目标坐标。统计不同人物/起点、现有 scope/forward/path 命中与真实 AStar 次数和时间。图获取按 floor_source、graph_key、entry_lookup、source_proof_refresh、lru_touch、trim 分段；刷新与驱逐另记事件。只报告现有距离场构建，禁止为推测反向复用额外建场。

所有时间和事件均为诊断。嵌套子事件不能与父段相加；handler_body_us 不含调用入口和参数字典构造，不能从插桩整步中减去它冒充 plain。get_id_path 的停止时间在事件参数构造前读取。距离场原调用计时包含其正常预约掩码参数计算和原生适配器。

source-proof.json 保留四个文件的原始/生成哈希、完整逐处替换和字节级逆变换证明，新增 helper 单独登记。prepare-receipt.json 记录准备尝试、静态核验和实际原生 DLL 哈希。首次准备的 token 断言失败保留于 prepare-attempt-1.log；复制耗时包含在该次1.133秒命令内，未单独计时，不推测独立复制耗时。

执行顺序：python probe.py verify；python probe.py run；python probe.py summarize。run 只执行一次完整 GP80 plain 驱动，使用原隔离环境和同引擎，禁止同时启动其他引擎或构建。完成后比较80步完整世界、事件、工作、队列、原查询计数和最终二进制哈希；不以功能一致代替正式性能验收。
