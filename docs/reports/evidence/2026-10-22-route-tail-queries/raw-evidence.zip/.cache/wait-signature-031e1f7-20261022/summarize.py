"""Verify and archive the wait-dependency batch investigation.

This script reads existing evidence. It never starts Godot, builds a dependency,
changes a source snapshot, edits game/tests, or changes process scheduling.
Run only after measurement has stopped: verification and ZIP creation do CPU/IO
work. All timings remain diagnostic; the plain windows are the end-to-end data.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import subprocess
import sys
from datetime import datetime, timezone
import uuid
import zipfile

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
OUT = REPO / "docs/reports/evidence/2026-10-22-wait-dependency-batch"
BASE = "031e1f770664b5a270a47f8f3ed255593a656331"
FIX = None
CONFIG = {}
CONFIG_PATH = ROOT / "delivery-config.json"
INPUTS = REPO / ".cache/task-navigation-20261019"
WINDOWS = {
    "public360": (360, "public-v6.input.bin"),
    "gp80": (80, "gp.input.bin"),
    "operations40": (40, "op.input.bin"),
}
SIDES = {"a": "before", "b": "after", "c": "after", "d": "before"}
PLAIN = [(label, window) for label in "abcd" for window in WINDOWS]
SELECTED = {
    "public360": [0, 1, 27, 63, 67, 69, 124, 129, 136, 140, 194, 219, 279],
    "gp80": [0, 1, 3, 4, 15, 27, 28, 39, 79],
}
PRODUCTION_CHANGES = set()
PASS_BATCH = None
CASES = set()
OUTPUTS = ("quick-summary.json", "function-summary.json", "functional-summary.json", "source-check.json", "raw-evidence.zip", "raw-manifest.json")
CORE_PREFIXES = ("game/", "content/", "tools/performance/")
TEXT_SUFFIXES = {".gd", ".uid", ".tscn", ".tres", ".gdextension", ".json", ".py", ".ps1", ".cpp", ".hpp", ".h", ".c", ".cmake", ".txt", ".cfg", ".toml", ".md", ".yml", ".yaml", ".sh"}


def require(condition, context):
    if not condition:
        raise ValueError(str(context))


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def encoded(value):
    return (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n").encode("utf-8")


def digest(value):
    return hashlib.sha256(value).hexdigest()


def sha(path):
    result = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            result.update(block)
    return result.hexdigest()


def relative(path):
    return Path(path).resolve().relative_to(REPO).as_posix()


def resolve(path):
    value = Path(path)
    result = (value if value.is_absolute() else REPO / value).resolve()
    require(result.is_relative_to(REPO), ("Evidence path escaped repository", path))
    return result


def load_config():
    global CONFIG, FIX, PRODUCTION_CHANGES, OUT
    CONFIG = read(CONFIG_PATH)
    require(CONFIG.get("baseline_commit", BASE) == BASE, "Wrong configured baseline")
    FIX = CONFIG["fix_commit"]
    require(isinstance(FIX, str) and re.fullmatch(r"[0-9a-f]{7,40}", FIX), "Set actual measured fix_commit")
    PRODUCTION_CHANGES = set(CONFIG["changed_files"])
    require(PRODUCTION_CHANGES, "Set actual changed source paths")
    OUT = resolve(CONFIG.get("output", "docs/reports/evidence/2026-10-22-wait-dependency-batch"))
    require(CONFIG.get("acceptance_batches"), "Set actual acceptance_batches and authoritative claim_cases")
    require(CONFIG.get("native_build", {}).get("identity"), "Set actual current native build identity")
    require(CONFIG["native_build"].get("origin") == "new_build_this_round", "This round records a real new native build")
    require(CONFIG.get("expect_native_changed", True) is True, "This round expects the measured new native DLL")
    require(not CONFIG.get("extra_selected_runs", []) and not CONFIG.get("root_references", []), "This round uses lightweight sections, not all-instance or root-window profiles")

def git(*arguments, data=None):
    return subprocess.check_output(["git", *arguments], cwd=REPO, input=data)


def git_blobs(commit, paths):
    """Read the actual committed blobs in one process, including asset bytes."""
    expressions = [commit + ":" + path for path in paths]
    raw = git("cat-file", "--batch", data="".join(x + "\n" for x in expressions).encode("utf-8"))
    cursor = 0
    result = {}
    for path in paths:
        end = raw.index(b"\n", cursor)
        header = raw[cursor:end].split()
        require(len(header) == 3 and header[1] == b"blob", (commit, path, header))
        size = int(header[2])
        cursor = end + 1
        result[path] = raw[cursor:cursor + size]
        cursor += size + 1
    require(cursor == len(raw), "Unexpected trailing Git batch data")
    return result


def identity_rows(identity):
    rows = identity["source"]
    require(isinstance(rows, list) and rows, "Missing source identity rows")
    result = {row["path"]: row["sha256"].lower() for row in rows}
    require(len(result) == len(rows), "Duplicate source identity path")
    require(all(not Path(path).is_absolute() and ".." not in Path(path).parts for path in result), "Unsafe source path")
    return result


def dependency_proof(identity, project, match_workspace=None):
    if match_workspace is None:
        match_workspace = project.name.startswith("after")
    names = {"oddly_good_platform.windows.x86_64.dll": identity["native_sha256"],
             "libgmp-10.dll": identity["gmp_sha256"], "libmpfr-6.dll": identity["mpfr_sha256"],
             **identity["runtime_sha256"]}
    result = []
    for name, expected in names.items():
        source = "game/platform/windows/bin/" + name
        actual, delivered = sha(project / source), sha(REPO / source)
        require(actual == expected.lower(), (project, source, "Actual native dependency mismatch"))
        if match_workspace:
            require(actual == delivered, (project, source, "Delivered native dependency mismatch"))
        result.append({"path": source, "sha256": actual, "workspace_equal": actual == delivered,
                       "payload_archived": False})
    require(sha(identity["engine"]) == identity["engine_sha256"].lower(), (project, "Source identity engine mismatch"))
    return {"actual_native_files": result, "source_identity_engine": identity["engine"],
            "actual_source_identity_engine_sha256": sha(identity["engine"])}


class Archive:
    def __init__(self):
        self.entries = {}

    def add(self, path, role):
        path = Path(path).resolve()
        require(path.is_file(), ("Missing evidence", path))
        name = relative(path)
        existing = self.entries.get(name)
        require(existing is None or existing["path"] == path, ("Archive name collision", name))
        if existing:
            if role not in existing["roles"]:
                existing["roles"].append(role)
        else:
            self.entries[name] = {"path": path, "roles": [role]}

    def virtual(self, name, value, role):
        require(name not in self.entries and not name.startswith("/") and ".." not in Path(name).parts, name)
        self.entries[name] = {"data": value, "roles": [role]}

    def write_and_verify(self, destination):
        files = []
        with zipfile.ZipFile(destination, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as output:
            for name, item in sorted(self.entries.items()):
                if "path" in item:
                    path = item["path"]
                    before = path.stat()
                    actual_sha = sha(path)
                    output.write(path, name)
                    after = path.stat()
                    require((before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns), ("Evidence changed while archiving", path))
                    size = before.st_size
                    origin = relative(path)
                else:
                    raw = item["data"]
                    actual_sha, size, origin = digest(raw), len(raw), "generated-verification-proof"
                    output.writestr(name, raw)
                files.append({"path": name, "size": size, "sha256": actual_sha, "origin": origin, "roles": item["roles"]})
        with zipfile.ZipFile(destination) as archive:
            names = archive.namelist()
            require(len(names) == len(set(names)) == len(files), "Duplicate/missing ZIP member")
            require(set(names) == {row["path"] for row in files}, "ZIP membership mismatch")
            for row in files:
                info = archive.getinfo(row["path"])
                require(info.file_size == row["size"], ("ZIP size mismatch", row["path"]))
                check = hashlib.sha256()
                with archive.open(row["path"]) as stream:
                    for block in iter(lambda: stream.read(1024 * 1024), b""):
                        check.update(block)
                require(check.hexdigest() == row["sha256"], ("ZIP SHA mismatch", row["path"]))
        return {"schema_version": 1, "diagnostic_only": True, "formal_pass": False,
                "archive": "raw-evidence.zip", "archive_size": destination.stat().st_size,
                "archive_sha256": sha(destination), "member_count": len(files),
                "all_members_size_and_sha256_verified_after_zip": True,
                "files": files,
                "excluded_binary_payloads": ["Godot executables", ".godot imports", "asset payloads", "unchanged runtime dependency DLLs"],
                "binary_identity_note": "Actual source, asset, engine and dependency digests were checked separately in source-check.json; hashes are identity evidence, not a business correctness oracle."}


def prepared_config(original, path, identity):
    if path not in {"project.godot", "export_presets.cfg"}:
        return original
    text = original.decode("utf-8")
    if path == "project.godot":
        old = 'config/custom_user_dir_name="oddly-good-hospital"'
        require(text.count(old) == 1, (path, "Unexpected original user directory setting"))
        text = text.replace(old, 'config/custom_user_dir_name="' + identity["profile"] + '"')
    elif path == "export_presets.cfg":
        template = (REPO / ".cache/tools/godot-4.7.2/templates").as_posix()
        text = text.replace(".cache/tools/godot-4.7.2/templates", template)
    else:
        return original
    # prepare.ps1 uses Set-Content with one Windows record terminator. The
    # source identity hashes the copied original before this isolated rewrite.
    return text.encode("utf-8") + b"\r\n"


def snapshot_proof(side, commit, archive):
    project = ROOT / (side + "-project")
    path = project / "source-identity.json"
    identity = read(path)
    require(identity["head"] == commit, (side, "Source identity commit mismatch"))
    expected = identity_rows(identity)
    originals = git_blobs(commit, list(expected))
    checked = []
    for source, expected_sha in expected.items():
        require(digest(originals[source]) == expected_sha, (side, source, "Manifest differs from Git blob"))
        snapshot = project / source
        actual_sha = sha(snapshot)
        prepared = prepared_config(originals[source], source, identity)
        require(actual_sha == digest(prepared), (side, source, "Actual frozen source differs"))
        workspace_sha = sha(REPO / source) if side == "after" else None
        if side == "after":
            require(workspace_sha == expected_sha, (source, "Delivery workspace differs from measured after source"))
        checked.append({"path": source, "committed_original_sha256": expected_sha,
                        "actual_snapshot_sha256": actual_sha, "workspace_sha256": workspace_sha,
                        "isolated_prepare_rewrite": source in {"project.godot", "export_presets.cfg"}})
        if source.startswith(CORE_PREFIXES) and snapshot.suffix.lower() in TEXT_SUFFIXES:
            archive.add(snapshot, "frozen-source-text")
        elif source.startswith("addons/source_assets/") or source == "tests/acceptance/clinical_timing.gd":
            archive.add(snapshot, "frozen-runtime-support-source")
        elif source in {"project.godot", "export_presets.cfg"}:
            archive.add(snapshot, "isolated-runtime-config")
    archive.add(path, "frozen-complete-source-and-asset-manifest")
    dlls = {"oddly_good_platform.windows.x86_64.dll": identity["native_sha256"],
            "libgmp-10.dll": identity["gmp_sha256"], "libmpfr-6.dll": identity["mpfr_sha256"],
            **identity["runtime_sha256"]}
    binaries = []
    for name, expected_sha in dlls.items():
        source = "game/platform/windows/bin/" + name
        actual_sha, workspace_sha = sha(project / source), sha(REPO / source)
        require(actual_sha == expected_sha.lower(), (side, source, "Native dependency identity mismatch"))
        if side == "after":
            require(actual_sha == workspace_sha, (side, source, "Delivered native dependency differs"))
        binaries.append({"path": source, "sha256": actual_sha, "workspace_equal": actual_sha == workspace_sha, "payload_archived": name == "oddly_good_platform.windows.x86_64.dll"})
        if name == "oddly_good_platform.windows.x86_64.dll":
            archive.add(project / source, "actual-measured-native-platform-library")
    return {"side": side, "commit": commit, "project": relative(project),
            "source_identity_sha256": sha(path), "source_count": len(checked),
            "all_source_rows_checked_against_actual_files_and_committed_blobs": True,
            "delivery_workspace_matches_all_after_original_source_rows": True if side == "after" else None,
            "files": checked, "native_dependencies": binaries,
            "complete_dependency_proof": dependency_proof(identity, project)}, expected




def metric_values(samples):
    values = [row["elapsed_us"] for row in samples]
    ordered = sorted(values)
    count, total = len(values), sum(values)
    return {"count": count, "total_us": total, "mean_us": total / count,
            "p50_us": ordered[math.ceil(count * .50) - 1], "p95_us": ordered[math.ceil(count * .95) - 1],
            "p99_us": ordered[math.ceil(count * .99) - 1], "max_us": ordered[-1],
            "cold_first_us": values[0], "following_mean_us": (total - values[0]) / max(1, count - 1)}




def measured(label, window, side, mode, archive, project_override=None):
    path = ROOT / (label + "-" + window + ".json")
    data = read(path)
    launch_path = ROOT / (label + "-" + window + ".launch.json")
    launch = read(launch_path)
    require(mode == "plain", "Only the ordinary plain driver is used in this round")
    project = Path(project_override) if project_override is not None else ROOT / (side + "-project")
    steps, input_name = WINDOWS[window]
    require(data["complete"] and data["qualified"] and not data["errors"], (path, "Unqualified/incomplete"))
    require(data["diagnostic_only"] is True and data["formal_pass"] is False and data["formal_acceptance_paused"] is True, path)
    require(data["mode"] == mode and data["requested_steps"] == len(data["samples"]) == steps, path)
    require(all(value is True for value in data["qualification"].values()), path)
    require(all(value is True for value in data.get("public_checks", {}).values()), path)
    require(all(row["complete"] and row["present"] == 160 and row["index"] == index for index, row in enumerate(data["samples"])), path)
    for boundary in ("initial", "final"):
        state = data[boundary]
        require(state["validation"] == "" and state["ok"] and not state["errors"], (path, boundary))
        require(state["present"] == 160 and state["active_patients"] == 120 and state["staff"] == 32 and state["present_visitors"] == 8, (path, boundary, "Population changed"))
        require(state["rooms"] == 64 and state["facilities"] == 1336, (path, boundary, "World size changed"))
    require(data["final"]["minimum_present"] == data["final"]["maximum_present"] == 160 and data["final"]["same_actor_ids"], path)
    require(data["final"]["tick"] - data["initial"]["tick"] == steps, (path, "Not ordinary complete ticks"))
    require(not data["public"]["errors"] and not data.get("setup", {}).get("errors", []), path)
    if data["operations"]:
        require(all(value is True for value in data["operations"]["checks"].values()), path)
    for key, expected in metric_values(data["samples"]).items():
        require(key in data["metrics"] and math.isclose(data["metrics"][key], expected, rel_tol=1e-12, abs_tol=1e-7), (path, "Metric recomputation mismatch", key))
    require(sha(INPUTS / input_name) == data["source_input_sha256"], (path, "Wrong input"))
    require(sha(Path(str(path) + ".final.bin")) == data["final_binary_sha256"], (path, "Final binary identity mismatch"))
    require(launch["exit_code"] == 0 and not launch["timed_out"] and not launch["errors"], path)
    require(not launch["affinity_changed"] and not launch["priority_changed"], path)
    require(launch["diagnostic_only"] and launch["formal_pass"] is False, path)
    require(launch["self_contained"] and launch.get("isolated_appdata") and launch.get("isolated_localappdata"), path)
    require(sha(launch["engine"]) == launch["engine_sha256"].lower(), (path, "Actual engine changed"))
    require("--path" in launch["arguments"] and Path(launch["arguments"][launch["arguments"].index("--path") + 1]).resolve() == project.resolve(), (path, "Wrong runtime project"))
    for source, expected in data["sources"].items():
        require(source.startswith("res://") and sha(project / source.removeprefix("res://")) == expected, (path, source, "Observed source hash differs"))
    progress_path = Path(str(path) + ".steps.ndjson")
    progress = [json.loads(line) for line in progress_path.read_text(encoding="utf-8-sig").splitlines() if line.strip()]
    enters = [row for row in progress if row["kind"] == "enter"]
    completed = [row for row in progress if row["kind"] == "complete"]
    require(len(progress) == 2 * steps and len(enters) == len(completed) == steps, (path, "Missing progress rows"))
    require([row["sample"] for row in completed] == data["samples"], (path, "NDJSON/report samples differ"))
    require(all(progress[2 * index]["kind"] == "enter" and progress[2 * index]["index"] == index and progress[2 * index + 1]["kind"] == "complete" for index in range(steps)), path)
    for suffix in ("stdout.log", "stderr.log"):
        log = ROOT / (label + "-" + window + "." + suffix)
        text = log.read_text(encoding="utf-8-sig", errors="replace")
        require("SCRIPT ERROR:" not in text and "ERROR:" not in text, log)
        archive.add(log, "measurement-log")
    for item in (path, launch_path, progress_path, Path(str(path) + ".final.bin")):
        archive.add(item, "raw-" + mode + "-measurement")
    result = {"run": label + "-" + window, "side": side, "mode": mode, "window": window,
              "result": relative(path), "result_sha256": sha(path), "metrics_us": data["metrics"],
              "launch": launch, "execution": data["execution"], "engine_version": data["engine"],
              "source_input_sha256": data["source_input_sha256"], "final_binary_sha256": data["final_binary_sha256"],
              "initial_tick": data["initial"]["tick"], "final_tick": data["final"]["tick"],
              "step_seconds": .1, "all_steps_complete_with_160_actors": True,
              "qualification": data["qualification"], "public_checks": data.get("public_checks"),
              "work_ticks_by_kind": data["final"]["work_ticks_by_kind"], "public_results": data["public"],
              "operations_results": data["operations"], "top_ten_steps": sorted(data["samples"], key=lambda x: x["elapsed_us"], reverse=True)[:10]}
    return result, data, completed


def compare_semantics(reference, actual, label):
    reference_public = {key: value for key, value in reference["public"].items() if key != "query_counts"}
    actual_public = {key: value for key, value in actual["public"].items() if key != "query_counts"}
    fields = ("source_input_sha256", "initial", "final", "event_records", "operations", "setup", "public_input", "qualification")
    equality = {field: reference[field] == actual[field] for field in fields}
    equality["full_public_results_except_diagnostic_query_counts"] = reference_public == actual_public
    require(all(equality.values()), (label, "Business output mismatch", equality))
    # Retain both a semantic comparison and the auxiliary binary observation.
    return {"run": label, "semantic_fields_equal": equality,
            "final_binary_equal_auxiliary": reference["final_binary_sha256"] == actual["final_binary_sha256"]}


def metric_comparison(before, after):
    keys = ("mean_us", "p50_us", "p95_us", "p99_us", "max_us", "cold_first_us", "following_mean_us", "total_us")
    return {key: {"before": before[key], "after": after[key], "delta": after[key] - before[key],
                  "change_percent": (after[key] / before[key] - 1) * 100 if before[key] else None} for key in keys}


def counter_comparison(before, after):
    return {key: {"before": before.get(key), "after": after.get(key),
                  "before_field_present": key in before, "after_field_present": key in after,
                  "delta": after[key] - before[key] if key in before and key in after else None}
            for key in sorted(set(before) | set(after)) if before.get(key) != after.get(key)}




def regression_proof(batch, expected_cases, expected_failed, after_sources, archive, claimed_cases=None, allowed_source_differences=(), source_reuse_note=""):
    project = REPO / ".cache/acceptance" / batch
    claimed_cases = expected_cases if claimed_cases is None else set(claimed_cases)
    require(claimed_cases <= expected_cases, (batch, "Claimed cases not present in original batch"))
    allowed_source_differences = set(allowed_source_differences)
    data, status, timing, identity = (read(project / name) for name in ("acceptance-results.json", "execution-status.json", "timing-summary.json", "source-identity.json"))
    require(data["completed"] and timing["completed"] and timing["phase"] == "finished", batch)
    require(set(data["results"]) == expected_cases, (batch, "Wrong selected cases"))
    observed_failed = {key for key, value in data["results"].items() if not value["passed"]}
    require(observed_failed == expected_failed and data["failed"] == len(expected_failed), (batch, "Unexpected failed case set"))
    require(status["import_exit"] == 0 and status["test_exit"] == (1 if expected_failed else 0) and status["script_errors"] is False, batch)
    sources = identity_rows(identity)
    checked = []
    wanted = {"tests/acceptance/runner.gd", "tests/acceptance/checkpoints.gd"}
    suite_names = {"OPS": "operations", "STAFF": "staff", "SPACE": "space", "CORE": "core", "CLIN": "clinical", "GROW": "growth"}
    wanted.update("tests/acceptance/" + suite_names[case.split("-")[0]] + ".gd" for case in expected_cases)
    wanted.update(CONFIG.get("regression_test_sources", []))
    wanted.update(allowed_source_differences)
    pending = list(wanted)
    while pending:
        name = pending.pop()
        if name not in sources or not (project / name).is_file():
            continue
        text = (project / name).read_text(encoding="utf-8-sig")
        for dependency in re.findall(r'res://(tests/[^"\\s]+\\.gd)', text):
            if dependency not in wanted:
                wanted.add(dependency)
                pending.append(dependency)
    before_sources = identity_rows(read(ROOT / "before-project/source-identity.json"))
    for source, expected_sha in sources.items():
        if not (source.startswith(CORE_PREFIXES) or source in wanted):
            continue
        actual_sha = sha(project / source)
        require(actual_sha == expected_sha, (batch, source, "Acceptance source snapshot differs"))
        workspace_sha = sha(REPO / source)
        if not expected_failed:
            if workspace_sha != actual_sha:
                require(source in allowed_source_differences and source_reuse_note, (batch, source, "Unreviewed passing-source difference"))
            elif source in after_sources:
                require(actual_sha == after_sources[source], (batch, source, "Regression/performance source differs"))
        canonical = None
        if source in after_sources and actual_sha == after_sources[source]:
            canonical = relative(ROOT / "after-project" / source)
        elif source in before_sources and actual_sha == before_sources[source]:
            canonical = relative(ROOT / "before-project" / source)
        checked.append({"path": source, "actual_snapshot_sha256": actual_sha, "workspace_sha256": workspace_sha,
                        "workspace_equal": workspace_sha == actual_sha, "identical_archived_source": canonical,
                        "reviewed_reuse_for_claimed_cases": workspace_sha != actual_sha and source in allowed_source_differences,
                        "source_reuse_note": source_reuse_note if workspace_sha != actual_sha else None})
        if source in wanted or (canonical is None and source.startswith(CORE_PREFIXES)):
            if (project / source).suffix.lower() in TEXT_SUFFIXES:
                archive.add(project / source, "actual-regression-source")
    for name in ("acceptance-results.json", "execution-status.json", "timing-summary.json", "source-identity.json", "fixture-config.json", "execution.log", "import.log", "project.godot", "export_presets.cfg"):
        if (project / name).exists():
            archive.add(project / name, "regression-original-evidence")
    dependencies = dependency_proof(identity, project, match_workspace=not expected_failed)
    if expected_failed:
        archive.add(project / "game/platform/windows/bin/oddly_good_platform.windows.x86_64.dll", "failed-regression-native-platform-library")
    return {"batch": batch, "selected_cases": sorted(expected_cases), "claim_cases": sorted(claimed_cases),
            "prior_results_not_used_as_current_case_evidence": sorted(expected_cases - claimed_cases),
            "failed_cases": sorted(observed_failed), "completed": True,
            "scope": "Selected cases only; not full-suite, build, pixel or release performance acceptance.",
            "classification": "selected_regressions_passed" if not expected_failed else "retained_actual_failed_regression_batch",
            "status": status, "timing_ms": timing, "original_results": data,
            "source_identity_sha256": sha(project / "source-identity.json"), "checked_source_count": len(checked), "checked_sources": checked,
            "all_selected_passing_sources_equal_delivery": all(row["workspace_equal"] for row in checked) if not expected_failed else None,
            "reviewed_source_reuse_note": source_reuse_note or None,
            "source_head": identity["head"], "test_arguments": identity["test_arguments"], "complete_dependency_proof": dependencies}

def native_build_proof(archive):
    spec = CONFIG["native_build"]
    path = resolve(spec["identity"])
    identity = read(path)
    output_key = spec.get("output_sha256_key", "native_sha256")
    sources_key = spec.get("sources_key", "sources")
    require(output_key in identity and sources_key in identity, ("Build identity fields missing", output_key, sources_key))
    output = ROOT / "after-project/game/platform/windows/bin/oddly_good_platform.windows.x86_64.dll"
    output_sha = sha(output)
    require(str(identity[output_key]).lower() == output_sha, "Build identity DLL differs from actually measured after DLL")
    rows = identity[sources_key]
    if isinstance(rows, dict):
        rows = [{"path": key, "sha256": value} for key, value in rows.items()]
    require(isinstance(rows, list) and rows, "Build identity has no source hashes")
    checked = []
    for row in rows:
        actual = resolve(row["path"])
        require(sha(actual) == row["sha256"].lower(), ("Build source changed", actual))
        checked.append({"path": relative(actual), "sha256": row["sha256"].lower()})
        if actual.suffix.lower() in TEXT_SUFFIXES:
            archive.add(actual, "native-build-source")
    changed_native = {path for path in PRODUCTION_CHANGES if path.startswith("game/platform/") and Path(path).suffix in {".h", ".hpp", ".cpp", ".c"}}
    require(changed_native <= {row["path"] for row in checked}, ("Native build identity omits changed sources", changed_native))
    archive.add(path, "native-build-identity")
    logs = []
    for name in spec.get("logs", []):
        log = resolve(name)
        archive.add(log, "native-build-log")
        logs.append({"path": relative(log), "sha256": sha(log)})
    return {"identity": relative(path), "identity_sha256": sha(path), "actual_measured_output_sha256": output_sha,
            "actual_build_sources_checked": checked, "logs": logs, "original_identity": identity,
            "build_origin": spec["origin"], "new_build_performed_this_round": True,
            "build_note": "Actual new native build identity and successful receipt; current source hashes and the DLL used by after measurements are checked."}




def environment_proof(archive):
    launches = []
    engine_paths = set()
    for path in sorted(ROOT.glob("*.launch.json")):
        value = read(path)
        archive.add(path, "actual-process-launch-receipt")
        launches.append({"receipt": relative(path), **value})
        engine_paths.add(Path(value["engine"]))
        for suffix in (".stdout.log", ".stderr.log"):
            sibling = path.with_name(path.name.removesuffix(".launch.json") + suffix)
            if sibling.exists():
                archive.add(sibling, "actual-process-log")
    engines = []
    for engine in sorted(engine_paths):
        require(sha(engine) == next(row["engine_sha256"].lower() for row in launches if Path(row["engine"]) == engine), engine)
        installed = Path("C:/programs/godot") / engine.name
        require(sha(engine) == sha(installed), ("Engine copy changed", engine))
        marker = engine.parent / "_sc_"
        require(marker.exists() and marker.stat().st_size == 0, "Missing self-contained marker")
        archive.add(marker, "portable-self-contained-marker")
        engines.append({"path": relative(engine), "sha256": sha(engine), "installed_byte_hash_equal": True, "payload_archived": False})
    tool_logs = []
    for path in sorted(ROOT.glob("*.log")):
        if path.name.startswith("summarize-") and path.stat().st_size == 0:
            continue
        archive.add(path, "investigation-log")
        text = path.read_text(encoding="utf-8-sig", errors="replace")
        if "Traceback (most recent call last)" in text:
            tool_logs.append({"path": relative(path), "sha256": sha(path), "classification": "tool_failure_retained; not a business failure"})
    configured = []
    for spec in CONFIG.get("evidence_paths", []):
        if isinstance(spec, str):
            spec = {"path": spec, "role": "additional-current-round-evidence"}
        path = resolve(spec["path"])
        archive.add(path, spec.get("role", "additional-current-round-evidence"))
        configured.append({**spec, "path": relative(path), "sha256": sha(path)})
    return {"engines": engines, "actual_launches": launches, "tool_failures": tool_logs,
            "configured_evidence_including_actual_build_or_tool_failures": configured,
            "process_isolation": "run.py overrides APPDATA and LOCALAPPDATA only for each child; engine _sc_ marker is retained.",
            "scheduling": "Launch receipts preserve actual wall/child CPU and unchanged affinity/priority. No frequency/scheduler causal attribution is inferred."}


SIGNATURE_SECTIONS = ("setup", "region", "facilities", "dynamic", "routing", "queue", "actors", "reservations", "environment")


def inline_source_proof(spec, current_sources, archive):
    proof_path = resolve(spec["proof"])
    proof = read(proof_path)
    project = resolve(spec.get("project", proof["project"]))
    side = spec["side"]
    plain = ROOT / (side + "-project")
    target = proof["production_path"]
    require(proof["only_inline_timestamps_and_runtime_counters"] and proof["inverse_byte_equal"], proof_path)
    require(tuple(proof["sections"]) == SIGNATURE_SECTIONS, (proof_path, "Unexpected section boundaries"))
    require(not (project / "all-instance-profile-identity.json").exists(), (project, "Heavy wrappers are not this experiment"))
    generated = (project / target).read_bytes()
    require(digest(generated) == proof["generated_sha256"], (proof_path, "Generated source changed"))
    reconstructed = generated.decode("utf-8")
    counter = proof.get("counter_proof", {})
    if counter:
        require(counter["inverse_byte_equal"] and reconstructed.count(counter["generated"]) == 1, proof_path)
        reconstructed = reconstructed.replace(counter["generated"], counter["original"], 1)
    for replacement, original in reversed(proof["modifications"]):
        require(reconstructed.count(replacement) == 1, (proof_path, "Clock inverse is not unique"))
        reconstructed = reconstructed.replace(replacement, original, 1)
    original_bytes = reconstructed.encode("utf-8")
    require(digest(original_bytes) == proof["original_sha256"] == current_sources[target], proof_path)
    require(original_bytes == (plain / target).read_bytes(), (proof_path, "Inverse differs from measured production"))
    identity_path = project / "source-identity.json"
    identity = read(identity_path)
    require(identity_rows(identity) == current_sources, (proof_path, "Diagnostic original source inventory differs from this side"))
    config_originals = git_blobs(identity["head"], ["project.godot", "export_presets.cfg"])
    checked = []
    for name, expected in current_sources.items():
        expected_runtime = proof["generated_sha256"] if name == target else expected
        if name in config_originals:
            require(digest(config_originals[name]) == expected, (proof_path, name, "Original runtime config changed"))
            expected_runtime = digest(prepared_config(config_originals[name], name, identity))
        actual = sha(project / name)
        require(actual == expected_runtime, (proof_path, name, "Actual diagnostic source differs"))
        checked.append({"path": name, "actual_sha256": actual, "generated_inline_source": name == target,
                        "canonical_plain_source": relative(plain / name)})
    current_identity = read(plain / "source-identity.json")
    for key in ("engine_sha256", "native_sha256", "gmp_sha256", "mpfr_sha256"):
        require(identity[key].lower() == current_identity[key].lower(), (proof_path, key, "Wrong diagnostic binary"))
    require(identity["runtime_sha256"] == current_identity["runtime_sha256"], proof_path)
    dependencies = dependency_proof(identity, project, match_workspace=side == "after")
    for path in (proof_path, project / target, identity_path, project / "project.godot", project / "export_presets.cfg"):
        archive.add(path, "lightweight-inline-diagnostic-source-or-proof")
    archive.virtual("verification-proofs/" + spec["label"] + "/" + spec["window"] + "/inverse-" + target + ".txt", original_bytes, "inline-clock-and-counter-independent-inverse")
    return project, {"proof": relative(proof_path), "proof_sha256": sha(proof_path),
                     "project": relative(project), "original_sha256": proof["original_sha256"],
                     "actual_generated_sha256": digest(generated), "independent_inverse_byte_equal": True,
                     "source_count": len(checked), "actual_sources": checked, "dependencies": dependencies,
                     "diagnostic_source_head": identity["head"], "current_side_source_head": current_identity["head"],
                     "original_source_inventory_matches_current_side": True,
                     "declared_original_source_project": proof.get("source_project"),
                     "actual_runtime_project": relative(project)}


def lightweight_run(spec, sources_by_side, raw_plain, archive):
    label, side, window, kind = (spec[key] for key in ("label", "side", "window", "kind"))
    require(side in {"before", "after"} and window in {"public360", "gp80"}, "Invalid lightweight diagnostic side/window")
    require(kind in {"signature_sections", "dependency_counts"}, "Unknown lightweight diagnostic kind")
    project, proof = inline_source_proof(spec, sources_by_side[side], archive)
    row, data, completed = measured(label, window, side, "plain", archive, project_override=project)
    reference_label = "a" if side == "before" else "b"
    semantic = compare_semantics(raw_plain[(reference_label, window)], data, row["run"])
    counts = data["public"]["query_counts"]
    nondiagnostic = {key: value for key, value in counts.items() if not key.startswith("diag_")}
    require(nondiagnostic == raw_plain[(reference_label, window)]["public"]["query_counts"], (row["run"], "Inline observer changed production query counts"))
    diagnostic = {key: value for key, value in counts.items() if key.startswith("diag_")}
    calls = diagnostic.get("diag_signature_calls")
    require(isinstance(calls, int) and calls > 0, (row["run"], "Missing actual signature-call count"))
    sections = []
    for name in SIGNATURE_SECTIONS:
        key = "diag_signature_" + name + "_us"
        require(key in diagnostic and isinstance(diagnostic[key], int) and diagnostic[key] >= 0, (row["run"], key))
        sections.append({"section": name, "total_us": diagnostic[key], "mean_us_per_complete_step": diagnostic[key] / WINDOWS[window][0],
                         "mean_us_per_signature_call": diagnostic[key] / calls})
    plain_context = []
    for plain_label in ("a", "d") if side == "before" else ("b", "c"):
        comparison = metric_comparison(raw_plain[(plain_label, window)]["metrics"], data["metrics"])
        plain_context.append({"plain_run": plain_label + "-" + window, "diagnostic_metric_changes_us": comparison})
    row["evidence_kind"] = kind
    return {"run": row["run"], "side": side, "window": window, "kind": kind,
            "metrics_us_diagnostic_window": row["metrics_us"], "full_window_steps": data["requested_steps"],
            "signature_calls": calls, "sections": sections, "diagnostic_counters": diagnostic,
            "production_query_counts": nondiagnostic, "source_proof": proof, "launch": row["launch"],
            "raw_result": row["result"], "semantic_comparison": semantic,
            "same_side_plain_context": plain_context,
            "timing_limit": "Inline clocks and their array/counter bookkeeping perturb execution. Nine measured spans are not exact CPU self-time, not a full-step partition, and not interchangeable with plain-window timing."}


def build_summaries(archive):
    fix = git("rev-parse", FIX).decode().strip()
    require(re.fullmatch(r"[0-9a-f]{40}", fix), fix)
    before_proof, before_sources = snapshot_proof("before", BASE, archive)
    after_proof, after_sources = snapshot_proof("after", fix, archive)
    changes = sorted(path for path in set(before_sources) | set(after_sources)
                     if before_sources.get(path) != after_sources.get(path) and path.startswith(CORE_PREFIXES))
    require(set(changes) == {path for path in PRODUCTION_CHANGES if path.startswith(CORE_PREFIXES)}, ("Unexpected measured source changes", changes))
    before_id = read(ROOT / "before-project/source-identity.json")
    after_id = read(ROOT / "after-project/source-identity.json")
    require(before_id["native_sha256"].lower() != after_id["native_sha256"].lower(), "New native DLL was not measured")
    for key in ("engine_sha256", "gmp_sha256", "mpfr_sha256"):
        require(before_id[key].lower() == after_id[key].lower(), ("Unrelated binary changed", key))
    require(before_id["runtime_sha256"] == after_id["runtime_sha256"], "Unrelated runtime dependency changed")
    environment = environment_proof(archive)
    native_build = native_build_proof(archive)
    plain, raw, semantic_checks = [], {}, []
    allowed_counts = set(CONFIG.get("query_count_changes_allowed", ["public_wait_dependency_batches", "public_wait_dependency_rectangles", "reservation_candidate_queries"]))
    for label, window in PLAIN:
        row, data, progress = measured(label, window, SIDES[label], "plain", archive)
        plain.append(row)
        raw[(label, window)] = data
        semantic_checks.append(compare_semantics(raw[("a", window)], data, row["run"]))
        unexpected = set(counter_comparison(raw[("a", window)]["public"]["query_counts"], data["public"]["query_counts"])) - allowed_counts
        require(not unexpected, (row["run"], "Unexplained production-query counter changes", sorted(unexpected)))
    comparisons = []
    for before, after, pair in (("a", "b", "A1_to_B1"), ("d", "c", "A2_to_B2_reverse_execution_order")):
        for window in WINDOWS:
            comparisons.append({"pair": pair, "window": window, "before_run": before + "-" + window, "after_run": after + "-" + window,
                                "metric_changes_us": metric_comparison(raw[(before, window)]["metrics"], raw[(after, window)]["metrics"]),
                                "query_counter_changes": counter_comparison(raw[(before, window)]["public"]["query_counts"], raw[(after, window)]["public"]["query_counts"])})
    defaults = []
    for label, side in (("sections", "before"), ("after-sections", "after")):
        for window in ("public360", "gp80"):
            defaults.append({"label": label, "side": side, "window": window, "kind": "signature_sections",
                             "proof": str(ROOT / (label + "-source-proof.json"))})
    defaults.append({"label": "counts", "side": "before", "window": "public360", "kind": "dependency_counts",
                     "proof": str(ROOT / "counts-source-proof.json")})
    light_specs = CONFIG.get("light_runs", defaults)
    required_pairs = {(side, window) for side in ("before", "after") for window in ("public360", "gp80")}
    require({(row["side"], row["window"]) for row in light_specs if row["kind"] == "signature_sections"} == required_pairs, "Both sides need actual public/GP section windows")
    names = [(row["label"], row["window"]) for row in light_specs]
    require(len(names) == len(set(names)) and all(label not in SIDES for label, window in names), "Diagnostic name collision")
    light = [lightweight_run(spec, {"before": before_sources, "after": after_sources}, raw, archive) for spec in light_specs]
    semantic_checks.extend(row["semantic_comparison"] for row in light)
    section_comparisons = []
    for window in ("public360", "gp80"):
        before = next(row for row in light if row["kind"] == "signature_sections" and row["side"] == "before" and row["window"] == window)
        after = next(row for row in light if row["kind"] == "signature_sections" and row["side"] == "after" and row["window"] == window)
        unexpected = set(counter_comparison(before["production_query_counts"], after["production_query_counts"])) - allowed_counts
        require(not unexpected, (window, "Unexpected cross-source lightweight production counters", sorted(unexpected)))
        section_comparisons.append({"window": window, "before_run": before["run"], "after_run": after["run"],
                                    "before_signature_calls": before["signature_calls"], "after_signature_calls": after["signature_calls"],
                                    "sections": [{"section": x["section"], "before_total_us": x["total_us"], "after_total_us": y["total_us"],
                                                  "before_mean_us_per_step": x["mean_us_per_complete_step"], "after_mean_us_per_step": y["mean_us_per_complete_step"],
                                                  "delta_mean_us_per_step": y["mean_us_per_complete_step"] - x["mean_us_per_complete_step"]}
                                                 for x, y in zip(before["sections"], after["sections"])]})
    batches, claimed = [], {}
    for spec in CONFIG["acceptance_batches"]:
        claim_cases = spec.get("claim_cases", spec["cases"])
        require(claim_cases, "Each accepted batch needs explicit nonempty authoritative claim_cases")
        proof = regression_proof(spec["id"], set(spec["cases"]), set(), after_sources, archive,
                                 claimed_cases=claim_cases, allowed_source_differences=spec.get("allowed_source_differences", []),
                                 source_reuse_note=spec.get("source_reuse_note", ""))
        for case in claim_cases:
            require(case not in claimed, ("Case claimed by two batches", case))
            claimed[case] = spec["id"]
        batches.append(proof)
    failures = [regression_proof(spec["id"], set(spec["cases"]), set(spec["failed_cases"]), after_sources, archive)
                for spec in CONFIG.get("fail_batches", [])]
    regressions = [{"pair": row["pair"], "window": row["window"], "metric": metric, **change}
                   for row in comparisons for metric, change in row["metric_changes_us"].items()
                   if metric in {"mean_us", "p95_us", "p99_us", "max_us", "cold_first_us"} and change["delta"] > 0]
    common = {"schema_version": 1, "diagnostic_only": True, "formal_pass": False, "formal_acceptance_paused": True,
              "baseline_commit": BASE, "fix_commit": fix, "delivery_config": relative(CONFIG_PATH), "delivery_config_sha256": sha(CONFIG_PATH)}
    quick = {**common, "scope": "Full ordinary HospitalSimulation.step; original legal fixed160 inputs, 0.1 simulation second per complete step; headless editor debug engine.",
             "plain_runs": plain, "paired_comparisons": comparisons, "observed_plain_regressions_retained": regressions,
             "execution_order": [row["run"] for row in sorted(plain, key=lambda value: value["launch"]["started_at_utc"])],
             "population": {"present": 160, "patients": 120, "staff": 32, "visitors": 8, "floors": 4, "rooms": 64, "facilities": 1336},
             "windows": {key: {"steps": value[0], "input": relative(INPUTS / value[1]), "source_input_sha256": sha(INPUTS / value[1])} for key, value in WINDOWS.items()},
             "interpretation": {"percent_change": "Positive is slower; negative is faster.", "quantiles": "Nearest-rank per original complete plain window. No pooled windows, discarded cold/tail steps or diagnostic substitutions.",
                                "diagnostic_windows": "Signature sections and count observers are separate full windows. Their timings are not plain whole-step performance.",
                                "acceptance": "No formal performance acceptance is claimed."}}
    counter_semantics = {"reservation_candidate_queries": "This path changes the counter's granularity from per-rectangle lookups to batch requests. A reduction does not establish fewer original-rectangle geometric checks.",
                         "public_wait_dependency_rectangles": "Original rectangles presented to the batched dependency path; retain separately from batch count.",
                         "missing_field": "Missing counters are unobserved, not independently observed zeroes."}
    functions = {**common, "measurement_kind": "inline_signature_sections_and_separate_counts", "all_instance_wrappers_run": False,
                 "lightweight_runs": light, "section_comparisons": section_comparisons, "counter_semantics": counter_semantics,
                 "limits": ["Nine spans are within each signature body, not a partition of the complete ordinary step.",
                            "Timer arrays, reads and counter writes have unisolated overhead. Do not subtract a handler to reconstruct production CPU time.",
                            "The counts window adds loop/counter work; its timings are not the baseline signature budget.",
                            "No heavy all-instance function table or newly measured full-window root stages are claimed."]}
    functional = {**common, "selected_case_evidence": claimed, "acceptance_batches": batches, "current_round_failed_batches": failures,
                  "fixed_input_semantic_comparisons": semantic_checks, "no_failed_business_batch_in_this_round": not failures,
                  "evidence_reuse_note": "Each case names its authoritative completed batch. Earlier results for cases rerun later are retained as history but excluded from current claims. Reviewed source differences are recorded with actual hashes.",
                  "verification_status": {"selected_cases": str(len(claimed)) + " authoritative passing case results", "full_suite": "not run",
                                          "native_build": "new actual native build identity and measured DLL checked", "pixel_or_interactive_check": "not run", "formal_performance_acceptance": "paused"}}
    source_check = {**common, "source_snapshots": [before_proof, after_proof], "configured_changed_files": sorted(PRODUCTION_CHANGES),
                    "measured_production_changes": changes, "native_platform_changed": True, "other_engine_and_runtime_dependencies_equal": True,
                    "native_build": native_build, "environment": environment,
                    "inline_diagnostic_proofs": [{"run": row["run"], "kind": row["kind"], "side": row["side"], **row["source_proof"]} for row in light],
                    "counter_semantics": counter_semantics, "final_binary_hashes_are_auxiliary": True,
                    "delivery_workspace_matches_measured_after_source_and_native": True,
                    "all_instance_wrappers_run": False, "root_full_windows_run": False,
                    "packaging": "Each archive member is reread and size/SHA-256 verified before publishing."}
    attribution = REPO / "docs/reports/2026-10-22-step-attribution.md"
    if attribution.exists():
        archive.add(attribution, "prior-attribution-context")
        source_check["prior_attribution_context"] = {"path": relative(attribution), "sha256": sha(attribution), "role": "Context only; not a current-round measurement"}
    archive.add(CONFIG_PATH, "delivery-configuration")
    for name in ("run.py", "sections.py", "summarize.py"):
        if (ROOT / name).exists():
            archive.add(ROOT / name, "investigation-script")
    for name in CONFIG.get("diagnostic_scripts", []):
        archive.add(resolve(name), "actual-diagnostic-generator-script")
    for steps, input_name in WINDOWS.values():
        archive.add(INPUTS / input_name, "original-fixed-input-binary")
    return dict(zip(OUTPUTS[:4], (quick, functions, functional, source_check)))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--replace", action="store_true", help="Replace only the six derived outputs after successful complete verification; raw evidence is always read-only.")
    args = parser.parse_args()
    load_config()
    require(OUT.resolve().is_relative_to(REPO), "Output escaped repository")
    if not args.replace:
        require(not any((OUT / name).exists() for name in OUTPUTS), "Derived outputs already exist; use --replace only for an intentional derived-output regeneration.")
    staging = OUT.parent / (".ordinary-step-evidence-staging-" + uuid.uuid4().hex)
    staging.mkdir(parents=True)
    archive = Archive()
    try:
        summaries = build_summaries(archive)
        for name, value in summaries.items():
            target = staging / name
            target.write_bytes(encoded(value))
            archive.virtual((OUT / name).relative_to(REPO).as_posix(), target.read_bytes(), "derived-summary")
        manifest = archive.write_and_verify(staging / "raw-evidence.zip")
        manifest["generated_at_utc"] = datetime.now(timezone.utc).isoformat()
        (staging / "raw-manifest.json").write_bytes(encoded(manifest))
        OUT.mkdir(parents=True, exist_ok=True)
        if not args.replace:
            require(not any((OUT / name).exists() for name in OUTPUTS), "Output appeared during verification; staged evidence preserved.")
        for name in OUTPUTS:
            os.replace(staging / name, OUT / name)
        staging.rmdir()
        print(json.dumps({"output": str(OUT), "files": list(OUTPUTS), "archive_members": manifest["member_count"],
                          "archive_size": manifest["archive_size"], "archive_sha256": manifest["archive_sha256"],
                          "diagnostic_only": True, "formal_pass": False}, ensure_ascii=False))
    except Exception:
        print("Evidence verification failed. Original evidence was not changed. Staging retained: " + str(staging), file=sys.stderr)
        raise


if __name__ == "__main__":
    main()
