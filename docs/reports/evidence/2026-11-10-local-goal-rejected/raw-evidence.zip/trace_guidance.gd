extends SceneTree

class ObserveMovement extends HospitalMovement:
	var contacts: Dictionary={}
	func _init(geometry: HospitalSpace) -> void: super(geometry)
	func _local_collision(world: WorldState, actor: Dictionary, movement: Dictionary, contact: MotionResult) -> void:
		var row: Dictionary={"position":actor.location.cell.duplicate(),"before":movement.get("local_move",{}).duplicate(true),"blockers":contact.blocker_actor_ids.duplicate(),"static":contact.static_reason,"motion":[contact.requested_motion.x,contact.requested_motion.y]}
		super._local_collision(world,actor,movement,contact)
		row.after=movement.get("local_move",{}).duplicate(true)
		contacts[actor.id]=row

func _initialize() -> void: call_deferred("_run")

func _run() -> void:
	var args: PackedStringArray=OS.get_cmdline_user_args()
	var envelope: Dictionary=FileAccess.open(args[1],FileAccess.READ).get_var(false)
	var content:=HospitalContent.new()
	var world:=WorldState.new(envelope.facts)
	var sim:=HospitalSimulation.new(world,content)
	var observer:=ObserveMovement.new(sim.space)
	sim.space.movement=observer
	var initial_validation: String=world.validate(content)
	var initial: Dictionary=world.freeze()
	var traces: Array=[]
	var errors: Array=[]
	var goal_changes: Array=[]
	for tick: int in 400:
		observer.contacts.clear()
		var result: TickResult=sim.step()
		if result==null: errors.append("incomplete step");break
		var actors: Dictionary={}
		for visit_id: String in initial.floor_guidance.visits:
			var visit: Dictionary=initial.visits.get(visit_id,{})
			var id: String=str(visit.get("actor_id",""))
			if id.is_empty() or not world.facts.actors.has(id): continue
			var actor: Dictionary=world.facts.actors[id]
			var move: Dictionary=world.facts.moves.get(id,{})
			var guide: Dictionary=world.facts.floor_guidance.visits.get(visit_id,{})
			actors[id]={"location":actor.location.duplicate(true),"cursor":move.get("cursor",-1),"local":move.get("local_move",{}).duplicate(true),"goal":move.get("target_cell",[]).duplicate(),"sequence":move.get("request_sequence",-1),"guide":guide.get("phase",""),"reason":world.facts.visits[visit_id].get("waiting_reason",""),"contact":observer.contacts.get(id,{}).duplicate(true)}
		traces.append({"tick":world.sim_tick,"actors":actors})
		if tick%50==0:
			print("TRACE ",tick," tick=",world.sim_tick)
			var validation: String=world.validate(content)
			if not validation.is_empty(): errors.append(validation);break
	var final_validation: String=world.validate(content)
	FileAccess.open(args[0],FileAccess.WRITE).store_string(JSON.stringify({"scope":"400 real full simulation steps from retained terminal; diagnostic, not performance sample","input_sha256":FileAccess.get_sha256(args[1]),"initial_validation":initial_validation,"final_validation":final_validation,"errors":errors,"initial":initial,"final":world.freeze(),"traces":traces},"\t"))
	print("TRACE_COMPLETE ",traces.size()," errors=",errors)
	sim.dispose()
	quit(0 if initial_validation.is_empty() and final_validation.is_empty() and errors.is_empty() else 1)
