"""Run selected functional groups serially with isolated Godot user data."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

parser = argparse.ArgumentParser()
parser.add_argument('output', type=Path)
parser.add_argument('script')
parser.add_argument('--acceptance', action='store_true')
parser.add_argument('cases', nargs='*')
args, extra = parser.parse_known_args()
args.cases += extra
root = Path.cwd()
out = args.output.resolve()
out.mkdir(parents=True, exist_ok=False)
environment = dict(os.environ)
for key, name in [('APPDATA', 'roaming'), ('LOCALAPPDATA', 'local')]:
    environment[key] = str(out / 'runtime' / name)
    Path(environment[key]).mkdir(parents=True)
engine = r'C:\code\loyayz\oddly-good-hospital\.cache\ordinary-tail-2d65f93-20261022\engine\Godot_v4.7.2-stable_win64_console.exe'
acceptance = root / 'acceptance-results.json'
if args.acceptance:
    assert not acceptance.exists()
command = [engine, '--headless', '--path', str(root), '--script', args.script,
           '--', *([] if args.acceptance else [str(out / 'result.json')]), *args.cases]
identity = {
    'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'engine_sha256': hashlib.file_digest(Path(engine).open('rb'), 'sha256').hexdigest(),
    'source_sha256': {str(p): hashlib.sha256(p.read_bytes()).hexdigest()
                      for folder in ['game', 'tests/acceptance']
                      for p in sorted(Path(folder).rglob('*.gd'))},
}
(out / 'source-identity.json').write_text(json.dumps(identity, indent=2), encoding='utf-8')
(out / 'source.patch').write_bytes(subprocess.check_output(['git', 'diff', 'HEAD', '--']))
started = time.perf_counter()
reason = ''
with (out / 'run.log').open('w', encoding='utf-8') as log:
    process = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT,
                               env=environment, creationflags=subprocess.CREATE_NO_WINDOW)
    try:
        while process.poll() is None:
            time.sleep(1)
            messages = (out / 'run.log').read_text(encoding='utf-8')
            if 'SCRIPT ERROR:' in messages or any(line.startswith('ERROR:') for line in messages.splitlines()):
                reason = 'script/engine error'
                process.terminate()
                break
            if time.perf_counter() - started > 600:
                reason = 'timeout'
                process.terminate()
                break
        process.wait(timeout=10)
    finally:
        if process.poll() is None:
            process.kill()
status = {'command': command, 'returncode': process.returncode,
          'seconds': time.perf_counter() - started, 'reason': reason}
if args.acceptance and acceptance.exists():
    acceptance.rename(out / 'result.json')
(out / 'status.json').write_text(json.dumps(status, indent=2), encoding='utf-8')
print(json.dumps(status), flush=True)
if (out / 'result.json').exists():
    result = json.loads((out / 'result.json').read_text(encoding='utf-8-sig'))
    print(json.dumps({'ok': result.get('ok'), 'groups': list(result.get('groups', {})),
                      'completed': result.get('completed'), 'failed': result.get('failed'),
                      'cases': [{k: row[k] for k in ['case', 'ok', 'checks', 'arrived', 'error'] if k in row}
                                for row in result.get('cases', [])]}, ensure_ascii=False))
print((out / 'run.log').read_text(encoding='utf-8')[-600:])
raise SystemExit(process.returncode if process.returncode else (1 if reason else 0))
