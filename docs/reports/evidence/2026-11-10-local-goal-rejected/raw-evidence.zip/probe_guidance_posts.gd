extends SceneTree
func _initialize() -> void:call_deferred("_run")
func _run() -> void:
	var args: PackedStringArray=OS.get_cmdline_user_args()
	var envelope: Dictionary=FileAccess.open(args[1],FileAccess.READ).get_var(false)
	var content:=HospitalContent.new()
	var world:=WorldState.new(envelope.facts)
	var sim:=HospitalSimulation.new(world,content)
	var before: Dictionary=world.freeze()
	var rows: Array=[]
	for id: String in world.facts.floor_guidance.visits:
		var guide: Dictionary=world.facts.floor_guidance.visits[id]
		if guide.phase!="desk_queue":continue
		var visit: Dictionary=world.facts.visits[id]
		var actor: Dictionary=world.facts.actors[visit.actor_id]
		var desk: Dictionary=world.facts.floor_guidance.desks[guide.desk_id]
		var nurse: String=str(desk.get("nurse_id",""))
		var quote: Dictionary=sim.space.facility_quote(world,guide.desk_id,visit.actor_id,[nurse])
		var geometry: Dictionary=sim.space.facility_geometry_quote(world,guide.desk_id,visit.actor_id,[nurse])
		var layout: Dictionary=sim.space.facility_layout(world,guide.desk_id)
		var point: Vector2=ConvoyTrail.point(layout.patient_cell)
		var post:=Rect2(point,Vector2.ONE*sim.space.clearance(actor))
		sim.space._ensure_actor_index(world)
		var near: Array=[]
		for other_id: String in sim.space._actor_index.candidates(int(actor.location.floor_id),post.grow(1.0),[actor.id,nurse]):
			var move: Dictionary=world.facts.moves.get(other_id,{})
			var other: Dictionary=world.facts.actors[other_id]
			near.append({"id":other_id,"cell":other.location.cell,"post_overlap":post.intersects(sim.space._actor_index.rectangle(other_id),false),"goal":move.get("target_cell",[]),"waiting":move.get("waiting_reason",""),"local":move.get("local_move",{})})
		rows.append({"visit":id,"actor":actor.id,"desk":guide.desk_id,"visit_waiting_reason":visit.get("waiting_reason",""),"quote":quote,"geometry":geometry,"layout":layout,"post":[post.position.x,post.position.y,post.size.x,post.size.y],"nearby":near})
	var unchanged: bool=world.freeze()==before
	FileAccess.open(args[0],FileAccess.WRITE).store_string(JSON.stringify({"scope":"Zero simulation steps; readonly actual post quotes and local indexed bodies","source_input":args[1],"facts_unchanged":unchanged,"validation":world.validate(content),"rows":rows},"\t"))
	print("POST_PROBE rows=",rows.size()," unchanged=",unchanged)
	sim.dispose();quit(0 if unchanged else 1)
