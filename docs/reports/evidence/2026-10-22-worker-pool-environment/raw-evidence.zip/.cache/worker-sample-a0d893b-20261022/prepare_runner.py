from pathlib import Path
import hashlib
import json
import shutil

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT/'experiment-project'
source = PROJECT/'tools/performance/representative.gd'
original = source.read_bytes()
text = original.decode('utf-8')
newline = '\r\n' if '\r\n' in text else '\n'
replacements = []

def change(old, new):
    global text
    old, new = old.replace('\n',newline),new.replace('\n',newline)
    assert text.count(old)==1
    text = text.replace(old,new,1)
    replacements.append(dict(original=old,generated=new))

change('\tvar ops: RefCounted = Operations.new()\n',
    '\tclinical.simulation.services.departments.sample_workers_enabled = str(options.get("workers","off"))=="on"\n'
    '\tclinical.simulation.services.departments.sample_worker_tasks = int(options.get("worker-tasks","4"))\n'
    '\tclinical.simulation.services.departments.sample_worker_diagnostics = str(options.get("worker-diagnostics","false"))=="true"\n'
    '\tvar ops: RefCounted = Operations.new()\n')
change('\treport.final = clinical.inspect(true)\n',
    '\treport.worker_sample = clinical.simulation.services.departments.sample_worker_report()\n'
    '\treport.final = clinical.inspect(true)\n')
change('\t\tvar observation: Dictionary = clinical.observe(result)\n',
    '\t\tif str(options.get("worker-records","false"))=="true" and clinical.simulation.services.departments._worker_sample_batch!=null:\n'
    '\t\t\treport.get_or_add("worker_sample_step_records",[]).append({"tick":result.sim_tick,"batch":clinical.simulation.services.departments._worker_sample_batch._last.duplicate(true)})\n'
    '\t\tvar observation: Dictionary = clinical.observe(result)\n')
generated = text.encode('utf-8')
restored = text
for row in reversed(replacements):
    assert restored.count(row['generated'])==1
    restored=restored.replace(row['generated'],row['original'],1)
assert restored.encode('utf-8') == original
target = source.with_name('representative_worker.gd')
if target.exists():
    old_copy = ROOT/'representative_worker-trial01.gd'
    assert not old_copy.exists()
    shutil.copy2(target,old_copy)
    shutil.copy2(ROOT/'runner-proof.json',ROOT/'runner-proof-trial01.json')
target.write_bytes(generated)
proof = dict(path=str(target.relative_to(PROJECT)), original_sha256=hashlib.sha256(original).hexdigest(),
    generated_sha256=hashlib.sha256(generated).hexdigest(), replacements=replacements,
    inverse_byte_equal=True, initialization_or_warming_outside_step=False,
    no_business_or_measurement_window_changes=True)
(ROOT/'runner-proof.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(proof,ensure_ascii=False))
