from __future__ import annotations

import hashlib
import json
from pathlib import Path
import shutil
import subprocess


ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
SOURCE = REPO / ".cache/wait-signature-031e1f7-20261022/after-project"
PROJECT = ROOT / "experiment-project"


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def prepare():
    assert not PROJECT.exists(), "Retain every prepared experiment; do not overwrite"
    original_files = {}
    identities = {}
    for relative in ("game/operations/environment_service.gd", "game/operations/department_service.gd"):
        original = (SOURCE / relative).read_bytes()
        commits = {}
        for ref in ("d5f048e", "a0d893b"):
            commit = subprocess.check_output(["git", "rev-parse", ref], cwd=REPO).decode().strip()
            raw = subprocess.check_output(["git", "show", commit + ":" + relative], cwd=REPO)
            assert raw == original and (REPO / relative).read_bytes() == original
            commits[commit] = sha(raw)
        original_files[relative] = original
        identities[relative] = commits
    shutil.copytree(SOURCE, PROJECT)
    proofs = []
    for relative, original in original_files.items():
        text = original.decode("utf-8")
        nl = "\r\n" if "\r\n" in text else "\n"
        replacements = []

        def change(old, new):
            nonlocal text
            old = old.replace("\n", nl)
            new = new.replace("\n", nl)
            assert text.count(old) == 1, (relative, old)
            text = text.replace(old, new, 1)
            replacements.append({"original": old, "generated": new})

        if relative.endswith("environment_service.gd"):
            old = '\tresult.value = clampi(int(result.value)-int(result.noise),0,100)\n\tresult.status = "current"\n\treturn result\n'
            new = '\treturn _finish_observation(result)\n\nfunc _finish_observation(result: Dictionary) -> Dictionary:\n' + old
            change(old, new)
        else:
            change('var _worked: Dictionary = {}\n', 'var _worked: Dictionary = {}\nvar sample_workers_enabled: bool = false\nvar sample_worker_tasks: int = 4\nvar sample_worker_diagnostics: bool = false\nvar _worker_sample_batch: RefCounted\n')
            old = '\tif environment!=null: environment.begin_query(world)\n\tfor visit_id: String in world.active_visit_ids():\n'
            new = '\tif environment!=null: environment.begin_query(world)\n\tvar _worker_visit_ids: Array = world.active_visit_ids()\n\tvar _worker_sample_active: bool = sample_workers_enabled and environment!=null and environment.get_script()==preload("res://game/operations/environment_service.gd")\n\tif _worker_sample_active:\n\t\tif _worker_sample_batch==null: _worker_sample_batch = preload("res://tools/performance/worker_sample_batch.gd").new()\n\t\t_worker_sample_active = _worker_sample_batch.prepare(world,environment,_worker_visit_ids,sample_worker_tasks,sample_worker_diagnostics)\n\t\tif _worker_sample_active: _worker_sample_batch.begin_apply()\n\tfor visit_id: String in _worker_visit_ids:\n'
            change(old, new)
            change('\t\t\tobservation = _environment(world,visit.actor_id,int(actor.location.floor_id),actor.location.cell)\n', '\t\t\tobservation = _worker_sample_batch.consume(world,environment,visit_id,str(visit.actor_id)) if _worker_sample_active else _environment(world,visit.actor_id,int(actor.location.floor_id),actor.location.cell)\n')
            change('\tif environment!=null: environment.end_query()\n\tfor staff_id: String in world.ids("staff"):\n', '\tif _worker_sample_active: _worker_sample_batch.end_apply(environment)\n\tif environment!=null: environment.end_query()\n\tfor staff_id: String in world.ids("staff"):\n')
            change('func _environment(world: WorldState, actor_id: String, floor_id: int, cell: Array) -> Dictionary:\n', 'func sample_worker_report() -> Dictionary:\n\treturn _worker_sample_batch.report() if _worker_sample_batch!=null else {"batches":0,"jobs":0,"processed":0,"consumed":0,"failed_batches":0,"threads":{}}\n\nfunc _environment(world: WorldState, actor_id: String, floor_id: int, cell: Array) -> Dictionary:\n')
        generated = text.encode("utf-8")
        reverse = text
        for row in reversed(replacements):
            assert reverse.count(row["generated"]) == 1
            reverse = reverse.replace(row["generated"], row["original"], 1)
        assert reverse.encode("utf-8") == original
        (PROJECT / relative).write_bytes(generated)
        proofs.append({"path": relative, "original_sha256": sha(original), "generated_sha256": sha(generated), "committed_original_sha256": identities[relative], "inverse_byte_equal": True, "replacements": replacements})
    helper = "tools/performance/worker_sample_batch.gd"
    shutil.copy2(ROOT / "worker_sample_batch.gd", PROJECT / helper)
    proof = {"diagnostic_only": True, "formal_pass": False, "engine_started": False, "source_project": str(SOURCE), "project": str(PROJECT), "files": proofs, "added_helper": {"path": helper, "sha256": sha((PROJECT / helper).read_bytes())}, "switches": {"sample_workers_enabled": False, "sample_worker_tasks": 4, "sample_worker_diagnostics": False}, "report": "departments.sample_worker_report()", "references": ["https://docs.godotengine.org/en/stable/classes/class_workerthreadpool.html", "https://docs.godotengine.org/en/stable/tutorials/performance/thread_safe_apis.html"]}
    (ROOT / "source-proof.json").write_text(json.dumps(proof, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps({"project": str(PROJECT), "proof": str(ROOT / "source-proof.json"), "engine_started": False}, ensure_ascii=False))


if __name__ == "__main__":
    prepare()
