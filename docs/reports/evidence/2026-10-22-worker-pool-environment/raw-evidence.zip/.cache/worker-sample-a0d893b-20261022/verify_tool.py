from pathlib import Path
import hashlib
import importlib.util
import json
import shutil
import sys

sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
REPO=ROOT.parents[1]
script=REPO/'tools/performance/experiments/worker_sample_experiment.py'
spec=importlib.util.spec_from_file_location('worker_experiment',script)
module=importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
assert module.REPO==REPO
target=ROOT/'tool-verification-project'
assert not target.exists()
for relative in ['project.godot','game/operations/environment_service.gd','game/operations/department_service.gd','tools/performance/representative.gd','tests/acceptance/growth.gd']:
    output=target/relative
    output.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(REPO/relative,output)
result=module.prepare(target,True)
rows=[]
for relative in ['game/operations/environment_service.gd','game/operations/department_service.gd','tools/performance/representative_worker.gd','tools/performance/worker_sample_batch.gd','tests/acceptance/growth.gd','tests/acceptance/worker_sample_checks.gd']:
    raw=(target/relative).read_bytes()
    assert raw==(ROOT/'experiment-project'/relative).read_bytes(),relative
    rows.append(dict(path=relative,sha256=hashlib.sha256(raw).hexdigest(),actual_byte_equal_measured_or_functional_copy=True))
snapshots={path:path.read_bytes() for path in target.rglob('*') if path.is_file()}
try:
    module.prepare(target,True)
except ValueError:
    rejected_existing=True
else:
    raise AssertionError('Existing experiment must not be overwritten')
assert all(path.read_bytes()==raw for path,raw in snapshots.items())
try:
    module.prepare(REPO,False)
except ValueError:
    rejected_repository=True
else:
    raise AssertionError('Production repository must be rejected')
output=dict(diagnostic_only=True,formal_pass=False,engine_started=False,
    generated_files=rows,installed=result,
    production_repository_rejected_before_writes=rejected_repository,
    existing_experiment_rejected_without_file_changes=rejected_existing,
    note='Only relocation/generation was checked; byte-identical game and helper sources reuse the measured windows and selected functional checks.')
(ROOT/'tool-verification.json').write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(generated_files=len(rows),byte_equal=True,repository_rejected=True,existing_experiment_rejected=True,engine_started=False)))
