from pathlib import Path
import hashlib
import importlib.util
import json
import shutil

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
PROJECT = ROOT/'experiment-project'
assert PROJECT.resolve()==(REPO/'.cache/worker-sample-a0d893b-20261022/experiment-project').resolve()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
write = lambda path, value: path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
existing = PROJECT/'acceptance-results.json'
shutil.copy2(existing,ROOT/'checks-01.acceptance-results.json')
backup = ROOT/'baseline-check-backup'
backup.mkdir()
paths = ['game/operations/environment_service.gd','game/operations/department_service.gd','tests/acceptance/growth.gd']
saved = {}
proof = []
for relative in paths:
    raw = (PROJECT/relative).read_bytes()
    saved[relative]=raw
    target = backup/relative
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(raw)
try:
    for relative in paths:
        raw = (REPO/relative).read_bytes()
        (PROJECT/relative).write_bytes(raw)
        proof.append(dict(path=relative,baseline_actual_sha256=sha(raw),worker_before_sha256=sha(saved[relative])))
    growth = PROJECT/paths[-1]
    before = growth.read_bytes()
    old = b'"calls":observation.calls,"sampled_coverages":sampled_coverages'
    new = b'"calls":observation.calls,"sample_calls":observation.sample_calls,"sampled_coverages":sampled_coverages'
    assert before.count(old)==1
    diagnostic=before.replace(old,new,1)
    assert diagnostic.replace(new,old,1)==before
    growth.write_bytes(diagnostic)
    write(ROOT/'baseline-checks.source-check.json',dict(
        original_game_actual_byte_equal_workspace=True,diagnostic_only=True,formal_pass=False,
        files=proof,original_assertions_unchanged=True,
        growth_metadata_only=dict(original=old.decode(),generated=new.decode(),inverse_byte_equal=True,
            baseline_sha256=sha(before),diagnostic_sha256=sha(diagnostic))))
    spec=importlib.util.spec_from_file_location('launcher',REPO/'.cache/wait-signature-031e1f7-20261022/run.py')
    launcher=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(launcher)
    launcher.ROOT=ROOT
    caught=None
    try:
        launcher.launch(['--headless','--path',PROJECT,'--script','res://tests/acceptance/runner.gd','--','growth','--case=GROW-72','--case=GROW-75'],ROOT/'baseline-checks')
    except RuntimeError as error:
        caught=str(error)
    shutil.copy2(existing,ROOT/'baseline-checks.acceptance-results.json')
    actual=json.loads(existing.read_text(encoding='utf-8-sig'))
    assert actual['completed'] and actual['checks']==2
    assert actual['results']['GROW-75']['passed']
    row=actual['results']['GROW-72']
    assert not row['passed'] and row['details']['sample_calls']==2 and row['details']['calls']==3
    assert all(row['details'][key] for key in ['injected','sampling_equal','readonly'])
    write(ROOT/'baseline-checks.reproduction.json',dict(
        original_game_grow72_failure_reproduced=True,expected_assertion_failure=True,
        retained_original_grow75_pass=True,recorded_launcher_failure=caught,
        grow72=row,rule='One explicit sample_at plus the real arrival environment score each samples once; environment_at is the third total observation.'))
    print(json.dumps(dict(original_game_grow72_failure_reproduced=True,sample_calls=row['details']['sample_calls'],grow75_pass=True)))
finally:
    restored=[]
    for relative,raw in saved.items():
        (PROJECT/relative).write_bytes(raw)
        assert (PROJECT/relative).read_bytes()==raw
        restored.append(dict(path=relative,sha256=sha(raw)))
    write(ROOT/'baseline-checks.restore-proof.json',dict(restored_exact_worker_project=True,files=restored))
