from pathlib import Path
import hashlib
import json
import shutil

ROOT=Path(__file__).resolve().parent
REPO=ROOT.parents[1]
PROJECT=ROOT/'experiment-project'
read=lambda path:json.loads(Path(path).read_text(encoding='utf-8-sig'))
sha=lambda raw:hashlib.sha256(raw).hexdigest()
proof=read(REPO/'.cache/worker-sample-checks-hook.json')
helper=REPO/'.cache/worker-sample-checks.gd'
target=PROJECT/proof['added_helper']['target']
shutil.copy2(target,ROOT/'checks-helper-attempt01.gd')
assert sha(helper.read_bytes())==proof['added_helper']['sha256']
shutil.copy2(helper,target)
source=REPO/proof['modified_source']
original=source.read_bytes()
assert sha(original)==proof['original_sha256']
old=proof['replacement']['original'].encode('utf-8')
new=proof['replacement']['generated'].encode('utf-8')
assert original.count(old)==1
generated=original.replace(old,new,1)
assert sha(generated)==proof['generated_sha256'] and generated.replace(new,old,1)==original
growth=PROJECT/proof['modified_source']
shutil.copy2(growth,ROOT/'checks-growth-attempt01.gd')
growth.write_bytes(generated)
record=dict(diagnostic_only=True,formal_pass=False,
    baseline_original_game_failure='baseline-checks.reproduction.json',
    exact_grow72_calls_assertion_corrected_to_2=True,business_rules_unchanged=True,
    helper_fixture_uses_existing_legal_admission=True,helper_expected_water_predicates_unchanged=True,
    production_growth_sha256=sha(original),generated_growth_sha256=sha(generated),
    helper_sha256=sha(helper.read_bytes()),hook=proof,
    reused_passed_cases=['STAFF-32','OPS-11','OPS-18'],selected=['GROW-72','GROW-75'])
(ROOT/'checks-02.source-check.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in record.items() if k!='hook'}))
