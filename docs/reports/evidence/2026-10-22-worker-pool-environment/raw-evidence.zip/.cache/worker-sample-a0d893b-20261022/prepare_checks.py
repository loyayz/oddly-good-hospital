from pathlib import Path
import hashlib
import json
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
PROJECT = ROOT/'experiment-project'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
read = lambda path: json.loads(Path(path).read_text(encoding='utf-8-sig'))
assert not (ROOT/'checks-source-proof.json').exists()
rows = []
replaced_uid_metadata = []
checkout_line_endings = []
paths = subprocess.check_output(['git','ls-files','tests'],cwd=REPO,text=True).splitlines()
for relative in paths:
    path = PROJECT/relative
    path.parent.mkdir(parents=True,exist_ok=True)
    if path.exists():
        if path.read_bytes()!=(REPO/relative).read_bytes():
            assert relative.endswith('.uid'), relative
            replaced_uid_metadata.append(dict(path=relative,prepared_sha256=sha(path.read_bytes()),test_source_sha256=sha((REPO/relative).read_bytes())))
            shutil.copy2(REPO/relative,path)
    else:
        shutil.copy2(REPO/relative,path)
    raw = path.read_bytes()
    committed = subprocess.check_output(['git','show','a0d893b:'+relative],cwd=REPO)
    if raw != committed:
        assert raw.replace(b'\r\n',b'\n') == committed.replace(b'\r\n',b'\n'), relative
        checkout_line_endings.append(dict(path=relative,actual_sha256=sha(raw),git_blob_sha256=sha(committed),normalized_line_endings_equal=True))
    rows.append(dict(path=relative,sha256=sha(raw)))
proof = read(REPO/'.cache/worker-sample-checks-hook.json')
helper = REPO/'.cache/worker-sample-checks.gd'
assert sha(helper.read_bytes())==proof['added_helper']['sha256']
shutil.copy2(helper,PROJECT/proof['added_helper']['target'])
target = PROJECT/proof['modified_source']
original = target.read_bytes()
before = proof['replacement']['original'].encode('utf-8')
after = proof['replacement']['generated'].encode('utf-8')
assert sha(original)==proof['original_sha256'] and original.count(before)==1
generated=original.replace(before,after,1)
assert sha(generated)==proof['generated_sha256']
assert generated.replace(after,before,1)==original
target.write_bytes(generated)
result=dict(diagnostic_only=True,formal_pass=False,
    test_sources=rows,hook=proof,selected=['GROW-75','GROW-72','OPS-11','OPS-18','STAFF-32'],
    cases_reason='Same environmental values, live subject water permission, real noise/wall/screen, and anger handoff; Worker path has additional finite GROW-75 controls.',
    no_fixture_rebuild_requested=True,no_engine_started=True,
    actual_original_test_sources_equal_current_workspace=True,
    test_logic_equal_a0_with_listed_checkout_line_endings=True)
result['replaced_cached_uid_metadata'] = replaced_uid_metadata
result['checkout_line_endings'] = checkout_line_endings
(ROOT/'checks-source-proof.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(test_sources=len(rows),selected=result['selected'],inverse_byte_equal=True)))
