from pathlib import Path
import hashlib
import json
import shutil
import subprocess

ROOT=Path(__file__).resolve().parent
REPO=ROOT.parents[1]
PROJECT=ROOT/'production-project'
rows=[]
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','tests'],cwd=REPO,text=True).splitlines()
for relative in sorted(set(paths)):
    source=REPO/relative
    if not source.is_file(): continue
    target=PROJECT/relative
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(source,target)
    assert target.read_bytes()==source.read_bytes()
    rows.append(dict(path=relative,sha256=hashlib.sha256(source.read_bytes()).hexdigest()))
assert 'tests/acceptance/worker_sample_checks.gd' in [x['path'] for x in rows]
proof=dict(diagnostic_only=True,formal_pass=False,actual_test_sources=rows,
    no_generated_hook=True,normal_current_grow75_includes_real_default_worker_checks=True,
    selected=['GROW-72','GROW-75'],reused_unchanged_interface_passes=['OPS-11','OPS-18','STAFF-32'],
    source_scope='Production game remains the measured 485-row snapshot. Current normal acceptance sources are copied byte equal; no runtime service cache or hospital is restored.')
(ROOT/'functional-final.source-check.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(test_sources=len(rows),selected=proof['selected'],normal_production_cases=True)))
