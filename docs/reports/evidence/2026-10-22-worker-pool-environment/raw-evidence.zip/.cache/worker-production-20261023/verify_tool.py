from pathlib import Path
import importlib.util
import json
import shutil
import sys

sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
REPO=ROOT.parents[1]
spec=importlib.util.spec_from_file_location('tool',REPO/'tools/performance/experiments/worker_sample_experiment.py')
tool=importlib.util.module_from_spec(spec)
spec.loader.exec_module(tool)
assert tool.REPO==REPO
target=ROOT/'tool-verification-project'
assert not target.exists()
for relative in ['project.godot','game/operations/environment_sample_batch.gd','tools/performance/representative.gd']:
    destination=target/relative
    destination.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(REPO/relative,destination)
installed=tool.prepare(target)
relative='tools/performance/representative_worker.gd'
assert (target/relative).read_bytes()==(ROOT/'production-project'/relative).read_bytes()
before={path:path.read_bytes() for path in target.rglob('*') if path.is_file()}
try:
    tool.prepare(target)
except ValueError:
    rejected_existing=True
else:
    raise AssertionError('Must reject an installed copy')
assert all(path.read_bytes()==raw for path,raw in before.items())
try:
    tool.prepare(REPO)
except ValueError:
    rejected_repository=True
else:
    raise AssertionError('Must reject the production repository')
result=dict(diagnostic_only=True,formal_pass=False,engine_started=False,
    generated_runner_byte_equal_actual_measured_production=True,
    installed=installed,existing_experiment_rejected_without_changes=rejected_existing,
    current_repository_rejected_before_writes=rejected_repository,
    production_game_and_normal_grow75_are_not_modified_by_tool=True)
(ROOT/'tool-verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result))
