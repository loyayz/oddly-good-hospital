"""Freeze existing Worker evidence. No engine/build/test invocation is made."""
from __future__ import annotations
from collections import Counter
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import time
import uuid

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
OLD = REPO / '.cache/worker-sample-a0d893b-20261022'
WHOLE = REPO / '.cache/whole-stages-a0d893b-20261022'
PRIOR = REPO / '.cache/wait-signature-031e1f7-20261022'
BASE = PRIOR / 'after-project'
EXPERIMENT = OLD / 'experiment-project'
PRODUCTION = ROOT / 'production-project'
OUT = REPO / 'docs/reports/evidence/2026-10-22-worker-pool-environment'
HEAD = 'a0d893b3ca57cb7e078fbf23b09a910846d43820'
OUTPUTS = ('summary.json', 'whole-stages-summary.json', 'raw-manifest.json', 'raw-evidence.zip')
spec = importlib.util.spec_from_file_location('existing_evidence', PRIOR / 'summarize.py')
lib = importlib.util.module_from_spec(spec)
spec.loader.exec_module(lib)
read, need, encoded, digest, rel = lib.read, lib.require, lib.encoded, lib.digest, lib.relative
original_sha = lib.sha
hash_cache = {}


def sha(path):
    path = Path(path).resolve()
    before = path.stat()
    key = (path, before.st_size, before.st_mtime_ns)
    if key not in hash_cache:
        hash_cache[key] = original_sha(path)
        after = path.stat()
        need((before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns), (path, 'Changed while hashing'))
    return hash_cache[key]


lib.sha = sha


def reference(path):
    return {'path': rel(path), 'size': path.stat().st_size, 'sha256': sha(path)}


def undo(raw, changes, original_key, generated_key):
    text = raw.decode('utf-8')
    for row in reversed(changes):
        need(text.count(row[generated_key]) == 1, ('Inverse token not unique', row[generated_key][:100]))
        text = text.replace(row[generated_key], row[original_key], 1)
    return text.encode('utf-8')


def source_verification(archive):
    identity = read(BASE / 'source-identity.json')
    old_rows = lib.identity_rows(identity)
    need(len(old_rows) == 484, 'Expected original 484-row inventory')
    originals = lib.git_blobs(HEAD, list(old_rows))
    integration = read(OLD / 'production-integration-proof.json')
    changed = {r['path']: r for r in integration['files']}
    production_identity = read(ROOT / 'production-source-identity.json')
    current = {r['path']: r['sha256'] for r in production_identity['production_sources']}
    recorded_current = dict(current)
    configs = {r['path']: r['prepared_sha256'] for r in production_identity['prepared_configurations']}
    for row in production_identity['prepared_configurations']:
        need(current[row['path']] == row['prepared_sha256'], 'Unexpected prepared configuration identity')
        current[row['path']] = row['production_sha256']
    need(len(current) == 485 and set(current) - set(old_rows) == {'game/operations/environment_sample_batch.gd'}, 'Wrong production inventory')
    need({p for p in old_rows if current[p] != old_rows[p]} == set(changed), 'Unexpected production game changes')
    checked = []
    for path, expected in old_rows.items():
        need(digest(originals[path]) == expected, (path, 'a0 Git/source manifest differs'))
        prepared = lib.prepared_config(originals[path], path, identity)
        need(sha(BASE / path) == digest(prepared), (path, 'Frozen original differs'))
        expected_experiment = changed[path]['experiment_sha256'] if path in changed else digest(prepared)
        need(sha(EXPERIMENT / path) == expected_experiment, (path, 'Frozen experiment differs'))
        checked.append({'path': path, 'a0_original_sha256': expected, 'frozen_original_actual_sha256': sha(BASE / path),
                        'experiment_actual_sha256': sha(EXPERIMENT / path)})
    production_checked = []
    for path, expected in current.items():
        need(sha(REPO / path) == expected, (path, 'Current production source differs'))
        actual = sha(PRODUCTION / path)
        need(actual == configs.get(path, expected), (path, 'Measured production copy differs'))
        production_checked.append({'path': path, 'production_sha256': expected, 'recorded_snapshot_sha256': recorded_current[path],
                                   'actual_measured_copy_sha256': actual, 'isolated_runtime_config_rewrite': path in configs})
    inverses = []
    for path, row in changed.items():
        actual = (REPO / path).read_bytes()
        experiment = (EXPERIMENT / path).read_bytes()
        recovered_experiment = undo(actual, row['production_deltas'], 'original', 'generated')
        need(recovered_experiment == experiment and digest(experiment) == row['experiment_sha256'], (path, 'Production delta inverse failed'))
        recovered_original = undo(experiment, row['experiment_replacements'], 'original', 'generated')
        need(recovered_original == originals[path], (path, 'Original game inverse failed'))
        archive.virtual('verification-proofs/original-a0/' + path, originals[path], 'independently-recovered-original-game')
        archive.add(REPO / path, 'actual-final-production-game')
        archive.add(EXPERIMENT / path, 'actual-measured-opt-in-game')
        inverses.append({'path': path, 'actual_production_sha256': sha(REPO / path), 'actual_experiment_sha256': sha(EXPERIMENT / path),
                         'independent_production_to_experiment_to_a0_byte_inverse': True})
    helper = REPO / 'game/operations/environment_sample_batch.gd'
    recovered = undo(helper.read_bytes(), integration['helper']['production_description_deltas'], 'original', 'generated')
    need(recovered == (OLD / 'worker_sample_batch.gd').read_bytes(), 'Production helper differs beyond recorded descriptions')
    archive.add(helper, 'actual-final-production-worker-helper')
    archive.add(BASE / 'source-identity.json', 'reused-original-complete-source-manifest')
    archive.add(ROOT / 'production-source-identity.json', 'actual-final-485-source-manifest')
    dependency = lib.dependency_proof(identity, PRODUCTION, match_workspace=True)
    for item in dependency['actual_native_files']:
        path = item['path']
        need(sha(BASE / path) == sha(EXPERIMENT / path) == sha(PRODUCTION / path) == item['sha256'], (path, 'Native dependency differs'))
    native_proof = read(PRIOR / 'native-build-identity.json')
    need(native_proof['native_sha256'].lower() == identity['native_sha256'].lower(), 'Wrong reused native build')
    for row in native_proof['sources']:
        need(sha(REPO / row['path']) == row['sha256'].lower(), (row['path'], 'Reused native build source differs'))
    prior_dir = REPO / 'docs/reports/evidence/2026-10-22-wait-dependency-batch'
    prior_manifest = read(prior_dir / 'raw-manifest.json')
    for name in ['source-check.json', 'raw-manifest.json']:
        p = prior_dir / name
        need(digest(lib.git_blobs(HEAD, [rel(p)])[rel(p)]) == sha(p), (p, 'Prior source proof is not the committed document'))
    return {'original_snapshot_commit': HEAD, 'original_identity_head': identity['head'],
            'old_a0_verification_uses_frozen_snapshot_not_changed_workspace': True,
            'original_484_and_experimental_484_actual_rows': checked, 'final_485_actual_rows': production_checked,
            'independent_two_game_inverses': inverses, 'production_helper_description_inverse_to_measured_681a': True,
            'actual_engine_and_native_dependencies': dependency, 'reused_native_build_identity': reference(PRIOR / 'native-build-identity.json'),
            'native_build_sources_rechecked': len(native_proof['sources']), 'native_build_this_round': False,
            'reused_complete_original_source_archive': {'directory': rel(prior_dir), 'archive_sha256': prior_manifest['archive_sha256'],
                                                      'source_check': reference(prior_dir / 'source-check.json'), 'manifest': reference(prior_dir / 'raw-manifest.json')},
            'complete_original_snapshot_payload_not_repackaged': True}


def main():
    started = time.perf_counter()
    need(not any((OUT / name).exists() for name in OUTPUTS), 'Refusing to overwrite existing final evidence')
    OUT.mkdir(parents=True, exist_ok=True)
    staging = OUT / ('.worker-freeze-' + uuid.uuid4().hex)
    staging.mkdir()
    archive = lib.Archive()
    proof = source_verification(archive)
    old_summary = read(OLD / 'summary.json')
    whole_summary = read(WHOLE / 'summary.json')
    run_sets = [(OLD, list(old_summary['runs'])), (WHOLE, list(whole_summary['runs'])),
                (ROOT, ['a3-' + w for w in lib.WINDOWS] + ['b3-' + w for w in lib.WINDOWS] + ['gp-tail-diagnostic'])]
    binary_members, aliases, measurements, all_launches = {}, [], [], []
    final_runs = {}
    for folder, names in run_sets:
        for name in names:
            path = folder / (name + '.json')
            data = read(path)
            need(data['complete'] and data['qualified'] and not data['errors'] and all(data['qualification'].values()), (path, 'Incomplete window'))
            binary = Path(str(path) + '.final.bin')
            actual_binary_sha = sha(binary)
            need(actual_binary_sha == data['final_binary_sha256'], (binary, 'Actual final binary differs'))
            if actual_binary_sha not in binary_members:
                archive.add(binary, 'deduplicated-actual-final-world-payload')
                binary_members[actual_binary_sha] = rel(binary)
            aliases.append({'path': rel(binary), 'canonical_member': binary_members[actual_binary_sha],
                            'size': binary.stat().st_size, 'actual_sha256': actual_binary_sha, 'actual_file_hash_checked': True})
            launch = read(folder / (name + '.launch.json'))
            need(launch['exit_code'] == 0 and not launch['errors'] and not launch['timed_out'], (name, 'Performance launch failed'))
            need(sha(launch['engine']) == launch['engine_sha256'].lower(), (name, 'Actual engine differs'))
            timing = {'run': name, 'cache': rel(folder), 'steps': len(data['samples']),
                      'initialization_ms': data['initialization_elapsed_us'] / 1000, 'step_ms': data['metrics']['total_us'] / 1000,
                      'engine_wall_ms': launch['wall_ms'], 'engine_cpu_ms': launch['child_cpu_ms']}
            measurements.append(timing)
            if folder == ROOT:
                reference_data = read(PRIOR / ('b-' + ('gp80' if name == 'gp-tail-diagnostic' else name.split('-', 1)[1]) + '.json'))
                business = lib.compare_semantics(reference_data, data, name)
                need([{k: v for k, v in x.items() if k != 'elapsed_us'} for x in reference_data['samples']] ==
                     [{k: v for k, v in x.items() if k != 'elapsed_us'} for x in data['samples']], (name, 'Sample semantics differ'))
                semantics = read(folder / (name + '.semantic-check.json'))
                if name != 'gp-tail-diagnostic':
                    need(semantics['passed'] and all(semantics['checks'].values()), (name, 'Semantic receipt failed'))
                else:
                    need(semantics['complete_world_and_original_counts_equal'] and semantics['all_80_worker_records_complete'], name)
                a, b = reference_data['public']['query_counts'], data['public']['query_counts']
                differences = {k: {'expected': a.get(k), 'actual': b.get(k)} for k in sorted(set(a) | set(b)) if a.get(k) != b.get(k)}
                need(all(k.startswith('diag_worker_sample_') or k == 'environment_coverage_native_calls' for k in differences), (name, 'Unexpected work counter difference'))
                worker = data.get('worker_sample')
                if worker:
                    need(worker['processed'] == worker['consumed'] and not worker['failed_batches'] and sum(worker['threads'].values()) == worker['jobs'], (name, 'Worker aggregate failed'))
                final_runs[name] = {'raw_result': reference(path), 'metrics_us': data['metrics'], 'semantic_checks': business,
                                    'all_query_count_differences': differences, 'worker': worker, 'timing': timing,
                                    'source_receipt': rel(folder / (name + '.source-check.json')), 'launch': launch}
            if 'profile' in data:
                for key, source in data['profile']['sources'].items():
                    if isinstance(source, dict) and source.get('generated_sha256'):
                        generated = folder / (name + '.json.sources') / (key + '.gd')
                        need(sha(generated) == source['generated_sha256'], (name, key, 'Generated runtime source differs'))
        for path in sorted(folder.iterdir()):
            if not path.is_file() or path.name.endswith('.final.bin') or 'bookend' in path.name.lower():
                continue
            if path.suffix not in {'.json', '.py', '.gd', '.md', '.log'} and not path.name.endswith('.ndjson'):
                continue
            if path.name.startswith('freeze-') and path.suffix == '.log' and path.stat().st_size == 0:
                continue
            archive.add(path, 'original-evidence-source-or-tool')
        for directory in sorted(folder.glob('*.sources')):
            for path in sorted(directory.rglob('*')):
                if path.is_file(): archive.add(path, 'actual-runtime-generated-profiler-source')
        for path in sorted(folder.glob('*.launch.json')):
            launch = read(path)
            need(sha(launch['engine']) == launch['engine_sha256'].lower(), (path, 'Actual launch engine differs'))
            role = 'measurement' if path.name.removesuffix('.launch.json') in names else ('import' if '--import' in launch['arguments'] else 'functional')
            all_launches.append({'path': rel(path), 'role': role, 'receipt': launch})
    for directory in [OLD / 'baseline-check-backup', OLD / 'tool-before-normal-grow75']:
        for path in sorted(directory.rglob('*')):
            if path.is_file(): archive.add(path, 'preserved-old-source-or-tool-version')
    for project in [EXPERIMENT, OLD / 'tool-verification-project', PRODUCTION, ROOT / 'tool-verification-project']:
        for name in ['worker-sample-source-proof.json', 'tools/performance/representative_worker.gd',
                     'tools/performance/worker_sample_batch.gd', 'tests/acceptance/growth.gd', 'tests/acceptance/worker_sample_checks.gd']:
            path = project / name
            if path.is_file(): archive.add(path, 'preserved-actual-runner-test-helper-or-generation-proof')
    for path in sorted((REPO / 'tools/performance/experiments').iterdir()):
        if path.is_file(): archive.add(path, 'final-opt-in-diagnostic-tool-only')
    for name in ['staff.gd', 'operations.gd', 'runner.gd', 'growth.gd', 'worker_sample_checks.gd', 'worker_sample_checks.gd.uid']:
        archive.add(REPO / 'tests/acceptance' / name, 'actual-normal-selected-test-source')
    archive.add(REPO / 'game/operations/environment_sample_batch.gd.uid', 'actual-import-generated-production-uid')
    archive.add(PRIOR / 'summarize.py', 'reused-hash-zip-and-semantic-verifier')
    for filename in ['public-v6.input.bin', 'gp.input.bin', 'op.input.bin']:
        archive.add(REPO / '.cache/task-navigation-20261019' / filename, 'original-read-only-160-actor-input')
    # The normal tests are checked against their actual measured copies, not an
    # earlier generated GROW-75 hook. Reused selected cases retain old results.
    functional = read(ROOT / 'functional-final.acceptance-results.json')
    functional_source = read(ROOT / 'functional-final.source-check.json')
    functional_semantic = read(ROOT / 'functional-final.semantic-check.json')
    need(functional['completed'] and functional['failed'] == 0 and all(v['passed'] for v in functional['results'].values()), 'Final selected checks failed')
    for row in functional_source['actual_test_sources']:
        need(sha(REPO / row['path']) == sha(PRODUCTION / row['path']) == row['sha256'], (row['path'], 'Normal measured test source differs'))
    for row in functional_semantic['generated_resource_uid_metadata']:
        need(sha(REPO / row['path']) == sha(PRODUCTION / row['path']) == row['sha256'], (row['path'], 'Actual imported UID differs'))
    initial = read(OLD / 'checks-01.acceptance-results.json')
    cases = {case: {'source': rel(OLD / 'checks-01.acceptance-results.json'), 'result': initial['results'][case], 'reused_unchanged_interface': True}
             for case in ['STAFF-32', 'OPS-11', 'OPS-18']}
    cases.update({case: {'source': rel(ROOT / 'functional-final.acceptance-results.json'), 'result': row, 'normal_final_test_entry': True}
                  for case, row in functional['results'].items()})
    need(len(cases) == 5 and all(row['result']['passed'] for row in cases.values()), 'Selected five not complete')
    worker_checks = functional['results']['GROW-75']['details']['worker_sample_checks']
    need(len(worker_checks['checks']) == 9 and all(worker_checks['checks'].values()), 'Final nine Worker checks not all true')
    installer = read(PRODUCTION / 'worker-sample-source-proof.json')
    for row in installer['files']:
        actual = (PRODUCTION / row['target']).read_bytes()
        need(digest(actual) == row['generated_sha256'], 'Final installed runner differs')
        original = undo(actual, row['replacements'], 'original', 'generated')
        need(original == (REPO / row['source']).read_bytes(), 'Final runner inverse differs')
    tool = read(ROOT / 'tool-verification.json')
    need(tool['generated_runner_byte_equal_actual_measured_production'] and tool['existing_experiment_rejected_without_changes'] and tool['current_repository_rejected_before_writes'], 'Final tool verification failed')
    need(sha(ROOT / 'tool-verification-project/tools/performance/representative_worker.gd') == installer['files'][0]['generated_sha256'], 'Verified generated runner differs')
    pairs = {}
    for window in lib.WINDOWS:
        a, b = final_runs['a3-' + window]['metrics_us'], final_runs['b3-' + window]['metrics_us']
        pairs[window] = {key: {'a3_us': a[key], 'b3_us': b[key], 'delta_percent': (b[key] / a[key] - 1) * 100}
                         for key in ['mean_us', 'p50_us', 'p95_us', 'p99_us', 'cold_first_us', 'following_mean_us', 'max_us', 'total_us']}
    diagnostic = read(ROOT / 'gp-tail-diagnostic.json')
    selected = next(i for i, row in enumerate(diagnostic['samples']) if row['tick'] == 851)
    tail = {'same_tick': 851, 'plain_b3_us': next(r['elapsed_us'] for r in read(ROOT / 'b3-gp80.json')['samples'] if r['tick'] == 851),
            'diagnostic_sample': diagnostic['samples'][selected], 'root_record': diagnostic['profile']['step_records'][selected],
            'worker_record': diagnostic['worker_sample_step_records'][selected], 'plain_difference_not_precisely_attributed': True,
            'dominant_tail_remains_dispatch_waiting': True, 'job_elapsed_overlaps_not_cpu': True}
    timing = {}
    for role in ['measurement', 'import', 'functional']:
        rows = [r for r in all_launches if r['role'] == role]
        timing[role] = {'launches': len(rows), 'engine_wall_ms': sum(r['receipt']['wall_ms'] for r in rows),
                        'engine_cpu_ms': sum(r['receipt']['child_cpu_ms'] for r in rows), 'failed_launches': [r['path'] for r in rows if r['receipt']['exit_code'] != 0]}
    timing['all_engine_launches'] = {'launches': len(all_launches), 'wall_ms': sum(r['receipt']['wall_ms'] for r in all_launches),
                                    'cpu_ms': sum(r['receipt']['child_cpu_ms'] for r in all_launches)}
    timing['ordinary_window_totals'] = {'windows': len(measurements), 'steps': sum(r['steps'] for r in measurements),
                                       'initialization_ms': sum(r['initialization_ms'] for r in measurements), 'step_ms': sum(r['step_ms'] for r in measurements),
                                       'by_run': measurements}
    timing['preparation'] = {'final_production_project_wall_ms': read(ROOT / 'production-source-identity.json')['preparation_wall_ms'],
                             'other_preparation_ms': None, 'note': 'Other preparation durations were not separately recorded. All actual preparation failure receipts are archived.'}
    result_files = list(OLD.glob('*.acceptance-results.json')) + list(ROOT.glob('*.acceptance-results.json'))
    timing['functional_runner_results'] = [{'path': rel(p), 'completed': read(p)['completed'], 'failed': read(p)['failed'], 'elapsed_ms': read(p)['elapsed_ms']} for p in result_files]
    timing['functional_runner_elapsed_total_ms'] = sum(read(p)['elapsed_ms'] for p in result_files)
    timing['nested_timing_note'] = 'Input initialization, ordinary steps and runner test time are within engine wall. Do not add these categories to wall or treat overlapping worker elapsed spans as CPU.'
    summary = {'schema_version': 1, 'diagnostic_only': True, 'formal_pass': False, 'formal_acceptance_paused': True,
               'generated_at_utc': datetime.now(timezone.utc).isoformat(),
               'adoption': {'production_default_enabled': True, 'tasks': 4, 'serial_switch_retained': True, 'custom_environment_or_space_stays_serial': True,
                            'historical_opt_in_trial_preserved_separately': True, 'measured_gain_not_claimed_universal': True,
                            'limits': ['GP final plain mean/P99 regress; all results retained.', 'Operations earlier trial mean/P95 regress and process CPU increases are retained.',
                                       'Department net observed savings about0.77ms public; dominant GP P99 waiting remains unresolved.', 'Root spans and helper jobs do not precisely explain plain causal differences.']},
               'final_production': {'source_identity': reference(ROOT / 'production-source-identity.json'), 'runs': final_runs, 'a3_b3_pairs': pairs,
                                    'gp851_diagnostic': tail, 'normal_selected_case_evidence': cases, 'selected_five_passed_not_full_suite': True,
                                    'functional_semantic_receipt': functional_semantic, 'normal_test_rows_actual_reverified': len(functional_source['actual_test_sources']),
                                    'tool_verification': tool, 'uncovered': worker_checks['not_covered']},
               'historical_opt_in_experiment': old_summary, 'whole_stages_summary': 'whole-stages-summary.json',
               'source_verification': proof, 'actual_launches_and_failures': all_launches, 'actual_timings': timing,
               'final_binary_aliases': aliases, 'all_actual_final_binary_sha_verified': True,
               'original_complete_snapshot_is_reused_by_committed_archive_reference': True,
               'excluded': ['entire copied projects', 'assets payloads', '.godot', 'isolated-user', 'unrun bookend preparations', 'engine and native DLL payloads'],
               'freeze_runs_no_engine_build_or_test': True}
    whole_summary['containing_package_freeze'] = {'all_six_final_binary_payloads_actual_hash_verified': True, 'source_identity_reverified_in_summary_json': True,
                                                 'focused_timings_still_not_adopted_as_cpu': True}
    whole_summary['business_validation']['binary_payload_rehash_deferred_to_later_freeze'] = False
    for name, value in [('summary.json', summary), ('whole-stages-summary.json', whole_summary)]:
        raw = encoded(value)
        need(json.loads(raw) == value, (name, 'JSON roundtrip'))
        (staging / name).write_bytes(raw)
        archive.virtual(rel(OUT / name), raw, 'frozen-combined-summary')
    manifest = archive.write_and_verify(staging / 'raw-evidence.zip')
    manifest.update({'generated_at_utc': datetime.now(timezone.utc).isoformat(), 'final_binary_aliases': aliases,
                     'all_alias_files_individually_sha_and_size_checked': True, 'unique_final_binary_members': len(binary_members),
                     'excluded_binary_payloads': summary['excluded'], 'binary_identity_note': 'Actual original484/experimental484/final485 sources and engine/native dependencies were checked. Complete original payloads reuse the committed wait-dependency-batch archive; original inputs and final binary aliases are retained. Hashes are auxiliary identity evidence.'})
    (staging / 'raw-manifest.json').write_bytes(encoded(manifest))
    for name in OUTPUTS: (staging / name).replace(OUT / name)
    staging.rmdir()
    print(json.dumps({'completed': True, 'directory': rel(OUT), 'members': manifest['member_count'], 'bytes': manifest['archive_size'],
                      'zip_sha256': manifest['archive_sha256'], 'manifest_sha256': sha(OUT / 'raw-manifest.json'),
                      'actual_final_binary_files': len(aliases), 'unique_final_binary_members': len(binary_members),
                      'measurement_windows': len(measurements), 'selected_cases': 5, 'freeze_ms': (time.perf_counter() - started) * 1000,
                      'timings': {k: v for k, v in timing.items() if k != 'ordinary_window_totals'}}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
