from pathlib import Path
import importlib.util
import json

ROOT=Path(__file__).resolve().parent
REPO=ROOT.parents[1]
spec=importlib.util.spec_from_file_location('measure',REPO/'.cache/worker_production_measure.py')
m=importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
identity=m.read(ROOT/'production-source-identity.json')
for row in identity['production_sources']:
    assert m.sha(m.PROJECT/row['path'])==row['sha256']
launch=m.module(m.PRIOR/'run.py','launcher')
launch.ROOT=ROOT
output=ROOT/'gp-tail-diagnostic.json'
source_input=REPO/'.cache/task-navigation-20261019/gp.input.bin'
m.write(output.with_suffix('.source-check.json'),dict(diagnostic_only=True,formal_pass=False,
    actual_sources_checked=identity['production_sources'],input_sha256=m.sha(source_input),
    root_only=True,worker_records_outside_step_timing=True,whole_window=80))
launch.launch(['--headless','--path',m.PROJECT,'--script','res://tools/performance/representative_worker.gd','--',
    '--input='+str(source_input),'--output='+str(output),'--steps=80','--profile=root',
    '--worker-diagnostics=true','--worker-records=true'],output)
actual=m.read(output)
expected=m.read(m.PRIOR/'b-gp80.json')
assert actual['complete'] and actual['qualified'] and not actual['errors']
for key in ['source_input_sha256','initial','final','qualification','operations','event_records','final_binary_sha256']:
    assert actual.get(key)==expected.get(key),key
assert [{k:v for k,v in x.items() if k!='elapsed_us'} for x in actual['samples']]==[{k:v for k,v in x.items() if k!='elapsed_us'} for x in expected['samples']]
for key in set(actual['public'])|set(expected['public']):
    if key!='query_counts': assert actual['public'].get(key)==expected['public'].get(key),key
for key in set(actual['public']['query_counts'])|set(expected['public']['query_counts']):
    if not key.startswith('diag_worker_sample_'):
        assert actual['public']['query_counts'].get(key)==expected['public']['query_counts'].get(key),key
profile=actual['profile']
assert profile['steps']==80 and profile['step_records_complete'] and not profile['errors'] and not profile['nested_calls']
assert len(actual['worker_sample_step_records'])==80
stages={x['tick']:x for x in profile['step_records']}
workers={x['tick']:x['batch'] for x in actual['worker_sample_step_records']}
plain=m.read(ROOT/'b3-gp80.json')
tick=max(plain['samples'],key=lambda x:x['elapsed_us'])['tick']
record=stages[tick]
top=sorted(record['stages'].items(),key=lambda pair:pair[1]['total_us'],reverse=True)
summary=dict(diagnostic_only=True,formal_pass=False,complete_world_and_original_counts_equal=True,
    all_80_worker_records_complete=True,plain_b3_p99_tick=tick,plain_b3_elapsed_us=max(x['elapsed_us'] for x in plain['samples']),
    same_tick_diagnostic_elapsed_us=record['outer_elapsed_us'],
    same_tick_diagnostic_top_stages=[dict(name=k,total_us=v['total_us']) for k,v in top[:6]],
    same_tick_worker=workers[tick],metrics=actual['metrics'])
m.write(ROOT/'gp-tail-diagnostic.semantic-check.json',summary)
print(json.dumps(summary),flush=True)
