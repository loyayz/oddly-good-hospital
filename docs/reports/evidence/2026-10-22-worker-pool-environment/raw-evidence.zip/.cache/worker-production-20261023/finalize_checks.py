from pathlib import Path
import hashlib
import json
import shutil

ROOT=Path(__file__).resolve().parent
REPO=ROOT.parents[1]
PROJECT=ROOT/'production-project'
read=lambda path:json.loads(Path(path).read_text(encoding='utf-8-sig'))
sha=lambda path:hashlib.sha256(Path(path).read_bytes()).hexdigest()
actual=read(PROJECT/'acceptance-results.json')
assert actual['completed'] and actual['checks']==2 and actual['failed']==0
worker=actual['results']['GROW-75']['details']['worker_sample_checks']
assert worker['ok'] and all(worker['checks'].values())
shutil.copy2(PROJECT/'acceptance-results.json',ROOT/'functional-final.acceptance-results.json')
identity=read(ROOT/'production-source-identity.json')
for row in identity['production_sources']:
    if row['path'] not in ['project.godot','export_presets.cfg']:
        assert sha(REPO/row['path'])==row['sha256']
for relative in ['tests/acceptance/growth.gd','tests/acceptance/worker_sample_checks.gd']:
    assert (REPO/relative).read_bytes()==(PROJECT/relative).read_bytes()
metadata=[]
for relative in ['game/operations/environment_sample_batch.gd.uid','tests/acceptance/worker_sample_checks.gd.uid']:
    source=PROJECT/relative
    target=REPO/relative
    assert source.is_file()
    if target.exists():
        assert target.read_bytes()==source.read_bytes()
    else:
        shutil.copy2(source,target)
    metadata.append(dict(path=relative,sha256=sha(target),source='Actual Godot import in measured production copy'))
record=dict(diagnostic_only=True,formal_pass=False,normal_current_test_sources_byte_equal=True,
    actual_production_sources_unchanged_since_measurement=True,
    selected=['GROW-72','GROW-75'],passed=True,worker_checks=worker['checks'],
    reused_unchanged_interface_passes=['OPS-11','OPS-18','STAFF-32'],
    five_selected_cases_passed_across_reused_and_final_evidence=True,
    generated_resource_uid_metadata=metadata,
    not_covered=worker.get('not_covered'),
    tool='tool-verification.json')
(ROOT/'functional-final.semantic-check.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(record))
