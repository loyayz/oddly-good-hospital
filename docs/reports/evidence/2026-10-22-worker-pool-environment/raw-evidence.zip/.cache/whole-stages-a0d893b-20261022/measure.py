from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import subprocess

CACHE = Path(__file__).resolve().parent
REPO = CACHE.parents[1]
PRIOR = REPO / '.cache/wait-signature-031e1f7-20261022'
PROJECT = PRIOR / 'after-project'

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def write(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--mode', choices=['plain', 'root', 'focused'], required=True)
    parser.add_argument('--window', choices=['public360', 'gp80'], required=True)
    args = parser.parse_args()
    focused = args.mode == 'focused'
    if focused:
        PROJECT = CACHE/'focused-project'
        transformation = read(CACHE/'focused-transformation.json')
    identity = read(PROJECT/'source-identity.json')
    assert identity['head'] == 'd5f048e1fe918bd764f3607db49a3c2f360be89a'
    checked = []
    configurations = []
    for row in identity['source']:
        relative = row['path']
        assert sha(REPO/relative) == row['sha256'], relative
        actual = sha(PROJECT/relative)
        if focused and relative == 'tools/performance/step_profile.gd':
            assert actual == transformation['after_sha256']
            generated = (PROJECT/relative).read_text(encoding='utf-8')
            restored = generated.replace(transformation['generated_selection'], transformation['original_selection'], 1).encode()
            assert hashlib.sha256(restored).hexdigest() == row['sha256'] == transformation['before_sha256']
        elif relative in ['project.godot', 'export_presets.cfg']:
            configurations.append(dict(path=relative, production_sha256=row['sha256'], prepared_sha256=actual))
        else:
            assert actual == row['sha256'], relative
        checked.append(row)
    native = PROJECT/'game/platform/windows/bin/oddly_good_platform.windows.x86_64.dll'
    assert sha(native) == identity['native_sha256'].lower() == sha(REPO/native.relative_to(PROJECT))
    for name in ['libgmp-10.dll', 'libmpfr-6.dll', 'libgcc_s_seh-1.dll', 'libwinpthread-1.dll']:
        relative = Path('game/platform/windows/bin')/name
        assert sha(PROJECT/relative) == sha(REPO/relative)
    assert not (PROJECT/'all-instance-profile-identity.json').exists()
    spec = importlib.util.spec_from_file_location('original_launcher', PRIOR/'run.py')
    launcher = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(launcher)
    launcher.ROOT = CACHE
    filename, steps = launcher.WINDOWS[args.window]
    source_input = REPO/'.cache/task-navigation-20261019'/filename
    output = CACHE/(args.mode+'-'+args.window+'.json')
    assert not output.exists()
    write(output.with_suffix('.source-check.json'), dict(
        diagnostic_only=True, formal_pass=False,
        workspace_commit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip(),
        frozen_source_commit=identity['head'], actual_rows_checked=checked,
        all_actual_workspace_and_frozen_production_rows_equal=True,
        focused_profiler_selection_exception='focused-transformation.json' if focused else None,
        prepared_configurations=configurations,
        native_sha256=sha(native), input_sha256=sha(source_input),
        source_identity_sha256=sha(PROJECT/'source-identity.json'),
        root_markers_only=args.mode=='root', nested_wrappers=focused,
        engine_rebuilt=False, runtime_caches_restored=False,
        note='Root diagnostic uses only the existing phase markers. Plain controls quantify observed perturbation; no observer subtraction claims plain CPU.'
    ))
    launcher.launch(['--headless', '--path', PROJECT, '--script', 'res://tools/performance/representative.gd', '--',
        '--input='+str(source_input), '--output='+str(output), '--steps='+str(steps), '--profile='+('nested' if focused else args.mode)], output)
    actual = read(output)
    assert actual['complete'] and actual['qualified'] and not actual['errors']
    expected = read(PRIOR/('b-'+args.window+'.json'))
    for field in ['source_input_sha256', 'initial', 'final', 'qualification', 'public', 'operations', 'event_records', 'final_binary_sha256']:
        assert actual.get(field) == expected.get(field), field
    assert len(actual['samples']) == steps
    for sample, reference in zip(actual['samples'], expected['samples']):
        assert {k:v for k,v in sample.items() if k!='elapsed_us'} == {k:v for k,v in reference.items() if k!='elapsed_us'}
    if args.mode == 'root' or focused:
        profile = actual['profile']
        assert profile['steps'] == steps and profile['step_records_complete']
        assert not profile['errors']
        if not focused:
            assert not profile['nested_calls']
        else:
            for group, methods in transformation['selected_methods'].items():
                assert sorted(profile['sources'][group]['methods']) == sorted(methods)
        assert profile['sources']['root_method_preserved']
    write(output.with_suffix('.semantic-check.json'), dict(
        complete=True, diagnostic_only=True, formal_pass=False, steps=steps,
        complete_world_events_work_public_operations_and_window_counts_equal=True,
        every_non_timing_sample_equal=True, reference=str(PRIOR/('b-'+args.window+'.json')),
        reference_sha256=sha(PRIOR/('b-'+args.window+'.json')),
        final_binary_sha256=actual['final_binary_sha256']))
    print(json.dumps(dict(output=str(output), metrics=actual['metrics'], semantics_equal=True)), flush=True)
