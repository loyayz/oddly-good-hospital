extends "res://game/clinic/clinical_runtime.gd"
var _step_profile_observer: RefCounted

func dispatch(world: WorldState) -> void:
	_step_profile_observer.enter_call("clinic.dispatch")
	super.dispatch(world)
	_step_profile_observer.exit_call("clinic.dispatch")

func service_candidates(world: WorldState, visit: Dictionary, kind: String, structural_only: bool = false, reference_schedule: bool = false, selection: Dictionary = {}) -> Array:
	_step_profile_observer.enter_call("clinic.service_candidates")
	var _step_profile_result: Variant = super.service_candidates(world,visit,kind,structural_only,reference_schedule,selection)
	_step_profile_observer.exit_call("clinic.service_candidates")
	return _step_profile_result

func _service_pair_reachable(world: WorldState, visit: Dictionary, facility_id: String, staff_id: String, base_layout: Dictionary, physical: Dictionary = {}) -> bool:
	_step_profile_observer.enter_call("clinic._service_pair_reachable")
	var _step_profile_result: Variant = super._service_pair_reachable(world,visit,facility_id,staff_id,base_layout,physical)
	_step_profile_observer.exit_call("clinic._service_pair_reachable")
	return _step_profile_result

func _build_availability(world: WorldState) -> Dictionary:
	_step_profile_observer.enter_call("clinic._build_availability")
	var _step_profile_result: Variant = super._build_availability(world)
	_step_profile_observer.exit_call("clinic._build_availability")
	return _step_profile_result
