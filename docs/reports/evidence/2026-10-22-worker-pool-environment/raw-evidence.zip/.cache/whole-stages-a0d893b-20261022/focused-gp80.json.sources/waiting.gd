extends "res://game/life/waiting_life.gd"
var _step_profile_observer: RefCounted

func dispatch(world: WorldState) -> void:
	_step_profile_observer.enter_call("waiting.dispatch")
	super.dispatch(world)
	_step_profile_observer.exit_call("waiting.dispatch")

func seat_candidates(world: WorldState, visit_id: String) -> Array:
	_step_profile_observer.enter_call("waiting.seat_candidates")
	var _step_profile_result: Variant = super.seat_candidates(world,visit_id)
	_step_profile_observer.exit_call("waiting.seat_candidates")
	return _step_profile_result

func _dispatch_public_seat(world: WorldState, visit: Dictionary, intent: Dictionary, selected_entry: Dictionary = {}) -> void:
	_step_profile_observer.enter_call("waiting._dispatch_public_seat")
	super._dispatch_public_seat(world,visit,intent,selected_entry)
	_step_profile_observer.exit_call("waiting._dispatch_public_seat")

func _wait_safely(world: WorldState, visit: Dictionary, intent: Dictionary) -> void:
	_step_profile_observer.enter_call("waiting._wait_safely")
	super._wait_safely(world,visit,intent)
	_step_profile_observer.exit_call("waiting._wait_safely")

func _dispatch_public_need(world: WorldState, visit: Dictionary, need: Dictionary) -> void:
	_step_profile_observer.enter_call("waiting._dispatch_public_need")
	super._dispatch_public_need(world,visit,need)
	_step_profile_observer.exit_call("waiting._dispatch_public_need")
