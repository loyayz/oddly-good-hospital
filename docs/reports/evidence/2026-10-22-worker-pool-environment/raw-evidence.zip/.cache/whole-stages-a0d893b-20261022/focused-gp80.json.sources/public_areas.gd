extends "res://game/life/public_areas.gd"
var _step_profile_observer: RefCounted

func should_recheck(world: WorldState, intent: Dictionary, definitions: Array, members: Array = [], extra: Dictionary = {}) -> bool:
	_step_profile_observer.enter_call("public_areas.should_recheck")
	var _step_profile_result: Variant = super.should_recheck(world,intent,definitions,members,extra)
	_step_profile_observer.exit_call("public_areas.should_recheck")
	return _step_profile_result

func remember_wait(world: WorldState, intent: Dictionary, definitions: Array, members: Array = [], extra: Dictionary = {}) -> void:
	_step_profile_observer.enter_call("public_areas.remember_wait")
	super.remember_wait(world,intent,definitions,members,extra)
	_step_profile_observer.exit_call("public_areas.remember_wait")

func _decision_signature(world: WorldState, intent: Dictionary, definitions: Array, members: Array, extra: Dictionary, route_floors: Array = []) -> Array:
	_step_profile_observer.enter_call("public_areas._decision_signature")
	var _step_profile_result: Variant = super._decision_signature(world,intent,definitions,members,extra,route_floors)
	_step_profile_observer.exit_call("public_areas._decision_signature")
	return _step_profile_result

func facilities(world: WorldState, reference: Dictionary, definitions: Array) -> Array:
	_step_profile_observer.enter_call("public_areas.facilities")
	var _step_profile_result: Variant = super.facilities(world,reference,definitions)
	_step_profile_observer.exit_call("public_areas.facilities")
	return _step_profile_result

func compatible_geometry(world: WorldState, reference: Dictionary, definitions: Array, members: Array) -> bool:
	_step_profile_observer.enter_call("public_areas.compatible_geometry")
	var _step_profile_result: Variant = super.compatible_geometry(world,reference,definitions,members)
	_step_profile_observer.exit_call("public_areas.compatible_geometry")
	return _step_profile_result
