from pathlib import Path
import hashlib
import json
import shutil

CACHE = Path(__file__).resolve().parent
REPO = CACHE.parents[1]
SOURCE = REPO/'.cache/wait-signature-031e1f7-20261022/after-project'
TARGET = CACHE/'focused-project'
assert not TARGET.exists()
shutil.copytree(SOURCE, TARGET)
path = TARGET/'tools/performance/step_profile.gd'
original = path.read_bytes()
start = original.index(b'const COMMON_METHODS:')
end = original.index(b'var errors: Array = []')
old = original[start:end]
methods = {
    'waiting': ['dispatch', '_dispatch_public_seat', '_dispatch_public_need', '_wait_safely', 'seat_candidates'],
    'public_areas': ['should_recheck', 'remember_wait', '_decision_signature', 'compatible_geometry', 'facilities'],
    'clinic': ['dispatch', 'service_candidates', '_build_availability', '_service_pair_reachable'],
}
new = ('const COMMON_METHODS: Array[String] = []\nconst HOT_METHODS: Dictionary = '+json.dumps(methods, indent=2)+'\n\n').encode()
generated = original[:start]+new+original[end:]
assert generated.replace(new, old, 1) == original
path.write_bytes(generated)
proof = dict(diagnostic_only=True, formal_pass=False, original_selection=old.decode(), generated_selection=new.decode(),
    before_sha256=hashlib.sha256(original).hexdigest(), after_sha256=hashlib.sha256(generated).hexdigest(),
    only_modified_source='tools/performance/step_profile.gd', selection_inverse_byte_equal=True,
    selected_methods=methods, selected_method_count=sum(map(len, methods.values())),
    source_project=str(SOURCE), project=str(TARGET), production_bodies_changed=False,
    scope='Two largest dispatch stages only; no high-frequency spatial or environment leaf wrappers.')
(CACHE/'focused-transformation.json').write_text(json.dumps(proof, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
print(json.dumps(dict(project=str(TARGET), methods=proof['selected_method_count'], inverse_byte_equal=True)))
