
#include <algorithm>
#include <iostream>
#include <map>
#include <set>
#include <string>
#include <vector>
struct Node { bool choice = false; std::map<int,int> resources; std::vector<int> children; };
struct Model {
    std::vector<std::string> resources;
    std::map<std::string,int> resource_ids;
    std::vector<Node> nodes;
    std::vector<std::vector<int>> resource_nodes;
    std::map<std::string,std::string> locked_roles;
    std::vector<bool> enabled;
    void make_index() {         resource_nodes.resize(resources.size());
        for (size_t i = 0; i < nodes.size(); ++i)
            for (const auto& term : nodes[i].resources) resource_nodes[term.first].push_back(static_cast<int>(i));
 }
    void update_roles() {         std::vector<bool> local_valid(nodes.size(), true);
        for (const auto& role : locked_roles) {
            std::set<int> own;
            // Use the entire supplied identity as the prefix. In particular,
            // staff IDs containing ':' must retain the original comparison.
            const std::string prefix = "coverage:" + role.first + ":";
            auto first = std::lower_bound(resources.begin(), resources.end(), prefix);
            for (auto current = first; current != resources.end() && current->compare(0, prefix.size(), prefix) == 0; ++current) {
                const bool matches = current->substr(prefix.size()) == role.second;
                for (int node : resource_nodes[static_cast<size_t>(current - resources.begin())]) {
                    if (matches) own.insert(node);
                    else local_valid[node] = false;
                }
            }
            auto staff = resource_ids.find("staff:" + role.first);
            if (staff != resource_ids.end())
                for (int node : resource_nodes[staff->second]) if (!own.count(node)) local_valid[node] = false;
        }
        for (size_t i = 0; i < nodes.size(); ++i) {
            const Node& node = nodes[i];
            bool children = !node.choice;
            for (int child : node.children) {
                if (node.choice) children = children || enabled[child];
                else children = children && enabled[child];
            }
            enabled[i] = local_valid[i] && children;
        }
 }
    void original() {
        for (size_t i = 0; i < nodes.size(); ++i) {
            const Node& node = nodes[i]; bool valid = true;
            for (const auto& role : locked_roles) {
                bool own = false, active = false;
                for (const auto& term : node.resources) {
                    const auto& name = resources[term.first];
                    const std::string prefix = "coverage:" + role.first + ":";
                    if (name.compare(0, prefix.size(), prefix) == 0) {
                        if (name.substr(prefix.size()) != role.second) valid = false;
                        else own = true;
                    }
                    if (name == "staff:" + role.first) active = true;
                }
                if (active && !own) valid = false;
            }
            bool children = !node.choice;
            for (int child : node.children) {
                if (node.choice) children = children || enabled[child];
                else children = children && enabled[child];
            }
            enabled[i] = valid && children;
        }
    }
};
int main() {
    Model actual;
    for (const char* staff_text : {"a", "a:b", "worker:with:colons", "n"}) {
        const std::string staff(staff_text);
        actual.resources.push_back("staff:" + staff);
        for (const char* ward : {"w1", "w2", "ward:x"}) actual.resources.push_back("coverage:" + staff + ":" + ward);
    }
    actual.resources.push_back("facility:unrelated");
    std::sort(actual.resources.begin(), actual.resources.end());
    for (size_t i=0; i<actual.resources.size(); ++i) actual.resource_ids[actual.resources[i]]=static_cast<int>(i);
    actual.nodes.push_back(Node{}); // Empty AND and OR retain different semantics.
    actual.nodes.push_back(Node{true,{}, {}});
    const int resource_count=static_cast<int>(actual.resources.size());
    for (int a=0; a<resource_count; ++a) {
        actual.nodes.push_back(Node{false,{{a,1}}, {}});
        for (int b=a+1; b<resource_count; ++b) actual.nodes.push_back(Node{false,{{a,1},{b,1}}, {}});
    }
    const int leaves=static_cast<int>(actual.nodes.size());
    for (int a=0; a<leaves; ++a) {
        const int b=(a*7+3)%leaves;
        actual.nodes.push_back(Node{false,{}, {a,b}});
        actual.nodes.push_back(Node{true,{}, {a,b}});
    }
    actual.enabled.assign(actual.nodes.size(),true);
    actual.make_index();
    Model control=actual;
    std::vector<std::map<std::string,std::string>> locks{{}};
    for (const char* staff : {"a", "a:b", "worker:with:colons", "n", "missing", ""})
        for (const char* ward : {"w1", "w2", "ward:x", "b:w1", ""}) locks.push_back({{staff,ward}});
    locks.push_back({{"a","w1"},{"a:b","w2"},{"n","ward:x"}});
    locks.push_back({{"a","b:w1"},{"a:b","w1"},{"worker:with:colons","w2"}});
    locks.push_back({});
    int checked=0;
    // Repeat transitions on the same graph, including clearing and relocking.
    for (int pass=0; pass<3; ++pass) for (const auto& value : locks) {
        actual.locked_roles=value; control.locked_roles=value;
        actual.update_roles(); control.original();
        if (actual.enabled!=control.enabled) { std::cerr<<"role enabled mismatch at transition "<<checked<<"\n"; return 1; }
        ++checked;
    }
    std::cout<<"{\"transitions\":"<<checked<<",\"nodes\":"<<actual.nodes.size()<<",\"resources\":"<<actual.resources.size()<<",\"enabled_equal\":true}\n";
}
