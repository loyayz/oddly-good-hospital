# CL-A01～CL-A10 实现交接

状态：生产实现和新增 helper 已冻结；仅执行了 `git diff --check`。引擎解析、功能断言与固定 160 人测量由统一串行执行记录定义，本文不报告未运行的收益。原审计是修复前证据，不能当作修复后状态或计时。

## 逐项实现与微验证

| ID | 实现位置与最小边界 | 新增 helper 与实际记录字段 | 状态 |
| --- | --- | --- | --- |
| CL-A01 | `clinical_runtime.gd::_select_plan` 同一次无指定医生推荐按首次医生 ID 去重；`arrival_readiness` 保留首次完整 GP 数组用于诊断检查 | CLIN-35：`quote_calls_by_doctor_plan`、`consult_pairs`、`gp_calls/control_gp_calls`；真实报价与保留旧重复枚举的独立 readiness 控制完整相等 | 已实现，未执行 |
| CL-A02 | `staff_wellbeing.gd::_select_facility` 用原定义集合并先验证类型/员工区；`clinical_development.gd::_desks` 指定桌单元素、否则稳定 FUR05 索引；研究 `_find_pair` 同一次合法桌查询只建一次合格 worker ID 列表 | STAFF-43：`sleep_occupancy_queries/all_facilities`；原完整往返仍执行。共享桌资格与课程研究交接复用 STAFF-06/07、GROW-30/32 | 已实现，未执行 |
| CL-A03 | `waiting_life.gd` 占用拥有者集合/公共房间/using 分组限只读 route scope；`hospital_visitors.gd` 本批 ward/present/waiting 视图及按 visit 的当前停留身份索引；`clinical_development.gd` busy/desk 视图；scheduler/Simulation 显式传 busy；wellbeing 同岗位与责任视图 | STAFF-44：自身占用例外、第二拥有者下一查询可见、桌位新提交可见、当前 active_job 字段与不同 world 校验；STAFF-41、CLIN-23/30～33 覆盖对应真实路径 | 已实现，未执行 |
| CL-A04 | `clinical_development.gd::_base_view/_base_line/_base_start_quote/_yield_prepared_base` 本阶段按设施分组和派生队列；候选单独插入；准备/移动/完成后使旧、新设施队列失效；让路先检查实际身体相交再建队列 | STAFF-44：独立旧队列公式对照，`entry_calls_two_identical_queries`、`entry_calls_with_candidate_and_changed_owner`；真实让路继续由 STAFF-41 覆盖 | 已实现，未执行 |
| CL-A05 | `recruitment_service.gd::settle` 独立 observer 消费 visits 与环境/维修完成 ID，仍读取原 practice flag；`clinical_development.gd::_settle_cases` 消费待交接 visit+当前 active ID；真实 departed 后 Arrival 通知；培训/研究阶段遍历仅活动任务 ID，不删终态历史 | STAFF-43：64 条已消费历史、单新增、重复 settle、同 ID 原地 flag 更新并正式通知、集合替换、恢复；`practice_sequence`。注册与真实离院病例交接由相应临床/员工流程用例验证 | 已实现，未执行 |
| CL-A06 | shortage 只隔离 staff 映射/记录；waiting using 投影仅隔离 actors/需要/预约写入路径；招聘寻访仅隔离 recruitment RNG 与 entity scalar | CLIN-35：只隔离实际写入路径、源全 facts/RNG 相等；STAFF-43 正常付费 search；原等待饮水与寻访失败原子性用 STAFF-35/38 | 已实现，未执行 |
| CL-A07 | `arrival_service.gd::capacity/_resource_budgets/_maintenance_view` 一次按 facility 聚合逐工单 ceil 余量与整班阻塞，三班只做原截断 | GROW-85：独立原逐工单预算公式、`per_job_rounding_total_ticks`、`maintenance_builds`、`facility_queries`、只读 facts；不调用完整病例容量求解 | 已实现，未执行 |
| CL-A08 | `RecruitmentService.search_status(world)` 只返回 active_search 深副本；UI 分区接入该 API | STAFF-43：正常 paid search 后读取，`card_calls/standard_preview_calls` 与深副本/只读断言 | 已实现，未执行；与 PRES-06 共一个根因 |
| CL-A09 | `ResearchJobIndex` 保存 research_id→原字典顺序身份，active/rewards/unlock 始终读取当前记录；clinic/arrivals/research 服务各自 observer；新增研究发布通知 | GROW-85：`actual_query_calls`，真实付费 waiting→pause/resume→cancel→restart；同数量集合替换、同 ID owner 通知替换、不同世界恢复、清空集合重建，源 world.validate | 已实现，未执行 |
| CL-A10 | `staff_wellbeing.gd::_select_facility/_dispatch_task` 回传同一次 rest 已完整求出的 tea（包括空结果）；`_tea_position` 逐格完整循环开独立 dynamic scope，返回前结束；不同 sleep 投影仍独立 | STAFF-43：保留旧重复调用的控制，完整 facts/RNG 相等、真实 move 请求，`tea_calls/control_tea_calls`、`route_calls/control_route_calls`、`dynamic_batches` | 已实现，未执行；dynamic 前缀属于 OP-A12 同一公共修复 |

每个新增 case 输出总 `elapsed_usec`。总耗时不能拆作各根因单项时间，以上 probe 尚未执行，不能预填预期次数作为实测值。独立控制仅重现重复查询；临床报价、格检查、路径与真实 move 提交仍调用生产实现。

## 所有者与恢复

- 所有视图均为运行时派生数据，不进入 facts/freeze。
- 同步 route scope 内禁止写事实，结束后丢弃。茶位范围只包含同一真实员工；不同适配投影/actor 位置不共享该范围。
- busy 视图只缓存阶段内不变的 session/preparation/transfer/handoff 正向成员；`clinical_release` 和 `active_job_id` 逐次读当前员工事实。desk 视图按混合实体队列原顺序，在每次真实派单后更新拥有者。
- WorldState pending observer 独立消费，集合/世界恢复重建，正式同 ID 更正必须通知 `fact_record_changed` 或 receipt wrapper。研究/亲友动态 observer 传 weak owner，结束后可回收。
- 研究索引只保存身份分组，当前 state/rewards 不另存副本；集合身份/数量/owner 通知变化重建，清空同一字典也重建。
- 终态任务 ID 索引保留 paused/inventory 等可恢复状态；命令所有者使用公共失效入口。同 ID 终态复活须 `operation_records_changed`，不依赖数量变化猜测。

## 统一注册入口

- `CLIN-35`：`clinical_repeated_work.gd.new().run_case(t, content)`。
- `STAFF-43`：`staff_repeated_work.gd.new().run(t, content)`。
- `STAFF-44`：`staff_repeated_work.gd.new().run_views(t, content)`。
- `GROW-85`：`growth_repeated_work.gd.new().run(t, content, cache)`，使用 `research_opened` 的真实 GP 前提；helper 自行 dispose 创建的 Simulation。

## 运营分区只读复核

核对 finance station 几何索引、active/pending 操作索引、movement reservation broadphase、BuildPreview checker、动态交通前缀和改建所有者。正式建设/改建以 facts setter 或 geometry invalidation 发布；自动维修新建使用新 ID；各 execute 在可能原地更新前使任务索引失效。movement 在释放旧预约后建立范围，门预约新增/替换立即重索引，步末清空；精确 BodySweep 仍决定相交。BuildPreview 依赖变化创建新 job/checker，candidate 后段只读。动态交通每个目标仍检查出口，前缀和停靠候选范围对应 actor/group 与起终楼层。未发现可证实的新缺陷；该结论仅为静态复核。
