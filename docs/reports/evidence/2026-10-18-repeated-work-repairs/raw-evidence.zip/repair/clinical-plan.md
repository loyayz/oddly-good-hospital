# CL-A01～CL-A10 修复计划

业务基准仍为 docs/design 的诊疗、真实到场、共享桌、员工生活、到访机会及恢复规则。保留全部人物、设施、票、候选、历史、原排序、拒绝原因、随机流、冻结承诺与实际路线。以下仅收缩重复计算；未运行引擎、功能用例或基准。

## 派生状态与失效契约

同步只读查询使用调用内视图，按事实所有者分别索引占用、归属和承诺；不写 facts，不跨实际预约/移动/任务状态变更使用旧视图。混合课程/研究派单按原实体序逐项更新桌位视图，后提交者仍看到先提交者。基地视图按设施分组，准备/移动改变后使相关队列失效。

完成消费与研究身份索引由各服务实例保存，只存派生记录/待消费身份。世界对象或集合替换时重建；正式直接写入新增/替换集合在公共入口检查，独立 settle 首次从完整历史重建；消费记录仍以原 facts 幂等标记为准。生产完成事实通过窄通知入口加入待消费集合，不逐步轮询全部已消费历史。当前正式测试的直接写入点须逐一核对；不能用隐含 world_revision 替代实际集合/所有者边界。任意外部直接回写已经消费的旧记录须显式重建入口，不把这类未定义写入当作生产性能优化理由。

## 逐项方向

| ID | 实现方向 | 不变边界 | 最小相关选例/微验证 |
| --- | --- | --- | --- |
| CL-A01 | _select_plan 同次 doctor 去重；arrival_readiness 复用完整结构GP数组 | 首次医生/设施顺序、全部方案与失败回退、只读RNG | CLIN-02/06/07/11/34；重复医生失败回退及无GP/证据不足计数 |
| CL-A02 | 员工类型/员工区先过滤；指定桌单元素，无指定按FUR05索引 | 全部合法设施、总恢复时长排序、完整往返、指定桌失败原因 | STAFF-22/23/41、06/07；GROW-30/32 |
| CL-A03 | 候诊占用/房间、亲友归属/等待格、共享桌与safe_busy分别建调用/阶段视图；更新真实派单后的桌拥有者；同岗位替手只遍历该角色组 | 不能把床通行权限当工作、自己例外和重复拥有者、后续派单可见性 | STAFF-29/30/34/35/42、06/07/12/16/21/41；CLIN-23/30～33；GROW-30/32，按改动触发子集 |
| CL-A04 | 基地员工一次分组，复用无candidate队列、候选插入派生排序；对相关任务/移动变更失效 | commitment/queue_tick/ID、实际让路、候选不同不能混用 | STAFF-12/16/41；队列相同与异层不相交计数 |
| CL-A05 | 注册/运营完成入待消费队列；成长治愈病例队列；恢复或集合替换重建，active新事实兼容直接写入 | 原阶段才结算、幂等、历史不删、真实离院后病例、R11实践转换 | STAFF-02/08/09/10/40；OPS-32及独立新增receipt/恢复/重复settle |
| CL-A06 | shortage/忙饮水/招聘寻访只复制会写入的映射与记录 | 投影只读，原失败原子性/RNG/entity_next、不同世界空间身份、完整返回路线 | CLIN-08/11/34；STAFF-35/38；OPS-11/32 |
| CL-A07 | 容量请求一次按facility聚合原始维修余量与完整班阻塞，三班仅截断正常余量 | 多工单相加、任一暂停/无工人/非正率仍完整班阻塞 | 小预算独立算例；GROW-03/08/39/43及相关OPS暂停工时 |
| CL-A08 | RecruitmentService.search_status(world) 只返回active_search深副本 | query原完整语义、状态文本、当前入口/卡片不缓存 | STAFF-36/38/39；UI由呈现分区采用窄API |
| CL-A09 | 同次/服务任务索引按research_id分组，按当前记录读state/frozen rewards；已知集合成员变化/替换重建 | 首次命中、active/completed区别、冻结成果、恢复 | GROW-34/35/37/38；取消后新任务/直接替换集合 |
| CL-A10 | 同次rest选址把已算茶位传给原fallback，不再重复完整搜索 | 全部8×8员工区格、身体与真实路线/最短路、提交复核；睡眠原独立床查询 | STAFF-22/41；无椅有茶、无合法茶与完整事实/RNG/调用数 |

## 跨分区接口

- `RecruitmentService.search_status(world) -> Dictionary`：只返回 active_search 深副本，UI状态栏使用，不构建候选卡片。
- `HospitalClinicalDevelopment.busy_view(world) -> Dictionary` 与 `safe_busy(world, staff_id, view={})`：调用者在一段承诺集合不变的查询中复用；active_job/clinical_release始终读取当前员工事实。Simulation的dispatch_idle整批可显式建立一份。
- `RecruitmentService.queue_completion(world, source, receipt)`：完成事实所有者在写入最终receipt后通知，实际实践仍在原settle阶段消费。运营完成源需由运营分区接入。
- `ArrivalService.development` 引用同世界的 Development；真实 departed 后 `queue_case(world,visit)`，避免 complete-step 从active集合移除前漏交接。Simulation初始化/解绑由父代理接入。

测试新增独立helper，注册文件不修改；给父代理提供编号/入口。正式Release、742全量、GPU、两小时保持暂停。所有执行由父代理串行调度。
