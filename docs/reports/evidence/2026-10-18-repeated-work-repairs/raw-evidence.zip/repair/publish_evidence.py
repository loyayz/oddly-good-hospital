from pathlib import Path
import json,hashlib,statistics,zipfile,shutil,subprocess
out=Path(__file__).resolve().parent; root=out.parents[1]
dest=root/'docs/reports/evidence/2026-10-18-repeated-work-repairs'; dest.mkdir(parents=True,exist_ok=True)
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
metrics={'diagnostic_only':True,'formal_pass':False,'baseline':'9f7dc5b5274e7d190ad4b58f85c596e0ce06d6b4','scenes':{}}
for scene in ['gp','operations']:
    data=read(out/(scene+'-plain-measurements.json')); rows=data['runs']
    assert len(rows)==6 and all(r['qualified'] for r in rows)
    assert len({r['input_sha256'] for r in rows})==len({r['final_binary_sha256'] for r in rows})==1
    medians={side:{key:statistics.median(r['metrics'][key] for r in rows if r['side']==side) for key in rows[0]['metrics']} for side in ['before','after']}
    metrics['scenes'][scene]={'runs':rows,'median_window_metrics':medians,'mean_reduction':1-medians['after']['mean_us']/medians['before']['mean_us'],'whole_facts_events_rng_binary_equal':True}
metrics['tools']={'T02':read(out/'tools-measurements.json')['reports'][0],'T03_final':read(out/'tools-measurements-t03-r2.json')['reports'][0]}
metrics['native_roles']=read(out/'native-roles-r1/result.json')
(dest/'measurements.json').write_text(json.dumps(metrics,ensure_ascii=False,indent=2),encoding='utf8',newline='\n')
ids=['59fca63d70ad49a9877bdb519c7f6896','d3bd4987c8054f0da8b322f25305aa21','2a6912427dbc47849a9b97d9bedff105','b66632143a8244a698f95b28c578ce17','d468a64acbdf4dacb2fc6d76d24959cb']
batches=[]; final={}
for run_id in ids:
    folder=root/'.cache/acceptance'/run_id
    result=read(folder/'acceptance-results.json') if (folder/'acceptance-results.json').exists() else None
    batches.append({'id':run_id,'timing':read(folder/'timing-summary.json'),'checks':result['checks'] if result else 0,'failed':result['failed'] if result else None,'completed':result['completed'] if result else False})
    if result:
        for key,value in result['results'].items(): final[key]={'batch':run_id,**value}
assert len(final)==107 and all(v['passed'] for v in final.values())
(dest/'functional-summary.json').write_text(json.dumps({'selected_unique_cases':107,'all_selected_final_passed':True,'formal_pass':False,'batches':batches,'final_results':final,'offline_checks':{'python_unit_groups':7,'frame_cursor_checks':201,'fixture_source_policy_checks':32,'native_role_transitions':102,'note':'Offline tool check results were observed in terminal; no standalone raw unit stdout log was saved. The benchmark outputs and native compiler outputs are archived.'}},ensure_ascii=False,indent=2),encoding='utf8',newline='\n')
identities={'baseline_archive_sha256':sha(out/'before-source.zip'),'projects':{side:read(out/(side+'-project/source-identity.json')) for side in ['before','after']}}
(dest/'source-identities.json').write_text(json.dumps(identities,ensure_ascii=False,indent=2),encoding='utf8',newline='\n')
archive=dest/'raw-evidence.zip'; files={}
def add(p,name):
    if p.is_file(): files[name]=p
for p in out.iterdir():
    if p.is_file() and p.name!='before-source.zip' and p.suffix in ['.json','.log','.ndjson','.bin','.py','.md']: add(p,'repair/'+p.name)
for name in ['compile.log','result.json','roles.cpp']: add(out/'native-roles-r1'/name,'native/'+name)
for run_id in ids:
    for name in ['acceptance-results.json','execution.log','import.log','source-identity.json','timing-summary.json','fixture-config.json']:
        add(root/'.cache/acceptance'/run_id/name,'acceptance/'+run_id+'/'+name)
for relative in ['clinical-corrected/clinical-corrected-r2-gp_work_handoff.input.bin','operations.input.bin']:
    add(root/'.cache/performance-loop-20261018'/relative,'inputs/'+Path(relative).name)
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name,p in sorted(files.items()): z.write(p,name)
(dest/'archive-manifest.json').write_text(json.dumps({'archive':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,'entries':[{'path':name,'bytes':p.stat().st_size,'sha256':sha(p)} for name,p in sorted(files.items())]},ensure_ascii=False,indent=2),encoding='utf8',newline='\n')
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'entries':len(files),'selected_unique_cases':len(final),'mean_reductions':{s:v['mean_reduction'] for s,v in metrics['scenes'].items()}},ensure_ascii=False))
