from pathlib import Path
import subprocess,sys,json,statistics,hashlib
out=Path(__file__).resolve().parent; root=out.parents[1]
previous=root/'.cache/performance-loop-20261018'
scene=sys.argv[1]; mode=sys.argv[2] if len(sys.argv)>2 else 'plain'
inputs={'gp':(previous/'clinical-corrected/clinical-corrected-r2-gp_work_handoff.input.bin',80),'operations':(previous/'operations.input.bin',40)}
input_file,steps=inputs[scene]; rows=[]
sides=['before','after']
for pair in range(3 if mode=='plain' else 1):
    for side in (sides if pair%2==0 else list(reversed(sides))):
        name=f'{scene}-{side}-{mode}-p{pair+1}'; output=out/(name+'.json')
        # First high-cost baseline may be censored. Keep it; never use timeout as a duration.
        args=[sys.executable,str(out/'run_engine.py'),str(out/(side+'-project')),name,'120' if scene=='operations' else '55','--input='+str(input_file),'--output='+str(output),f'--steps={steps}','--profile='+mode]
        status=subprocess.run(args,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf8',errors='replace')
        if status.returncode:
            print(status.stdout,flush=True)
            rows.append({'side':side,'pair':pair+1,'name':name,'completed':False,'run':json.loads((out/(name+'.run.json')).read_text(encoding='utf8'))})
            if scene!='operations' or side!='before': raise SystemExit('A measured window failed; retain and diagnose')
            sides=['after']
            continue
        v=json.loads(output.read_text(encoding='utf8'))
        row={'side':side,'pair':pair+1,'name':name,'completed':True,'qualified':v['qualified'],'input_sha256':v['source_input_sha256'],'final_binary_sha256':v['final_binary_sha256'],'metrics':v['metrics'],'qualification':v['qualification']}
        rows.append(row); print(json.dumps(row,ensure_ascii=False),flush=True)
        if not v['qualified']: raise SystemExit('Complete but unqualified window; diagnose')
    (out/(scene+'-'+mode+'-measurements.json')).write_text(json.dumps({'diagnostic_only':True,'formal_pass':False,'baseline':'9f7dc5b5274e7d190ad4b58f85c596e0ce06d6b4','runs':rows},indent=2),encoding='utf8')
print('MEASUREMENTS_FINISHED',flush=True)
