# 运营与空间重复工作修复计划

范围为 OP-A01～OP-A12 的建造、运营、经济与模拟实现；临床和 UI 实现由各自所有者处理。所有业务事实、原历史、完成凭据、候选资格、排序、拒绝条件、真实移动、预约授权、连续身体碰撞、工时、金额及随机流保持。派生索引不进入 freeze，恢复及整体 facts 替换后重建。不得用 nominal 或 ignore_people 绕过真实候选判断。

| 编号 | 实施边界与失效所有权 | 定向验证及理由 |
| --- | --- | --- |
| A01 | 一次环境派工延迟查询一次工具，缓存无工具；楼板按定义取完整工具候选，仍逐人路线/区域/封锁。 | OPS-12/13/14/42；SPACE-14/16/18：缺条件、到场、争用、换工具与原余量。 |
| A02 | WorldState 提供完成来源增量观察；生产者发布通知，来源字典替换/恢复重建；消费前时间窗/身份去重；原 receipts 不删。 | OPS-16/32、STAFF-40、CORE-18：贡献归属、重复、过期、离职、恢复。 |
| A03 | 财务服务位统计复用正式布局修订及设施身份；正式建造/库存/施工/容量边界触发失效，逐 tick 分子照常累积。 | OPS-33/35/36：逐人/逐 tick 舍入、容量及布局改变、恢复、只读预测。 |
| A04 | 可恢复活动订单派生 ID；初始/集合替换/新增重建，终态从活动集移除，命令明确失效；上门离院独立推进。 | OPS-21/22/23/27/38/39；OPS-13/14、SPACE-18：终态历史保留、安全交接、库存/取消/升格/恢复。 |
| A05 | 每份完整候选及切片 job 共用 candidate/previous checker 对；依赖过期重建整个 job，实际逐人物独立路线不删。 | SPACE-05/09/10/30/33：失败原子、出口、已承诺目标、几何/预约及只读。 |
| A06 | 一次 spawn_dirt 建立楼层禁止点/设施空间候选视图，81格仍按原最近/X/Y；最近点选完再检查 plot 上限。 | OPS-15/16/17：幂等、桶合并、精确占位、同距排序、满 plot。 |
| A07 | 常规/手术设备按定义索引；同次路由复用逐科室结构报价，保留注册随机抽取和有效科室上下文。 | OPS-30/31/32：结构与瞬时不足区分，错科纠正、原票及只读。 |
| A08 | preparing 成员可恢复索引；waiting_all 单次只读安全集合分组，单订单入口保持实时；dispatch 不跨事实变动复用旧准备。提供 UI 批量API供所有者接入。 | SPACE-33/35/36/44、CORE-34：实际腾空、临床责任、原维护任务、取消/应用/恢复、只读。 |
| A09 | 预约区域 broadphase 仅存在于同步查询或真实移动阶段；移动新增/释放门预约即时更新，逐候选仍用实时权限与精确 Rect/BodySweep。 | SPACE-08/09/10及涉及床位授权边界：新预约、授权、实际释放、分数扫掠、后续批次不复用。 |
| A10 | 单次 validate 预建合法装修单元 owner 集合，逐账目完整结构/身份验证保留，未知 owner 拒绝。 | CORE-18/21/45、OPS-14；新增合法退款和缺失/畸形owner输入。 |
| A11 | 账本所有者同步维护 owner→凭据 ID 索引；仍筛 settled 并按原 ID 排序；整体账本替换/恢复重建。 | OPS-32/36、CORE-45：同病例多尝试、待结转已结、重发、恢复。 |
| A12 | 新显式真实动态批次仅清洁员候选枚举使用；相同人物 floor-leg 和运输结构/前缀复用，任务提交前结束，禁止跨人物/步/预约变更持有。 | OPS-16/17/42、SPACE-09/10；独立控制新旧实际路线/结果、占用出口、不同身体/授权、源事实/RNG不变与失效。 |

独立测试 helper 覆盖派生索引的冷/热/新增/终态/字典替换/恢复、真实动态批次对照、几何占位边界及坏 owner。注册文件不改，由统一运行者接入。已有选例按实际修改交接选择，不运行完整专题、742容量或2小时矩阵。实现期间只进行静态源/差异检查；所有 Godot/引擎、回归和性能运行由统一运行者执行，同一160人输入不删负载。

## 已实施接口与交接

- `WorldState.pending_fact_ids(observer,source,records,owner=null)` 为独立观察者消费派生队列；动态观察者传 weak owner，读或通知时清理已释放对象。固定观察者不传 owner。`fact_record_changed(source,id)` 同 ID 重写也重新通知，各观察者不共享消费游标。
- `completion_receipt_ids(source,observer="staff_jobs")` / `completion_receipt_added(source,id)` 是环境/维护原凭据集合的同体系入口，recruitment 使用独立 `recruitment_practice`。原凭据、已消费身份和员工贡献不删、不提前结算。
- `active_operation_ids(domain,collection,terminal,ordered=false,field="phase")` 首次、源字典替换或数量变化重建；只遍历当前活动 ID 并剔除终态。正式命令入口通过 `operation_records_changed` 处理恢复/取消/同 ID 原位重写。库存、暂停任务保留，不跳过上门人员实际离院。
- `HospitalSpace.begin_dynamic_route_query(world)` / `end_route_query()` 建立独立真实只读批次；不继承父 nominal reference。入口同步当前人物一次，出口/碰撞/时间仍真实计算；floor-leg 结果、交通结构和队列前缀只活到批次结束，支持清洁及同人物茶位搜索。
- `HospitalRemodel.waiting_all(world)` 仅返回 preparing 的 `order_id -> reason`，UI 在一次可见刷新中共享；原 `_waiting` 独立调用仍新建实时视图。UI 接入由表现分区负责。
- 财务服务位依赖正式设施布局修订、世界/设施容器身份和设施数量。正式建造、打包/落位、拆建、蓝图/改建使用候选 facts 替换或几何失效；当前源码没有运行中原位写 `capacity`/`stored`/`under_construction` 的额外命令。EQ05 构造容量属于新设施事实，恢复/容器替换重建；逐 tick 移动/工作只 `touch(false)`，不导致每步重扫。新增加此类原位写入的正式所有者必须调用 `invalidate_geometry`。
- `BuildService.actor_safety` 可选传 candidate/previous checker；完整建造/连接及切片 job 都只建一对，所有实际人物路线独立保留。

## 注册说明与计量边界

`tests/acceptance/operations_repeated_work.gd` 提供三个返回 `{ok,details}` 的入口，注册文件由统一验证者修改：

| 建议编号 | 入口 | 实际输出 |
| --- | --- | --- |
| OPS-43 | `run_indices(content)` | `checks` 的独立观察者、通知/重写、weak owner释放、恢复、正式建造/库存费率、活动/终态历史、ledger owner与坏owner、改建批次/取消失效结果；`elapsed_including_fixture_us` 只表示含前提的回归耗时。 |
| OPS-44 | `run_routes(content)` | 六个真实路线/权限/出口/分数位置场景的完整结果/世界/RNG一致性；每个 variant 的 `route_queries`、`actual_scope_build_us`、`actual_query_us`、`actual_total_query_us`、`control_query_us`；`actual_counts/control_counts` 中 `floor_route_hits`、`floor_route_builds`、`candidate_connections`。后续新批次失效核验不混入计数快照。完整对照使用真实路由和完整预约遍历，不使用假路线。 |
| OPS-45 | `run_spawns(content)` | `checked_cells`、`view_build_us`、`indexed_cell_query_us`、`full_cell_query_us`、完整遍历合法性及最近/X/Y选择一致性；比较时必须将视图构建计入。 |

| 编号 | 业务回归 | 同一160人快速窗口的覆盖边界 | 可观测计量；未执行前无数值 |
| --- | --- | --- | --- |
| A01 | OPS-12/13/14/42；楼板 SPACE-14/16/18 | OP+16格待工输入可覆盖无工具分支；无装修工，不能声称施工或楼板进度。 | 现有 profiler `environment._tool` 的 calls/inclusive_us/exclusive_us；工具数量、实际订单与单位数来自输入，不能用4F当计数。 |
| A02 | OPS-16/32、STAFF-40、OPS-43 | 必须观察真实清洁完成后产生的凭据；首步/无完成历史窗口只覆盖空来源入口。 | OPS-43 的消费/通知/恢复布尔边界；现有 departments.settle 时间是整个收尾阶段，不单独归为receipt耗时。 |
| A03 | OPS-33/35/36、OPS-43 | 每个完整 step 的运营分子实际累积；OP固定布局不覆盖容量/库存变动，专项正式命令与恢复另验。 | OPS-43 确切800/960/800费率与恢复；finance.settle 阶段时间含工资/日界，不能直接称服务位缓存耗时。 |
| A04 | OPS-21/22/23/27/38/39、OPS-13/14、SPACE-18、OPS-43 | 当前待工单可覆盖活动枚举；没有长期终态历史时不声称历史增长收益。 | OPS-43 的活动ID/取消后历史保留与恢复；维护/环境派工推进的实际 profiler calls/time。 |
| A05 | SPACE-05/09/10/30/33 | 普通运行step没有建造预览/提交，固定160窗口不覆盖该操作。 | 指定建造/连接/切片操作的实际耗时另测；无专属helper微基准，不能用2A模型作为创建实测数。 |
| A06 | OPS-15/16/17、OPS-45 | 组合输入准备中的spawn不属于measured step；只有窗口内真实来源触发才覆盖。 | OPS-45 的187格实查及含视图构建的完整遍历对照时间。 |
| A07 | OPS-30/31/32 | 只在实际登记/错科路由发生时覆盖，已路由GP/门诊不能冒充结构查询覆盖。 | departments 路由/就绪实际调用；未注册到nested profiler的方法不得声称已有分支time。 |
| A08 | SPACE-33/35/36/44、CORE-34、OPS-43 | 普通160临床输入无preparing改建，不覆盖多安排安全查询；OPS-43检查两份真实安排及目标身体/取消。 | OPS-43 具体等待原因及只读/封锁结果；UI批量查询实际耗时由表现分区记录，不与空间重复计数。 |
| A09 | SPACE-08/09/10、OPS-44 | 仅实际存在预约且发生查询/扫掠时覆盖；预约数为0不能证明空间候选收益。 | OPS-44完整预约遍历控制的动态矩形/连续扫掠授权结果；路由time包含其工作，没有独立region计数时不拆占比。 |
| A10 | CORE-18/21/45、OPS-14、OPS-43 | 完整世界校验在输入/加载边界，不是每步成本；固定160.step不覆盖校验算法收益。 | OPS-43 合法单元owner通过/未知owner拒绝；含前提总回归时间不是validate微基准。 |
| A11 | OPS-32/36、CORE-45、OPS-43 | 只有实际离院收尾/小票重读才覆盖；无离院窗口不证明历史账目收益。 | OPS-43 owner ID及待结→已结/恢复结果；实际小票调用time另测，不把finance总phase归给小票。 |
| A12 | OPS-16/17/42、SPACE-09/10、OPS-44 | 全局16份清洁及真实茶位候选搜索在该160输入可覆盖；必须等完整step结束再报告全步收益。 | OPS-44真实路线、公共leg hits/builds及包含batch初始化的时间；160以space.query_counts的实际累计差及plain完整step时间为准。55.35s首步超时没有分支占比。 |

静态 `git diff --check` 无输出；当前没有执行引擎解析、功能回归或性能测试，不表述为通过。完整正式矩阵、742容量及2小时验证保持暂停。
