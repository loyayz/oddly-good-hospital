from pathlib import Path
import zipfile,shutil,hashlib,json,subprocess
root=Path(__file__).resolve().parents[2]; out=Path(__file__).resolve().parent
engine=Path('C:/programs/godot/Godot_v4.7.2-stable_win64_console.exe')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
for side in ['before','after']:
    project=out/(side+'-project')
    if project.exists(): raise SystemExit('Project already exists: '+str(project))
    if side=='before':
        with zipfile.ZipFile(out/'before-source.zip') as z: z.extractall(project)
    else:
        paths=subprocess.check_output(['git','-c','core.quotePath=false','ls-files','--cached','--others','--exclude-standard'],cwd=root,text=True,encoding='utf8').splitlines()
        for relative in sorted(set(paths)):
            if not (relative.startswith(('game/','content/','assets/','addons/source_assets/','tools/performance/','tests/acceptance/')) or relative in ['project.godot','export_presets.cfg']): continue
            p=root/relative
            if not p.is_file(): continue
            dest=project/relative; dest.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(p,dest)
    # Both runs use exactly the same diagnostic driver, not modified business code.
    for p in (root/'tools/performance').glob('representative*.gd'):
        shutil.copy2(p,project/'tools/performance'/p.name)
    shutil.copy2(root/'tools/performance/step_profile.gd',project/'tools/performance/step_profile.gd')
    native=out/'before-native' if side=='before' else root/'game/platform/windows/bin'
    native_dest=project/'game/platform/windows/bin'; native_dest.mkdir(parents=True,exist_ok=True)
    for p in native.glob('*.dll'): shutil.copy2(p,native_dest/p.name)
    shutil.copytree(root/'.godot/imported',project/'.godot/imported',dirs_exist_ok=True)
    p=project/'project.godot'; original=p.read_text(encoding='utf8')
    p.write_text(original.replace('config/custom_user_dir_name="oddly-good-hospital"','config/custom_user_dir_name="OddlyGoodHospital Repeated Repair '+side+' 20261018"'),encoding='utf8',newline='\n')
    sources=[]
    for area in ['game','content','tools/performance','tests/acceptance']:
        for p in sorted((project/area).rglob('*')):
            if p.is_file(): sources.append({'path':p.relative_to(project).as_posix(),'sha256':sha(p)})
    (project/'source-identity.json').write_text(json.dumps({'baseline':'9f7dc5b5274e7d190ad4b58f85c596e0ce06d6b4','side':side,'project':str(project),'engine_sha256':sha(engine),'sources':sources},indent=2),encoding='utf8')
    print(json.dumps({'side':side,'project':str(project),'native_sha256':sha(native_dest/'oddly_good_platform.windows.x86_64.dll'),'sources':len(sources)}),flush=True)
