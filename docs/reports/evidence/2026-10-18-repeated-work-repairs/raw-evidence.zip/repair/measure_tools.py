from pathlib import Path
import sys,json,time,statistics,random,tracemalloc
root=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(root/'tools/performance/acceptance'))
import analyze as after
import analysis_reference as before
out=Path(__file__).resolve().parent
class Clock:
    calls=0
    def map(self,value):
        self.calls+=1
        return (value-2,value+3)
def compatible(a,b):
    if isinstance(a,dict):return a.keys()==b.keys() and all(compatible(a[k],b[k]) for k in a)
    if isinstance(a,(list,tuple)):return len(a)==len(b) and all(compatible(x,y) for x,y in zip(a,b))
    if isinstance(a,float):return abs(a-b)<=1e-8*max(1,abs(a),abs(b))
    return a==b
def measure(name,old,new,details):
    result_old,result_new=old(),new()
    assert compatible(result_old,result_new),name
    rows=[]
    for pair in range(3):
        for label,run in ([('before',old),('after',new)] if pair%2==0 else [('after',new),('before',old)]):
            started=time.perf_counter_ns();run();elapsed=time.perf_counter_ns()-started
            rows.append({'pair':pair+1,'side':label,'elapsed_ns':elapsed})
    peaks={}
    for label,run in [('before',old),('after',new)]:
        tracemalloc.start();run();peaks[label]=tracemalloc.get_traced_memory()[1];tracemalloc.stop()
    medians={label:statistics.median(row['elapsed_ns'] for row in rows if row['side']==label) for label in ['before','after']}
    return {'name':name,'input':details,'equivalent_complete_output':True,'runs':rows,'median_ns':medians,'reduction':1-medians['after']/medians['before'],'traced_peak_bytes':peaks}
rng=random.Random(181018)
definite=[rng.randrange(300000)/1000 for _ in range(4000)]
optional=[rng.randrange(300000)/1000 for _ in range(800)]
limits={'p95_ms':200,'p99_ms':290,'max_ms':300}
reports=[]
if 'T03' not in sys.argv[1:]:
    reports.append(measure('T02',lambda:before.bounded_distribution(definite,optional,1000,limits),lambda:after.bounded_distribution(definite,optional,1000,limits),{'definite':4000,'optional':800,'all_optional_counts_evaluated':801}))
steps=[]
for i in range(6000):
    steps.append({'hospital_session':str(i%3),'started_engine_us':i*10,'elapsed_us':i%10000+10,'main_elapsed_us':i%9000+5,'between_slices_wall_us':20,
                  '_start_bounds':(i*10-3,i*10+3) if i%97 else None,'_completion_bounds':(i*10+5,i*10+8) if i%101 else None})
frames=[{'start_ms':i*10,'duration_ms':i%20+1} for i in range(6000)]
telemetry=[{'kind':'session_state','qpc_ticks':i*60,'engine_us':i*60,'actual_speed':0 if i%10 in (3,4) else 1,'requested_speed':0 if i%10 in (3,4) else 1} for i in range(1000)]
densities=[{'kind':'density','qpc_ticks':i*25,'density_bp':9500} for i in range(2400)]
windows=[(i*1100+5,i*1100+905) for i in range(50)]
def old_windows():
    clock=Clock();result=[]
    for start,end in windows:
        result.append({'speed':before.speed_window(telemetry,steps,clock,start,end,1000,1),
                       'steps':before.step_population(steps,start,end,100,limits),
                       'frames':[f for f in frames if start<=f['start_ms']<end],
                       'density':[d for d in densities if start<=d['qpc_ticks']<end]})
    return {'windows':result,'clock_calls':clock.calls}
def new_windows():
    clock=Clock();si=after.StepWindows(steps);sp=after.SpeedWindows(telemetry,si,clock)
    fi=after.PointWindows(frames,lambda r:r['start_ms']);di=after.PointWindows(densities,lambda r:r['qpc_ticks'])
    result=[]
    for start,end in windows:
        result.append({'speed':after.speed_window(telemetry,steps,clock,start,end,1000,1,sp),
                       'steps':after.step_population(steps,start,end,100,limits,si),
                       'frames':fi.select(start,end),'density':di.select(start,end)})
    return {'windows':result,'clock_calls':clock.calls}
old_count=old_windows()['clock_calls'];new_count=new_windows()['clock_calls']
reports.append(measure('T03',lambda:old_windows()['windows'],lambda:new_windows()['windows'],{'steps':6000,'frames':6000,'session_states':1000,'density':2400,'independent_windows':50,'index_build_included':True,'clock_map_calls_before':old_count,'clock_map_calls_after':new_count}))
record={'diagnostic_only':True,'formal_pass':False,'python':sys.version,'reports':reports,'scope':'Synthetic complete offline populations; no game step, capture or formal acceptance was run.'}
output=out/('tools-measurements-t03-r2.json' if 'T03' in sys.argv[1:] else 'tools-measurements.json')
if output.exists():raise SystemExit('Immutable evidence already exists')
output.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps(record,ensure_ascii=False,indent=2))
