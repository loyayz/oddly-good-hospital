# 表现与容量重复工作修复边界

范围：PRES01～PRES11、CAP01。PRES06 使用招聘服务 `search_status(world)` 窄投影；完整列表继续 query。仅修改本分区生产文件和新增独立验证 helper，不修改专题注册入口，不启动引擎、测试、构建或基准。

| ID | 实施与不变语义 | 所有权/失效 | 选例与理由 |
| --- | --- | --- | --- |
| PRES01 | 一次 update 只求一次可见全局 AABB；每批当前骨矩阵照常发布 | 单次调用局部值，无跨帧缓存 | CORE-31/33/48，多批、空、切院和移动边界 |
| PRES02 | 完成批次内合并员工蒙皮重绑；纯设施发布不重绑；当前 Visit 分组一次。独立 publish_resource 仍同步完成重绑，先拒绝迟到票 | 完成批次局部 defer 标志，旧来源解绑后才能替换，结束统一绑定；外部调用不复用旧分组 | CORE-32/33/48，双 actor/混合/设施、拒绝票和独立入口 |
| PRES03 | 模型首次解析播放器、骨骼、骨索引和剪辑映射；保留首次/后缀匹配顺序与回退、每帧 seek/当前骨姿态 | 缓存在各自根 Node 的 metadata，随实例释放；内容替换生成新实例，不缓存动态姿态 | CORE-33/48，缺片段、低动态和替换 |
| PRES04 | 内容一次建可升级 definition 集合；每 update 一次升级状态索引，保留原最后匹配顺序 | 内容 fingerprint 缓存仅所属 view；升级状态只在本次 update 存活；独立状态入口仍构建当前索引 | CORE-48、OPS-21～27相关状态边界 |
| PRES05 | 方案选项只读对应 disease 的有序方案定义，详情仍实时完整比较；提交报价复核不变 | 无跨刷新报价缓存；直接保留 catalog 原顺序，不增加内容索引 | CLIN-06/13/34、CORE-30/34 |
| PRES06 | 寻访摘要用服务 search_status，不构建简历/标准预览 | 返回当前事实副本；UI 不复制事实所有权 | 招聘相关选例与 CORE-30/34 |
| PRES07 | 在精确原始依赖快照未变时复用几何/环境/热图签名输入投影；每次比较当前字段和顺序，不按 tick/revision 跳过 | view 私有 deep-copy 快照，含世界身份/楼层；直接写入同 tick 也被精确结构比较发现；只在变化时重新投影/JSON，不改变可见业务结果 | CORE-31/33/48，同 tick 直接写入、门适配、脏污、热图事实变化 |
| PRES08 | 可见草案只在发布内容变化时深复制并发信号；继续逐帧 update 确认预算/失效 | 面板保存上次实际发布的独立值；取消/重新绑定清空；精确值比较不盲信 revision | CORE-30/36、SPACE-52 |
| PRES09 | 不规则格局部阻挡集合一次构建；矩形线性路径保持 | 一次 overlay 重建局部集合，原格相等与颜色不变 | SPACE-52与不规则格 helper |
| PRES10 | 导入复合键按实际分隔位置从最长前缀查 staff 字典，不逐键扫全员工 | 单次导入 staff ID 集合；仍最长精确匹配，允许 ID 内冒号，定义字段不改 | CORE-26/27，含冒号/共享前缀与原映射完整比较 |
| PRES11 | 娱乐设施通过已注册集合索引判断资格，保留设施序 | 使用不可变内容注册表，不另建事实缓存 | CORE-34及娱乐选择 |
| CAP01 | 模型建立 resource→node 用户索引；岗位变化只遍历前缀精确命中的资源和实际使用节点，再按原 DAG 顺序传播 enabled | 模型私有不可变索引，所有节点含未达节点；用完整角色 ID 构造前缀及精确 staff 名，不拆冒号；预算和求解缓存原失效保持 | 容量岗位锁定/解锁/冲突、含冒号角色、预算和证书复用；原算法独立对照 |

跨帧的原始依赖比较仍然是必要读取；这项改动移除重复投影分配和 JSON 序列化，不声称所有线性比较都消失。全部旧业务校验、合法候选、资源和阈值保留。独立验证 helper 对新增局部算法与冷旧路径比较；父任务统一注册并串行执行所选回归、原生构建及固定160人快速测量，完整正式验收保持暂停。

## 实施交接

- `hospital_view.gd`：AABB 局部复用；资源完成批次共享当前 Visit 分组，按当前/原批次员工来源决定解绑，完成批次统一重绑。独立 actor 发布同步绑定；纯设施/非员工发布不重建员工页。`_skin_actor_ids` 与实际成功批次同生共清，避免身份删除后漏解绑。
- 播放器/骨骼解析依附模型根 Node，替换实例即换来源；设施代理发布清除先前缺失播放器结果。剪辑名和骨索引分别响应当前固定 Godot 4.7.2 的 `animation_list_changed`、`bone_list_changed` 信号失效。信号已由现有 ABI `extension_api.json` 静态核对，未运行引擎。
- 几何、环境、热图源快照只在精确依赖不相等时 deep-copy；相等时保留同一快照，跳过字段投影和 JSON。字典外部遍历顺序另比较 keys，直接写入不依赖 world.touch。仍需逐帧精确比较，收益待测。
- `remodel_panel.gd` 另外接入运营分区 OP-A08 的 `waiting_all(world)`，同一摘要只提取一批 waiting 理由；服务仍拥有事实和优先级。

独立 helper 注册（父任务统一修改注册文件）：

| 编号 | `tests/acceptance/repeated_presentation.gd` 入口 | 范围 |
| --- | --- | --- |
| CORE-51 | `await run_projection(t,content,case_id)` | 冷/暖依赖投影、同修订直接变化、热图与只读 |
| CORE-52 | `await run_resources(t,content,case_id)` | 多批一次 AABB、同批资源合并、独立/迟到/设施发布、模型解析与信号失效 |
| CORE-53 | `run_ui(t,content,case_id)` | 一次方案比较、提交复核、窄寻访状态、预览发布隔离 |
| CORE-54 | `run_import_overlay(t,content,case_id)` | 原完整 remap 对照，含冒号/共享前缀；不规则预览颜色 |

原生交接命令（尚未执行；输出目录须不存在）：

```powershell
python tests/native/repeated_roles.py --zig .cache/native-math/zig-x86_64-windows-0.15.2/zig.exe --output .cache/repeated-work-repairs-20261018/roles-r1
pwsh -NoProfile -File tools/build-platform-guard.ps1 -GodotPath C:/programs/godot/Godot_v4.7.2-stable_win64_console.exe
```

离线 helper 编译当前源码原样提取的 resource→node 索引构造、角色过滤与 enabled 传播，与原完整节点×角色算法对照；不启动 Godot/求解器，不新增游戏诊断接口。此检查不代替原生集成，重建后选择 GROW-45、80、82 与相关岗位/预算变化边界。源码只做 diff whitespace 核对，Python helper 只做 AST 语法解析；没有运行任何功能 helper、构建或性能测量。
