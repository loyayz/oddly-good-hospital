import hashlib,json,shutil,sys
from pathlib import Path
old=Path('C:/Users/cong/dot-work/ogh-boundary-20261112');base=Path('C:/Users/cong/dot-work/ogh-fixed-boundary-20261112');project=base/'.cache/boundary-project'
repo=Path('C:/Users/cong/dot-work/oddly-good-hospital-handoff-20261112')
assert not base.exists()
meta=json.loads((old/'input-identity.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for rel,digest in meta['source'].items():
 source=old/'.cache/boundary-project'/rel;assert sha(source)==digest,rel
 target=project/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
for source in (old/'.cache/boundary-project/.godot/imported').glob('*'):
 if source.is_file():
  target=project/'.godot/imported'/source.name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
for name,digest in meta['native'].items():
 source=old/'.cache/boundary-project/game/platform/windows/bin'/name;assert sha(source)==digest
 target=project/'game/platform/windows/bin'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
for name in ['prepare_transport_trace.py','transport_diagnostic_trace.gd','prepare_builtin_script_profile.py','campaign160.py','parse_builtin_script_profile.py']:
 dst=base/'tools/performance/current'/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(old/'tools/performance/current'/name,dst)
shutil.copy2(old/'full-terminal.bin',base/'full-terminal.bin')
rel='game/building/hospital_movement.gd';source=repo/rel
assert sha(source)=='fd9d720d6c7688eff475bb15968c64a3e4fcdeb0a2acb8878c00619e1e556ca4'
shutil.copy2(source,project/rel);meta['source'][rel]=sha(source)
meta['scope']='Identical full-world boundary with only validated local rejoin-collision production fix.'
(base/'input-identity.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
sys.path.insert(0,str(base/'tools/performance/current'))
import prepare_builtin_script_profile as guard
print('Import fixed isolated project',flush=True)
guard.run_process([meta['engine'],'--headless','--path',str(project),'--editor','--import','--quit'],project,base/'import',120)
out=base/'plain8/result.json'
print('Run fixed plain eight steps',flush=True)
command=[meta['engine'],'--headless','--path',str(project),'--script','res://tools/performance/current/plain_v4.gd','--','--input='+str(base/'full-terminal.bin'),'--output='+str(out),'--steps=8','--prefix-steps=0','--worker-tasks=4','--main-thread-policy=app']
guard.run_process(command,project,out.parent,120)
result=json.loads(out.read_text());assert result['complete'] and result['all_completed_steps']==8
s=(old/'run_detail8.py').read_text(encoding='utf-8').replace(str(old).replace('\\','/'),str(base).replace('\\','/'))
s=s.replace("(project/'transport-diagnostic-identity.json').rename(project/'transport-diagnostic-identity.second.json')",'')
(base/'run_detail8.py').write_text(s,encoding='utf-8')
print('Run fixed traced eight steps',flush=True)
exec(compile(s,str(base/'run_detail8.py'),'exec'))
assert sha(project/rel)==meta['source'][rel]
