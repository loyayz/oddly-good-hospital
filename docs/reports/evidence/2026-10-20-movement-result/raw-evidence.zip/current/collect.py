import hashlib
import json
import re
import shutil
import subprocess
import zipfile
from pathlib import Path

TASK = Path(__file__).resolve().parent
ROOT = TASK.parents[1]
OLD = ROOT / '.cache/review-2026-10-20'
DEST = ROOT / 'docs/reports/evidence/2026-10-20-movement-result'
DEST.mkdir(parents=True, exist_ok=True)

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

baseline = read(OLD / 'complete-project/source-identity.json')
delivery = read(TASK / 'after-project/source-identity.json')
summary = {'scope': 'Quick verification only; formal acceptance paused.', 'baseline_dev': '1893a398052fef71c2a57530260ea98fa0f31888', 'implementation_head': delivery['head'], 'runs': {}, 'historical_evidence_retained': True, 'measurement_order':'new public/gp/operations, then unchanged control public/gp/operations; not interleaved repetitions'}
for scene in ['public', 'gp', 'operations']:
    for version, path, identity in [('historical', OLD/f'complete-{scene}.json', baseline), ('before', TASK/f'control-{scene}.json', baseline), ('after', TASK/f'{scene}.json', delivery)]:
        value = read(path)
        summary['runs'][f'{version}-{scene}'] = {
            'head': identity['head'], 'native_sha256': identity['native_sha256'],
            'input_sha256': value['source_input_sha256'], 'complete': value['complete'],
            'qualified': value['qualified'], 'qualification': value['qualification'],
            'metrics': value['metrics'], 'errors': value['errors'],
            'public_checks': value.get('public_checks',{}),
            'query_counts': value.get('public',{}).get('query_counts',{}),
            'present_min': value['final']['minimum_present'], 'present_max': value['final']['maximum_present'],
            'same_actor_ids': value['final']['same_actor_ids'],
            'clinical_work_ticks': value['final'].get('work_ticks_by_kind',{}),
            'final_binary_sha256': value['final_binary_sha256'], 'execution': value['execution'],
        }
    assert summary['runs'][f'before-{scene}']['input_sha256'] == summary['runs'][f'after-{scene}']['input_sha256']
summary['same_final_binary_by_scene'] = {scene: summary['runs'][f'before-{scene}']['final_binary_sha256']==summary['runs'][f'after-{scene}']['final_binary_sha256'] for scene in ['public','gp','operations']}
save(DEST/'quick-summary.json', summary)

batches, latest = [], {}
projects = []
for log in sorted(TASK.glob('functional-*.log')):
    match = re.search(r'ACCEPTANCE_PROJECT=(.+)', log.read_text(encoding='utf-8-sig'))
    if not match:
        continue
    project = Path(match.group(1).strip())
    projects.append(project)
    result = read(project/'acceptance-results.json')
    output = (project/'execution.log').read_text(encoding='utf-8-sig')
    batches.append({'log':log.name, 'project_id':project.name,
                    'timing':read(project/'timing-summary.json'),
                    'execution_status':read(project/'execution-status.json'),
                    'checks':result['checks'], 'failed':result['failed'],
                    'script_errors':len(re.findall(r'SCRIPT ERROR:',output)),
                    'exit_warnings':[line for line in output.splitlines() if 'WARNING:' in line or 'leaked' in line]})
    for case, row in result['results'].items():
        latest[case] = {'passed':row['passed'],'project_id':project.name,'requirement':row['requirement'], 'setup_ms':row['setup_ms'],'body_ms':row['body_ms']}
functional = {'latest_unique_cases':len(latest),'latest_passed':sum(row['passed'] for row in latest.values()),'latest_per_case':dict(sorted(latest.items())),'batches':batches}
save(DEST/'functional-summary.json',functional)

def verify(identity, head, check_workspace=False):
    rows = []
    for source in identity['source']:
        if not source['path'].startswith('game/'):
            continue
        blob = subprocess.check_output(['git','show',head+':'+source['path']],cwd=ROOT)
        row = {'path':source['path'],'sha256':source['sha256'],'git_blob_matches':hashlib.sha256(blob).hexdigest()==source['sha256']}
        if check_workspace:
            row['workspace_matches'] = sha(ROOT/source['path'])==source['sha256']
        rows.append(row)
    assert all(row['git_blob_matches'] and row.get('workspace_matches',True) for row in rows)
    return rows

source_check = {'baseline_matches_dev_game':verify(baseline,summary['baseline_dev']), 'delivery_matches_frozen_game':verify(delivery,delivery['head'],True), 'functional_game_matches':{}}
expected_game = {row['path']:row['sha256'] for row in delivery['source'] if row['path'].startswith('game/')}
for project in projects:
    actual_game = {row['path']:row['sha256'] for row in read(project/'source-identity.json')['source'] if row['path'].startswith('game/')}
    source_check['functional_game_matches'][project.name] = expected_game==actual_game
assert all(source_check['functional_game_matches'].values())
source_check['native_unchanged'] = baseline['native_sha256'].lower()==delivery['native_sha256'].lower()
source_check['engine_unchanged'] = baseline['engine_sha256'].lower()==delivery['engine_sha256'].lower()
assert source_check['native_unchanged'] and source_check['engine_unchanged']
save(DEST/'source-check.json',source_check)

commands = {'functional_first':{'shell':'pwsh','command':"& ./tests/run-acceptance.ps1 -CaseId @('SPACE-56','SPACE-53','SPACE-55','SPACE-33','SPACE-35','SPACE-36','STAFF-41','OPS-44','CLIN-25')"}, 'functional_repair':{'shell':'pwsh','command':"& ./tests/run-acceptance.ps1 -CaseId @('OPS-44')"}, 'prepare':['pwsh','-File','tools/performance/prepare.ps1','-Output',str(TASK/'after-project')], 'quick':[], 'control':[]}
for scene, filename, steps in [('public','public-v6.input.bin',300),('gp','gp.input.bin',80),('operations','op.input.bin',40)]:
    commands['quick'].append([delivery['engine'],'--headless','--path',str(TASK/'after-project'),'--script','res://tools/performance/representative.gd','--','--input='+str(ROOT/'.cache/task-navigation-20261019'/filename),'--output='+str(TASK/f'{scene}.json'),'--steps='+str(steps),'--profile=plain'])
    commands['control'].append([baseline['engine'],'--headless','--path',str(OLD/'complete-project'),'--script','res://tools/performance/representative.gd','--','--input='+str(ROOT/'.cache/task-navigation-20261019'/filename),'--output='+str(TASK/f'control-{scene}.json'),'--steps='+str(steps),'--profile=plain'])
save(DEST/'commands.json',commands)

text = (TASK/'report-draft.md').read_text(encoding='utf-8')
section = f"实现冻结为`{delivery['head']}`，原生库SHA256仍为`{delivery['native_sha256'].lower()}`，本轮未修改或重建原生库。\n\n"
section += f"最新有效证据为 **{functional['latest_unique_cases']}项选定用例，{functional['latest_passed']}项通过**："+'、'.join(sorted(latest))+'。\n\n'
section += '''新增SPACE-56覆盖8组字面接触边界，以及真实单人／整组位移、受阻零位移、门等待、阻挡解除后的真实到场、精确次成员归属、同阶段旧组结束后新个人行程和无阻挡主体重查。首批9项中8项通过，OPS-44失败：独立全量预约枚举替身未带生产接口已有的reservation_id，新结果消费该字段时出错。补齐替身身份字段后仅重跑OPS-44通过。原始失败及脚本错误保留，未以首批8项通过宣称整批通过，也未更改碰撞或授权预期。

原有测试中的布尔碰撞观察改为读取本次MotionResult.blocked，门计时替身同步新增结果参数；这些是明确接口变化引起的必要修改，没有重构通用验证工具。JSON缺库提示属于文字修改，检查对应内容，不为其额外运行保存流程。

### 固定合法160人快速对照

历史基线保留上一轮有效证据；逐项核对其游戏文件与基线dev相等。新实现重新冻结独立工程，依次读取同一份公共300步、GP80步和运营40步输入。新窗口大幅变快但公共场景的最终世界及主要计数完全一致，不能直接把全部下降归给移动结果衔接，因此另在当前环境依次回放未修改的同源基线，保留三组结果。计时期间不并行构建或测试。每个窗口检查真实临床工作、完整步、合法世界、同一160人身份和相应公共／运营业务结果。原始SHA256、资格和逐步记录见证据。

单位ms；这是headless/debug引擎中的普通完整模拟步，原生后端O2，不包含渲染、持久化IO及GameSession后台完整742病例准备。顺序为新实现三个窗口，再回放原实现三个窗口，均从冷服务缓存开始；不是交错重复采集。波动不能归因给单一代码项，不能外推Release达标。

| 场景／版本 | 步数 | 均值 | P95 | 最大 | 业务资格 |
| --- | ---: | ---: | ---: | ---: | --- |
'''
for scene,label in [('public','公共设施'),('gp','GP'),('operations','运营')]:
    for version,name in [('historical','历史基线'),('before','本轮基线复测'),('after','补齐后')]:
        run = summary['runs'][f'{version}-{scene}']
        m = run['metrics']
        section += f"| {label}／{name} | {m['count']} | {m['mean_us']/1000:.2f} | {m['p95_us']/1000:.2f} | {m['max_us']/1000:.2f} | {'通过' if run['qualified'] else '未通过'} |\n"
section += '\n'
for scene,label in [('public','公共设施'),('gp','GP'),('operations','运营')]:
    before = summary['runs'][f'before-{scene}']['metrics']['mean_us']
    after = summary['runs'][f'after-{scene}']['metrics']['mean_us']
    section += f"{label}均值变化{(after/before-1)*100:+.1f}%。"
section += '''以上变化以本轮基线复测为分母，不以历史较慢窗口当作单独收益证明。实际值及无收益／退化结果均保留；本轮没有新增阶段内部计时，不拿上一轮阶段占比充当新实现的阶段证据。三个既知性能问题仍待讨论。

本轮相邻新旧版本的三个最终世界二进制摘要各自相同，现有主Space查询计数也各自完全一致；这些计数没有覆盖每次原生宽阶段调用。结果衔接和阻挡主体不重查由SPACE-56独立断言验证。本轮没有证明稳定整步加速，不将小幅波动或历史大幅下降包装成优化收益。

完整逐项时间、首步／后续均值、P50/P95/P99/最大、查询计数、最终世界摘要和源码核验见[证据目录](evidence/2026-10-20-movement-result/README.md)。最终世界二进制是否相同仅作额外观察，规则正确性由规格及独立边界断言定义；精确阻挡选择修复允许产生合法行程差异。
'''
text = text.replace('RESULTS_PENDING',section)
text = text.replace('## 修复与实际交接', '移动结果及精确阻挡交接已补齐，9项相关选定用例的最新证据通过；上轮列明的10项成熟实现均已接入，7项保留理由仍明确。合法160人相邻快速对照全部通过业务资格，但未证明稳定整步加速。\n\n## 修复与实际交接')
(ROOT/'docs/reports/2026-10-20-movement-result-handoff.md').write_text(text,encoding='utf-8')

entries = {}
def add(path, name):
    if path.is_file(): entries[name]=path
for path in TASK.iterdir():
    if path.is_file() and path.suffix in ['.json','.log','.ndjson','.bin','.py','.md']:
        add(path,'current/'+path.name)
for project in projects:
    for name in ['source-identity.json','fixture-config.json','import.log','execution.log','execution-status.json','acceptance-results.json','timing-summary.json']:
        add(project/name,'functional/'+project.name+'/'+name)
add(TASK/'after-project/source-identity.json','source/after-identity.json')
add(TASK/'after-project/import.log','source/after-import.log')
add(OLD/'complete-project/source-identity.json','source/before-identity.json')
for scene in ['public','gp','operations']:
    for suffix in ['.json','.json.steps.ndjson','.json.final.bin','.json.status.json','.log']:
        add(OLD/f'complete-{scene}{suffix}','baseline/'+scene+suffix)
for name in ['public-v6.input.bin','gp.input.bin','op.input.bin']:
    path = ROOT/'.cache/task-navigation-20261019'/name
    add(path,'inputs/'+name)
    add(Path(str(path)+'.provenance.json'),'inputs/'+name+'.provenance.json')
for name in ['quick-summary.json','functional-summary.json','source-check.json','commands.json']:
    add(DEST/name,'summary/'+name)
archive = DEST/'raw-evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as output:
    for name,path in sorted(entries.items()): output.write(path,name)
manifest = [{'entry':name,'bytes':path.stat().st_size,'sha256':sha(path)} for name,path in sorted(entries.items())]
save(DEST/'raw-manifest.json',{'entries':manifest,'archive':{'bytes':archive.stat().st_size,'sha256':sha(archive)}})
with zipfile.ZipFile(archive) as check:
    assert check.testzip() is None
    for row in manifest: assert hashlib.sha256(check.read(row['entry'])).hexdigest()==row['sha256']
(DEST/'README.md').write_text('''# 移动结果交接证据

- [快速对照](quick-summary.json)：原合法160人输入、历史基线、本轮同源基线复测与新实现、完整步耗时、资格和工作量。
- [选例结果](functional-summary.json)：9项选例、首批OPS-44失败及修复重跑，准备和测试时间。
- [源码核验](source-check.json)：基线对dev、交付对冻结游戏文件、两个功能批次来源及未变的引擎／原生库。
- [命令](commands.json)、[原始归档](raw-evidence.zip)、[SHA256清单](raw-manifest.json)。

归档包含原始失败、逐步记录、最终真实世界、输入及来源身份，不包含玩家医院、引擎缓存或二进制依赖。基线来自f830113，同1893a39游戏文件逐项一致；本轮在新实现后回放未修改基线，保留历史窗口，未做交错重复采集。正式性能验收暂停，短窗口不构成Release、全量功能或稳定性通过。
''',encoding='utf-8')
print(json.dumps({'implementation':delivery['head'],'unique_cases':len(latest),'passed':functional['latest_passed'],'game_files_checked':len(expected_game),'archive_entries':len(manifest),'archive_bytes':archive.stat().st_size,'all_quick_qualified':all(row['qualified'] for row in summary['runs'].values())}))
