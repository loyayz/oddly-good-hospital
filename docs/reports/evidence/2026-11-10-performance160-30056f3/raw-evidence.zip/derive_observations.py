import json
from pathlib import Path
import statistics

HERE = Path(__file__).resolve().parent
RUNS = HERE / "runs"
raw = []
stages = []
for repeat in [1, 2, 3]:
    records = [json.loads(line) for line in (RUNS / f"r{repeat}.json.steps.ndjson").read_text(encoding="utf-8").splitlines()]
    raw.append([record["sample"] for record in records if record["kind"] == "complete"][1000:])
    source = json.loads((RUNS / f"r{repeat}.json.stages.json").read_text(encoding="utf-8"))
    stages.append({record["tick"]: record for record in source["step_records"]})

metadata = [[{key: value for key, value in record.items() if key != "elapsed_us"} for record in rows] for rows in raw]
assert metadata[0] == metadata[1] == metadata[2]
load = {"mean_active_moves": statistics.mean(record["moves"] for record in raw[0]),
        "min_active_moves": min(record["moves"] for record in raw[0]),
        "max_active_moves": max(record["moves"] for record in raw[0]),
        "min_present": min(record["present"] for record in raw[0]),
        "max_present": max(record["present"] for record in raw[0]),
        "step_metadata_except_elapsed_equal_across_three": True}
slow = []
for tick in stages[0]:
    movement = [source[tick]["stages"]["movement.space"]["total_us"] for source in stages]
    whole = [source[tick]["outer_elapsed_us"] for source in stages]
    slow.append({"tick": tick, "movement_us": movement, "whole_us": whole,
                 "median_movement_us": statistics.median(movement)})
slow.sort(key=lambda record: record["median_movement_us"], reverse=True)
result = {"load": load, "repeated_slow_ticks_by_median_movement": slow[:10],
          "limits": "Per-step metadata equality and recurring slow intervals are observations, not a function-level attribution or proof of each actor's eventual arrival."}
with (HERE / "derived-observations.json").open("x", encoding="utf-8") as stream:
    json.dump(result, stream, ensure_ascii=False, indent=2)
print(json.dumps(result, ensure_ascii=False))
