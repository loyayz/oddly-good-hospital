from pathlib import Path
import sys,json,hashlib,os,platform,importlib.util,traceback,subprocess
B=Path(__file__).resolve().parent;root=B.parent;R=root/'oddly-good-hospital-cloud-recovery-20261112'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,v):Path(p).write_text(json.dumps(v,indent=2))
def host():
 d={'node_sha256':hashlib.sha256(platform.node().encode()).hexdigest(),'cpu_count':os.cpu_count(),'affinity':sorted(os.sched_getaffinity(0))}
 for path in ['/proc/meminfo','/proc/stat','/sys/fs/cgroup/cpu.max','/sys/fs/cgroup/cpu.stat','/sys/fs/cgroup/memory.max','/sys/fs/cgroup/memory.current']:
  try:d[path]=Path(path).read_text()
  except OSError:d[path]='unavailable'
 return d
cfg=json.loads((root/'root-stage-recovery-20261112/config.json').read_text())
for p,h in cfg['locked_files'].items():assert sha(p)==h,p
for proc in Path('/proc').iterdir():
 if proc.name.isdigit():
  try:comm=(proc/'comm').read_text().strip()
  except OSError:continue
  assert not comm.lower().startswith('godot'),f'engine slot busy: {proc.name}'
spec=importlib.util.spec_from_file_location('safe_lifecycle_guard',root/'root-stage-recovery-20261112/linux_guard_v2.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g);g.PROJECT=R;g.LIBRARY_PATH=cfg['library_path']
assert len(sys.argv)==4 and sys.argv[3]=='PARENT_RELEASED', 'Explicit subsequent parent release required'
mode,runid=sys.argv[1:3];assert mode in ['parse','continue']
identity=json.loads((B/'prepared-identity.json').read_text())
for rel,digest in identity['sources'].items():assert sha(R/rel)==digest,rel
assert sha(identity['input'])==identity['input_sha256']
extra=[identity['input']] if mode=='continue' else []
out=B/runid;out.mkdir(exist_ok=False)
import shutil
shutil.copytree(B/'sources',out/'sources')
shutil.copy2(B/'prepared-identity.json',out/'prepared-identity.json')
shutil.copy2(__file__,out/'run_prepared.py')
shutil.copy2(spec.origin,out/'linux_guard_v2.py')
shutil.copy2(identity['input'],out/'input.bin')
extra=[str(out/'input.bin')] if mode=='continue' else []
write(out/'identity.json',{'engine':cfg['engine'],'locked_files':cfg['locked_files'],'test_sha':sha(R/'tests/acceptance/run_upgrade_continuation.gd'),'guard_sha':sha(spec.origin),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'clinical_source_sha':sha(R/'game/clinic/clinical_runtime.gd')})
cmd=[cfg['engine'],'--headless','--path',str(R),'--script','res://tests/acceptance/run_upgrade_continuation.gd']
cmd+=['--check-only'] if mode=='parse' else ['--',mode,str(out),*extra]
write(out/'host-before.json',host())
try:g.run(cmd,out/'engine',timeout=600,allowed_exits=(0,1))
except BaseException:write(out/'error.json',{'traceback':traceback.format_exc()});raise
finally:write(out/'host-after.json',host())
print(mode,json.loads((out/'engine/process.json').read_text())['returncode'])
