from pathlib import Path
p=Path('oddly-good-hospital-cloud-recovery-20261112/game/building/hospital_transit.gd');s=p.read_text()
def rep(a,b):
 global s
 assert s.count(a)==1,(a[:70],s.count(a));s=s.replace(a,b)
rep('''				var rect: Rect2 = space._unit_rect(world,actor,Vector2(cell),members,offsets)
				if rect.intersects(exit,false) or not space.static_reason(world,actor,floor_id,cell,members,offsets).is_empty() or not space._dynamic_clear(world,actor.id,floor_id,rect,members):''','''				var path: Dictionary = space._floor_route(world,actor,floor_id,anchor,cell,members,offsets)
				if not path.ok: continue
				var previous: Vector2=ConvoyTrail.point(actor.location.cell)
				var facing: float=float(actor.facing)
				for segment: Dictionary in path.path:
					var next: Vector2=ConvoyTrail.point(segment.cell)
					if next!=previous: facing=atan2(next.x-previous.x,next.y-previous.y)
					previous=next
				var sample: Dictionary=actor.duplicate();sample.facing=facing
				var rect: Rect2 = _unit_at_facing(space,world,actor,Vector2(cell),members,offsets,facing)
				if rect.intersects(exit,false) or not space.static_reason(world,sample,floor_id,cell,members,offsets).is_empty() or not space._dynamic_clear(world,actor.id,floor_id,rect,members):''')
rep('''				var path: Dictionary = space._floor_route(world,actor,floor_id,anchor,cell,members,offsets)
				if path.ok:
					space.movement.queue_waypoint(world,movement,floor_id,[cell.x,cell.y],true)
					if movement.has("transit_ticket"):
						movement.transit_wait={"sequence":movement.request_sequence,"cell":[cell.x,cell.y]}
					return''','''				space.movement.queue_waypoint(world,movement,floor_id,[cell.x,cell.y],true)
				if movement.has("transit_ticket"):
					movement.transit_wait={"sequence":movement.request_sequence,"cell":[cell.x,cell.y]}
				return''')
rep('''	return space._unit_rect(world,world.facts.actors[id],ConvoyTrail.point(connection.anchor),m.get("members",[id]),m.get("offsets",{}))''','''	var actor: Dictionary=world.facts.actors[id]
	var origin: Vector2=ConvoyTrail.point(connection.anchor)
	var members: Array=m.get("members",[id])
	var offsets: Dictionary=m.get("offsets",{})
	# Candidate exclusion only, not a reservation. Preserve the current
	# footprint and both possible orthogonal approach orientations.
	var rect: Rect2=space._unit_rect(world,actor,origin,members,offsets)
	for facing: float in [0.0,PI*0.5]:
		rect=rect.merge(_unit_at_facing(space,world,actor,origin,members,offsets,facing))
	return rect

static func _unit_at_facing(space: HospitalSpace, world: WorldState, actor: Dictionary, origin: Vector2, members: Array, offsets: Dictionary, facing: float) -> Rect2:
	var sample: Dictionary=actor.duplicate();sample.facing=facing
	var rect: Rect2=space._actor_rect(sample,origin)
	# _move_step rotates every non-convoy member to the same actual leg.
	# Current valid saves require groups to use convoy, whose portal branch
	# above already supplies its complete authoritative envelope.
	for id: String in members:
		if id==actor.id: continue
		sample=world.facts.actors[id].duplicate();sample.facing=facing
		rect=rect.merge(space._actor_rect(sample,origin+ConvoyTrail.point(offsets[id])))
	return rect''')
p.write_bytes(s.encode())
