from pathlib import Path
import json,hashlib,subprocess,zipfile,difflib
b=Path(__file__).resolve().parent;r=b.parent/'oddly-good-hospital-cloud-recovery-20261112'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2))
report=r/'docs/reports/2026-11-12-transit-waiting-orientation.md'
s=report.read_text()+'''
## 最终单一完整标准例
在上述40/240/120历史原始结果保留后，协调者依据真实运输阶段及逐腿离散余程批准一次400tick固定帽完整例，不是更改业务或性能门槛。full-final01从stop-body01完整preWorld恢复，输入逐字相同；362个原0.1秒movement ticks真实到达两原目标后立即停止。原request/目标每步保留、保护体每步不动、身体/扫掠/步长、World合法、实际服务顺序、选点修正、selected朝向几何和查询只读均通过。默认fresh fixture现在也包含真实protected S52，默认full帽400；本次验证明确使用原完整输入运行full流程，不声称新医院随机身份与原输入相同。原40-stop模式保留为候选定向防回退。

生产最终SHA：hospital_movement c8b025c0872fad84b71623234fb8f3bfdce9abe9f81d1f64062d7e5f4b912e78；hospital_transit 1bf9996caa46f6983b7d7e258011c0b984bb1ac16338959e8262a16080a37fc9；world_state 349e096840a646d83cafa08694eeb7b4ece56d9b2f5abb01c50332353694edeb。已无活动引擎，全部run进程reaped。最终完整例耗时见runs.json（包含引擎启动，非性能指标）。停止修改/运行，等待统一发布。
'''
report.write_text(s);(b/'report.md').write_text(s)
uid={str(p.relative_to(r)):sha(p) for p in r.rglob('*.uid')};old=json.loads((b.parent/'upgrade-handoff-20261112/uid-before.json').read_text());assert uid==old
write(b/'uid-proof.json',{'count':len(uid),'same_as_prior':True,'files':uid})
runs=[]
for p in sorted(b.glob('*/engine/process.json')):
 d=json.loads(p.read_text());assert d['reaped'] and not d['timed_out'];runs.append({'run':p.parent.parent.name,'exit':d['returncode'],'wall_seconds':d['wall_seconds'],'reaped':True,'command':d['command']})
write(b/'runs.json',runs)
assert sha(b/'stop-body01/preWorld.bin')==sha(b/'full-final01/preWorld.bin')
write(b/'input-qualification.json',{'old_input_sha256':sha(b/'stop-body01/preWorld.bin'),'final_input_sha256':sha(b/'full-final01/preWorld.bin'),'byte_equal':True,'stage1_archive_sha256':'12fb7dcac4760e17b82ab2d667abbe5ae66bcc221d89b3780734506c0964263c','stage1_immutable':True})
files=['game/building/hospital_movement.gd','game/building/hospital_transit.gd','game/sim/world_state.gd','tests/acceptance/transit_waiting_identity.gd','tests/acceptance/transit_waiting_non_square.gd','tests/acceptance/connector_prefix_chain.gd','tests/acceptance/run_upgrade_continuation.gd']
(b/'final-source').mkdir(exist_ok=True)
for name in files:(b/'final-source'/Path(name).name).write_bytes((r/name).read_bytes())
write(b/'final-source/sha256.json',{name:sha(r/name) for name in files})
base=(b.parent/'transit-waiting-identity-20261112/final-source/hospital_transit.gd').read_text().splitlines(True);new=(r/'game/building/hospital_transit.gd').read_text().splitlines(True)
(b/'stage2-transit-only.patch').write_text(''.join(difflib.unified_diff(base,new,fromfile='stage1/hospital_transit.gd',tofile='stage2/hospital_transit.gd')))
(b/'all-uncommitted.patch').write_bytes(subprocess.check_output(['git','diff','--',*files],cwd=r))
write(b/'summary.json',{'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'all_processes_reaped':True,'uid_663_unchanged':True,'full_final_ticks':362,'full_final_passed':True,'old_failures_retained':['initial01','stop-body01','corrected-flow01','tail01'],'no_long_upgrade_run':True,'upgrade_parser_sha':'3f8d8a5d4ed09e10589d78b8ca708789336c7a470f0d8f53036f9b56907dcc55','metadata_caveat':'Before tail-audit01 identity.test_sha names non_square fixture even when command executes waiting/upgrade script; real command and source hashes identify executed source. No old outputs overwritten.'})
exclude={'waiting-orientation-stage2.zip','members.json','package-result.json'}
paths=[p for p in b.rglob('*') if p.is_file() and p.name not in exclude and '__pycache__' not in p.parts]
manifest={str(p.relative_to(b)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in paths};write(b/'members.json',manifest)
z=b/'waiting-orientation-stage2.zip'
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as f:
 for p in paths+[b/'members.json']:f.write(p,str(p.relative_to(b)))
with zipfile.ZipFile(z) as f:
 assert f.testzip() is None
 for n,v in manifest.items():assert hashlib.sha256(f.read(n)).hexdigest()==v['sha256']
result={'path':str(z),'sha256':sha(z),'bytes':z.stat().st_size,'members':len(paths)+1};write(b/'package-result.json',result);print(json.dumps(result))
