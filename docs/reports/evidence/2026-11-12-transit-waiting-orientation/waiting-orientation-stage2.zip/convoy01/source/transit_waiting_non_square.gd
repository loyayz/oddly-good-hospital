extends "res://tests/acceptance/transit_busy_recovery.gd"

class ContactMovement extends HospitalMovement:
	var contacts: Array=[]
	func _init(geometry: HospitalSpace) -> void: super(geometry)
	func _local_collision(world: WorldState, actor: Dictionary, movement: Dictionary, contact: HospitalMovement.MotionResult) -> void:
		contacts.append({"tick":world.sim_tick,"id":actor.id,"blockers":contact.blocker_actor_ids.duplicate(),"requested":[contact.requested_motion.x,contact.requested_motion.y],"actual":[contact.actual_motion.x,contact.actual_motion.y]})
		super._local_collision(world,actor,movement,contact)

func _run() -> void:
	suite.content=HospitalContent.new()
	var out: String=OS.get_cmdline_user_args()[0]
	var stop_body: bool=OS.get_cmdline_user_args().size()>1 and OS.get_cmdline_user_args()[1]=="stop_body"
	var sim: HospitalSimulation=suite._transit_fixture()
	var world: WorldState=sim.world
	var c: Dictionary=world.facts.connectors[suite._connection(sim)]
	suite._add_actor(sim,"aaa_incoming","S49",c.anchor,1)
	suite._add_actor(sim,"leader","S69",c.anchor,2)
	suite._add_actor(sim,"zzz_later","S52",[38,78],2)
	if stop_body: suite._add_actor(sim,"protected","S52",[38,76],2)
	var observer: ContactMovement=ContactMovement.new(sim.space)
	sim.space.movement=observer
	world.facts.actors.leader.facing=0.0
	world.facts.actors.zzz_later.facing=0.0
	var requests: Dictionary={}
	requests.incoming=sim.space.request_move(world,"aaa_incoming",2,[44,86])
	requests.leader=sim.space.request_move(world,"leader",1,[44,82])
	requests.later=sim.space.request_move(world,"zzz_later",1,[48,86])
	var args: PackedStringArray=OS.get_cmdline_user_args()
	if args.size()>2:
		var loaded: Dictionary=FileAccess.open(args[2],FileAccess.READ).get_var()
		sim.dispose();sim=HospitalSimulation.new(WorldState.new(loaded.duplicate(true)),suite.content);world=sim.world;c=world.facts.connectors[suite._connection(sim)]
		observer=ContactMovement.new(sim.space);sim.space.movement=observer
	var input: Dictionary=world.freeze().duplicate(true)
	var selected_envelope: Rect2=HospitalTransit._selected_entry(sim.space,world,c,"leader")
	var selected_original: Rect2=sim.space._actor_rect(world.facts.actors.leader,ConvoyTrail.point(c.anchor))
	var sample: Dictionary=world.facts.actors.zzz_later.duplicate();sample.facing=0.0
	var hypothetical_stop: Rect2=sim.space._actor_rect(sample,ConvoyTrail.point(c.anchor)+Vector2.RIGHT)
	var selected_orientation_guard: bool=not selected_original.intersects(hypothetical_stop,false) and selected_envelope.intersects(hypothetical_stop,false)
	var geometry_read_only: bool=world.freeze()==input
	FileAccess.open(out+"/preWorld.bin",FileAccess.WRITE).store_var(input)
	var error: String=world.validate(suite.content)
	var safe: bool=_floor_safety(sim,world.facts.actors.duplicate(true))
	var initial_static: Dictionary={}
	for id: String in ["leader","zzz_later"]:
		var actor: Dictionary=world.facts.actors[id]
		var point: Vector2=ConvoyTrail.point(actor.location.cell)
		initial_static[id]=sim.space.navigation.structural_clearance(world,actor,int(actor.location.floor_id)).sweep_reason(point,point)
	var frames: Array=[]
	var choices: Array=[]
	var order: Array=[]
	var seen: Dictionary={}
	var reached: bool=false
	for step: int in (40 if stop_body else 240):
		if not error.is_empty() or not safe or not requests.values().all(func(v: String)->bool:return v.is_empty()) or not initial_static.values().all(func(v: String)->bool:return v.is_empty()): break
		var before: Dictionary=world.facts.actors.duplicate(true)
		suite._movement_tick(sim)
		for id: String in ["leader","zzz_later"]:
			var m: Dictionary=world.facts.moves.get(id,{})
			if m.has("route_waypoint"):
				var key: String=id+str(m.route_waypoint.cell)
				if not seen.has(key):
					seen[key]=true
					choices.append({"tick":world.sim_tick,"id":id,"actor":world.facts.actors[id].duplicate(true),"waypoint":m.route_waypoint.duplicate(true),"selected":c.get("assigned_actor_id",""),"phase":c.phase,"actors":world.facts.actors.duplicate(true)})
		var primary: String=c.get("primary_actor_id","")
		if not primary.is_empty() and not order.has(primary):order.append(primary)
		safe=safe and _floor_safety(sim,before)
		error=world.validate(suite.content)
		frames.append({"tick":world.sim_tick,"actors":world.facts.actors.duplicate(true),"moves":world.facts.moves.duplicate(true),"connector":c.duplicate(true)})
		if not world.facts.moves.has("leader") and not world.facts.moves.has("zzz_later"):
			reached=sim.space.at(world,"leader",1,[44,82]) and sim.space.at(world,"zzz_later",1,[48,86]);break
	var result: Dictionary={"ok":reached and safe and error.is_empty(),"requests":requests,"initial_static":initial_static,"safe":safe,"valid":error,"reached_both":reached,"ticks":frames.size(),"order":order,"choices":choices,"final_moves":world.facts.moves.duplicate(true),"contacts":observer.contacts,"selected_orientation_guard":selected_orientation_guard,"geometry_read_only":geometry_read_only,"stop_choice_safe":not choices.any(func(choice: Dictionary)->bool:return choice.id=="leader" and ConvoyTrail.point(choice.waypoint.cell)==Vector2(37,76))}
	if stop_body: result.ok=safe and error.is_empty() and result.stop_choice_safe
	result.ok=result.ok and selected_orientation_guard and geometry_read_only
	FileAccess.open(out+"/frames.bin",FileAccess.WRITE).store_var(frames)
	FileAccess.open(out+"/final.bin",FileAccess.WRITE).store_var(world.freeze())
	FileAccess.open(out+"/result.json",FileAccess.WRITE).store_string(JSON.stringify(result,"  "))
	sim.dispose();quit(0 if result.ok else 1)
