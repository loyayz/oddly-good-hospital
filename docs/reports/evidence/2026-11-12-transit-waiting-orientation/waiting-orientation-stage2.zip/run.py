from pathlib import Path
import sys,json,hashlib,os,platform,importlib.util,traceback,subprocess
B=Path(__file__).resolve().parent;root=B.parent;R=root/'oddly-good-hospital-cloud-recovery-20261112'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,v):Path(p).write_text(json.dumps(v,indent=2))
def host():
 d={'node_sha256':hashlib.sha256(platform.node().encode()).hexdigest(),'cpu_count':os.cpu_count(),'affinity':sorted(os.sched_getaffinity(0))}
 for path in ['/proc/meminfo','/proc/stat','/sys/fs/cgroup/cpu.max','/sys/fs/cgroup/cpu.stat','/sys/fs/cgroup/memory.max','/sys/fs/cgroup/memory.current']:
  try:d[path]=Path(path).read_text()
  except OSError:d[path]='unavailable'
 return d
cfg=json.loads((root/'root-stage-recovery-20261112/config.json').read_text())
for p,h in cfg['locked_files'].items():assert sha(p)==h,p
for proc in Path('/proc').iterdir():
 if proc.name.isdigit():
  try:comm=(proc/'comm').read_text().strip()
  except OSError:continue
  assert not comm.lower().startswith('godot'),f'engine slot busy: {proc.name}'
spec=importlib.util.spec_from_file_location('safe_lifecycle_guard',root/'root-stage-recovery-20261112/linux_guard_v2.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g);g.PROJECT=R;g.LIBRARY_PATH=cfg['library_path']
mode,runid,*extra=sys.argv[1:];out=B/runid;out.mkdir(exist_ok=False)
write(out/'identity.json',{'engine':cfg['engine'],'locked_files':cfg['locked_files'],'test_sha':sha(R/'tests/acceptance/transit_waiting_non_square.gd'),'guard_sha':sha(spec.origin),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'clinical_source_sha':sha(R/'game/clinic/clinical_runtime.gd')})
if mode=='chain':
 script='res://tests/acceptance/connector_prefix_chain.gd'
elif mode=='waiting': script='res://tests/acceptance/transit_waiting_identity.gd'
elif mode=='parse-upgrade': script='res://tests/acceptance/run_upgrade_continuation.gd'
else: script='res://tests/acceptance/transit_waiting_non_square.gd'
identity=json.loads((out/'identity.json').read_text())
identity['non_square_fixture_sha']=identity.pop('test_sha')
identity['executed_script']=script
identity['test_sha']=sha(R/script.removeprefix('res://'))
write(out/'identity.json',identity)
cmd=[cfg['engine'],'--headless','--path',str(R),'--script',script]
cmd+=['--check-only'] if mode in ['parse','parse-upgrade'] else (['--','chain',str(out),*extra] if mode=='chain' else ['--',str(out),*extra])
(out/'source').mkdir()
for n in ['game/building/hospital_movement.gd','game/building/hospital_transit.gd','game/sim/world_state.gd','tests/acceptance/transit_waiting_non_square.gd','tests/acceptance/connector_prefix_chain.gd','tests/acceptance/transit_waiting_identity.gd','tests/acceptance/run_upgrade_continuation.gd']:
 (out/'source'/Path(n).name).write_bytes((R/n).read_bytes())
write(out/'source/sha256.json',{p.name:sha(p) for p in (out/'source').iterdir()})
native=R/'game/platform/linux/bin/oddly_good_platform.linux.x86_64.so'
assert sha(native)=='3e97c961acf01e178046efc14b5dff786a83b4e91f09638528ccf531b248d379'
write(out/'native.json',{'path':str(native),'sha256':sha(native)})
write(out/'host-before.json',host())
try:g.run(cmd,out/'engine',timeout=600,allowed_exits=(0,1))
except BaseException:write(out/'error.json',{'traceback':traceback.format_exc()});raise
finally:write(out/'host-after.json',host())
print(mode,json.loads((out/'engine/process.json').read_text())['returncode'])
