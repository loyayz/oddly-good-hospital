extends "res://game/community/research_service.gd"
var _acceptance_timing: RefCounted
func boundaries(world: WorldState) -> void:
	var started: int = Time.get_ticks_usec()
	super.boundaries(world)
	_acceptance_timing.count("service.research.boundaries",started)
func advance(world: WorldState) -> void:
	var started: int = Time.get_ticks_usec()
	super.advance(world)
	_acceptance_timing.count("service.research.advance",started)
func settle(world: WorldState) -> void:
	var started: int = Time.get_ticks_usec()
	super.settle(world)
	_acceptance_timing.count("service.research.settle",started)
