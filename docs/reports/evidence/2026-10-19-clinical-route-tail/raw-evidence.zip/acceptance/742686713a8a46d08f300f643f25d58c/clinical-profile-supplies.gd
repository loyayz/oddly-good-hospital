extends "res://game/operations/supply_service.gd"
var _acceptance_timing: RefCounted
func boundaries(world: WorldState) -> void:
	var started: int = Time.get_ticks_usec()
	super.boundaries(world)
	_acceptance_timing.count("service.supplies.boundaries",started)
func advance(world: WorldState) -> void:
	var started: int = Time.get_ticks_usec()
	super.advance(world)
	_acceptance_timing.count("service.supplies.advance",started)
