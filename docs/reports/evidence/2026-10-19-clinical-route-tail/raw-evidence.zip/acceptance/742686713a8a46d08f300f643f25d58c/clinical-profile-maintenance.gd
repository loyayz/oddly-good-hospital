extends "res://game/operations/maintenance_service.gd"
var _acceptance_timing: RefCounted
func boundaries(world: WorldState) -> void:
	var started: int = Time.get_ticks_usec()
	super.boundaries(world)
	_acceptance_timing.count("service.maintenance.boundaries",started)
func dispatch(world: WorldState) -> void:
	var started: int = Time.get_ticks_usec()
	super.dispatch(world)
	_acceptance_timing.count("service.maintenance.dispatch",started)
func advance(world: WorldState) -> void:
	var started: int = Time.get_ticks_usec()
	super.advance(world)
	_acceptance_timing.count("service.maintenance.advance",started)
