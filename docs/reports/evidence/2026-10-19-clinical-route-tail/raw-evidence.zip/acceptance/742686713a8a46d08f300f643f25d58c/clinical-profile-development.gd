extends "res://game/staff/clinical_development.gd"
var _acceptance_timing: RefCounted
func dispatch(world: WorldState) -> void:
	var started: int = Time.get_ticks_usec()
	super.dispatch(world)
	_acceptance_timing.count("service.development.dispatch",started)
func advance(world: WorldState) -> void:
	var started: int = Time.get_ticks_usec()
	super.advance(world)
	_acceptance_timing.count("service.development.advance",started)
func settle(world: WorldState) -> void:
	var started: int = Time.get_ticks_usec()
	super.settle(world)
	_acceptance_timing.count("service.development.settle",started)
