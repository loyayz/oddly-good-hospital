extends "res://game/staff/staff_wellbeing.gd"
var _acceptance_timing: RefCounted
func dispatch(world: WorldState) -> void:
	var started: int = Time.get_ticks_usec()
	super.dispatch(world)
	_acceptance_timing.count("service.wellbeing.dispatch",started)
func boundaries(world: WorldState) -> void:
	var started: int = Time.get_ticks_usec()
	super.boundaries(world)
	_acceptance_timing.count("service.wellbeing.boundaries",started)
func advance(world: WorldState, worked: Dictionary = {}, before_movement: Dictionary = {}) -> void:
	var started: int = Time.get_ticks_usec()
	super.advance(world,worked,before_movement)
	_acceptance_timing.count("service.wellbeing.advance",started)
