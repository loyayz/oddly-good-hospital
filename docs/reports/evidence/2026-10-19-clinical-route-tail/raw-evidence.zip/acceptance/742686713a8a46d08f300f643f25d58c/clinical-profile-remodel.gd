extends "res://game/building/remodel_service.gd"
var _acceptance_timing: RefCounted
func dispatch(world: WorldState) -> void:
	var started: int = Time.get_ticks_usec()
	super.dispatch(world)
	_acceptance_timing.count("service.remodel.dispatch",started)
