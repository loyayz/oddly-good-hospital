extends "res://game/operations/environment_service.gd"
var _acceptance_timing: RefCounted
func dispatch(world: WorldState) -> void:
	var started: int = Time.get_ticks_usec()
	super.dispatch(world)
	_acceptance_timing.count("service.environment.dispatch",started)
func advance(world: WorldState) -> void:
	var started: int = Time.get_ticks_usec()
	super.advance(world)
	_acceptance_timing.count("service.environment.advance",started)
func _wall_between(world: WorldState, floor_id: int, first: Array, second: Array) -> bool:
	var started: int = Time.get_ticks_usec()
	var result: bool = super._wall_between(world,floor_id,first,second)
	_acceptance_timing.count("service.environment._wall_between",started)
	return result
func _coverage_edges(world: WorldState, floor_id: int) -> Dictionary:
	var started: int = Time.get_ticks_usec()
	var result: Dictionary = super._coverage_edges(world,floor_id)
	_acceptance_timing.count("service.environment._coverage_edges",started)
	return result
func _edge_open(world: WorldState, floor_id: int, first: Array, second: Array, noise: bool, edges: Dictionary = {}) -> bool:
	var started: int = Time.get_ticks_usec()
	var result: bool = super._edge_open(world,floor_id,first,second,noise,edges)
	_acceptance_timing.count("service.environment._edge_open",started)
	return result
func _coverage(world: WorldState, floor_id: int, origin: Array, radius: int, noise: bool, edges: Dictionary = {}) -> Dictionary:
	var started: int = Time.get_ticks_usec()
	var result: Dictionary = super._coverage(world,floor_id,origin,radius,noise,edges)
	_acceptance_timing.count("service.environment._coverage",started)
	return result
func environment_at(world: WorldState, floor_id: int, cell: Array, actor_id: String = "", explain: bool = true) -> Dictionary:
	var started: int = Time.get_ticks_usec()
	var result: Dictionary = super.environment_at(world,floor_id,cell,actor_id,explain)
	_acceptance_timing.count("service.environment.environment_at",started)
	return result
func _water_usable(world: WorldState, facility: Dictionary, actor_id: String) -> bool:
	var started: int = Time.get_ticks_usec()
	var result: bool = super._water_usable(world,facility,actor_id)
	_acceptance_timing.count("service.environment._water_usable",started)
	return result
