extends "res://game/operations/department_service.gd"
var _acceptance_timing: RefCounted
func dispatch(world: WorldState) -> void:
	var started: int = Time.get_ticks_usec()
	super.dispatch(world)
	_acceptance_timing.count("service.departments.dispatch",started)
func advance(world: WorldState) -> void:
	var started: int = Time.get_ticks_usec()
	super.advance(world)
	_acceptance_timing.count("service.departments.advance",started)
func sample(world: WorldState) -> void:
	var started: int = Time.get_ticks_usec()
	super.sample(world)
	_acceptance_timing.count("service.departments.sample",started)
func settle(world: WorldState) -> void:
	var started: int = Time.get_ticks_usec()
	super.settle(world)
	_acceptance_timing.count("service.departments.settle",started)
