extends "res://game/economy/finance_service.gd"
var _acceptance_timing: RefCounted
func settle(world: WorldState) -> void:
	var started: int = Time.get_ticks_usec()
	super.settle(world)
	_acceptance_timing.count("service.finance.settle",started)
