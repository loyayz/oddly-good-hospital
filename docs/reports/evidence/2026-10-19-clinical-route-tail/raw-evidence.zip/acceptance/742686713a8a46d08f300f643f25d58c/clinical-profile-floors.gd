extends "res://game/building/floor_service.gd"
var _acceptance_timing: RefCounted
func dispatch(world: WorldState) -> void:
	var started: int = Time.get_ticks_usec()
	super.dispatch(world)
	_acceptance_timing.count("service.floors.dispatch",started)
func advance(world: WorldState) -> void:
	var started: int = Time.get_ticks_usec()
	super.advance(world)
	_acceptance_timing.count("service.floors.advance",started)
