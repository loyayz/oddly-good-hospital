extends "res://game/arrivals/arrival_service.gd"
var _acceptance_timing: RefCounted
func boundaries(world: WorldState) -> bool:
	var started: int = Time.get_ticks_usec()
	var result: bool = super.boundaries(world)
	_acceptance_timing.count("service.arrivals.boundaries",started)
	return result
func arrivals(world: WorldState) -> void:
	var started: int = Time.get_ticks_usec()
	super.arrivals(world)
	_acceptance_timing.count("service.arrivals.arrivals",started)
func advance_wait(world: WorldState) -> void:
	var started: int = Time.get_ticks_usec()
	super.advance_wait(world)
	_acceptance_timing.count("service.arrivals.advance_wait",started)
func needs(world: WorldState) -> void:
	var started: int = Time.get_ticks_usec()
	super.needs(world)
	_acceptance_timing.count("service.arrivals.needs",started)
func settle(world: WorldState) -> void:
	var started: int = Time.get_ticks_usec()
	super.settle(world)
	_acceptance_timing.count("service.arrivals.settle",started)
