extends SceneTree

class DetailClinic extends HospitalClinic:
	var details: RefCounted
	func service_candidates(world: WorldState, visit: Dictionary, kind: String, structural_only: bool = false, reference_schedule: bool = false, selection: Dictionary = {}) -> Array:
		var entry: Dictionary = {"visit":visit.id,"actor":visit.actor_id,"kind":kind,"structural":structural_only,"floor":world.facts.actors[visit.actor_id].location,"facilities":{},"started":Time.get_ticks_usec()}
		details.active.append(entry)
		var result: Array = super.service_candidates(world,visit,kind,structural_only,reference_schedule,selection)
		entry.elapsed_us = Time.get_ticks_usec()-int(entry.started)
		entry.erase("started")
		entry.candidates = result.size()
		details.active.pop_back()
		details.queries.append(entry)
		return result

class DetailSpace extends HospitalSpace:
	var details: RefCounted
	func route(world: WorldState, actor_id: String, floor_id: int, target: Array, members: Array = [], offsets: Dictionary = {}, ignore_people: bool = false) -> Dictionary:
		var result: Dictionary = super.route(world,actor_id,floor_id,target,members,offsets,ignore_people)
		if not details.active.is_empty():
			var row: Dictionary = details.active.back()
			var reasons: Dictionary = row.get("routes",{})
			var key: String = str(result.get("status",""))+":"+str(result.get("reason","ok"))
			reasons[key] = int(reasons.get(key,0))+1
			row.routes = reasons
		return result
	func facility_quote(world: WorldState, facility_id: String, actor_id: String, staff_ids: Array = []) -> Dictionary:
		var started: int = Time.get_ticks_usec()
		var result: Dictionary = super.facility_quote(world,facility_id,actor_id,staff_ids)
		if not details.active.is_empty():
			var row: Dictionary = details.active.back()
			var key: String = str(result.get("reason","ok"))
			var counts: Dictionary = row.facilities.get(key,{"calls":0,"total_us":0})
			counts.calls += 1
			counts.total_us += Time.get_ticks_usec()-started
			row.facilities[key] = counts
		return result

class DetailProfile extends "res://tools/performance/step_profile.gd":
	var queries: Array = []
	var active: Array = []
	func _wrap(original: RefCounted, group: String, arguments: Array) -> RefCounted:
		var result: RefCounted
		if group=="clinic": result = DetailClinic.new(arguments[0],arguments[1])
		elif group=="space": result = DetailSpace.new(arguments[0])
		else: return super._wrap(original,group,arguments)
		_copy_script_properties(original,result)
		result.details = self
		return result

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var options: Dictionary = {}
	for argument: String in OS.get_cmdline_user_args():
		options[argument.trim_prefix("--").get_slice("=",0)] = argument.substr(argument.find("=")+1)
	var content: HospitalContent = HospitalContent.new()
	var clinical: RefCounted = load("res://tools/performance/representative_clinical.gd").new(content,options.input)
	var profiler: DetailProfile = DetailProfile.new()
	profiler.source_directory = options.output+".sources"
	clinical.simulation = profiler.attach(clinical.simulation,true)
	profiler.begin_step()
	var started: int = Time.get_ticks_usec()
	var result: TickResult = clinical.simulation.step()
	profiler.end_step(result,Time.get_ticks_usec()-started)
	var events: Array = []
	for event: SimEvent in result.facts: events.append(event.to_record())
	var final: FileAccess = FileAccess.open(options.output+".final.bin",FileAccess.WRITE)
	final.store_var({"facts":clinical.world.freeze(),"events":events})
	final.close()
	var report: Dictionary = {"diagnostic_only":true,"queries":profiler.queries,"profile":profiler.report(),"final":clinical.inspect(true),"final_binary_sha256":FileAccess.get_sha256(options.output+".final.bin")}
	var file: FileAccess = FileAccess.open(options.output,FileAccess.WRITE)
	file.store_string(JSON.stringify(report,"\t"))
	file.close()
	print("DETAIL_QUERIES="+str(profiler.queries.size()))
	clinical.dispose()
	quit(0 if profiler.errors.is_empty() and report.final.ok else 1)
