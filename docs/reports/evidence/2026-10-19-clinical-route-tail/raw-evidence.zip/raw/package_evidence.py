from pathlib import Path
import json,re,hashlib,zipfile,subprocess,statistics
task=Path(__file__).resolve().parent
root=task.parents[1]
dest=root/'docs/reports/evidence/2026-10-19-clinical-route-tail'
dest.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
def save(name,value):
    (dest/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf8',newline='\n')
def compact(r):
    final={k:r['final'][k] for k in ['source_tick','tick','observed_steps','minimum_present','maximum_present','same_actor_ids','validation','work_ticks_by_kind','services_started','services_completed','present','active_patients','present_visitors','facilities','rooms','staff','ok','errors'] if k in r['final']}
    return {**{k:r[k] for k in ['mode','source_input_sha256','complete','qualified','qualification','metrics','initialization_elapsed_us','final_binary_sha256','execution','sources']},'public_checks':r.get('public_checks',{}),'public':{k:v for k,v in r['public'].items() if k!='trace'},'final':final,'operations':r.get('operations',{}),'profile':{k:v for k,v in r.get('profile',{}).items() if k not in ['step_records','sources']}}
projects={}
for log in task.glob('*.console.log'):
    match=re.search(r'ACCEPTANCE_PROJECT=([^\r\n]+)',log.read_text(encoding='utf8',errors='replace'))
    if match: projects[Path(match.group(1).strip())]=log
batches=[]
latest={}
for p,log in sorted(projects.items(),key=lambda item:(item[0]/'acceptance-results.json').stat().st_mtime):
    result=load(p/'acceptance-results.json')
    status=load(p/'execution-status.json')
    batches.append({'log':log.name,'project':p.name,'checks':result['checks'],'failed':result['failed'],'completed':result['completed'],'status':status,'timing':load(p/'timing-summary.json')})
    if result['completed'] and not status['script_errors']:
        for cid,row in result['results'].items(): latest[cid]={**row,'batch':log.name}
assert len(latest)==18 and all(r['passed'] for r in latest.values())
save('functional-summary.json',{'scope':'18 affected clinical, reservation and traffic cases only','distinct_cases':18,'passed':18,'unresolved':[],'batches':batches,'cases':latest})
reports={}
for p in task.glob('*.json'):
    if p.name.endswith('.run.json'): continue
    r=load(p)
    if 'metrics' in r and 'public' in r: reports[p.stem]=compact(r)
pairs={}
for scene in ['gp','op']:
    sides={}
    for side,prefix in [('before',f'before-{scene}-pair'),('after',f'final-{scene}-')]:
        rs=[reports[prefix+str(i)] for i in range(1,4)]
        assert all(r['complete'] and r['qualified'] for r in rs)
        sides[side]={'reports':[prefix+str(i)+'.json' for i in range(1,4)],'median':{key:statistics.median(r['metrics'][key] for r in rs) for key in rs[0]['metrics']}}
    for i in range(1,4): assert reports[f'before-{scene}-pair{i}']['final_binary_sha256']==reports[f'final-{scene}-{i}']['final_binary_sha256']
    sides['mean_change_percent']=(sides['after']['median']['mean_us']/sides['before']['median']['mean_us']-1)*100
    pairs[scene]=sides
before=reports['reuse-e464-public-plain']; after=reports['final-public-plain']; profiled=reports['final-public-root']
assert all(r['qualified'] and all(r['public_checks'].values()) for r in [before,after,profiled])
assert before['source_input_sha256']==after['source_input_sha256']==profiled['source_input_sha256']
assert before['final_binary_sha256']==after['final_binary_sha256']==profiled['final_binary_sha256']
for name in ['before-tail-nested','before-tail-plain','v1-tail-nested','v1-tail-plain','v2-tail-nested','v2-tail-plain','v3-tail-nested','v3-tail-plain']:
    assert reports[name]['complete'] and reports[name]['final_binary_sha256']==reports['before-tail-plain']['final_binary_sha256']
steps={}
for name in ['reuse-e464-public-plain','final-public-plain']:
    r=load(task/(name+'.json'))
    steps[name]={'step277':r['samples'][277],'largest_steps':sorted(r['samples'],key=lambda x:x['elapsed_us'],reverse=True)[:12]}
nonzero=[]
for p in task.glob('*.run.json'):
    r=load(p)
    if r['exit_code'] or r['timed_out'] or r['engine_errors']:
        expected='tail-' in p.name and r['exit_code']==1 and not r['timed_out'] and not r['engine_errors']
        nonzero.append({'metadata':p.name,'classification':'complete_single_step_without_actual_clinical_work_qualified_false' if expected else 'failed_or_incomplete',**r})
details={}
for name in ['detail-v1','detail-routes-v1']:
    r=load(task/(name+'.json'))
    assert r['final_binary_sha256']==reports['before-tail-plain']['final_binary_sha256']
    details[name]={'top_queries':sorted(r['queries'],key=lambda x:x['elapsed_us'],reverse=True)[:8],'queries':len(r['queries']),'final_binary_sha256':r['final_binary_sha256'],'errors':r['profile']['errors']}
save('quick-summary.json',{'diagnostic_only':True,'formal_pass':False,'formal_acceptance_paused':True,'baseline':'e464f289004b4264f6e4876747bbf99f26466be8','pairs':pairs,'public_step_details':steps,'runs':reports,'nonzero_exits':nonzero,'candidate_diagnostics':details,'baseline_reuse':load(task/'reused-evidence.json'),'no_gain_results':['v1 tail plain12.360136s→12.543327s, no route or facility quote count reduction','v2 GP anchor56.1923625ms vs v1 anchor51.862125ms; geometry-only prefilter added routes; final v3 retains cheap real occupancy checks',f'Final operations mean change {pairs["op"]["mean_change_percent"]:+.2f} percent: no demonstrated material gain',f'Final public P50 change {(after["metrics"]["p50_us"]/before["metrics"]["p50_us"]-1)*100:+.2f} percent; cold first change {(after["metrics"]["cold_first_us"]/before["metrics"]["cold_first_us"]-1)*100:+.2f} percent: retained regressions']})
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],cwd=root,text=True,encoding='utf8').splitlines()
source=[{'path':p,'sha256':sha(root/p)} for p in sorted(set(paths)) if (p.startswith(('game/','tools/performance/','tests/acceptance/','content/')) or p in ['project.godot','export_presets.cfg']) and (root/p).is_file()]
frozen=load(task/'after-v3-project/source-identity.json')
before_id=load(task/'before-project/source-identity.json')
for item in frozen['source']:
    if item['path'].endswith('.gd'): assert sha(root/item['path'])==item['sha256'],'Executable drift: '+item['path']
last_project=sorted(projects,key=lambda p:(p/'acceptance-results.json').stat().st_mtime)[-1]
test_id=load(last_project/'source-identity.json')
for item in test_id['source']:
    if item['path'] in ['tests/acceptance/clinical_gathering.gd','tests/acceptance/clinical_selected_doctor.gd']: assert sha(root/item['path'])==item['sha256'],'Test drift: '+item['path']
assert before_id['engine_sha256']==frozen['engine_sha256'] and before_id['native_sha256']==frozen['native_sha256']
save('final-source-identity.json',{'baseline':before_id['head'],'sources':source,'final_executable_source_matches_frozen_project':True,'changed_test_assertion_sources_match_passed_project':True,'matched_test_assertion_files':['tests/acceptance/clinical_gathering.gd','tests/acceptance/clinical_selected_doctor.gd'],'test_catalog_documentation_only_change':'CLIN-34 requirement label clarified; assertions unchanged','before_project_identity':'performance/before-project/source-identity.json','after_project_identity':'performance/after-v3-project/source-identity.json','engine_sha256':frozen['engine_sha256'],'native_sha256':frozen['native_sha256'],'input_sha256':{p.name:sha(p) for p in task.glob('*.input.bin')}})
entries={}
def add(p,name):
    if p.is_file(): entries[name.replace('\\','/')]=p
for p in task.iterdir():
    if p.is_file(): add(p,'raw/'+p.name)
    elif p.name.endswith('.sources'):
        for child in p.rglob('*'): add(child,'raw/'+child.relative_to(task).as_posix())
for p in projects:
    for name in ['acceptance-results.json','execution-status.json','execution.log','import.log','source-identity.json','timing-summary.json','fixture-config.json','tests/acceptance/clinical_gathering.gd','tests/acceptance/clinical_selected_doctor.gd']:
        add(p/name,'acceptance/'+p.name+'/'+name)
    for generated in p.glob('clinical-profile-*.gd'): add(generated,'acceptance/'+p.name+'/'+generated.name)
for p in task.glob('*project'):
    for name in ['source-identity.json','import.log']: add(p/name,'performance/'+p.name+'/'+name)
    for item in load(p/'source-identity.json')['source']:
        name=item['path']
        if name.endswith('.gd') and name.startswith(('game/building/','game/clinic/','game/life/','tools/performance/')): add(p/name,'performance/'+p.name+'/'+name)
old=root/'.cache/gp-public-tail-20261019'
for stem in ['v2-public-root','v2-gp-nested']:
    for p in (old/(stem+'.json.sources')).rglob('*'): add(p,'reused-generated/'+p.relative_to(old).as_posix())
archive=dest/'raw-evidence.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name,p in sorted(entries.items()): z.write(p,name)
manifest={'archive':archive.name,'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'entry_count':len(entries),'entries':[{'path':name,'sha256':sha(p),'bytes':p.stat().st_size} for name,p in sorted(entries.items())]}
save('evidence-manifest.json',manifest)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for item in manifest['entries']: assert hashlib.sha256(z.read(item['path'])).hexdigest()==item['sha256']
print(json.dumps({'cases':len(latest),'pairs':pairs,'public_before':before['metrics'],'public_after':after['metrics'],'archive_bytes':archive.stat().st_size,'entries':len(entries)},ensure_ascii=False))
