from pathlib import Path
import subprocess,json
out=Path(__file__).resolve().parent
root=out.parents[1]
project=out/'before-project'
def run(args,name,diagnostic=False):
    result=subprocess.run(args,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf8',errors='replace')
    (out/(name+'.console.log')).write_text(result.stdout,encoding='utf8')
    okay=result.returncode==0
    if diagnostic and result.returncode==1:
        r=json.loads((out/(name+'.json')).read_text(encoding='utf8'))
        meta=json.loads((out/(name+'.run.json')).read_text(encoding='utf8'))
        okay=r['complete'] and not r['errors'] and not meta['engine_errors'] and not meta['timed_out'] and all(v for k,v in r['qualification'].items() if k!='actual_clinical_work')
    print(json.dumps({'batch':name,'exit_code':result.returncode,'batch_ok':okay}),flush=True)
    if not okay: raise SystemExit(result.returncode or 2)
run(['pwsh','-NoProfile','-File',str(root/'tools/performance/prepare.ps1'),'-Output',str(project)],'before-prepare')
run(['python','-X','utf8',str(out/'run_engine.py'),str(project),'tail-resume','90','script=res://tools/performance/resume_representative.gd',f'--source={out/"public-v6.input.bin"}',f'--final={root/".cache/gp-public-tail-20261019/v2-public-plain.json.final.bin"}',f'--output={out/"tick2923.input.bin"}'],'tail-resume')
for name,source,steps,mode,diagnostic in [('before-tail-nested','tick2923.input.bin',1,'nested',True),('before-tail-plain','tick2923.input.bin',1,'plain',True),('before-gp-anchor','gp.input.bin',80,'plain',False)]:
    run(['python','-X','utf8',str(out/'run_engine.py'),str(project),name,'300',f'--input={out/source}',f'--output={out/(name+".json")}',f'--steps={steps}',f'--profile={mode}'],name,diagnostic)
