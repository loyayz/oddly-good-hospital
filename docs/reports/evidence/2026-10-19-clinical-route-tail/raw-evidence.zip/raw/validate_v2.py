from pathlib import Path
import subprocess,json
out=Path(__file__).resolve().parent
root=out.parents[1]
project=out/'after-v2-project'
def run(args,name,diagnostic=False):
    result=subprocess.run(args,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf8',errors='replace')
    (out/(name+'.console.log')).write_text(result.stdout,encoding='utf8')
    okay=result.returncode==0
    if diagnostic and result.returncode==1:
        r=json.loads((out/(name+'.json')).read_text(encoding='utf8'))
        m=json.loads((out/(name+'.run.json')).read_text(encoding='utf8'))
        okay=r['complete'] and not r['errors'] and not m['engine_errors'] and not m['timed_out'] and all(v for k,v in r['qualification'].items() if k!='actual_clinical_work')
    print(json.dumps({'batch':name,'exit_code':result.returncode,'batch_ok':okay}),flush=True)
    if not okay: raise SystemExit(result.returncode or 2)
def probe(name,target,steps,source,mode='plain',diagnostic=False):
    run(['python','-X','utf8',str(out/'run_engine.py'),str(target),name,'900',f'--input={out/source}',f'--output={out/(name+".json")}',f'--steps={steps}',f'--profile={mode}'],name,diagnostic)
def equal(a,b):
    ra=json.loads((out/(a+'.json')).read_text(encoding='utf8'))
    rb=json.loads((out/(b+'.json')).read_text(encoding='utf8'))
    okay=ra['final_binary_sha256']==rb['final_binary_sha256']
    print(json.dumps({'comparison':[a,b],'facts_events_rng_sha_equal':okay}),flush=True)
    if not okay: raise SystemExit(3)
run(['pwsh','-NoProfile','-File',str(root/'tests/run-acceptance.ps1'),'-Case','CLIN-06,CLIN-11,CLIN-13,CLIN-15,CLIN-17,CLIN-29,CLIN-30,CLIN-33,CLIN-34,CLIN-35,SPACE-08,SPACE-24,SPACE-26,SPACE-28,SPACE-46,SPACE-48,SPACE-51,SPACE-53'],'v2-regression')
run(['pwsh','-NoProfile','-File',str(root/'tools/performance/prepare.ps1'),'-Output',str(project)],'v2-prepare')
probe('v2-tail-nested',project,1,'tick2923.input.bin','nested',True)
equal('before-tail-nested','v2-tail-nested')
probe('v2-tail-plain',project,1,'tick2923.input.bin','plain',True)
equal('before-tail-plain','v2-tail-plain')
probe('v2-gp-anchor',project,80,'gp.input.bin')
equal('before-gp-anchor','v2-gp-anchor')
