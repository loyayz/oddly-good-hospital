extends "res://game/building/remodel_service.gd"
var _step_profile_observer: RefCounted

func dispatch(world: WorldState) -> void:
	_step_profile_observer.enter_call("remodel.dispatch")
	super.dispatch(world)
	_step_profile_observer.exit_call("remodel.dispatch")
