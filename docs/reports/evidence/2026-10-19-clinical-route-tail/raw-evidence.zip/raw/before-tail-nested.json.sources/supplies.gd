extends "res://game/operations/supply_service.gd"
var _step_profile_observer: RefCounted

func boundaries(world: WorldState) -> void:
	_step_profile_observer.enter_call("supplies.boundaries")
	super.boundaries(world)
	_step_profile_observer.exit_call("supplies.boundaries")

func advance(world: WorldState) -> void:
	_step_profile_observer.enter_call("supplies.advance")
	super.advance(world)
	_step_profile_observer.exit_call("supplies.advance")
