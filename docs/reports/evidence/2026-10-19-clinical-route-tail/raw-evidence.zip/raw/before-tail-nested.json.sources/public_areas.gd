extends "res://game/life/public_areas.gd"
var _step_profile_observer: RefCounted

func _ensure(world: WorldState) -> void:
	_step_profile_observer.enter_call("public_areas._ensure")
	super._ensure(world)
	_step_profile_observer.exit_call("public_areas._ensure")

func facilities(world: WorldState, reference: Dictionary, definitions: Array) -> Array:
	_step_profile_observer.enter_call("public_areas.facilities")
	var _step_profile_result: Variant = super.facilities(world,reference,definitions)
	_step_profile_observer.exit_call("public_areas.facilities")
	return _step_profile_result

func compatible_geometry(world: WorldState, reference: Dictionary, definitions: Array, members: Array) -> bool:
	_step_profile_observer.enter_call("public_areas.compatible_geometry")
	var _step_profile_result: Variant = super.compatible_geometry(world,reference,definitions,members)
	_step_profile_observer.exit_call("public_areas.compatible_geometry")
	return _step_profile_result

func select(world: WorldState, actor_id: String, definitions: Array, room_kinds: Array, purpose: String, members: Array = [], maximum_travel_ticks: int = 9223372036854775807) -> Dictionary:
	_step_profile_observer.enter_call("public_areas.select")
	var _step_profile_result: Variant = super.select(world,actor_id,definitions,room_kinds,purpose,members,maximum_travel_ticks)
	_step_profile_observer.exit_call("public_areas.select")
	return _step_profile_result

func waiting_point(world: WorldState, actor_id: String, reference: Dictionary, maximum_travel_ticks: int = 9223372036854775807) -> Dictionary:
	_step_profile_observer.enter_call("public_areas.waiting_point")
	var _step_profile_result: Variant = super.waiting_point(world,actor_id,reference,maximum_travel_ticks)
	_step_profile_observer.exit_call("public_areas.waiting_point")
	return _step_profile_result

func _waiting_point(world: WorldState, actor_id: String, reference: Dictionary, maximum_travel_ticks: int) -> Dictionary:
	_step_profile_observer.enter_call("public_areas._waiting_point")
	var _step_profile_result: Variant = super._waiting_point(world,actor_id,reference,maximum_travel_ticks)
	_step_profile_observer.exit_call("public_areas._waiting_point")
	return _step_profile_result

func _entry_landings(world: WorldState, actor_id: String, floor_id: int) -> Dictionary:
	_step_profile_observer.enter_call("public_areas._entry_landings")
	var _step_profile_result: Variant = super._entry_landings(world,actor_id,floor_id)
	_step_profile_observer.exit_call("public_areas._entry_landings")
	return _step_profile_result

func safe_wait(world: WorldState, actor_id: String, floor_id: int, cell: Array) -> bool:
	_step_profile_observer.enter_call("public_areas.safe_wait")
	var _step_profile_result: Variant = super.safe_wait(world,actor_id,floor_id,cell)
	_step_profile_observer.exit_call("public_areas.safe_wait")
	return _step_profile_result

func _wait_constraints(world: WorldState) -> Dictionary:
	_step_profile_observer.enter_call("public_areas._wait_constraints")
	var _step_profile_result: Variant = super._wait_constraints(world)
	_step_profile_observer.exit_call("public_areas._wait_constraints")
	return _step_profile_result

func _wait_estimate(world: WorldState, reference: Dictionary, facility_ids: Array, purpose: String) -> int:
	_step_profile_observer.enter_call("public_areas._wait_estimate")
	var _step_profile_result: Variant = super._wait_estimate(world,reference,facility_ids,purpose)
	_step_profile_observer.exit_call("public_areas._wait_estimate")
	return _step_profile_result

func turn(world: WorldState, intent: Dictionary, facility_id: String) -> bool:
	_step_profile_observer.enter_call("public_areas.turn")
	var _step_profile_result: Variant = super.turn(world,intent,facility_id)
	_step_profile_observer.exit_call("public_areas.turn")
	return _step_profile_result

func _queue_fit(world: WorldState, facility_id: String, ids: Array) -> Dictionary:
	_step_profile_observer.enter_call("public_areas._queue_fit")
	var _step_profile_result: Variant = super._queue_fit(world,facility_id,ids)
	_step_profile_observer.exit_call("public_areas._queue_fit")
	return _step_profile_result
