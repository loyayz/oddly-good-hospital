extends "res://game/arrivals/arrival_service.gd"
var _step_profile_observer: RefCounted

func boundaries(world: WorldState) -> bool:
	_step_profile_observer.enter_call("arrivals.boundaries")
	var _step_profile_result: Variant = super.boundaries(world)
	_step_profile_observer.exit_call("arrivals.boundaries")
	return _step_profile_result

func arrivals(world: WorldState) -> void:
	_step_profile_observer.enter_call("arrivals.arrivals")
	super.arrivals(world)
	_step_profile_observer.exit_call("arrivals.arrivals")

func advance_wait(world: WorldState) -> void:
	_step_profile_observer.enter_call("arrivals.advance_wait")
	super.advance_wait(world)
	_step_profile_observer.exit_call("arrivals.advance_wait")

func needs(world: WorldState) -> void:
	_step_profile_observer.enter_call("arrivals.needs")
	super.needs(world)
	_step_profile_observer.exit_call("arrivals.needs")

func settle(world: WorldState) -> void:
	_step_profile_observer.enter_call("arrivals.settle")
	super.settle(world)
	_step_profile_observer.exit_call("arrivals.settle")

func take_events() -> Array[SimEvent]:
	_step_profile_observer.enter_call("arrivals.take_events")
	var _step_profile_result: Variant = super.take_events()
	_step_profile_observer.exit_call("arrivals.take_events")
	return _step_profile_result

func capacity(world: WorldState, subtract_existing: bool = true, cancellation: Callable = Callable()) -> Dictionary:
	_step_profile_observer.enter_call("arrivals.capacity")
	var _step_profile_result: Variant = super.capacity(world,subtract_existing,cancellation)
	_step_profile_observer.exit_call("arrivals.capacity")
	return _step_profile_result

func _case_experience(world: WorldState, disease_id: String) -> Dictionary:
	_step_profile_observer.enter_call("arrivals._case_experience")
	var _step_profile_result: Variant = super._case_experience(world,disease_id)
	_step_profile_observer.exit_call("arrivals._case_experience")
	return _step_profile_result

func _reference_basis(world: WorldState, shift: int) -> Dictionary:
	_step_profile_observer.enter_call("arrivals._reference_basis")
	var _step_profile_result: Variant = super._reference_basis(world,shift)
	_step_profile_observer.exit_call("arrivals._reference_basis")
	return _step_profile_result

func _resource_budgets(world: WorldState, classes: Array, shift: int, resource_ids: Variant = null, maintenance: Dictionary = {}) -> Dictionary:
	_step_profile_observer.enter_call("arrivals._resource_budgets")
	var _step_profile_result: Variant = super._resource_budgets(world,classes,shift,resource_ids,maintenance)
	_step_profile_observer.exit_call("arrivals._resource_budgets")
	return _step_profile_result

func _existing_workload(world: WorldState, shift: int, query: Variant = null, commitments: Dictionary = {}, cancellation: Callable = Callable()) -> Dictionary:
	_step_profile_observer.enter_call("arrivals._existing_workload")
	var _step_profile_result: Variant = super._existing_workload(world,shift,query,commitments,cancellation)
	_step_profile_observer.exit_call("arrivals._existing_workload")
	return _step_profile_result
