extends "res://game/building/navigation_cache.gd"
var _step_profile_observer: RefCounted

func floor_source(space: HospitalSpace, world: WorldState, floor_id: int) -> Dictionary:
	_step_profile_observer.enter_call("navigation.floor_source")
	var _step_profile_result: Variant = super.floor_source(space,world,floor_id)
	_step_profile_observer.exit_call("navigation.floor_source")
	return _step_profile_result

func facility_index(space: HospitalSpace, world: WorldState, floor_id: int) -> BodyIndex:
	_step_profile_observer.enter_call("navigation.facility_index")
	var _step_profile_result: Variant = super.facility_index(space,world,floor_id)
	_step_profile_observer.exit_call("navigation.facility_index")
	return _step_profile_result

func query_graphs(space: HospitalSpace, world: WorldState, floor_id: int, actor: Dictionary, members: Array, offsets: Dictionary) -> Dictionary:
	_step_profile_observer.enter_call("navigation.query_graphs")
	var _step_profile_result: Variant = super.query_graphs(space,world,floor_id,actor,members,offsets)
	_step_profile_observer.exit_call("navigation.query_graphs")
	return _step_profile_result

func graph(space: HospitalSpace, world: WorldState, floor_id: int, actor: Dictionary, members: Array, offsets: Dictionary) -> FloorNavigation:
	_step_profile_observer.enter_call("navigation.graph")
	var _step_profile_result: Variant = super.graph(space,world,floor_id,actor,members,offsets)
	_step_profile_observer.exit_call("navigation.graph")
	return _step_profile_result

func _refresh_graph(space: HospitalSpace, world: WorldState, floor_id: int, actor: Dictionary, members: Array, offsets: Dictionary, source: Dictionary, entry: Dictionary) -> Dictionary:
	_step_profile_observer.enter_call("navigation._refresh_graph")
	var _step_profile_result: Variant = super._refresh_graph(space,world,floor_id,actor,members,offsets,source,entry)
	_step_profile_observer.exit_call("navigation._refresh_graph")
	return _step_profile_result

func _trim(target: int) -> void:
	_step_profile_observer.enter_call("navigation._trim")
	super._trim(target)
	_step_profile_observer.exit_call("navigation._trim")

func clearance(space: HospitalSpace, world: WorldState, floor_id: int, actor: Dictionary, members: Array = [], offsets: Dictionary = {}) -> RouteClearance:
	_step_profile_observer.enter_call("navigation.clearance")
	var _step_profile_result: Variant = super.clearance(space,world,floor_id,actor,members,offsets)
	_step_profile_observer.exit_call("navigation.clearance")
	return _step_profile_result

func travel_distance(space: HospitalSpace, world: WorldState, floor_id: int, actor: Dictionary, start: Vector2i, goal: Vector2i, witness: bool = false) -> Dictionary:
	_step_profile_observer.enter_call("navigation.travel_distance")
	var _step_profile_result: Variant = super.travel_distance(space,world,floor_id,actor,start,goal,witness)
	_step_profile_observer.exit_call("navigation.travel_distance")
	return _step_profile_result

func _distance_field(graph: FloorNavigation, query: RouteClearance, goal: Vector2i) -> Dictionary:
	_step_profile_observer.enter_call("navigation._distance_field")
	var _step_profile_result: Variant = super._distance_field(graph,query,goal)
	_step_profile_observer.exit_call("navigation._distance_field")
	return _step_profile_result
