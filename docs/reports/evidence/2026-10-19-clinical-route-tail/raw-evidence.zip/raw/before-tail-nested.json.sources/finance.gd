extends "res://game/economy/finance_service.gd"
var _step_profile_observer: RefCounted

func settle(world: WorldState) -> void:
	_step_profile_observer.enter_call("finance.settle")
	super.settle(world)
	_step_profile_observer.exit_call("finance.settle")
