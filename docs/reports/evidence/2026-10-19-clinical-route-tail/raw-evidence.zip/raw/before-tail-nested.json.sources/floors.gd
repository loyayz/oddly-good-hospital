extends "res://game/building/floor_service.gd"
var _step_profile_observer: RefCounted

func dispatch(world: WorldState) -> void:
	_step_profile_observer.enter_call("floors.dispatch")
	super.dispatch(world)
	_step_profile_observer.exit_call("floors.dispatch")

func advance(world: WorldState) -> void:
	_step_profile_observer.enter_call("floors.advance")
	super.advance(world)
	_step_profile_observer.exit_call("floors.advance")

func worked_staff() -> Dictionary:
	_step_profile_observer.enter_call("floors.worked_staff")
	var _step_profile_result: Variant = super.worked_staff()
	_step_profile_observer.exit_call("floors.worked_staff")
	return _step_profile_result
