extends "res://game/staff/clinical_development.gd"
var _step_profile_observer: RefCounted

func dispatch(world: WorldState) -> void:
	_step_profile_observer.enter_call("development.dispatch")
	super.dispatch(world)
	_step_profile_observer.exit_call("development.dispatch")

func advance(world: WorldState) -> void:
	_step_profile_observer.enter_call("development.advance")
	super.advance(world)
	_step_profile_observer.exit_call("development.advance")

func settle(world: WorldState) -> void:
	_step_profile_observer.enter_call("development.settle")
	super.settle(world)
	_step_profile_observer.exit_call("development.settle")

func worked_staff() -> Dictionary:
	_step_profile_observer.enter_call("development.worked_staff")
	var _step_profile_result: Variant = super.worked_staff()
	_step_profile_observer.exit_call("development.worked_staff")
	return _step_profile_result
