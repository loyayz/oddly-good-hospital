extends "res://game/staff/personal_beds.gd"
var _step_profile_observer: RefCounted

func sync(world: WorldState) -> void:
	_step_profile_observer.enter_call("personal_beds.sync")
	super.sync(world)
	_step_profile_observer.exit_call("personal_beds.sync")

func bed_for(world: WorldState, staff_id: String) -> String:
	_step_profile_observer.enter_call("personal_beds.bed_for")
	var _step_profile_result: Variant = super.bed_for(world,staff_id)
	_step_profile_observer.exit_call("personal_beds.bed_for")
	return _step_profile_result
