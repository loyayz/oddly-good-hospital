extends "res://game/operations/environment_service.gd"
var _step_profile_observer: RefCounted

func begin_query(world: WorldState) -> void:
	_step_profile_observer.enter_call("environment.begin_query")
	super.begin_query(world)
	_step_profile_observer.exit_call("environment.begin_query")

func end_query() -> void:
	_step_profile_observer.enter_call("environment.end_query")
	super.end_query()
	_step_profile_observer.exit_call("environment.end_query")

func worked_staff() -> Dictionary:
	_step_profile_observer.enter_call("environment.worked_staff")
	var _step_profile_result: Variant = super.worked_staff()
	_step_profile_observer.exit_call("environment.worked_staff")
	return _step_profile_result

func dispatch(world: WorldState) -> void:
	_step_profile_observer.enter_call("environment.dispatch")
	super.dispatch(world)
	_step_profile_observer.exit_call("environment.dispatch")

func advance(world: WorldState) -> void:
	_step_profile_observer.enter_call("environment.advance")
	super.advance(world)
	_step_profile_observer.exit_call("environment.advance")

func _arrive(world: WorldState, job: Dictionary, floor_id: int, cell: Array) -> bool:
	_step_profile_observer.enter_call("environment._arrive")
	var _step_profile_result: Variant = super._arrive(world,job,floor_id,cell)
	_step_profile_observer.exit_call("environment._arrive")
	return _step_profile_result

func _work_position(world: WorldState, staff_id: String, floor_id: int, target: Array, adjacent: bool) -> Dictionary:
	_step_profile_observer.enter_call("environment._work_position")
	var _step_profile_result: Variant = super._work_position(world,staff_id,floor_id,target,adjacent)
	_step_profile_observer.exit_call("environment._work_position")
	return _step_profile_result

func _safety_query(world: WorldState) -> Dictionary:
	_step_profile_observer.enter_call("environment._safety_query")
	var _step_profile_result: Variant = super._safety_query(world)
	_step_profile_observer.exit_call("environment._safety_query")
	return _step_profile_result

func _tool(world: WorldState) -> String:
	_step_profile_observer.enter_call("environment._tool")
	var _step_profile_result: Variant = super._tool(world)
	_step_profile_observer.exit_call("environment._tool")
	return _step_profile_result

func _coverage_edges(world: WorldState, floor_id: int) -> Dictionary:
	_step_profile_observer.enter_call("environment._coverage_edges")
	var _step_profile_result: Variant = super._coverage_edges(world,floor_id)
	_step_profile_observer.exit_call("environment._coverage_edges")
	return _step_profile_result

func _coverage(world: WorldState, floor_id: int, origin: Array, radius: int, noise: bool, edges: Dictionary = {}) -> Dictionary:
	_step_profile_observer.enter_call("environment._coverage")
	var _step_profile_result: Variant = super._coverage(world,floor_id,origin,radius,noise,edges)
	_step_profile_observer.exit_call("environment._coverage")
	return _step_profile_result

func _positive_facilities(world: WorldState, floor_id: int, coverage: Dictionary) -> Array:
	_step_profile_observer.enter_call("environment._positive_facilities")
	var _step_profile_result: Variant = super._positive_facilities(world,floor_id,coverage)
	_step_profile_observer.exit_call("environment._positive_facilities")
	return _step_profile_result

func _nearby_actors(world: WorldState, floor_id: int, cell: Array) -> Array:
	_step_profile_observer.enter_call("environment._nearby_actors")
	var _step_profile_result: Variant = super._nearby_actors(world,floor_id,cell)
	_step_profile_observer.exit_call("environment._nearby_actors")
	return _step_profile_result

func environment_at(world: WorldState, floor_id: int, cell: Array, actor_id: String = "", explain: bool = true) -> Dictionary:
	_step_profile_observer.enter_call("environment.environment_at")
	var _step_profile_result: Variant = super.environment_at(world,floor_id,cell,actor_id,explain)
	_step_profile_observer.exit_call("environment.environment_at")
	return _step_profile_result

func sample_at(world: WorldState, floor_id: int, cell: Array, actor_id: String = "") -> Dictionary:
	_step_profile_observer.enter_call("environment.sample_at")
	var _step_profile_result: Variant = super.sample_at(world,floor_id,cell,actor_id)
	_step_profile_observer.exit_call("environment.sample_at")
	return _step_profile_result

func _observe_at(world: WorldState, floor_id: int, cell: Array, actor_id: String, explain: bool, nearby: bool) -> Dictionary:
	_step_profile_observer.enter_call("environment._observe_at")
	var _step_profile_result: Variant = super._observe_at(world,floor_id,cell,actor_id,explain,nearby)
	_step_profile_observer.exit_call("environment._observe_at")
	return _step_profile_result

func _water_usable(world: WorldState, facility: Dictionary, actor_id: String) -> bool:
	_step_profile_observer.enter_call("environment._water_usable")
	var _step_profile_result: Variant = super._water_usable(world,facility,actor_id)
	_step_profile_observer.exit_call("environment._water_usable")
	return _step_profile_result
