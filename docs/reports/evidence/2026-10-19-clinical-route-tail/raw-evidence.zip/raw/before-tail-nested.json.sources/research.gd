extends "res://game/community/research_service.gd"
var _step_profile_observer: RefCounted

func boundaries(world: WorldState) -> void:
	_step_profile_observer.enter_call("research.boundaries")
	super.boundaries(world)
	_step_profile_observer.exit_call("research.boundaries")

func advance(world: WorldState) -> void:
	_step_profile_observer.enter_call("research.advance")
	super.advance(world)
	_step_profile_observer.exit_call("research.advance")

func settle(world: WorldState) -> void:
	_step_profile_observer.enter_call("research.settle")
	super.settle(world)
	_step_profile_observer.exit_call("research.settle")

func worked_staff() -> Dictionary:
	_step_profile_observer.enter_call("research.worked_staff")
	var _step_profile_result: Variant = super.worked_staff()
	_step_profile_observer.exit_call("research.worked_staff")
	return _step_profile_result

func take_events() -> Array[SimEvent]:
	_step_profile_observer.enter_call("research.take_events")
	var _step_profile_result: Variant = super.take_events()
	_step_profile_observer.exit_call("research.take_events")
	return _step_profile_result
