extends "res://game/staff/recruitment_service.gd"
var _step_profile_observer: RefCounted

func boundaries(world: WorldState) -> void:
	_step_profile_observer.enter_call("recruitment.boundaries")
	super.boundaries(world)
	_step_profile_observer.exit_call("recruitment.boundaries")

func advance(world: WorldState) -> void:
	_step_profile_observer.enter_call("recruitment.advance")
	super.advance(world)
	_step_profile_observer.exit_call("recruitment.advance")

func settle(world: WorldState) -> void:
	_step_profile_observer.enter_call("recruitment.settle")
	super.settle(world)
	_step_profile_observer.exit_call("recruitment.settle")
