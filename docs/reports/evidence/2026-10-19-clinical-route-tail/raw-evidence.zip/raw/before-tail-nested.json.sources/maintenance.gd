extends "res://game/operations/maintenance_service.gd"
var _step_profile_observer: RefCounted

func worked_staff() -> Dictionary:
	_step_profile_observer.enter_call("maintenance.worked_staff")
	var _step_profile_result: Variant = super.worked_staff()
	_step_profile_observer.exit_call("maintenance.worked_staff")
	return _step_profile_result

func boundaries(world: WorldState) -> void:
	_step_profile_observer.enter_call("maintenance.boundaries")
	super.boundaries(world)
	_step_profile_observer.exit_call("maintenance.boundaries")

func dispatch(world: WorldState) -> void:
	_step_profile_observer.enter_call("maintenance.dispatch")
	super.dispatch(world)
	_step_profile_observer.exit_call("maintenance.dispatch")

func advance(world: WorldState) -> void:
	_step_profile_observer.enter_call("maintenance.advance")
	super.advance(world)
	_step_profile_observer.exit_call("maintenance.advance")

func _position(world: WorldState, item: Dictionary, staff_id: String) -> Dictionary:
	_step_profile_observer.enter_call("maintenance._position")
	var _step_profile_result: Variant = super._position(world,item,staff_id)
	_step_profile_observer.exit_call("maintenance._position")
	return _step_profile_result

func _any_repair_position(world: WorldState, item: Dictionary) -> bool:
	_step_profile_observer.enter_call("maintenance._any_repair_position")
	var _step_profile_result: Variant = super._any_repair_position(world,item)
	_step_profile_observer.exit_call("maintenance._any_repair_position")
	return _step_profile_result

func _worker_ready(world: WorldState, id: String, own_job: String = "") -> bool:
	_step_profile_observer.enter_call("maintenance._worker_ready")
	var _step_profile_result: Variant = super._worker_ready(world,id,own_job)
	_step_profile_observer.exit_call("maintenance._worker_ready")
	return _step_profile_result

func _dispatch_departures(world: WorldState) -> void:
	_step_profile_observer.enter_call("maintenance._dispatch_departures")
	super._dispatch_departures(world)
	_step_profile_observer.exit_call("maintenance._dispatch_departures")
