extends "res://game/operations/department_service.gd"
var _step_profile_observer: RefCounted

func dispatch(world: WorldState) -> void:
	_step_profile_observer.enter_call("departments.dispatch")
	super.dispatch(world)
	_step_profile_observer.exit_call("departments.dispatch")

func advance(world: WorldState) -> void:
	_step_profile_observer.enter_call("departments.advance")
	super.advance(world)
	_step_profile_observer.exit_call("departments.advance")

func worked_staff() -> Dictionary:
	_step_profile_observer.enter_call("departments.worked_staff")
	var _step_profile_result: Variant = super.worked_staff()
	_step_profile_observer.exit_call("departments.worked_staff")
	return _step_profile_result

func sample(world: WorldState) -> void:
	_step_profile_observer.enter_call("departments.sample")
	super.sample(world)
	_step_profile_observer.exit_call("departments.sample")

func settle(world: WorldState) -> void:
	_step_profile_observer.enter_call("departments.settle")
	super.settle(world)
	_step_profile_observer.exit_call("departments.settle")
