extends "res://game/staff/shift_scheduler.gd"
var _step_profile_observer: RefCounted

func boundaries(world: WorldState) -> void:
	_step_profile_observer.enter_call("scheduler.boundaries")
	super.boundaries(world)
	_step_profile_observer.exit_call("scheduler.boundaries")

func dispatch(world: WorldState) -> void:
	_step_profile_observer.enter_call("scheduler.dispatch")
	super.dispatch(world)
	_step_profile_observer.exit_call("scheduler.dispatch")

func advance(world: WorldState) -> void:
	_step_profile_observer.enter_call("scheduler.advance")
	super.advance(world)
	_step_profile_observer.exit_call("scheduler.advance")

func worked_staff() -> Dictionary:
	_step_profile_observer.enter_call("scheduler.worked_staff")
	var _step_profile_result: Variant = super.worked_staff()
	_step_profile_observer.exit_call("scheduler.worked_staff")
	return _step_profile_result
