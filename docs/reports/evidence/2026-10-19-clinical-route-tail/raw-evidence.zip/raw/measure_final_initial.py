from pathlib import Path
import subprocess,json,shutil,hashlib
out=Path(__file__).resolve().parent
root=out.parents[1]
project=out/'after-v3-project'
load=lambda p:json.loads(p.read_text(encoding='utf8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def run(args,name):
    result=subprocess.run(args,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf8',errors='replace')
    (out/(name+'.console.log')).write_text(result.stdout,encoding='utf8')
    print(json.dumps({'batch':name,'exit_code':result.returncode,'batch_ok':result.returncode==0}),flush=True)
    if result.returncode: raise SystemExit(result.returncode)
def probe(name,target,steps,source,mode='plain'):
    run(['python','-X','utf8',str(out/'run_engine.py'),str(target),name,'1200',f'--input={out/source}',f'--output={out/(name+".json")}',f'--steps={steps}',f'--profile={mode}'],name)
def equal(a,b):
    okay=load(out/(a+'.json'))['final_binary_sha256']==load(out/(b+'.json'))['final_binary_sha256']
    print(json.dumps({'comparison':[a,b],'facts_events_rng_sha_equal':okay}),flush=True)
    if not okay: raise SystemExit(3)
old=root/'.cache/gp-public-tail-20261019'
old_id=load(old/'after-v2-project/source-identity.json')
before_id=load(out/'before-project/source-identity.json')
old_sources={x['path']:x['sha256'] for x in old_id['source']}
checked=[]
for x in before_id['source']:
    if x['path'].startswith(('game/','content/','tools/performance/')):
        assert x['sha256']==old_sources[x['path']],x['path']
        checked.append(x['path'])
assert old_id['engine_sha256']==before_id['engine_sha256']
assert old_id['native_sha256']==before_id['native_sha256']
reused=[]
for source_name,dest_name in [('v2-public-plain','reuse-e464-public-plain'),('v2-public-root','reuse-e464-public-root'),('v2-gp-nested','reuse-e464-gp-nested')]:
    for suffix in ['.json','.json.steps.ndjson','.json.final.bin','.log','.run.json']:
        source=old/(source_name+suffix)
        target=out/(dest_name+suffix)
        assert not target.exists(),target
        shutil.copy2(source,target)
        reused.append({'from':str(source.relative_to(root)),'to':target.name,'sha256':sha(target)})
shutil.copy2(old/'after-v2-project/source-identity.json',out/'reuse-e464-source-identity.json')
(out/'reused-evidence.json').write_text(json.dumps({'baseline':'e464f289004b4264f6e4876747bbf99f26466be8','matching_executable_content_and_tools':checked,'same_engine_native':True,'files':reused},indent=2)+'\n',encoding='utf8')
for scene,steps,source in [('gp',80,'gp.input.bin'),('op',40,'op.input.bin')]:
    for i in range(1,4):
        probe(f'before-{scene}-pair{i}',out/'before-project',steps,source)
        probe(f'final-{scene}-{i}',project,steps,source)
        equal(f'before-{scene}-pair{i}',f'final-{scene}-{i}')
probe('final-gp-nested',project,80,'gp.input.bin','nested')
equal('final-gp-1','final-gp-nested')
probe('final-public-plain',project,300,'public-v6.input.bin')
equal('reuse-e464-public-plain','final-public-plain')
assert all(load(out/'final-public-plain.json')['public_checks'].values())
probe('final-public-root',project,300,'public-v6.input.bin','root')
equal('final-public-plain','final-public-root')
assert all(load(out/'final-public-root.json')['public_checks'].values())
