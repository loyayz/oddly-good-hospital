from pathlib import Path
import subprocess,json,sys,time
out=Path(__file__).resolve().parent; root=out.parents[1]
engine='C:/programs/godot/Godot_v4.7.2-stable_win64_console.exe'
project=Path(sys.argv[1]).resolve(); name=sys.argv[2]; timeout=float(sys.argv[3]); args=sys.argv[4:]
command=[engine,'--headless','--path',str(project)]
if args and args[0]=='import': command+=['--editor','--import','--quit']; args=args[1:]
elif args and args[0].startswith('script='): command+=['--script',args[0][7:],'--']; args=args[1:]
else: command+=['--script','res://tools/performance/representative.gd','--']
command+=args
log=out/(name+'.log'); meta=out/(name+'.run.json')
if log.exists() or meta.exists(): raise SystemExit('Evidence already exists')
started=time.perf_counter(); timed_out=False; termination=None
with log.open('w',encoding='utf8') as stream:
    process=subprocess.Popen(command,cwd=root,stdout=stream,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
    try: code=process.wait(timeout)
    except subprocess.TimeoutExpired:
        timed_out=True
        stopped=subprocess.run(['taskkill','/PID',str(process.pid),'/T','/F'],capture_output=True,text=True,encoding='utf8',errors='replace')
        termination={'exit_code':stopped.returncode,'stdout':stopped.stdout,'stderr':stopped.stderr}
        code=process.wait(timeout=5)
lines=log.read_text(encoding='utf8',errors='replace').splitlines()
errors=[s for s in lines if 'SCRIPT ERROR:' in s or 'ERROR:' in s]
data={'command':command,'pid':process.pid,'timeout_seconds':timeout,'elapsed_seconds':time.perf_counter()-started,'exit_code':code,'timed_out':timed_out,'termination':termination,'engine_errors':errors,'log':str(log)}
meta.write_text(json.dumps(data,indent=2),encoding='utf8')
print(json.dumps(data),flush=True); print('\n'.join(lines[-5:]),flush=True)
sys.exit(0 if code==0 and not timed_out and not errors else 1)
