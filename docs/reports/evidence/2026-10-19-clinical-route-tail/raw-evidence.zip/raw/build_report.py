from pathlib import Path
import json
task=Path(__file__).resolve().parent
root=task.parents[1]
dest=root/'docs/reports/evidence/2026-10-19-clinical-route-tail'
load=lambda p:json.loads(p.read_text(encoding='utf8'))
s=load(dest/'quick-summary.json'); f=load(dest/'functional-summary.json')
r=s['runs']; pairs=s['pairs']
ms=lambda x:f'{x/1000:,.3f}'
pct=lambda a,b:f'{(b/a-1)*100:+.2f}%'
def pairrow(scene,title):
    a=pairs[scene]['before']['median']; b=pairs[scene]['after']['median']
    return '| '+title+' | '+' | '.join(ms(a[k])+' → '+ms(b[k]) for k in ['mean_us','p95_us','cold_first_us','following_mean_us'])+' | '+pct(a['mean_us'],b['mean_us'])+' |'
bp=r['reuse-e464-public-plain']; ap=r['final-public-plain']
bt=r['before-tail-plain']; at=r['v3-tail-plain']
bc={x['name']:x for x in r['before-tail-nested']['profile']['nested_calls']}
ac={x['name']:x for x in r['v3-tail-nested']['profile']['nested_calls']}
gb={x['name']:x for x in r['reuse-e464-gp-nested']['profile']['nested_calls']}
ga={x['name']:x for x in r['final-gp-nested']['profile']['nested_calls']}
gp_calls='\n'.join('| `'+name+'` | '+str(gb.get(name,{}).get('calls',0))+' → '+str(ga.get(name,{}).get('calls',0))+' | '+ms(gb.get(name,{}).get('inclusive_us',0))+' → '+ms(ga.get(name,{}).get('inclusive_us',0))+' |' for name in ['clinic.plan_quote','space.facility_quote','space.route','space._floor_route'])
def callrow(name):
    a=bc.get(name,{'calls':0,'inclusive_us':0}); b=ac.get(name,{'calls':0,'inclusive_us':0})
    return f'| `{name}` | {a["calls"]:,} → {b["calls"]:,} | {ms(a["inclusive_us"])} → {ms(b["inclusive_us"])} |'
root_before={x['name']:x for x in r['reuse-e464-public-root']['profile']['root_stages']}
root_after=r['final-public-root']['profile']['root_stages']
stages='\n'.join('| `'+x['name']+'` | '+f'{root_before[x["name"]]["total_us"]/1e6:.3f} → {x["total_us"]/1e6:.3f}'+' | '+f'{root_before[x["name"]]["profiled_whole_share"]*100:.2f}% → {x["profiled_whole_share"]*100:.2f}%'+' |' for x in root_after[:6])
publicrows='\n'.join('| '+label+' | '+ms(bp['metrics'][key])+' | '+ms(ap['metrics'][key])+' | '+pct(bp['metrics'][key],ap['metrics'][key])+' |' for label,key in [('完整步均值','mean_us'),('P50','p50_us'),('P95','p95_us'),('最大步','max_us'),('冷首步','cold_first_us')])
manifest=load(dest/'evidence-manifest.json')
reg33=f['cases']['CLIN-33']['details']['route_before_complete_fit']
reg34=f['cases']['CLIN-34']['details']
cases='、'.join(f['cases'])
text=f'''# 临床候选重复报价与路线长尾：160人快速对照

基线为 `dev@e464f289004b4264f6e4876747bbf99f26466be8`。GP80步均值中位数 **{ms(pairs['gp']['before']['median']['mean_us'])}ms → {ms(pairs['gp']['after']['median']['mean_us'])}ms（{pairs['gp']['mean_change_percent']:+.2f}%）**；公共300步均值 **{ms(bp['metrics']['mean_us'])}ms → {ms(ap['metrics']['mean_us'])}ms（{pct(bp['metrics']['mean_us'],ap['metrics']['mean_us'])}）**。此前68秒长尾已在上一轮降到约11秒，本轮继续处理后段临床搜索；两轮基线不能混用。

这是Godot 4.7.2 Debug/Headless普通完整 `HospitalSimulation.step()` 的快速验证。**正式Release性能验收继续暂停；当前没有正式性能达标结论。** 最终执行源码与测试以[逐文件身份](evidence/2026-10-19-clinical-route-tail/final-source-identity.json)为准。

## 固定输入与测量边界

继续使用原始合法160人：120患者、32员工、8真实亲友；64房间、1,336设施、4层。原GP80步、门诊/清洁40步、公共竞争300步输入不重建、不改位置、不删人、不缩短窗口。三个原输入SHA分别为 `14bfa213c792d0da30bbf48cb39b360166cff6ecb7f8e46e17ff9bddf37bb0b0`、`dcd41d686a06d0571ae0ad81d83332ce7ca331d4d810de7c5d2b14dede7dcdd3`、`56ea8338361470fee88659ed806d412aa49927c0709c30d4fbdf536a20eb4f76`。

所有引擎串行运行，每轮新建运行时服务，保留冷首步；初始化、观察和写证据在整步计时之外。GP和运营各三组交替before/after；公共plain及root各一完整窗口。公共及GP nested基线复用e464对应的既有原始证据：当前基线与旧冻结工程的game、content、可执行性能工具、引擎和native逐项相同。唯一差异为不参与执行的 `tools/performance/REPRESENTATIVE.md`，双侧SHA及复用来源记录在摘要中。

所有完整窗口均保持160人、相同身份、合法世界和实际临床工时；每组最终**完整事实、随机流及有序事件二进制SHA相同**。公共窗口7项业务检查全部通过，包括真实排队、实际使用、多个区域、使用完成和真实离位后复用。原等待队列、到场取位、手动指定设施、个人床、医疗预约、票序、价格、成功率和工时规则不变。

另从e464公共窗口真实执行结束的tick2923恢复完整边界，比较2923→2924单步。该步没有实际临床工时，`qualified=false`、引擎退出1是保留的诊断结果；人数、世界合法性、完整步和身份校验通过。它不能替代有实际诊疗的完整窗口，更不能充当正式验收。

## 发现、处理与拒绝理由

| 方向 | 结论 | 实现或具体理由 |
| --- | --- | --- |
| 为全部候选先计算路线，随后才寻找首个可执行报价 | 采用 | 按原设施/医生顺序逐候选完整报价，首个完整可用方案成功后结束。失败继续搜索，保留指定医生、结构可行性聚合、最后失败原因及完整返回数值。不是“只看第一个候选”。 |
| 派单仅判断原方案是否结构失效，却重复检查暂时资源 | 采用 | 该守卫只取结构条件且忽略耗材暂缺；实际可用人员、床、供给、排班和开工前完整复核仍由原交接执行。暂缺保留原方案与票号；结构失效仍重新会诊或待确认。 |
| 明知患者/职员不能到达仍先证明全院其他人的出口 | 采用最终v3 | 先执行同一适配算法的预检，保留原医生交接、身体占用和已有预约；按完整布局及owner建立只读投影，验证真实完整路线；投影结束后回原世界执行完整设施报价，成功后才接受候选。预检不授权占用或预约。 |
| 仅用几何预检，再检查完整路线 | v2实测后收紧 | 该中间版正确性对照通过，但引入原本可被身体/预约提前拒绝的路线，GP anchor比v1变慢；最终预检保留这些便宜的实际约束，只延后出口证明。 |
| 增加床位查询缓存作为当前长尾主修复 | 不采用 | tick2923剖析32次床位查询合计约2.24ms，整步约13.1秒，约0.017%。该边界没有可证明的主要收益，不增加跨方案缓存及失效复杂度；不代表其他场景的床位成本已解决。 |
| 将跨层 `estimate_unknown` 当作永久不可达或跳过出口身体 | 不采用 | 真实目标出口被占用是合法等待；身体离位后必须重新报价。永久负缓存、绕过出口或删掉排队人物会改变业务结果。 |

tick2923原nested整步13.108秒，其中临床分派10.946秒（83.50%），候诊1.417秒（10.81%）。细分诊断记录106次候选查询：同一患者的两次门诊结构检查各扫描256个设施/医生组合，其中195次设施适配成功，却195次完整路线均因“目标出口当前被占用，暂时无法估计离舱时间”失败；另外104次接待查询没有候选。此时只提前结束成功搜索不会减少任何调用，因此v1不能消除该长尾。

## 整步实测

GP与运营表为三轮相应指标的中位数，单位ms；不是合并样本后重新计算的分位数。绝对时长由plain完整步证明，root/nested仅用于归因。

| 窗口 | 全窗均值 前→后 | P95 前→后 | 冷首步 前→后 | 后续步均值 前→后 | 均值变化 |
| --- | --- | --- | --- | --- | --- |
{pairrow('gp','GP80')}
{pairrow('op','门诊/清洁40')}

运营窗口均值变化为{pairs['op']['mean_change_percent']:+.2f}%，该量级接近短窗运行噪声，按“未证明明显收益”保留，不计为可靠加速。GP冷首步也未得到明显改善；不能用后续步收益覆盖冷启动成本。

GP80步nested中的总候选查询仍为8,966次，但重操作减少；完整路线156→68次，说明收益发生在原有成功搜索内部，而不是减少诊疗或票号。报价调用仍6次，完整报价语义保留。

| GP80 nested | 次数 前→后 | 包含子调用耗时ms 前→后 |
| --- | --- | --- |
{gp_calls}

| 公共300步，plain n=1，ms | 前 | 后 | 变化 |
| --- | --- | --- | --- |
{publicrows}

公共窗口P50增加{pct(bp['metrics']['p50_us'],ap['metrics']['p50_us'])}，冷首步增加{pct(bp['metrics']['cold_first_us'],ap['metrics']['cold_first_us'])}。收益集中在昂贵搜索和P95，不表示每个模拟步都更快；这些退化数值保留，不以均值收益覆盖。

tick2923单步plain诊断 **{ms(bt['metrics']['mean_us'])}ms → {ms(at['metrics']['mean_us'])}ms（{pct(bt['metrics']['mean_us'],at['metrics']['mean_us'])}）**，两侧均为冷恢复单步。该数字不能与300步内的热态最大值直接互换。完整300步中此前第277步详值和最大12步均保存在摘要中。

| tick2923 nested，整步内调用 | 次数 前→后 | 包含子调用耗时ms 前→后 |
| --- | --- | --- |
{callrow('clinic.service_candidates')}
{callrow('space.facility_quote')}
{callrow('space.facility_preflight_quote')}
{callrow('space.route')}
{callrow('space._floor_route')}

完整设施报价减少不表示取消同等约束：不可达候选在原有必要条件处结束，可达候选仍经过完整检查。`space.route`在该单步中仍512次，说明剩余完整路线计算没有被本次修复消除；预检总成本也已计入整步。包含子调用时间不能相加。

公共300步root中的主要阶段如下；阶段互斥，比例分母为各自被剖析的完整窗口。

| 阶段 | 总耗时秒 前→后 | 完整剖析步占比 前→后 |
| --- | --- | --- |
{stages}

## 回归、失败与无收益结果

相关18项最终通过：{cases}。依据为临床报价、原方案等待与冻结承诺、资源束竞争、实际到齐交接、预约权限和交通出口语义；没有扩大为全量专题。17项复用同一v3批次通过结果，CLIN-33修复测试前提后单独通过。

CLIN-34对{reg34['checked_variants']}组输入比较完整报价、事实及随机流；对照先物化全部路线再报价，完整报价执行顺序保留旧方式，验证首候选失败后继续选择，受控对照少调用{reg34['eager_route_calls_saved']}次路线。CLIN-33新增{reg33['checked_variants']}组合法边界，对照先完整适配再路线，比较完整有序候选及只读事实，受控无路线输入避免{reg33['unreachable_complete_quotes_avoided']}次完整设施检查。这些是功能对照计数，不是160人性能指标。

- v1单步plain：12.360136→12.543327秒，约+1.48%，没有长尾收益；完整设施报价及路线次数未减少。其GP anchor改善，不能外推为所有场景都加速。
- v2 GP anchor：56.192ms，相比v1的51.862ms变慢；几何预检多做失败路线。最终v3恢复便宜的身体/预约检查，anchor为51.741ms。anchor均为n=1诊断，最终结论采用三组整步数据。
- v3首次18项回归中CLIN-33失败，原因是新测试前提错误地使用Visit ID作为展开预约owner，世界校验拒绝；实际与控制候选相同。改为已有Actor身份后只重跑CLIN-33，合法性及断言通过。原失败日志和前提源保留，不计为首次全绿。
- 基线复用脚本首次在Markdown来源SHA校验处停止，未启动测量。确认唯一差异为非执行说明文档后，显式记录该差异并继续严格检查所有执行和数据输入；首次失败脚本与错误记录保留。
- 两侧及各中间版单步诊断均无实际临床工时，`qualified=false`结果原样保留；没有把它们改报为完整性能场景通过。

## 剩余瓶颈与验收状态

本轮已证明GP及公共窗口的实际整步变化，尚未消除秒级长尾。tick2923仍重复搜索合法但当前出口未知的跨层路线；同一患者会在不同方案和设施/医生组合中重复计算。必须保留不同投影的预约权限、完整身体、交通票序和出口恢复语义，不能直接共享整个失败结果。冷首步、每步空间/路线准备与当前主要root阶段的成本以本报告表格为准，未宣称都已解决。

个人床首次分配此前约28～30秒的诊断没有在本轮复测；已有归属前提不能证明首次分床成本已解决。本轮约2.24ms的床位数据只属于tick2923的临床查询，不能外推至全院个人床匹配或完整742病例容量求解。

只有18项相关功能回归与本报告固定负载快速窗口完成。**同源Release导出及正式矩阵、完整742病例容量计算与内存、最大房间预览、实际渲染比例、GPU资源证据和两小时稳定性均保持暂停、未完成本轮验收。** 冻结合法日计划复用不证明重新完成742病例求解；headless模拟不证明渲染、游戏主循环、后台容量准备或存档I/O性能。没有降低阈值、改变模拟步长或缩减合法负载。

## 证据

[指标与阶段摘要](evidence/2026-10-19-clinical-route-tail/quick-summary.json)、[功能批次及前提/测试耗时](evidence/2026-10-19-clinical-route-tail/functional-summary.json)、[最终源码身份](evidence/2026-10-19-clinical-route-tail/final-source-identity.json)、[原始证据包](evidence/2026-10-19-clinical-route-tail/raw-evidence.zip)、[逐项清单](evidence/2026-10-19-clinical-route-tail/evidence-manifest.json)。原始包包含全部中间版、失败/无收益记录、原输入、最终完整事实、命令、超时参数、日志、逐步数据、独立对照源、剖析生成源和冻结实现。

证据包{manifest['archive_bytes']:,}字节，{manifest['entry_count']}项；SHA-256为 `{manifest['archive_sha256']}`。ZIP CRC及全部条目SHA已核对。源代码已完成引擎导入与相关回归，未单独执行正式Release构建或实机画面检查。
'''
(root/'docs/reports/2026-10-19-clinical-route-tail-performance.md').write_text(text,encoding='utf8',newline='\n')
print('REPORT_WRITTEN')
