import hashlib,json,pathlib,shutil,subprocess,uuid
repo=pathlib.Path(r'C:\code\loyayz\oddly-good-hospital')
root=pathlib.Path(__file__).resolve().parent
source=repo/'.cache/remaining-b9bb59d-20261021/after-project'
base='284efc9c339d23fe1299f901b1f7f738c2239876'
identity=json.loads((source/'source-identity.json').read_text(encoding='utf-8-sig'))
rows=[r for r in identity['source'] if r['path'].startswith(('game/','content/','tools/performance/'))]
data=subprocess.run(['git','cat-file','--batch'],input=''.join(base+':'+r['path']+'\n' for r in rows).encode(),cwd=repo,check=True,stdout=subprocess.PIPE).stdout
cursor=0
for row in rows:
 end=data.index(b'\n',cursor);header=data[cursor:end].split();size=int(header[-1]);cursor=end+1
 blob=data[cursor:cursor+size];cursor+=size+1
 assert hashlib.sha256(blob).hexdigest()==row['sha256'],row['path']
 assert hashlib.sha256((source/row['path']).read_bytes()).hexdigest()==row['sha256'],row['path']
target=root/'before-project'
shutil.copytree(source,target)
profile='OddlyGoodHospital Entry '+uuid.uuid4().hex
project=target/'project.godot'
project.write_text(project.read_text(encoding='utf-8-sig').replace(identity['profile'],profile),encoding='utf-8',newline='\n')
identity['head']=base;identity['project']=str(target);identity['profile']=profile
identity['baseline_verified_git_paths']=len(rows)
identity['frozen_origin_identity_sha256']=hashlib.sha256((source/'source-identity.json').read_bytes()).hexdigest()
identity['import_arguments']=['--headless','--editor','--path',str(target),'--import','--quit']
(target/'source-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
print('FROZEN_BASELINE',target,len(rows))
