import hashlib,json,pathlib,shutil,uuid
root=pathlib.Path(__file__).resolve().parent
source=root/'before-project';target=root/'before-fine-project'
if target.exists():
 for relative in ['game/life/public_areas.gd','game/building/hospital_space.gd','tools/performance/representative.gd','source-identity.json','project.godot']:
  shutil.copyfile(source/relative,target/relative)
else:
 shutil.copytree(source,target)
overlays=[]
def change(relative,apply):
 path=target/relative;old=path.read_bytes();text=old.decode('utf-8-sig');new=apply(text)
 assert new!=text,relative
 path.write_text(new,encoding='utf-8',newline='\n')
 overlays.append({'path':relative,'original_sha256':hashlib.sha256(old).hexdigest(),'observed_sha256':hashlib.sha256(path.read_bytes()).hexdigest()})

def entry(text):
 start=text.index('func _ordered_entry_cells(');end=text.index('\nfunc _entry_landings(',start);body=text[start:end]
 body=body.replace('\n\tvar start:', '\n\tvar diag_started: int = Time.get_ticks_usec()\n\tvar diag: Dictionary = Engine.get_meta(&"entry_index_fine")\n\tvar start:',1)
 body=body.replace('\n\tvar packed:', '\n\tvar diag_prepared: int = Time.get_ticks_usec()\n\tvar packed:',1)
 body=body.replace('\n\tif compact:\n\t\tpacked.resize(count)', '\n\tvar diag_enumerated: int = Time.get_ticks_usec()\n\tif compact:\n\t\tpacked.resize(count)',1)
 needle='\treturn {"packed":packed,"fallback":fallback,"compact":compact}'
 replacement='''\tvar diag_sorted: int = Time.get_ticks_usec()
\tvar geometry_id: int = -1
\tfor number: int in diag.geometry_handles.size():
\t\tif is_same(diag.geometry_handles[number],geometry): geometry_id = number; break
\tif geometry_id<0:
\t\tgeometry_id = diag.geometry_handles.size()
\t\tdiag.geometry_handles.append(geometry)
\tvar base: int = 0
\tif not bounds.unknown and not bounds.landings.is_empty():
\t\tbase = int(bounds.landings[0].ticks)
\t\tfor landing: Dictionary in bounds.landings: base = mini(base,int(landing.ticks))
\tvar relative: Array = []
\tfor landing: Dictionary in bounds.landings: relative.append([landing.cell,int(landing.ticks)-base])
\tvar order_basis: Array = [geometry_id,speed,bounds.unknown,relative]
\tif bounds.unknown or bounds.landings.is_empty(): order_basis.append(start)
\tvar key: String = JSON.stringify(order_basis)
\tvar row: Dictionary = diag.entry_orders.get_or_add(key,{"calls":0,"cells":geometry.cells.size(),"landings":relative,"speed":speed,"unknown":bounds.unknown,"first_tick":space._indexed_world.sim_tick,"raw_variants":{},"prep_us":0,"enumerate_us":0,"sort_us":0,"count":0})
\trow.calls += 1
\trow.count += count
\trow.prep_us += diag_prepared-diag_started
\trow.enumerate_us += diag_enumerated-diag_prepared
\trow.sort_us += diag_sorted-diag_enumerated
\trow.raw_variants[JSON.stringify([start,stub_ticks,bounds.landings,maximum_travel_ticks])] = true
\treturn {"packed":packed,"fallback":fallback,"compact":compact}'''
 assert body.count(needle)==1;body=body.replace(needle,replacement)
 text=text[:start]+body+text[end:]
 # Coarse cold preparation markers; no marker in the per-cell inner loop.
 start=text.index('func _ensure(');end=text.index('\nstatic func _key(',start);body=text[start:end]
 body=body.replace('\n\t\tvar zones:', '\n\t\tvar diag_cold: Dictionary = Engine.get_meta(&"entry_index_fine")\n\t\tvar diag_started: int = Time.get_ticks_usec()\n\t\tvar zones:',1)
 body=body.replace('\n\t\tvar ordered:', '\n\t\tvar diag_layout: int = Time.get_ticks_usec()\n\t\tvar ordered:',1)
 body=body.replace('\n\t\tvar seen:', '\n\t\tvar diag_sorted: int = Time.get_ticks_usec()\n\t\tvar seen:',1)
 body=body.replace('\n\t\tfor id: String in world.ids("facilities"):', '\n\t\tvar diag_components: int = Time.get_ticks_usec()\n\t\tfor id: String in world.ids("facilities"):',1)
 body+='''
\t\tvar diag_finished: int = Time.get_ticks_usec()
\t\tdiag_cold.cold_regions.append({"tick":world.sim_tick,"floor_id":floor_id,"layout_us":diag_layout-diag_started,"sort_us":diag_sorted-diag_layout,"components_and_index_us":diag_components-diag_sorted,"facility_region_us":diag_finished-diag_components,"cells":ordered.size()})
'''
 return text[:start]+body+text[end:]
change('game/life/public_areas.gd',entry)

def actor_index(text):
 needle='func _ensure_actor_index(world: WorldState) -> void:\n'
 text=text.replace(needle,needle+'\tvar diag_old_world: WorldState = _indexed_world\n\tvar diag_old_revision: int = _indexed_revision\n\tvar diag_old_scope: Dictionary = _indexed_actor_scope\n',1)
 needle='\tif not shared:\n\t\tquery_counts.actor_index_builds += 1'
 replacement='''\tif not shared:
\t\tvar diag: Dictionary = Engine.get_meta(&"entry_index_fine")
\t\tvar trace: Array = []
\t\tfor frame: Dictionary in get_stack().slice(1,5): trace.append(str(frame.source).get_file()+":"+str(frame.function))
\t\tvar same_world: bool = diag_old_world==world
\t\tvar same_actors: bool = diag_old_world!=null and is_same(diag_old_world.facts.actors,world.facts.actors)
\t\tvar kind: String = "forced" if same_world and diag_old_revision<0 else ("revision" if same_world else "world_switch")
\t\tvar key: String = JSON.stringify([kind,same_actors,scope.is_empty(),is_same(scope,diag_old_scope),trace])
\t\tvar row: Dictionary = diag.actor_rebuilds.get_or_add(key,{"kind":kind,"same_actors":same_actors,"trace":trace,"count":0,"ticks":{},"revision_examples":[]})
\t\trow.count += 1
\t\trow.ticks[str(world.sim_tick)] = int(row.ticks.get(str(world.sim_tick),0))+1
\t\tif row.revision_examples.size()<4: row.revision_examples.append([diag_old_revision,world.revision])
\t\tquery_counts.actor_index_builds += 1'''
 assert text.count(needle)==1;text=text.replace(needle,replacement,1)
 needle='func begin_dynamic_route_query(world: WorldState, refresh_actors: bool = true) -> void:\n'
 replacement=needle+'''\tvar diag: Dictionary = Engine.get_meta(&"entry_index_fine")
\tvar trace: Array = []
\tfor frame: Dictionary in get_stack().slice(1,4): trace.append(str(frame.source).get_file()+":"+str(frame.function))
\tvar diag_key: String = JSON.stringify([refresh_actors,trace])
\tdiag.dynamic_callers[diag_key] = int(diag.dynamic_callers.get(diag_key,0))+1
'''
 assert text.count(needle)==1;text=text.replace(needle,replacement,1)
 return text
change('game/building/hospital_space.gd',actor_index)

def runner(text):
 text=text.replace('func _run() -> void:\n','func _run() -> void:\n\tEngine.set_meta(&"entry_index_fine",{"geometry_handles":[],"entry_orders":{},"actor_rebuilds":{},"dynamic_callers":{},"cold_regions":[]})\n',1)
 needle='\tvar public_observer: RefCounted = Public.new(clinical.simulation.space)'
 replacement='\tEngine.set_meta(&"entry_index_fine",{"geometry_handles":[],"entry_orders":{},"actor_rebuilds":{},"dynamic_callers":{},"cold_regions":[]})\n'+needle
 assert text.count(needle)==1;text=text.replace(needle,replacement,1)
 needle='\treport.final_binary_sha256 = FileAccess.get_sha256(final_path)'
 replacement=needle+'\n\treport.fine_cost = (Engine.get_meta(&"entry_index_fine") as Dictionary).duplicate()\n\treport.fine_cost.erase("geometry_handles")\n\tEngine.remove_meta(&"entry_index_fine")'
 assert text.count(needle)==1;return text.replace(needle,replacement,1)
change('tools/performance/representative.gd',runner)
identity=json.loads((target/'source-identity.json').read_text(encoding='utf-8-sig'))
profile='OddlyGoodHospital Fine '+uuid.uuid4().hex
project=target/'project.godot';project.write_text(project.read_text(encoding='utf-8-sig').replace(identity['profile'],profile),encoding='utf-8',newline='\n')
identity['project']=str(target);identity['profile']=profile;identity['diagnostic_overlays']=overlays
(target/'source-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
print('FINE_PREPARED',target)
