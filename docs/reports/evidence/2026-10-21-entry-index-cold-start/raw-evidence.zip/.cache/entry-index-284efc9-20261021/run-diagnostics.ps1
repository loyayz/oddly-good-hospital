#requires -Version 7.0
$ErrorActionPreference='Stop'
$repo='C:/code/loyayz/oddly-good-hospital'
$root=Join-Path $repo '.cache/entry-index-284efc9-20261021'
$godot='C:/programs/godot/Godot_v4.7.2-stable_win64_console.exe'
foreach($project in 'before-fine-project','before-all-project'){
    $log=Join-Path $root ($project+'-import.log')
    & $godot --headless --editor --path (Join-Path $root $project) --import --quit *> $log
    if($LASTEXITCODE -ne 0 -or (Select-String $log -Pattern 'SCRIPT ERROR:|ERROR:' -Quiet)){Get-Content $log -Tail 20;throw "Diagnostic import failed: $project"}
}
$runs=@(
    @{name='before-fine-public40';project=(Join-Path $root 'before-fine-project');input='public-v6.input.bin';steps=40;script='representative.gd';mode='plain'},
    @{name='before-fine-gp40';project=(Join-Path $root 'before-fine-project');input='gp.input.bin';steps=40;script='representative.gd';mode='plain'},
    @{name='ops-legacy-a';project=(Join-Path $repo '.cache/remaining-b9bb59d-20261021/before-project');input='op.input.bin';steps=40;script='representative.gd';mode='plain'},
    @{name='ops-current-b';project=(Join-Path $root 'before-project');input='op.input.bin';steps=40;script='representative.gd';mode='plain'},
    @{name='ops-current-c';project=(Join-Path $root 'before-project');input='op.input.bin';steps=40;script='representative.gd';mode='plain'},
    @{name='ops-legacy-d';project=(Join-Path $repo '.cache/remaining-b9bb59d-20261021/before-project');input='op.input.bin';steps=40;script='representative.gd';mode='plain'},
    @{name='ops-all-current';project=(Join-Path $root 'before-all-project');input='op.input.bin';steps=40;script='representative_selected.gd';mode='all'},
    @{name='ops-all-legacy';project=(Join-Path $repo '.cache/remaining-b9bb59d-20261021/before-all-project');input='op.input.bin';steps=40;script='representative_selected.gd';mode='all'}
)
foreach($run in $runs){
    $output=Join-Path $root ($run.name+'.json')
    if(Test-Path $output){throw "Evidence exists: $output"}
    $log=[IO.Path]::ChangeExtension($output,'.log')
    $input=Join-Path $repo ('.cache/task-navigation-20261019/'+$run.input)
    & $godot --headless --path $run.project --script ('res://tools/performance/'+$run.script) -- "--input=$input" "--output=$output" "--steps=$($run.steps)" "--profile=$($run.mode)" --selected=0,1,19,20,21,38,39 *> $log
    if($LASTEXITCODE -ne 0 -or (Select-String $log -Pattern 'SCRIPT ERROR:|ERROR:' -Quiet)){Get-Content $log -Tail 18;throw "Diagnostic failed: $($run.name)"}
    $result=Get-Content $output -Raw|ConvertFrom-Json
    if(-not $result.qualified){throw "Unqualified: $($run.name)"}
    [ordered]@{run=$run.name;metrics=$result.metrics;qualified=$result.qualified;hash=$result.final_binary_sha256}|ConvertTo-Json -Depth 4 -Compress
}
