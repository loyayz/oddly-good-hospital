#requires -Version 7.0
$ErrorActionPreference='Stop'
$repo='C:/code/loyayz/oddly-good-hospital'
$root=Join-Path $repo '.cache/entry-index-284efc9-20261021'
$godot='C:/programs/godot/Godot_v4.7.2-stable_win64_console.exe'
$runs=@()
foreach($window in @(@{name='public360';input='public-v6.input.bin';steps=360},@{name='gp80';input='gp.input.bin';steps=80})){
    $runs+=@{name=('final-control-'+$window.name);project='before-project';input=$window.input;steps=$window.steps;mode='plain';script='representative.gd';selected='0'}
    $runs+=@{name=('final-plain-'+$window.name);project='final-project';input=$window.input;steps=$window.steps;mode='plain';script='representative.gd';selected='0'}
}
foreach($side in @(@{label='a';project='before-project'},@{label='b';project='final-project'},@{label='c';project='final-project'},@{label='d';project='before-project'})){
    $runs+=@{name=('final-ops-'+$side.label);project=$side.project;input='op.input.bin';steps=40;mode='plain';script='representative.gd';selected='0'}
}
foreach($window in @(@{name='public360';input='public-v6.input.bin';steps=360;selected='0,1,27,140,239,339'},@{name='gp40';input='gp.input.bin';steps=40;selected='0,27'},@{name='operations40';input='op.input.bin';steps=40;selected='0,1,19,20,21,38,39'})){
    $runs+=@{name=('final-all-'+$window.name);project='final-all-project';input=$window.input;steps=$window.steps;mode='all';script='representative_selected.gd';selected=$window.selected}
}
foreach($run in $runs){
    $output=Join-Path $root ($run.name+'.json')
    if(Test-Path $output){throw "Evidence exists: $output"}
    $log=[IO.Path]::ChangeExtension($output,'.log')
    $input=Join-Path $repo ('.cache/task-navigation-20261019/'+$run.input)
    & $godot --headless --path (Join-Path $root $run.project) --script ('res://tools/performance/'+$run.script) -- "--input=$input" "--output=$output" "--steps=$($run.steps)" "--profile=$($run.mode)" "--selected=$($run.selected)" *> $log
    if($LASTEXITCODE -ne 0 -or (Select-String $log -Pattern 'SCRIPT ERROR:|ERROR:' -Quiet)){Get-Content $log -Tail 18;throw "Run failed: $($run.name)"}
    $result=Get-Content $output -Raw|ConvertFrom-Json
    if(-not $result.qualified){throw "Unqualified: $($run.name)"}
    if($result.public_checks -and @($result.public_checks.PSObject.Properties | Where-Object {$_.Value -eq $false}).Count -gt 0){throw "Public check failed: $($run.name)"}
    [ordered]@{run=$run.name;metrics=$result.metrics;qualified=$result.qualified;hash=$result.final_binary_sha256}|ConvertTo-Json -Depth 4 -Compress
}
