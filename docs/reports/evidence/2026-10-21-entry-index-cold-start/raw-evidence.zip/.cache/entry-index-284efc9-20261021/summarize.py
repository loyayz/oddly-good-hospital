import hashlib,json,pathlib,statistics,subprocess,zipfile
REPO=pathlib.Path(r'C:\code\loyayz\oddly-good-hospital')
ROOT=pathlib.Path(__file__).resolve().parent
OUT=REPO/'docs/reports/evidence/2026-10-21-entry-index-cold-start'
BASE='284efc9c339d23fe1299f901b1f7f738c2239876'
OUT.mkdir(parents=True,exist_ok=True)
def read(path): return json.loads(pathlib.Path(path).read_text(encoding='utf-8-sig'))
def sha(path): return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()
def dump(name,value): (OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def measured(name):
 d=read(ROOT/(name+'.json'));p=d['public']
 assert d['qualified'] and d['complete'] and not d['errors']
 if d.get('public_checks'): assert all(d['public_checks'].values())
 return dict(run=name,metrics=d['metrics'],qualification=d['qualification'],public_checks=d.get('public_checks'),
  final_hash=d['final_binary_sha256'],input_sha256=d['source_input_sha256'],work=d['final']['work_ticks_by_kind'],query_counts=p['query_counts'],
  public_work=dict(starts=len(p['actual_use_starts']),completions=len(p['actual_use_completions']),ticks=p['actual_use_ticks'],queue_ticks=p['queue_actor_ticks'],reuses=p['actual_exit_then_reuse_count']),
  index27=d['samples'][27])
windows=[]
for window in ['public360','gp80','operations40']:
 rows=[measured('paired-'+window+'-'+letter) for letter in 'abcd']
 assert len({r['final_hash'] for r in rows})==1
 assert len({r['input_sha256'] for r in rows})==1
 assert all(r['work']==rows[0]['work'] and r['public_work']==rows[0]['public_work'] for r in rows)
 keys=['mean_us','p50_us','p95_us','p99_us','max_us','cold_first_us','following_mean_us']
 before={k:statistics.mean(rows[i]['metrics'][k] for i in [0,3]) for k in keys}
 after={k:statistics.mean(rows[i]['metrics'][k] for i in [1,2]) for k in keys}
 windows.append(dict(window=window,runs=rows,before_window_metric_average=before,after_window_metric_average=after,
  reductions={k:1-after[k]/before[k] for k in keys},whole_world_equal=True))
final_windows=[]
for window in ['public360','gp80']:
 b=measured('final-control-'+window);a=measured('final-plain-'+window)
 assert b['final_hash']==a['final_hash'] and b['input_sha256']==a['input_sha256']
 assert b['public_work']==a['public_work'] and b['work']==a['work']
 final_windows.append(dict(window=window,before=b,after=a,reductions={k:1-a['metrics'][k]/b['metrics'][k] for k in ['mean_us','p50_us','p95_us','max_us']}))
final_ops=[measured('final-ops-'+letter) for letter in 'abcd']
assert len({r['final_hash'] for r in final_ops})==1
dump('quick-summary.json',dict(baseline=BASE,formal_pass=False,formal_acceptance_paused=True,intermediate_abba=windows,final_windows=final_windows,final_ops_abba=final_ops,
 initial_baseline=[measured('before-plain-'+w) for w in ['public360','gp80','operations40']],
 caution='A/B/B/A uses before/after/after/before. Averages of per-window percentiles are descriptive only, never pooled formal percentiles. Full windows and runtime drift remain visible.'))

ops=[]
for name in ['ops-legacy-a','ops-current-b','ops-current-c','ops-legacy-d']:
 r=measured(name);d=read(ROOT/(name+'.json'))
 r['slowest_steps']=sorted(d['samples'],key=lambda row:row['elapsed_us'],reverse=True)[:6]
 ops.append(r)
assert len({r['final_hash'] for r in ops})==1
assert all(r['query_counts']==ops[0]['query_counts'] for r in ops)
dump('operations-investigation.json',dict(legacy='b9bb59d59ec5db1d75f80e6db25f27f335f7fa41',current=BASE,
 original_regression=dict(before_p95_us=36676,after_p95_us=40743,before_warm_mean_us=27557.2051282051,after_warm_mean_us=29041.9487179487),
 abba=ops,version_regression_reproduced=False,cpu_cause='unmeasured; no attribution to heat, frequency, or specific competing workload',
 environment_counter_probe='Win32_PerfFormattedData_PerfOS_Processor unavailable: CIM resource inaccessible',
 observed_common_costs=['Output tick1172: actual 4F-to-3F lift egress passed singleton members and rebuilt static geometry; fixed by exact singleton normalization.',
 'Output tick1191: seven source captures, first movement/1F stale predates current completions; six later captures follow four cleanup receipts incrementing global geometry revision. Source inputs unchanged; notifications retained pending owner soft-range contract.']))

profiles=[]
for name in ['ops-all-current','ops-all-legacy']+[side+'-all-'+w for w in ['public360','gp40','operations40'] for side in ['before','after','final']]:
 d=read(ROOT/(name+'.json'));p=d['profile'];assert not p['errors']
 steps=[]
 sample_indices={s['tick']:s['index'] for s in d['samples']}
 for s in p['step_records']:
  if not s['calls']: continue
  steps.append(dict(index=sample_indices[s['tick']],tick=s['tick'],outer_us=s['outer_elapsed_us'],observer_us=s['observer_handler_us'],residual_us=s['residual_us'],stages=s['stages'],
   hot=sorted([dict(name=k,**v) for k,v in s['calls'].items()],key=lambda v:v['exclusive_us'],reverse=True)[:18],
   target={k:v for k,v in s['calls'].items() if k in ['public_areas._ensure','public_areas._entry_order','public_areas._ordered_entry_cells',
    'space._ensure_actor_index','space._actor_exclusion_scope','space.begin_actor_exclusion_query','point_navigation._point_edges',
    'floor_graph._build','clearance._build_static','clearance.capture_source','space.static_reason','public_areas._queue_fit_in_query']}))
 if name in ['before-all-public360','after-all-public360','before-all-operations40','after-all-operations40']:
  window=name.split('-all-')[1];letter='a' if name.startswith('before-') else 'b'
  assert d['final_binary_sha256']==read(ROOT/(f'paired-{window}-{letter}.json'))['final_binary_sha256']
 if name=='final-all-public360': assert d['final_binary_sha256']==read(ROOT/'final-plain-public360.json')['final_binary_sha256']
 if name=='final-all-operations40': assert d['final_binary_sha256']==final_ops[1]['final_hash']
 profiles.append(dict(run=name,hash=d['final_binary_sha256'],errors=p['errors'],semantics=p['semantics'],sources=p['sources'],steps=steps))
fine=[]
assert read(ROOT/'control-plain-public40.json')['final_binary_sha256']==read(ROOT/'before-fine-public40.json')['final_binary_sha256']
assert len({read(ROOT/(name+'.json'))['final_binary_sha256'] for name in ['before-fine-gp40','before-all-gp40','after-all-gp40','final-all-gp40']})==1
for name in ['before-fine-public40','before-fine-gp40']:
 d=read(ROOT/(name+'.json'));f=d['fine_cost']
 assert d['qualified'] and not d['errors']
 fine.append(dict(run=name,hash=d['final_binary_sha256'],entry_calls=sum(r['calls'] for r in f['entry_orders'].values()),
  normalized_groups=len(f['entry_orders']),raw_groups=sum(len(r['raw_variants']) for r in f['entry_orders'].values()),
  entry_totals={k:sum(r[k] for r in f['entry_orders'].values()) for k in ['prep_us','enumerate_us','sort_us']},
  biggest_entry_groups=sorted(f['entry_orders'].items(),key=lambda row:row[1]['enumerate_us'],reverse=True)[:6],
  rebuilds=f['actor_rebuilds'],dynamic_callers=f['dynamic_callers'],cold_regions=f['cold_regions']))
dump('stage-function-summary.json',dict(profiles=profiles,fine=fine,
 caution='Whole-step gains use plain only. Diagnostic observer cost and wrapper perturbation remain. Inclusive contains children; do not add to exclusive or root stages. New helpers move exclusive ownership. Fine ticks are executing world.sim_tick; profile result tick is the completed tick.'))

batches=['81193fd956b34e30be439e4a83d671e6','2cf71badb57d4dcb822024f3328bce2c','559f99440e09447888b0db6680ca9ead']
functional=[]
for batch in batches:
 directory=REPO/'.cache/acceptance'/batch;r=read(directory/'acceptance-results.json')
 assert r['failed']==0 and r['completed']
 assert 'SCRIPT ERROR:' not in (directory/'execution.log').read_text(encoding='utf-8-sig')
 functional.append(dict(batch=batch,cases=r['requested_cases'],checks=r['checks'],failed=r['failed'],timing=read(directory/'timing-summary.json')))
unique=sorted(set(case for row in functional for case in row['cases']))
assert len(unique)==17
dump('functional-summary.json',dict(unique_selected_passed=unique,batches=functional,
 reuse='After the first16, only three pure values are hoisted outside a destination loop; six affected cross-floor/egress cases rerun. The final one-line source==queried-world fast guard cannot represent a valid exclusion scope; SPACE51 independently rerun. Unchanged task, cache, region, transit and reservation assertions reuse earlier passes.'))

before=read(ROOT/'before-project/source-identity.json');after=read(ROOT/'final-project/source-identity.json')
rows=[r for r in before['source'] if r['path'].startswith(('game/','content/','tools/performance/'))]
raw_git=subprocess.run(['git','cat-file','--batch'],input=''.join(BASE+':'+r['path']+'\n' for r in rows).encode(),cwd=REPO,check=True,stdout=subprocess.PIPE).stdout
cursor=0;baseline=[]
for row in rows:
 end=raw_git.index(b'\n',cursor);header=raw_git[cursor:end].split();size=int(header[-1]);cursor=end+1
 blob=raw_git[cursor:cursor+size];cursor+=size+1
 match=hashlib.sha256(blob).hexdigest()==row['sha256'];assert match,row['path']
 baseline.append(dict(path=row['path'],match=match,sha256=row['sha256']))
current=[dict(path=r['path'],match=sha(REPO/r['path'])==r['sha256'],sha256=r['sha256']) for r in after['source'] if r['path'].startswith(('game/','content/','tools/performance/'))]
assert current and all(r['match'] for r in current)
tests=read(REPO/'.cache/acceptance'/batches[-1]/'source-identity.json')
test_rows=tests.get('source',tests.get('files',[]))
test_checks=[dict(path=r['path'],match=sha(REPO/r['path'])==r['sha256']) for r in test_rows if r['path'].startswith('tests/acceptance/')]
assert test_checks and all(r['match'] for r in test_checks)
first=read(REPO/'.cache/acceptance'/batches[0]/'source-identity.json')
changes=[r['path'] for r in first.get('source',first.get('files',[])) if r['path'].startswith(('game/','content/','tests/acceptance/')) and sha(REPO/r['path'])!=r['sha256']]
assert sorted(changes)==['game/building/hospital_navigation.gd','game/building/hospital_space.gd'],changes
binary={k:before[k]==after[k] for k in ['engine_sha256','native_sha256','gmp_sha256','mpfr_sha256','runtime_sha256']};assert all(binary.values())
transforms=[]
for side in ['before','after','final']:
 directory=ROOT/(side+'-all-project');identity=read(directory/'all-instance-profile-identity.json')
 for row in identity['files']:
  assert sha(directory/row['path'])==row['generated_sha256']
  assert sha(directory/'.cache/tail-profile-originals'/row['path'])==row['original_sha256']==sha(ROOT/(side+'-project')/row['path'])
 transforms.append(dict(side=side,files=identity['transformed_file_count'],methods=identity['actual_method_count'],originals_match_plain=True))
dump('source-check.json',dict(baseline=BASE,baseline_rows=len(baseline),baseline_checks=baseline,current_rows=len(current),current=current,
 acceptance_rows=len(test_checks),acceptance=test_checks,first_batch_later_change=changes,binary_matches=binary,transforms=transforms,
 binary_identity={k:after[k] for k in binary}))

raw={}
def add(path):
 path=pathlib.Path(path)
 if path.is_file():raw[path.relative_to(REPO).as_posix()]=path
for p in ROOT.iterdir():
 if p.is_file():add(p)
 elif p.name.endswith('.sources'):
  for q in p.rglob('*.gd'):add(q)
 elif p.name.endswith('-project'):
  for rel in ['source-identity.json','all-instance-profile-identity.json','import.log','project.godot',
   'game/life/public_areas.gd','game/building/hospital_space.gd','game/building/hospital_navigation.gd',
   'tools/performance/representative.gd','tools/performance/representative_selected.gd','tools/performance/step_profile.gd']:
   add(p/rel)
  for q in (p/'.cache/tail-profile-originals').rglob('*.gd'):add(q)
for name in ['public-v6.input.bin','gp.input.bin','op.input.bin']:add(REPO/'.cache/task-navigation-20261019'/name)
for batch in batches:
 p=REPO/'.cache/acceptance'/batch
 for name in ['acceptance-results.json','execution.log','execution-status.json','import.log','timing-summary.json','source-identity.json']:add(p/name)
 for name in ['public_region_build.gd','public_phase_use.gd','navigation_static_reuse.gd']:add(p/'tests/acceptance'/name)
for side in ['before','before-all']:
 p=REPO/'.cache/remaining-b9bb59d-20261021'/(side+'-project')
 for name in ['source-identity.json','all-instance-profile-identity.json','game/life/public_areas.gd','game/building/hospital_space.gd','game/building/floor_navigation.gd']:add(p/name)
for p in OUT.glob('*.json'):
 if p.name!='raw-manifest.json':add(p)
manifest=[];archive=OUT/'raw-evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,p in sorted(raw.items()):
  z.write(p,name);manifest.append(dict(path=name,bytes=p.stat().st_size,sha256=sha(p)))
with zipfile.ZipFile(archive) as z:
 for row in manifest:assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256']
dump('raw-manifest.json',dict(archive_sha256=sha(archive),archive_bytes=archive.stat().st_size,verified_entries=len(manifest),entries=manifest))
print(json.dumps(dict(windows=[dict(window=w['window'],before=w['before_window_metric_average'],after=w['after_window_metric_average'],reductions=w['reductions']) for w in windows],source_rows=len(current),test_rows=len(test_checks),raw_entries=len(manifest),raw_bytes=archive.stat().st_size),ensure_ascii=False))
