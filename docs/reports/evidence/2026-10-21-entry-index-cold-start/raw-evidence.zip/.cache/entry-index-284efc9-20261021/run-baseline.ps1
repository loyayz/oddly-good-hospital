#requires -Version 7.0
$ErrorActionPreference='Stop'
$repo='C:/code/loyayz/oddly-good-hospital'
$root=Join-Path $repo '.cache/entry-index-284efc9-20261021'
$godot='C:/programs/godot/Godot_v4.7.2-stable_win64_console.exe'
& $godot --headless --editor --path (Join-Path $root 'before-project') --import --quit *> (Join-Path $root 'before-reimport.log')
if($LASTEXITCODE -ne 0 -or (Select-String (Join-Path $root 'before-reimport.log') -Pattern 'SCRIPT ERROR:|ERROR:' -Quiet)){throw 'Baseline import failed'}
$runs=@(
    @{name='before-plain-public360';input='public-v6.input.bin';steps=360},
    @{name='before-plain-gp80';input='gp.input.bin';steps=80},
    @{name='before-plain-operations40';input='op.input.bin';steps=40}
)
foreach($run in $runs){
    $output=Join-Path $root ($run.name+'.json')
    if(Test-Path -LiteralPath $output){throw "Evidence already exists: $output"}
    $input=Join-Path $repo ('.cache/task-navigation-20261019/'+$run.input)
    $log=[IO.Path]::ChangeExtension($output,'.log')
    & $godot --headless --path (Join-Path $root 'before-project') --script res://tools/performance/representative.gd -- "--input=$input" "--output=$output" "--steps=$($run.steps)" --profile=plain *> $log
    if($LASTEXITCODE -ne 0 -or (Select-String -LiteralPath $log -Pattern 'SCRIPT ERROR:|ERROR:' -Quiet)){Get-Content $log -Tail 12;throw "Run failed: $log"}
    $result=Get-Content $output -Raw|ConvertFrom-Json
    if(-not $result.qualified){throw "Unqualified: $output"}
    [ordered]@{run=$run.name;metrics=$result.metrics;qualified=$result.qualified;public_checks=$result.public_checks;final_hash=$result.final_binary_sha256}|ConvertTo-Json -Depth 4 -Compress
}
