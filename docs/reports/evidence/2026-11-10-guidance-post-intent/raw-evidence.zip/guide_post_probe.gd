extends SceneTree
func _initialize() -> void:call_deferred("_run")
func _run() -> void:
	var args: PackedStringArray=OS.get_cmdline_user_args()
	var content:=HospitalContent.new()
	var suite: RefCounted=load("res://tests/acceptance/floor_guidance.gd").new();suite._content=content
	var x: Dictionary=suite._base()
	for tick: int in 200:
		suite._step(x)
		if x.g._desk_usable(x.world,"guide"):break
	var layout: Dictionary=x.space.facility_layout(x.world,"guide")
	var head: Dictionary=suite._visit(x,"head",layout.patient_cell)
	var point: Dictionary=x.g._queue_point(x.world,head.actor_id,"guide",head.id)
	x.world.facts.actors[head.actor_id].location.cell=point.cell.duplicate()
	var passer: Dictionary=x.world.facts.actors[head.actor_id].duplicate(true)
	passer.id="passer";passer.name="过路者";passer.location.cell=[float(point.cell[0])-0.6,point.cell[1]]
	x.world.facts.actors["passer"]=passer
	for item: Array in [["lower_guard",[float(point.cell[0])-0.6,float(point.cell[1])+1.0]],["back_guard",[float(point.cell[0])-1.5,point.cell[1]]]]:
		var actor: Dictionary=passer.duplicate(true);actor.id=item[0];actor.location.cell=item[1]
		x.world.facts.actors[str(item[0])]=actor
	x.world.touch()
	var request: String=x.space.request_move(x.world,"passer",1,[float(point.cell[0])+2.5,point.cell[1]])
	x.g.prepare(x.world,head,x.world.facts.tickets[head.ticket_id])
	var state: Dictionary=x.g.state(x.world,"head")
	var initial: Dictionary=x.world.freeze()
	var validation: String=x.world.validate(content)
	var quote: Dictionary=x.space.facility_quote(x.world,"guide",head.actor_id,["guide_nurse"])
	var geometry: Dictionary=x.space.facility_geometry_quote(x.world,"guide",head.actor_id,["guide_nurse"])
	var trace: Array=[]
	var errors: Array=[]
	for tick: int in 300:
		suite._step(x)
		var error: String=x.world.validate(content)
		if not error.is_empty():errors.append(error);break
		state=x.g.state(x.world,"head")
		if tick<12 or tick%20==0:trace.append({"tick":tick,"head":x.world.facts.actors[head.actor_id].location.cell.duplicate(),"passer":x.world.facts.actors.passer.location.cell.duplicate(),"phase":state.phase,"reason":head.waiting_reason,"head_move":x.world.facts.moves.get(head.actor_id,{}).duplicate(true)})
		if not state.get("receipts",[]).is_empty():break
	var complete: bool=not state.get("receipts",[]).is_empty()
	var result: Dictionary={"ok":validation.is_empty() and request.is_empty() and geometry.get("ok",false) and complete and errors.is_empty(),"initial_validation":validation,"request":request,"initial_quote":quote,"initial_geometry":geometry,"initial":initial,"actual_guide_complete":complete,"errors":errors,"trace":trace,"final":x.world.freeze()}
	FileAccess.open(args[0],FileAccess.WRITE).store_string(JSON.stringify(result,"\t"))
	print(JSON.stringify({"complete":complete,"validation":validation,"errors":errors,"quote":quote.get("reason"),"geometry":geometry.get("ok")}))
	suite._dispose(x);quit(0 if result.ok else 1)
