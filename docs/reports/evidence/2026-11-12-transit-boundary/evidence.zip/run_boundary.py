import hashlib,importlib.util,json,sys
from pathlib import Path
base=Path('C:/Users/cong/dot-work/ogh-boundary-20261112')
project=base/'.cache/boundary-project'
sys.path.insert(0,str(base/'tools/performance/current'))
import prepare_builtin_script_profile as guard
import prepare_transport_trace as overlay
meta=json.loads((base/'input-identity.json').read_text())
engine=meta['engine']; input_path=base/'full-terminal.bin'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for rel,digest in meta['source'].items():assert sha(project/rel)==digest,rel
assert sha(input_path)==meta['input_sha256']
print('Importing isolated project',flush=True)
imp=guard.run_process([engine,'--headless','--path',str(project),'--editor','--import','--quit'],project,base/'import',120)
print('Running one plain production step',flush=True)
def run(name):
    folder=base/name;output=folder/'result.json'
    command=[engine,'--headless','--path',str(project),'--script','res://tools/performance/current/plain_v4.gd','--','--input='+str(input_path),'--output='+str(output),'--steps=1','--prefix-steps=0','--worker-tasks=4','--main-thread-policy=app']
    process=guard.run_process(command,project,folder,120)
    result=json.loads(output.read_text())
    assert result['complete'] and result['all_completed_steps']==1 and result['initial']['tick']==7633 and result['final']['tick']==7634 and not result['errors']
    return {'process':process,'result_sha256':sha(output),'final_sha256':result['final_sha256']}
plain=run('plain')
manifest=overlay.prepare(project)
print('Running one traced production step',flush=True)
traced=run('traced')
assert plain['final_sha256']==traced['final_sha256'],'Observer perturbed complete facts/events'
assert sha(input_path)==meta['input_sha256']
for rel,item in manifest['reversible_hooks'].items():
    p=project/rel;assert sha(p)==item['instrumented_sha256']
    text=p.read_text(encoding='utf-8')
    for pair in reversed(item['replacements']):
        old,new=pair['original'],pair['instrumented']
        if not old:assert text.endswith(new);text=text[:-len(new)]
        else:assert text.count(new)==1;text=text.replace(new,old,1)
    p.write_bytes(text.encode('utf-8'));assert sha(p)==item['original_sha256']
summary={'ok':True,'input_sha256':meta['input_sha256'],'plain':plain,'traced':traced,'complete_world_rng_events_equal':True,'overlay_restored_exactly':True,'scope':'Two executions of the same single boundary step from complete tick7633. No history replay or performance qualification.'}
(base/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps(summary),flush=True)
