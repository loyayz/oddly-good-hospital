import hashlib,json,sys
from pathlib import Path
base=Path('C:/Users/cong/dot-work/ogh-boundary-20261112');project=base/'.cache/boundary-project'
sys.path.insert(0,str(base/'tools/performance/current'))
import prepare_transport_trace as overlay
import prepare_builtin_script_profile as guard
(project/'transport-diagnostic-identity.json').rename(project/'transport-diagnostic-identity.first.json')
manifest=overlay.prepare(project)
patch=overlay.Patch(project/'game/building/hospital_space.gd')
patch.replace('class_name HospitalSpace\nextends RefCounted\n','class_name HospitalSpace\nextends RefCounted\n'+overlay.PREFIX)
# Patch only actual return branches; no additional queries or RNG.
import re
match=re.search(r'^func _dynamic_clear\([^\n]*\)[^\n]*:\n[\s\S]*?(?=^func |\Z)',patch.text,re.M);old=match[0];new=old
new=new.replace('\t\tif rect.intersects(region.rect,false):\n\t\t\treturn false','\t\tif rect.intersects(region.rect,false):\n\t\t\tif actor_id=="bench_patient_0018": _TransportDiagnostic._record(world,"actual_dynamic_reject",{"actor_id":actor_id,"branch":"reservation","reservation_id":region.reservation_id,"floor_id":floor_id})\n\t\t\treturn false')
new=new.replace('\t\tif _actor_index.intersects(floor_id,rect,actor_id,ignored):\n\t\t\treturn false','\t\tif _actor_index.intersects(floor_id,rect,actor_id,ignored):\n\t\t\tif actor_id=="bench_patient_0018": _TransportDiagnostic._record(world,"actual_dynamic_reject",{"actor_id":actor_id,"branch":"current_body_index","floor_id":floor_id,"rect":_TransportDiagnostic._raw_rect(rect)})\n\t\t\treturn false')
new=new.replace('\tif movement._sweep_index.intersects(floor_id,rect,actor_id,members):\n\t\treturn false','\tif movement._sweep_index.intersects(floor_id,rect,actor_id,members):\n\t\tif actor_id=="bench_patient_0018": _TransportDiagnostic._record(world,"actual_dynamic_reject",{"actor_id":actor_id,"branch":"accepted_sweep","floor_id":floor_id})\n\t\treturn false')
assert new.count('_TransportDiagnostic._record')==3
patch.replace(old,new)
m=project/'game/building/hospital_movement.gd';original=m.read_bytes();text=original.decode();header='func _move_step(world: WorldState, actor: Dictionary, movement: Dictionary, segment: Dictionary) -> MotionResult:'
assert text.count(header)==1
text=text.replace(header,header.replace('func _move_step(','func _boundary_original_move_step('),1)
wrapper='''
func _move_step(world: WorldState, actor: Dictionary, movement: Dictionary, segment: Dictionary) -> MotionResult:
	var captured: bool=actor.id=="bench_patient_0013"
	var before: Dictionary=_TransportDiagnostic._actor(world,actor.id) if captured else {}
	var result: MotionResult=_boundary_original_move_step(world,actor,movement,segment)
	if captured:
		_TransportDiagnostic._record(world,"actual_patient13_move",{"before":before,"after":_TransportDiagnostic._actor(world,actor.id),"segment":segment.duplicate(true),"requested":[result.requested_motion.x,result.requested_motion.y],"actual":[result.actual_motion.x,result.actual_motion.y],"body_ids":result.blocker_actor_ids.duplicate(),"reservation_ids":result.reservation_ids.duplicate(),"static_reason":result.static_reason,"door_id":result.door_id})
	return result
'''
text+=wrapper
extra={'space':patch.checked(),'movement_before_sha256':hashlib.sha256(original).hexdigest(),'movement_after_sha256':hashlib.sha256(text.encode()).hexdigest(),'wrapper':wrapper}
(base/'detail-overlay.json').write_text(json.dumps(extra,indent=2),encoding='utf-8')
patch.path.write_bytes(patch.text.encode());m.write_bytes(text.encode())
meta=json.loads((base/'input-identity.json').read_text());out=base/'detailed/result.json'
command=[meta['engine'],'--headless','--path',str(project),'--script','res://tools/performance/current/plain_v4.gd','--','--input='+str(base/'full-terminal.bin'),'--output='+str(out),'--steps=1','--prefix-steps=0','--worker-tasks=4','--main-thread-policy=app']
try:
 process=guard.run_process(command,project,out.parent,120)
 result=json.loads(out.read_text());plain=json.loads((base/'plain/result.json').read_text())
 assert result['complete'] and result['all_completed_steps']==1 and result['final_sha256']==plain['final_sha256']
 (base/'detailed/summary.json').write_text(json.dumps({'ok':True,'complete_world_rng_events_equal':True,'final_sha256':result['final_sha256'],'process':process},indent=2),encoding='utf-8')
 print('Detailed one-step full fact/event comparison passed',flush=True)
finally:
 patch.path.write_bytes(patch.original);m.write_bytes(original)
 for rel,item in manifest['reversible_hooks'].items():
  p=project/rel;t=p.read_text(encoding='utf-8')
  for pair in reversed(item['replacements']):
   old,new=pair['original'],pair['instrumented']
   if not old:assert t.endswith(new);t=t[:-len(new)]
   else:assert t.count(new)==1;t=t.replace(new,old,1)
  p.write_bytes(t.encode());assert hashlib.sha256(p.read_bytes()).hexdigest()==item['original_sha256']
