from pathlib import Path
import json,sys
base=Path('C:/Users/cong/dot-work/ogh-boundary-20261112');project=base/'.cache/boundary-project'
sys.path.insert(0,str(base/'tools/performance/current'))
import prepare_builtin_script_profile as guard
meta=json.loads((base/'input-identity.json').read_text());out=base/'plain8/result.json'
command=[meta['engine'],'--headless','--path',str(project),'--script','res://tools/performance/current/plain_v4.gd','--','--input='+str(base/'full-terminal.bin'),'--output='+str(out),'--steps=8','--prefix-steps=0','--worker-tasks=4','--main-thread-policy=app']
process=guard.run_process(command,project,out.parent,120)
result=json.loads(out.read_text());assert result['complete'] and result['all_completed_steps']==8
print('Plain eight-step bounded boundary passed',flush=True)
s=(base/'run_detail.py').read_text(encoding='utf-8-sig')
s=s.replace('transport-diagnostic-identity.first.json','transport-diagnostic-identity.second.json').replace("base/'detailed/result.json'","base/'detailed8/result.json'").replace("'--steps=1'","'--steps=8'").replace("base/'plain/result.json'","base/'plain8/result.json'").replace("result['all_completed_steps']==1","result['all_completed_steps']==8").replace("base/'detailed/summary.json'","base/'detailed8/summary.json'").replace("base/'detail-overlay.json'","base/'detail8-overlay.json'").replace('Detailed one-step','Detailed eight-step')
(base/'run_detail8.py').write_text(s,encoding='utf-8')
exec(compile(s,str(base/'run_detail8.py'),'exec'))
