extends RefCounted

# Observations run outside the complete-step timer and never edit facts.
var starts: Dictionary = {}
var completions: Dictionary = {}
var fallbacks: Dictionary = {}
var queued_actors: Dictionary = {}
var last_owner: Dictionary = {}
var previous: Dictionary = {}
var trace: Array = []
var errors: Array = []
var queue_peak: int = 0
var use_ticks: int = 0
var handoffs: int = 0
var initial_queries: Dictionary = {}

func _init(space: HospitalSpace) -> void:
	initial_queries = space.query_counts.duplicate()

func observe(world: WorldState, space: HospitalSpace) -> void:
	var current: Dictionary = {}
	var queued: int = 0
	for need: Dictionary in world.facts.waiting_life.needs.values():
		var actor_id: String = str(world.facts.visits[need.visit_id].actor_id)
		current[need.id] = need.duplicate(true)
		var prior: Dictionary = previous.get(need.id,{})
		if need.phase in ["local_wait","manual_wait"] and int(need.get("arrived_tick",-1))>=0:
			queued += 1
			queued_actors[actor_id] = true
		if need.phase=="using":
			if not starts.has(need.id):
				starts[need.id] = {"tick":world.sim_tick,"actor_id":actor_id,"facility_id":need.facility_id}
				if last_owner.has(need.facility_id) and last_owner[need.facility_id].actor_id!=actor_id:
					var old_actor: String = str(last_owner[need.facility_id].actor_id)
					if space.overlaps_facility(world,old_actor,need.facility_id): errors.append("New public use began before the previous body left: "+need.facility_id)
					else: handoffs += 1
				last_owner[need.facility_id] = starts[need.id]
				trace.append({"kind":"actual_use_start","id":need.id,"data":starts[need.id]})
				var total: int = 0
				for service: Dictionary in space.content.catalog.amenity_services:
					if service.purpose==need.purpose: total = ceili(float(service.ordinary_seconds)/WorldState.TICK_SECONDS)
				use_ticks += total-int(need.remaining_ticks)
			else: use_ticks += maxi(0,int(prior.get("remaining_ticks",need.remaining_ticks))-int(need.remaining_ticks))
			var layout: Dictionary = space.facility_layout(world,need.facility_id)
			if not space.at(world,actor_id,int(layout.floor_id),layout.patient_cell) or world.facts.moves.has(actor_id): errors.append("Public service ran without real arrival: "+need.id)
		if need.phase=="fallback" and not fallbacks.has(need.id):
			fallbacks[need.id] = world.sim_tick
			trace.append({"kind":"fallback_start","id":need.id,"tick":world.sim_tick})
		if need.phase=="returning" and prior.get("phase","")=="using":
			use_ticks += int(prior.remaining_ticks)
			completions[need.id] = world.sim_tick
			trace.append({"kind":"actual_use_complete","id":need.id,"tick":world.sim_tick})
	queue_peak = maxi(queue_peak,queued)
	previous = current

func report(space: HospitalSpace) -> Dictionary:
	var queries: Dictionary = {}
	for key: String in space.query_counts: queries[key] = int(space.query_counts[key])-int(initial_queries.get(key,0))
	return {"actual_use_starts":starts,"actual_use_completions":completions,"actual_use_ticks":use_ticks,"fallback_starts":fallbacks,"actual_queued_actors":queued_actors.keys(),"queue_peak":queue_peak,"actual_exit_then_reuse_count":handoffs,"query_counts":queries,"trace":trace,"errors":errors}
