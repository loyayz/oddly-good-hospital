from pathlib import Path
import json,re,hashlib,zipfile,subprocess,statistics,sys
task=Path(__file__).resolve().parent
root=task.parents[1]
dest=root/'docs/reports/evidence/2026-10-18-public-facility-area-use'
dest.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def compact_final(r):
    fields=['source_tick','tick','observed_steps','minimum_present','maximum_present','same_actor_ids','validation','work_ticks_by_kind','services_started','services_completed','phase_counts','present','active_patients','present_visitors','moves','preparations','facilities','rooms','staff','total_actor_records','added_actor_records','ok','errors','inventory_units','ledger_entries','supply_issues']
    return {k:r[k] for k in fields if k in r}
def save(name,value):
    (dest/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf8',newline='\n')

batches=[]
latest={}
projects={}
for log in task.glob('*.log'):
    match=re.search(r'ACCEPTANCE_PROJECT=([^\r\n]+)',log.read_text(encoding='utf8',errors='replace'))
    if match:
        project=Path(match.group(1).strip())
        if (project/'acceptance-results.json').exists(): projects[project]=log
for project,log in sorted(projects.items(),key=lambda item:item[0].joinpath('acceptance-results.json').stat().st_mtime):
    result=json.loads((project/'acceptance-results.json').read_text(encoding='utf-8-sig'))
    status=json.loads((project/'execution-status.json').read_text(encoding='utf-8-sig')) if (project/'execution-status.json').exists() else {}
    timing=json.loads((project/'timing-summary.json').read_text(encoding='utf-8-sig')) if (project/'timing-summary.json').exists() else {}
    item={'batch':log.name,'project':project.name,'checks':result.get('checks'), 'failed':result.get('failed'),'completed':result.get('completed'), 'status':status,'timing':timing,'cases':list(result.get('results',{}))}
    batches.append(item)
    if result.get('completed') and not status.get('script_errors',True):
        for cid,row in result.get('results',{}).items():
            latest[cid]={'batch':log.name,'project':project.name,'passed':row['passed'],'suite':row['suite'],'requirement':row['requirement'],'elapsed_ms':row['elapsed_ms'],'setup_ms':row['setup_ms'],'body_ms':row['body_ms'],'fixtures':row['fixtures']}
functional={'scope':'affected cases only; per-case passing evidence reused at unchanged interfaces; no full-suite claim','distinct_cases':len(latest),'passed':sum(row['passed'] for row in latest.values()),'unresolved':[cid for cid,row in latest.items() if not row['passed']],'final_batches':['final-source-regression-2.log','final-remaining-handoffs-1.log'],'batches':batches,'cases':dict(sorted(latest.items()))}
functional['reused_cases']=[cid for cid,row in functional['cases'].items() if row['batch'] not in functional['final_batches']]
save('functional-summary.json',functional)
if '--functional-only' in sys.argv:
    print(json.dumps({'distinct_cases':functional['distinct_cases'],'passed':functional['passed'],'unresolved':functional['unresolved'],'reused_cases':functional['reused_cases']},ensure_ascii=False))
    raise SystemExit(0)

quick={'diagnostic_only':True,'formal_pass':False,'formal_acceptance_paused':True,'baseline':'8c4a96efc08b2860d6eaa8673e928fad52f58601','pairs':{},'failures':[], 'public':{},'allocation':{}}
for scenario in ['gp','op']:
    sides={}
    for side in ['before','after']:
        reports=[json.loads((task/f'v8-{side}-{scenario}-{i}.json').read_text(encoding='utf8')) for i in [1,2,3]]
        assert all(r['qualified'] and r['complete'] for r in reports)
        sides[side]={'runs':[{'report':f'v8-{side}-{scenario}-{i}.json','input_sha256':r['source_input_sha256'],'qualified':r['qualified'],'metrics':r['metrics'],'initialization_elapsed_us':r['initialization_elapsed_us'],'final':compact_final(r['final']),'public':r['public'],'final_binary_sha256':r['final_binary_sha256']} for i,r in zip([1,2,3],reports)],'median_of_window_means_us':statistics.median(r['metrics']['mean_us'] for r in reports),'median_p50_us':statistics.median(r['metrics']['p50_us'] for r in reports),'median_p95_us':statistics.median(r['metrics']['p95_us'] for r in reports),'median_max_us':statistics.median(r['metrics']['max_us'] for r in reports),'median_cold_first_us':statistics.median(r['metrics']['cold_first_us'] for r in reports)}
    sides['mean_change_percent']=(sides['after']['median_of_window_means_us']/sides['before']['median_of_window_means_us']-1)*100
    nested=json.loads((task/f'v8-after-{scenario}-nested.json').read_text(encoding='utf8'))
    sides['profile']={'report':f'v8-after-{scenario}-nested.json','facts_rng_ordered_events_same_as_plain':nested['final_binary_sha256']==sides['after']['runs'][-1]['final_binary_sha256'],'root_stages':nested['profile']['root_stages'],'nested_calls':nested['profile']['nested_calls']}
    assert sides['profile']['facts_rng_ordered_events_same_as_plain']
    assert {r['input_sha256'] for side in ['before','after'] for r in sides[side]['runs']}.__len__()==1
    quick['pairs'][scenario]=sides
for name in ['public-v5-root-300','v8-after-public-root','late-v6-nested-1','late-v8-nested-1']:
    r=json.loads((task/(name+'.json')).read_text(encoding='utf8'))
    quick['public'][name]={'report':name+'.json','mode':r['mode'],'qualified':r['qualified'],'qualification':r['qualification'],'complete':r['complete'],'metrics':r['metrics'],'public_checks':r.get('public_checks',{}),'public':r['public'],'final':compact_final(r['final']),'profile':{k:v for k,v in r['profile'].items() if k not in ['step_records','sources']}}
assert quick['public']['v8-after-public-root']['qualified'] and all(quick['public']['v8-after-public-root']['public_checks'].values())
for name in ['before-bed-allocation','after-bed-allocation','v8-bed-allocation']:
    quick['allocation'][name]=json.loads((task/(name+'.json')).read_text(encoding='utf8'))
assert quick['allocation']['v8-bed-allocation']['ok'] and quick['allocation']['v8-bed-allocation']['owners']==quick['allocation']['before-bed-allocation']['owners']
for meta in task.glob('*.run.json'):
    r=json.loads(meta.read_text(encoding='utf8'))
    if r.get('exit_code') or r.get('timed_out') or r.get('engine_errors'): quick['failures'].append({'metadata':meta.name,'classification':'expected_no_clinical_work_diagnostic' if meta.name in ['late-v6-nested-1.run.json','late-v8-nested-1.run.json'] else 'incomplete_or_failed',**r})
save('quick-summary.json',quick)

paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],cwd=root,text=True,encoding='utf8').splitlines()
source=[{'path':p,'sha256':sha(root/p)} for p in sorted(set(paths)) if (p.startswith(('game/','tools/performance/','tests/acceptance/','content/')) or p in ['project.godot','export_presets.cfg']) and (root/p).is_file()]
frozen=json.loads((task/'after-v8-project/source-identity.json').read_text(encoding='utf-8-sig'))
for item in frozen['source']:
    if item['path'].endswith('.gd'): assert sha(root/item['path'])==item['sha256'], 'Final executable source drifted: '+item['path']
save('final-source-identity.json',{'baseline':quick['baseline'],'sources':source,'performance_project':'after-v8-project/source-identity.json','native_sha256':sha(root/'game/platform/windows/bin/oddly_good_platform.windows.x86_64.dll')})

entries={}
def add(file,name):
    if file.is_file(): entries[name.replace('\\','/')]=file
for file in task.iterdir():
    if file.is_file(): add(file,'raw/'+file.name)
    elif file.name.endswith('.sources'):
        for child in file.rglob('*'): add(child,'raw/'+child.relative_to(task).as_posix())
for project,log in projects.items():
    for name in ['acceptance-results.json','execution-status.json','execution.log','import.log','source-identity.json','timing-summary.json','fixture-config.json']:
        add(project/name,'acceptance/'+project.name+'/'+name)
    for name in ['tests/acceptance/public_area_use.gd','tests/acceptance/clinical_timing.gd','game/life/public_areas.gd','game/life/waiting_life.gd','game/staff/staff_wellbeing.gd','game/staff/personal_beds.gd','game/clinic/clinical_runtime.gd','game/operations/environment_service.gd']:
        add(project/name,'acceptance/'+project.name+'/'+name)
for project in task.glob('*project'):
    for name in ['source-identity.json','import.log']:
        add(project/name,'performance/'+project.name+'/'+name)
    for name in ['game/life/public_areas.gd','game/life/waiting_life.gd','game/staff/staff_wellbeing.gd','game/staff/personal_beds.gd','game/clinic/clinical_runtime.gd','game/operations/environment_service.gd','tools/performance/representative.gd','tools/performance/representative_public.gd','tools/performance/step_profile.gd']:
        add(project/name,'performance/'+project.name+'/'+name)
for file in [root/'.cache/performance-loop-20261018/clinical-corrected/clinical-corrected-r2-gp_work_handoff.input.bin',root/'.cache/performance-loop-20261018/operations.input.bin']:
    add(file,'original-inputs/'+file.name)
archive=dest/'raw-evidence.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,file in sorted(entries.items()): z.write(file,name)
save('evidence-manifest.json',{'archive':archive.name,'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'entry_count':len(entries),'entries':[{'path':name,'sha256':sha(file),'bytes':file.stat().st_size} for name,file in sorted(entries.items())]})
print(json.dumps({'cases':functional['distinct_cases'],'passed':functional['passed'],'unresolved':functional['unresolved'],'pairs':{k:{'before_mean_ms':v['before']['median_of_window_means_us']/1000,'after_mean_ms':v['after']['median_of_window_means_us']/1000,'change_percent':v['mean_change_percent']} for k,v in quick['pairs'].items()},'zip_bytes':archive.stat().st_size},ensure_ascii=False))
