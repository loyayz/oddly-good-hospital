from pathlib import Path
import subprocess, sys, shutil, hashlib, json
out=Path(__file__).resolve().parent
root=out.parents[1]
for name in ['representative.gd','representative_public.gd','step_profile.gd']:
    for side in ['before-project','after-v2-project']:
        shutil.copyfile(root/'tools/performance'/name,out/side/'tools/performance'/name)
shutil.copyfile(root/'tools/performance/prepare_public_input.gd',out/'after-v2-project/tools/performance/prepare_public_input.gd')
identities={}
for side in ['before-project','after-v2-project']:
    identities[side]={name:hashlib.sha256((out/side/'tools/performance'/name).read_bytes()).hexdigest() for name in ['representative.gd','representative_public.gd','step_profile.gd']}
(out/'probe-tools-identity.json').write_text(json.dumps(identities,indent=2),encoding='utf8')
def run(project,name,timeout,*args):
    result=subprocess.run([sys.executable,str(out/'run_engine.py'),str(out/project),name,str(timeout),*args],capture_output=True,text=True,encoding='utf8',errors='replace')
    (out/(name+'.console.log')).write_text(result.stdout+result.stderr,encoding='utf8')
    print(name,result.returncode,flush=True)
    if result.returncode: raise SystemExit(result.returncode)
for scenario,steps in [('gp',80),('op',40)]:
    name='after-v2-'+scenario+'-1'
    run('after-v2-project',name,180,f'--input={(out/(scenario+".input.bin")).as_posix()}',f'--output={(out/(name+".json")).as_posix()}',f'--steps={steps}','--profile=plain')
run('after-v2-project','public-v3-preparation',180,'script=res://tools/performance/prepare_public_input.gd',f'--source={(root/".cache/performance-loop-20261018/clinical-corrected/clinical-corrected-r2-gp_work_handoff.input.bin").as_posix()}',f'--output={(out/"public-v3.input.bin").as_posix()}','--contention=true')
name='after-v2-public-1'
run('after-v2-project',name,240,f'--input={(out/"public-v3.input.bin").as_posix()}',f'--output={(out/(name+".json")).as_posix()}','--steps=300','--profile=plain')
