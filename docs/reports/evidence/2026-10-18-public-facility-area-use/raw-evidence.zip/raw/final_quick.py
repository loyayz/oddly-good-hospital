from pathlib import Path
import subprocess, sys, shutil, hashlib, json
out=Path(__file__).resolve().parent
root=out.parents[1]
after='after-v5-project'
for name in ['representative.gd','representative_public.gd','step_profile.gd']:
    shutil.copyfile(root/'tools/performance'/name,out/'before-project/tools/performance'/name)
identities={side:{name:hashlib.sha256((out/side/'tools/performance'/name).read_bytes()).hexdigest() for name in ['representative.gd','representative_public.gd','step_profile.gd']} for side in ['before-project',after]}
if identities['before-project']!=identities[after]: raise SystemExit('Common diagnostic source differs')
(out/'final-common-tools-identity.json').write_text(json.dumps(identities,indent=2),encoding='utf8')
def run(project,name,timeout,*args):
    result=subprocess.run([sys.executable,str(out/'run_engine.py'),str(out/project),name,str(timeout),*args],capture_output=True,text=True,encoding='utf8',errors='replace')
    (out/(name+'.console.log')).write_text(result.stdout+result.stderr,encoding='utf8')
    print(name,result.returncode,flush=True)
    if result.returncode: raise SystemExit(result.returncode)
def measure(side,scenario,steps,index,mode='plain'):
    name=f'final-{side}-{scenario}-{index}'
    source=out/('public-v6.input.bin' if scenario=='public' else scenario+'.input.bin')
    run('before-project' if side=='before' else after,name,300,f'--input={source.as_posix()}',f'--output={(out/(name+".json")).as_posix()}',f'--steps={steps}',f'--profile={mode}')
    return json.loads((out/(name+'.json')).read_text(encoding='utf8'))
run(after,'after-bed-allocation',180,'script=res://tools/performance/personal_bed_probe.gd',f'--input={(out/"gp.input.bin").as_posix()}',f'--output={(out/"after-bed-allocation.json").as_posix()}')
a=json.loads((out/'after-bed-allocation.json').read_text(encoding='utf8'))
b=json.loads((out/'before-bed-allocation.json').read_text(encoding='utf8'))
if a['owners']!=b['owners']: raise SystemExit('Allocation changed the exact priority matching')
public=measure('after','public',300,1)
if not all(public['public_checks'].values()): raise SystemExit('After public contract checks failed: '+json.dumps(public['public_checks']))
measure('before','public',300,1)
plain={}
for index in range(1,4):
    for scenario,steps in [('gp',80),('op',40)]:
        for side in (['before','after'] if index%2 else ['after','before']):
            report=measure(side,scenario,steps,index)
            plain[(side,scenario)]=report['final_binary_sha256']
for scenario,steps in [('gp',80),('op',40),('public',300)]:
    report=measure('after',scenario,steps,'nested','nested')
    expected=public['final_binary_sha256'] if scenario=='public' else plain[('after',scenario)]
    if report['final_binary_sha256']!=expected: raise SystemExit('Profile changed facts or events: '+scenario)
print('Passed.',flush=True)
