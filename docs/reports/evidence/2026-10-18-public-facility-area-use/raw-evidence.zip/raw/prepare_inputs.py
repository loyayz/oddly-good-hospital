from pathlib import Path
import subprocess, json, time
root=Path(__file__).resolve().parents[2]
out=Path(__file__).resolve().parent
engine='C:/programs/godot/Godot_v4.7.2-stable_win64_console.exe'
project=out/'after-project'
gp=root/'.cache/performance-loop-20261018/clinical-corrected/clinical-corrected-r2-gp_work_handoff.input.bin'
op=root/'.cache/performance-loop-20261018/operations.input.bin'
for name, source, contention in [('gp',gp,False),('op',op,False),('public',gp,True)]:
    args=[engine,'--headless','--path',str(project),'--script','res://tools/performance/prepare_public_input.gd','--',f'--source={source.as_posix()}',f'--output={(out/(name+".input.bin")).as_posix()}',f'--contention={str(contention).lower()}']
    log=out/(name+'-preparation.log'); meta=out/(name+'-preparation.run.json')
    if log.exists() or meta.exists(): raise SystemExit('Evidence already exists: '+str(log))
    start=time.perf_counter()
    with log.open('w',encoding='utf8') as stream:
        process=subprocess.Popen(args,stdout=stream,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
        try: code=process.wait(timeout=360)
        except subprocess.TimeoutExpired:
            subprocess.run(['taskkill','/PID',str(process.pid),'/T','/F'],capture_output=True)
            process.wait(timeout=5); code=124
    lines=log.read_text(encoding='utf8',errors='replace').splitlines()
    errors=[line for line in lines if 'SCRIPT ERROR:' in line or 'ERROR:' in line]
    data={'command':args,'elapsed_seconds':time.perf_counter()-start,'exit_code':code,'engine_errors':errors}
    meta.write_text(json.dumps(data,indent=2),encoding='utf8')
    print(json.dumps({'name':name,**data}),flush=True)
    if code or errors: raise SystemExit(1)
