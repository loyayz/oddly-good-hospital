#requires -Version 7.0
$ErrorActionPreference = 'Stop'
$taskCases = 'CORE-09,CORE-26,CORE-27,CORE-48,CLIN-22,CLIN-23,STAFF-06,STAFF-07,STAFF-08,STAFF-09,STAFF-12,STAFF-16,STAFF-17,STAFF-20,STAFF-21,OPS-12,OPS-15,OPS-17,OPS-31,OPS-39,GROW-29,GROW-30,GROW-31,GROW-32,GROW-85'
& ./tests/run-acceptance.ps1 -Case $taskCases *> .cache/public-area-use-20261018/final-remaining-handoffs-1.log
if (-not $?) { exit 1 }
