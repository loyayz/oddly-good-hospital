extends SceneTree
func _initialize() -> void:
	for path: String in OS.get_cmdline_user_args():
		var file: FileAccess = FileAccess.open(path,FileAccess.READ)
		var saved: Dictionary = file.get_var()
		var facts: Dictionary = saved.facts
		var phases: Dictionary = {}
		for seat: Dictionary in facts.get("waiting_life",{}).get("seats",{}).values(): phases[seat.phase] = int(phases.get(seat.phase,0))+1
		print(JSON.stringify({"path":path,"tick":facts.sim_tick,"seats":phases,"needs":facts.get("waiting_life",{}).get("needs",{}),"staff_tasks":facts.staff.values().map(func(staff: Dictionary)->Dictionary: return {"id":staff.id,"task":staff.get("life_task",{})}).filter(func(row: Dictionary)->bool: return row.task.get("phase","idle")!="idle"),"visitors":facts.get("visitors",{}).get("stays",{}).values()}))
	quit()
