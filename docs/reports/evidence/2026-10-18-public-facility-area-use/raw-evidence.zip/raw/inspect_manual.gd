extends SceneTree
func _initialize() -> void:
	var file: FileAccess = FileAccess.open("C:/code/loyayz/oddly-good-hospital/.cache/public-area-use-20261018/gp.input.bin",FileAccess.READ)
	var world: WorldState = WorldState.new(file.get_var().facts)
	var content: HospitalContent = HospitalContent.new()
	var space: HospitalSpace = HospitalSpace.new(content)
	var service: HospitalWaitingLife = HospitalWaitingLife.new(content,space)
	var visit: Dictionary = world.facts.visits.bench_visit_0024
	for id: String in world.facility_ids("FUR09").slice(0,2):
		var candidate: WorldState = WorldState.new(world.freeze())
		var removed: Array = []
		for stay: Dictionary in candidate.facts.visitors.stays.values():
			if space.at(candidate,stay.actor_id,1,candidate.facts.facilities[id].patient_cell):
				removed.append(stay.actor_id)
				candidate.facts.actors[stay.actor_id].location = {"kind":"outside"}
		print("MANUAL "+JSON.stringify({"id":id,"facility":world.facts.facilities[id],"removed":removed,"public":service._public_seat(candidate,candidate.facts.facilities[id]),"quote":service._seat_quote(candidate,visit,id),"trip":space.facility_trip_quote(candidate,id,visit.actor_id)}))
	quit()
