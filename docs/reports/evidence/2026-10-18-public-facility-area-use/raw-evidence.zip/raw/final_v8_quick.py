from pathlib import Path
import subprocess, sys, shutil, hashlib, json
out=Path(__file__).resolve().parent
root=out.parents[1]
after='after-v8-project'
common=['representative.gd','representative_public.gd','step_profile.gd']
for name in common:
    shutil.copyfile(root/'tools/performance'/name,out/'before-project/tools/performance'/name)
identities={side:{name:hashlib.sha256((out/side/'tools/performance'/name).read_bytes()).hexdigest() for name in common} for side in ['before-project',after]}
if identities['before-project']!=identities[after]: raise SystemExit('Common diagnostic source differs')
(out/'final-v8-common-tools-identity.json').write_text(json.dumps(identities,indent=2),encoding='utf8')

def run(project,name,timeout,*args,diagnostic_without_work=False):
    result=subprocess.run([sys.executable,str(out/'run_engine.py'),str(out/project),name,str(timeout),*args],capture_output=True,text=True,encoding='utf8',errors='replace')
    (out/(name+'.console.log')).write_text(result.stdout+result.stderr,encoding='utf8')
    print(name,result.returncode,flush=True)
    if diagnostic_without_work:
        report=json.loads((out/(name+'.json')).read_text(encoding='utf8'))
        meta=json.loads((out/(name+'.run.json')).read_text(encoding='utf8'))
        if not report['complete'] or meta['engine_errors'] or not all(v for k,v in report['qualification'].items() if k!='actual_clinical_work'):
            raise SystemExit('Incomplete or invalid diagnostic continuation')
    elif result.returncode: raise SystemExit(result.returncode)

def measure(side,scenario,steps,index,mode='plain'):
    name=f'v8-{side}-{scenario}-{index}'
    source=out/('public-v6.input.bin' if scenario=='public' else scenario+'.input.bin')
    run('before-project' if side=='before' else after,name,900 if scenario=='public' else 300,
        f'--input={source.as_posix()}',f'--output={(out/(name+".json")).as_posix()}',f'--steps={steps}',f'--profile={mode}')
    return json.loads((out/(name+'.json')).read_text(encoding='utf8'))

plain={}
for index in range(1,4):
    for scenario,steps in [('gp',80),('op',40)]:
        for side in (['before','after'] if index%2 else ['after','before']):
            report=measure(side,scenario,steps,index)
            plain[(side,scenario)]=report['final_binary_sha256']
for scenario,steps in [('gp',80),('op',40)]:
    report=measure('after',scenario,steps,'nested','nested')
    if report['final_binary_sha256']!=plain[('after',scenario)]: raise SystemExit('Profile changed facts or events: '+scenario)
run(after,'late-v8-nested-1',120,f'--input={(out/"late-2923.input.bin").as_posix()}',f'--output={(out/"late-v8-nested-1.json").as_posix()}','--steps=1','--profile=nested',diagnostic_without_work=True)
public=measure('after','public',300,'root','root')
if not all(public['public_checks'].values()): raise SystemExit('Public contract failed: '+json.dumps(public['public_checks']))
run(after,'v8-bed-allocation',180,'script=res://tools/performance/personal_bed_probe.gd',f'--input={(out/"gp.input.bin").as_posix()}',f'--output={(out/"v8-bed-allocation.json").as_posix()}')
bed=json.loads((out/'v8-bed-allocation.json').read_text(encoding='utf8'))
if bed['owners']!=json.loads((out/'before-bed-allocation.json').read_text(encoding='utf8'))['owners']: raise SystemExit('Exact priority matching changed')
print('Passed.',flush=True)
