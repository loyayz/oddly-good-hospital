from pathlib import Path
import subprocess, sys, shutil, hashlib, json
out=Path(__file__).resolve().parent
root=out.parents[1]
after='after-v6-project'
common=['representative.gd','representative_public.gd','step_profile.gd']
for name in common:
    shutil.copyfile(root/'tools/performance'/name,out/'before-project/tools/performance'/name)
identities={side:{name:hashlib.sha256((out/side/'tools/performance'/name).read_bytes()).hexdigest() for name in common} for side in ['before-project',after]}
if identities['before-project']!=identities[after]: raise SystemExit('Common diagnostic source differs')
(out/'final-v6-common-tools-identity.json').write_text(json.dumps(identities,indent=2),encoding='utf8')

def run(project,name,timeout,*args):
    result=subprocess.run([sys.executable,str(out/'run_engine.py'),str(out/project),name,str(timeout),*args],capture_output=True,text=True,encoding='utf8',errors='replace')
    (out/(name+'.console.log')).write_text(result.stdout+result.stderr,encoding='utf8')
    print(name,result.returncode,flush=True)
    if result.returncode: raise SystemExit(result.returncode)

def measure(side,scenario,steps,index,mode='plain'):
    name=f'v6-{side}-{scenario}-{index}'
    source=out/('public-v6.input.bin' if scenario=='public' else scenario+'.input.bin')
    run('before-project' if side=='before' else after,name,900 if side=='before' and scenario=='public' else 300,
        f'--input={source.as_posix()}',f'--output={(out/(name+".json")).as_posix()}',f'--steps={steps}',f'--profile={mode}')
    return json.loads((out/(name+'.json')).read_text(encoding='utf8'))

public=measure('after','public',300,1)
if not all(public['public_checks'].values()): raise SystemExit('After public contract failed: '+json.dumps(public['public_checks']))
plain={}
for index in range(1,4):
    for scenario,steps in [('gp',80),('op',40)]:
        for side in (['before','after'] if index%2 else ['after','before']):
            report=measure(side,scenario,steps,index)
            plain[(side,scenario)]=report['final_binary_sha256']
for scenario,steps in [('gp',80),('op',40),('public',300)]:
    report=measure('after',scenario,steps,'nested','nested')
    expected=public['final_binary_sha256'] if scenario=='public' else plain[('after',scenario)]
    if report['final_binary_sha256']!=expected: raise SystemExit('Profile changed facts or events: '+scenario)
measure('before','public',300,1)
print('Passed.',flush=True)
