extends SceneTree
func _initialize() -> void:
	var file: FileAccess = FileAccess.open("C:/code/loyayz/oddly-good-hospital/.cache/public-area-use-20261018/gp.input.bin",FileAccess.READ)
	var input: Dictionary = file.get_var()
	var world: WorldState = WorldState.new(input.facts)
	print("VISITS "+JSON.stringify(world.facts.visits.values().slice(8,12)))
	print("ACTORS "+JSON.stringify(world.facts.visits.values().slice(8,12).map(func(v: Dictionary)->Dictionary: return {"actor":world.facts.actors[v.actor_id],"ticket":world.facts.tickets.get(v.ticket_id,{})})))
	print("TOILETS "+JSON.stringify(world.facility_ids("FUR07")))
	print("STAFF "+JSON.stringify(world.facts.staff.values().slice(0,1)))
	var content: HospitalContent = HospitalContent.new()
	var space: HospitalSpace = HospitalSpace.new(content)
	for id: String in ["bench_patient_0008","bench_patient_0020","bench_patient_0040","bench_patient_0080"]:
		print("PROBE "+JSON.stringify({"id":id,"location":world.facts.actors[id].location,"toilet":space.facility_trip_quote(world,"bench_room_1_09_0",id),"chair":space.facility_trip_quote(world,"acceptance_public_seat_0",id)}))
	var prep = load("res://tools/performance/prepare_public_input.gd").new()
	prep._shift_times(world.facts,1800)
	print("SHIFTED "+JSON.stringify({"tick":world.sim_tick,"staff":world.facts.staff.values()[0],"validation":world.validate(content)}))
	prep.free()
	quit()
