class_name HospitalPublicAreas
extends RefCounted

# Geometry is derived, never saved. Intent and queue times belong to the
# original visit/staff/visitor task; this service owns no second queue.
var _space: WeakRef
var space: HospitalSpace:
	get: return _space.get_ref()
var _world: WeakRef
var _revision: int = -1
var _regions: Array = []
var _by_cell: Dictionary = {}

func _init(geometry: HospitalSpace) -> void:
	_space = weakref(geometry)

func invalidate() -> void:
	_revision = -1

func for_facility(world: WorldState, facility_id: String) -> Dictionary:
	_ensure(world)
	for area: Dictionary in _regions:
		if facility_id in area.facilities: return area.ref.duplicate(true)
	return {}

func _ensure(world: WorldState) -> void:
	if _world!=null and _world.get_ref()==world and _revision==world.geometry_revision: return
	_world = weakref(world)
	_revision = world.geometry_revision
	_regions.clear()
	_by_cell.clear()
	var floors: Dictionary = {}
	for room: Dictionary in world.facts.rooms.values(): floors[int(room.floor_id)] = true
	for facility: Dictionary in world.facts.facilities.values(): floors[int(facility.floor_id)] = true
	for floor_id: int in floors:
		var zones: Dictionary = {}
		for plot: Array in HospitalSpace.floor_plots(world,floor_id):
			for y: int in range(int(plot[1])*32,(int(plot[1])+1)*32):
				for x: int in range(int(plot[0])*32,(int(plot[0])+1)*32): zones[Vector2i(x,y)] = ""
		for room_id: String in world.ids("rooms"):
			var room: Dictionary = world.facts.rooms[room_id]
			if int(room.floor_id)!=floor_id: continue
			for cell: Array in BuildGeometry.cells(room): zones[Vector2i(int(cell[0]),int(cell[1]))] = room_id
		var free: Dictionary = zones.duplicate()
		for cell: Array in HospitalSpace.floor_layout(world,floor_id).get("blocked",[]): free.erase(Vector2i(int(cell[0]),int(cell[1])))
		for collection: String in ["facilities","connectors"]:
			for record: Dictionary in world.facts[collection].values():
				if (int(record.floor_id)!=floor_id if collection=="facilities" else not HospitalTransit.has_stop(record,floor_id)) or record.get("stored",false): continue
				if collection=="facilities" and not space.content.facility_definition(record.definition_id).get("blocks_movement",true): continue
				var layout: Dictionary = space.facility_layout(world,record.id) if collection=="facilities" else record
				for y: int in range(int(layout.cell[1]),int(layout.cell[1])+int(layout.footprint[1])):
					for x: int in range(int(layout.cell[0]),int(layout.cell[0])+int(layout.footprint[0])): free.erase(Vector2i(x,y))
		var ordered: Array = free.keys()
		ordered.sort_custom(func(a: Vector2i,b: Vector2i)->bool: return a.y<b.y or a.y==b.y and a.x<b.x)
		var seen: Dictionary = {}
		for start: Vector2i in ordered:
			if seen.has(start): continue
			var cells: Dictionary = {start:true}
			var pending: Array[Vector2i] = [start]
			seen[start] = true
			var cursor: int = 0
			while cursor<pending.size():
				var point: Vector2i = pending[cursor]
				cursor += 1
				for direction: Vector2i in BuildGeometry.DIRECTIONS:
					var next: Vector2i = point+direction
					if seen.has(next) or not free.has(next) or zones[next]!=zones[start]: continue
					seen[next] = true
					cells[next] = true
					pending.append(next)
			var region: Dictionary = {"ref":{"floor_id":floor_id,"room_id":zones[start],"anchor":[start.x,start.y]},"cells":cells,"facilities":[]}
			_regions.append(region)
			for point: Vector2i in cells: _by_cell[_key(floor_id,point)] = region
		for id: String in world.ids("facilities"):
			var facility: Dictionary = world.facts.facilities[id]
			if int(facility.floor_id)!=floor_id or facility.get("stored",false): continue
			var layout: Dictionary = space.facility_layout(world,id)
			var point: Vector2i = Vector2i(int(layout.patient_cell[0]),int(layout.patient_cell[1]))
			var region: Dictionary = _by_cell.get(_key(floor_id,point),{})
			if not region.is_empty(): region.facilities.append(id)

static func _key(floor_id: int, point: Vector2i) -> String:
	return str(floor_id)+":"+str(point.x)+":"+str(point.y)

func region(world: WorldState, reference: Dictionary) -> Dictionary:
	_ensure(world)
	if reference.is_empty(): return {}
	if not str(reference.get("room_id","")).is_empty() and HospitalRemodel.blocked(world,reference.room_id): return {}
	var anchor: Array = reference.get("anchor",[])
	if anchor.size()!=2: return {}
	var result: Dictionary = _by_cell.get(_key(int(reference.floor_id),Vector2i(int(anchor[0]),int(anchor[1]))),{})
	return result if not result.is_empty() and result.ref==reference else {}

func contains(world: WorldState, reference: Dictionary, actor_id: String) -> bool:
	var area: Dictionary = region(world,reference)
	var actor: Dictionary = world.facts.actors[actor_id]
	if area.is_empty() or actor.location.kind!="floor" or int(actor.location.floor_id)!=int(reference.floor_id): return false
	var bounds: Rect2 = space.body_rectangle(actor)
	for y: int in range(floori(bounds.position.y),ceili(bounds.end.y)):
		for x: int in range(floori(bounds.position.x),ceili(bounds.end.x)):
			if not area.cells.has(Vector2i(x,y)): return false
	return true

func facilities(world: WorldState, reference: Dictionary, definitions: Array) -> Array:
	var result: Array = []
	for id: String in region(world,reference).get("facilities",[]):
		var facility: Dictionary = world.facts.facilities[id]
		if facility.definition_id in definitions and not facility.get("failed",false) and not HospitalRemodel.blocked(world,id): result.append(id)
	return result

func select(world: WorldState, actor_id: String, definitions: Array, room_kinds: Array, purpose: String, members: Array = []) -> Dictionary:
	_ensure(world)
	var actor: Dictionary = world.facts.actors[actor_id]
	if actor.location.kind!="floor": return {}
	var best: Dictionary = {}
	var travellers: Array = [actor_id] if members.is_empty() else members
	space.begin_dynamic_route_query(world)
	for area: Dictionary in _regions:
		var room: Dictionary = world.facts.rooms.get(area.ref.room_id,{})
		if not room.is_empty() and (not str(room.get("kind",room.get("type",""))) in room_kinds or HospitalRemodel.blocked(world,area.ref.room_id)): continue
		if room.is_empty() and not "" in room_kinds: continue
		var local: Array = facilities(world,area.ref,definitions)
		local = local.filter(func(id: String)->bool:
			var definition: Dictionary = space.content.facility_definition(world.facts.facilities[id].definition_id)
			var capacity: Dictionary = definition.get("adapter_capacity",definition)
			for member: String in travellers:
				var body: Dictionary = world.facts.actors[member]
				if space.clearance(body)>int(capacity.get("max_clearance_cells",96)) or float(space.body(body).height_m)>float(capacity.get("max_height_m",INF)): return false
			return true)
		if local.is_empty() and purpose!="rest": continue
		var point: Dictionary = waiting_point(world,actor_id,area.ref)
		if point.is_empty(): continue
		var all_reachable: bool = true
		for member: String in travellers:
			if member==actor_id: continue
			var entry: Dictionary = waiting_point(world,member,area.ref)
			if entry.is_empty(): all_reachable = false; break
			point.travel_ticks = maxi(int(point.travel_ticks),int(entry.travel_ticks))
		if not all_reachable: continue
		point.area = area.ref.duplicate(true)
		point.inside = contains(world,area.ref,actor_id)
		point.start_ticks = int(point.travel_ticks)+_wait_estimate(world,area.ref,local,purpose)
		if best.is_empty() or _earlier(point,best,purpose): best = point
	space.end_route_query()
	return best

static func _earlier(a: Dictionary,b: Dictionary,purpose: String) -> bool:
	if purpose in ["water","toilet"] and a.start_ticks!=b.start_ticks: return a.start_ticks<b.start_ticks
	if not purpose in ["water","toilet"] and a.inside!=b.inside: return a.inside
	if a.travel_ticks!=b.travel_ticks: return a.travel_ticks<b.travel_ticks
	return JSON.stringify(a.area)<JSON.stringify(b.area)

func waiting_point(world: WorldState, actor_id: String, reference: Dictionary) -> Dictionary:
	space.begin_route_query(world,{},false)
	var result: Dictionary = _waiting_point(world,actor_id,reference)
	space.end_route_query()
	return result

func _waiting_point(world: WorldState, actor_id: String, reference: Dictionary) -> Dictionary:
	var area: Dictionary = region(world,reference)
	if area.is_empty(): return {}
	var actor: Dictionary = world.facts.actors[actor_id]
	var floor_id: int = int(reference.floor_id)
	if contains(world,reference,actor_id) and safe_wait(world,actor_id,floor_id,actor.location.cell):
		return {"floor_id":floor_id,"cell":actor.location.cell.duplicate(),"travel_ticks":0}
	var points: Array = area.cells.keys()
	var origin: Vector2 = Vector2(float(actor.location.cell[0]),float(actor.location.cell[1]))
	points.sort_custom(func(a: Vector2i,b: Vector2i)->bool:
		var first: float = absf(origin.x-a.x)+absf(origin.y-a.y)
		var second: float = absf(origin.x-b.x)+absf(origin.y-b.y)
		return first<second if first!=second else a.y<b.y or a.y==b.y and a.x<b.x)
	var best: Dictionary = {}
	# Connectors preserve anchor XY. Every orthogonal walk therefore costs at
	# least this Manhattan distance, even when the real journey changes floors.
	for point: Vector2i in points:
		var lower: int = HospitalTransit.walking_ticks(space,actor,[],absf(origin.x-point.x)+absf(origin.y-point.y))
		if not best.is_empty() and lower>int(best.travel_ticks): break
		var cell: Array = [point.x,point.y]
		if not safe_wait(world,actor_id,floor_id,cell): continue
		var route: Dictionary = space.travel_quote(world,actor_id,floor_id,cell)
		if not route.ok or not route.has("arrival_ticks"): continue
		if best.is_empty() or int(route.arrival_ticks)<int(best.travel_ticks): best = {"floor_id":floor_id,"cell":cell,"travel_ticks":int(route.arrival_ticks)}
	return best

func safe_wait(world: WorldState, actor_id: String, floor_id: int, cell: Array) -> bool:
	var actor: Dictionary = world.facts.actors[actor_id]
	var point: Vector2i = Vector2i(roundi(cell[0]),roundi(cell[1]))
	if not space.static_reason(world,actor,floor_id,point).is_empty(): return false
	var bounds: Rect2 = space._actor_rect(actor,Vector2(float(cell[0]),float(cell[1])))
	if not space._dynamic_clear(world,actor_id,floor_id,bounds): return false
	var constraints: Dictionary = space.read_view(world,"public_wait_constraints",_wait_constraints.bind(world))
	for door: Rect2 in constraints.doors.get(floor_id,[]):
		if bounds.intersects(door,false): return false
	for x: int in range(floori(bounds.position.x/8.0),floori(bounds.end.x/8.0)+1):
		for y: int in range(floori(bounds.position.y/8.0),floori(bounds.end.y/8.0)+1):
			for work: Vector2 in constraints.points.get(floor_id,{}).get(Vector2i(x,y),[]):
				if bounds.has_point(work): return false
	for id: String in constraints.moves.get(_key(floor_id,Vector2i(roundi(cell[0]),roundi(cell[1]))),[]):
		if id!=actor_id: return false
	return true

func _wait_constraints(world: WorldState) -> Dictionary:
	var result: Dictionary = {"points":{},"doors":{},"moves":{}}
	for floor_key: String in world.facts.floors.overrides:
		var floor_id: int = int(floor_key)
		result.doors[floor_id] = []
		for door: Dictionary in world.facts.floors.overrides[floor_key].get("doors",[]): result.doors[floor_id].append(space._door_rect(door,int(door.span)).grow(1.0))
	for facility: Dictionary in world.facts.facilities.values():
		var floor_id: int = int(facility.floor_id)
		if not result.points.has(floor_id): result.points[floor_id] = {}
		var layout: Dictionary = space.facility_layout(world,facility.id)
		for work: Array in [layout.get("patient_cell",[])]+layout.get("operator_cells",[])+[layout.get("repair_cell",[])]:
			if work.is_empty(): continue
			var point: Vector2 = Vector2(float(work[0]),float(work[1]))
			var bucket: Vector2i = Vector2i(floori(point.x/8.0),floori(point.y/8.0))
			if not result.points[floor_id].has(bucket): result.points[floor_id][bucket] = []
			result.points[floor_id][bucket].append(point)
	for movement: Dictionary in world.facts.moves.values():
		var cell: Array = movement.target_cell
		var key: String = _key(int(movement.target_floor),Vector2i(roundi(cell[0]),roundi(cell[1])))
		if not result.moves.has(key): result.moves[key] = []
		result.moves[key].append(str(movement.actor_id))
	return result

func _wait_estimate(world: WorldState, reference: Dictionary, facility_ids: Array, purpose: String) -> int:
	if not purpose in ["water","toilet"]: return 0
	var earliest: int = 2147483647
	for id: String in facility_ids:
		var remaining: int = 0
		for need: Dictionary in world.facts.get("waiting_life",{}).get("needs",{}).values():
			if need.get("facility_id","")==id and need.phase in ["using","returning"]:
				remaining = maxi(remaining,int(need.remaining_ticks) if need.phase=="using" else 2147483647)
		earliest = mini(earliest,remaining)
	if earliest==2147483647: return earliest
	var queued: int = 0
	for intent: Dictionary in intents(world):
		if intent.get("public_purpose","")==purpose and intent.get("area",{})==reference and int(intent.get("arrived_tick",-1))>=0 and intent.phase in ["local_wait","local_travel"]: queued += 1
	var service_ticks: int = 0
	for service: Dictionary in space.content.catalog.amenity_services:
		if service.purpose==purpose: service_ticks = ceili(float(service.ordinary_seconds)/WorldState.TICK_SECONDS)
	return earliest+ceili(float(queued)/maxi(1,facility_ids.size()))*service_ticks

func intents(world: WorldState) -> Array:
	var result: Array = []
	for collection: String in ["seats","needs"]:
		for intent: Dictionary in world.facts.get("waiting_life",{}).get(collection,{}).values():
			if intent.has("public_purpose"): result.append(intent)
	for staff: Dictionary in world.facts.staff.values():
		var task: Dictionary = staff.get("life_task",{})
		if task.has("public_purpose"): result.append(task)
	for stay: Dictionary in world.facts.get("visitors",{}).get("stays",{}).values():
		if stay.has("public_use"): result.append(stay.public_use)
	return result

func turn(world: WorldState, intent: Dictionary, facility_id: String) -> bool:
	for other: Dictionary in intents(world):
		if is_same(other,intent) or int(other.get("arrived_tick",-1))<0 or not other.get("phase","") in ["local_wait","local_travel","manual_wait"] or other.get("public_purpose","")!=intent.public_purpose: continue
		if other.get("mode","auto")=="manual" and other.get("manual_facility_id","")!=facility_id: continue
		if other.get("mode","auto")!="manual" and not facility_id in region(world,other.get("area",{})).get("facilities",[]): continue
		var before: bool = int(other.arrived_tick)<int(intent.arrived_tick) or int(other.arrived_tick)==int(intent.arrived_tick) and str(other.id)<str(intent.id)
		if int(intent.get("arrived_tick",-1))<0: before = true
		if intent.public_purpose=="seat" and intent.has("ticket_id")!=other.has("ticket_id"): before = other.has("ticket_id")
		if not before: continue
		var ids: Array = other.get("staff_ids",[str(other.actor_id)])
		if ids.is_empty(): continue
		var fit: Dictionary = space.facility_quote(world,facility_id,ids[0],ids.slice(1))
		if fit.ok: return false
	return true
