extends "res://tests/acceptance/staff_fixtures.gd"

func run(t, database: HospitalContent, case_id: String) -> void:
	_content = database
	call("_case_"+case_id.right(2),t)

func _areas(staff: Dictionary = {}) -> Dictionary:
	var x: Dictionary = _fixture(staff)
	for entry: Array in [["west",34],["east",48]]:
		HospitalFactory._add_room(x.world,{"id":entry[0],"type":"waiting" if staff.is_empty() else "rest","anchor":[entry[1],66],"size":[10,12],"door":{"definition_id":"DR04","offset":3}},_content)
		_facility(x,str(entry[0])+"_chair","FUR09",[int(entry[1])+2,68],str(entry[0]))
	x.world.touch()
	return x

func _tick_waiting(x: Dictionary, ticks: int = 1) -> void:
	for _tick: int in ticks:
		x.world.facts.sim_tick += 1
		x.l.dispatch(x.world)
		x.space.advance(x.world)
		x.l.advance(x.world)
		x.world.touch(false)

func _until_seated(x: Dictionary, visit: Dictionary, limit: int = 600) -> bool:
	for _tick: int in limit:
		if x.world.facts.waiting_life.seats.get(visit.id,{}).get("phase","")=="seated": return true
		_tick_waiting(x)
	return false

func _case_45(t) -> void:
	var x: Dictionary = _areas()
	var visit: Dictionary = _visit(x,"regional",[38,90])
	x.world.facts.sim_tick = 50
	x.l.dispatch(x.world)
	var intent: Dictionary = x.world.facts.waiting_life.seats.get(visit.id,{})
	var departure: bool = intent.get("mode","")=="auto" and intent.get("facility_id","missing")=="" and intent.get("area",{}).get("room_id","")=="west" and x.world.facts.adaptations.is_empty()
	var travel_energy: float = float(visit.anger)
	var seated: bool = _until_seated(x,visit)
	t.check("STAFF-45",departure and seated and visit.anger==travel_energy and intent.facility_id=="west_chair" and intent.arrived_tick>=50 and x.l.validate(x.world).is_empty(),{"departure":departure,"seated":seated,"intent":intent,"validation":x.l.validate(x.world)})

func _case_46(t) -> void:
	var x: Dictionary = _areas()
	var first: Dictionary = _visit(x,"holder",[36,70])
	var second: Dictionary = _visit(x,"manual",[51,74])
	var occupied: bool = _seat_checkpoint(x,first,"west_chair")
	var request: CommandResult = x.l.execute(x.world,"waiting_select_seat",{"visit_id":second.id,"facility_id":"west_chair"})
	var fixed: bool = request.accepted and x.world.facts.waiting_life.seats.get(second.id,{}).get("manual_facility_id","")=="west_chair"
	_tick_waiting(x,25)
	fixed = fixed and x.world.facts.actors[second.actor_id].get("support_facility_id","")!="east_chair" and first.get("chair_calm_claimed",false)==false
	x.l.execute(x.world,"waiting_release_seat",{"visit_id":first.id})
	var exit: String = x.space.request_move(x.world,first.actor_id,1,[40,74])
	var seated: bool = _until_seated(x,second)
	t.check("STAFF-46",occupied and fixed and exit.is_empty() and seated and x.world.facts.actors[second.actor_id].support_facility_id=="west_chair",{"request":request.to_record(),"fixed":fixed,"seated":seated,"intent":x.world.facts.waiting_life.seats.get(second.id,{})})

func _case_47(t) -> void:
	var x: Dictionary = _areas()
	_facility(x,"toilet","FUR07",[39,68],"west")
	x.world.touch()
	var first: Dictionary = _visit(x,"first",[38,73])
	var second: Dictionary = _visit(x,"second",[40,73])
	x.world.facts.sim_tick = 1800
	x.l._begin_need(x.world,first)
	var first_using: bool = false
	for _tick: int in 150:
		if x.world.facts.waiting_life.needs[first.id].phase=="using": first_using = true; break
		_tick_waiting(x)
	x.l._begin_need(x.world,second)
	var queued: bool = x.world.facts.waiting_life.needs[second.id].phase=="local_wait"
	var second_using: bool = false
	var safe_release: bool = true
	for _tick: int in 350:
		var need: Dictionary = x.world.facts.waiting_life.needs.get(second.id,{})
		if need.get("phase","")=="using":
			second_using = true
			safe_release = not x.space.overlaps_facility(x.world,first.actor_id,"toilet")
			break
		_tick_waiting(x)
	var y: Dictionary = _areas()
	_facility(y,"toilet","FUR07",[39,68],"west")
	var exact: Dictionary = _visit(y,"exact",y.space.facility_layout(y.world,"toilet").patient_cell)
	y.world.touch()
	y.l._begin_need(y.world,exact)
	var boundary: Dictionary = y.world.facts.waiting_life.needs[exact.id]
	boundary.phase = "local_wait"
	boundary.remaining_ticks = 0
	boundary.facility_id = ""
	y.world.facts.adaptations.clear()
	y.world.facts.sim_tick = int(boundary.started_tick)+450
	y.l.dispatch(y.world)
	var exact_start: bool = boundary.phase=="using" and boundary.remaining_ticks==80
	t.check("STAFF-47",first_using and queued and second_using and safe_release and exact_start,{"first_started":first_using,"queued":queued,"second_started":second_using,"prior_physically_left":safe_release,"exact_45_seconds":exact_start,"second":x.world.facts.waiting_life.needs.get(second.id,{})})

func _case_48(t) -> void:
	var x: Dictionary = _areas()
	var first: Dictionary = _visit(x,"a_first",[37,73])
	var second: Dictionary = _visit(x,"z_second",[39,73])
	var one: CommandResult = x.l.execute(x.world,"waiting_select_seat",{"visit_id":first.id,"facility_id":"west_chair"})
	var two: CommandResult = x.l.execute(x.world,"waiting_select_seat",{"visit_id":second.id,"facility_id":"west_chair"})
	var no_remote: bool = x.world.facts.adaptations.is_empty()
	var first_seated: bool = _until_seated(x,first)
	var second_seated: bool = x.world.facts.waiting_life.seats[second.id].phase=="seated"
	var ticket: String = first.ticket_id
	var wait_ticks: int = int(x.world.facts.tickets[ticket].waited_ticks)
	var called: bool = x.l.call_patient(x.world,first.id)
	t.check("STAFF-48",one.accepted and two.accepted and no_remote and first_seated and not second_seated and called and first.ticket_id==ticket and x.world.facts.tickets[ticket].waited_ticks==wait_ticks,{"first_seated":first_seated,"second_seated":second_seated,"no_remote_claim":no_remote,"clinical_called":called})

func _case_49(t) -> void:
	var x: Dictionary = _areas({"first":"doctor","second":"nurse"})
	_facility(x,"game","RC03",[36,71],"west")
	x.world.touch()
	for staff: Dictionary in x.world.facts.staff.values():
		staff.energy = 60.0
		staff.stress_milli = 50000
		staff.on_shift = false
	_position(x,"first",[37,75])
	_position(x,"second",[54,87])
	var request: CommandResult = x.w.execute(x.world,"staff_recreation",{"staff_ids":["first","second"],"facility_id":"game"})
	var travelling: bool = request.accepted and not x.world.facts.staff_life.reservations.has("game") and x.world.facts.staff.first.recreation_count==0 and x.w._recreation_count(x.world)==2
	_life_ticks(x,20,true)
	x.w.dispatch(x.world)
	var waiting: bool = x.world.facts.staff.first.recreation_count==0
	x.world.facts.staff.second.active_job_id = "necessary_safe_work"
	x.w.dispatch(x.world)
	var cancelled: bool = x.world.facts.staff.first.life_task.phase=="returning" and x.world.facts.staff.second.life_task.phase=="returning" and x.world.facts.staff.first.recreation_count==0 and not x.world.facts.staff_life.reservations.has("game")
	t.check("STAFF-49",travelling and waiting and cancelled,{"request":request.to_record(),"travelling":travelling,"waited_for_last_member":waiting,"cancelled_before_start":cancelled})

func _case_50(t) -> void:
	var x: Dictionary = _areas()
	var visit: Dictionary = _visit(x,"saved",[37,73])
	x.l.execute(x.world,"waiting_select_seat",{"visit_id":visit.id,"facility_id":"east_chair"})
	var before: Dictionary = x.world.freeze()
	x = _restore(x)
	var same: bool = x.world.freeze()==before
	var seated: bool = _until_seated(x,x.world.facts.visits[visit.id])
	var intent: Dictionary = x.world.facts.waiting_life.seats.get(visit.id,{})
	t.check("STAFF-50",same and seated and intent.mode=="manual" and intent.manual_facility_id=="east_chair" and intent.started_tick==0 and x.l.validate(x.world).is_empty(),{"restore_equal":same,"seated":seated,"intent":intent,"validation":x.l.validate(x.world)})

func _case_51(t) -> void:
	var x: Dictionary = _areas()
	var visit: Dictionary = _visit(x,"manual_invalid",[37,73])
	x.l.execute(x.world,"waiting_select_seat",{"visit_id":visit.id,"facility_id":"west_chair"})
	x.world.facts.facilities.erase("west_chair")
	x.world.touch()
	for _tick: int in 300:
		_tick_waiting(x)
		if not x.world.facts.waiting_life.seats.has(visit.id): break
	var stopped: bool = not x.world.facts.waiting_life.seats.has(visit.id) and x.world.facts.actors[visit.actor_id].get("support_facility_id","")!="east_chair"
	t.check("STAFF-51",stopped,{"stopped_invalid_exact_target":stopped,"reason":visit.waiting_reason})

func _case_52(t) -> void:
	var x: Dictionary = _areas({"resting":"doctor"})
	_position(x,"resting",[38,90])
	x.world.facts.staff.resting.energy = 35.0
	x.w.dispatch(x.world)
	var task: Dictionary = x.world.facts.staff.resting.life_task
	var no_claim: bool = task.phase=="area_travel" and task.facility_id=="" and x.world.facts.staff_life.reservations.is_empty()
	var before: float = float(x.world.facts.staff.resting.energy)
	_life_ticks(x,10,true)
	var no_recovery: bool = float(x.world.facts.staff.resting.energy)<=before
	var rested: bool = _reach_life_phase(x,"resting","rest")
	var start: float = float(x.world.facts.staff.resting.energy)
	_life_ticks(x,10)
	t.check("STAFF-52",no_claim and no_recovery and rested and x.world.facts.staff.resting.energy>start and x.world.facts.staff.resting.awake_ticks>0,{"no_remote_claim":no_claim,"walking_did_not_recover":no_recovery,"rested":rested,"task":task,"energy":x.world.facts.staff.resting.energy})

func _beds() -> Dictionary:
	var x: Dictionary = _fixture({"first":"doctor","second":"nurse"})
	var room: String = _room(x)
	_facility(x,"bed_a","SE04",[40,70],room)
	_facility(x,"bed_b","SE04",[50,70],room)
	x.world.touch()
	x.w.ensure(x.world)
	return x

func _case_53(t) -> void:
	var x: Dictionary = _beds()
	var owners: Dictionary = x.world.facts.staff_life.personal_beds.duplicate(true)
	var own: String = x.w.personal_beds.bed_for(x.world,"first")
	var other: Dictionary = x.space.facility_quote(x.world,own,"second")
	x.world.facts.staff.second.awake_ticks = 13500
	x.world.facts.staff.second.energy = 1.0
	x.w.ensure(x.world)
	var fixed: bool = owners==x.world.facts.staff_life.personal_beds and owners.size()==2 and x.world.facts.adaptations.is_empty()
	x = _restore(x)
	t.check("STAFF-53",fixed and not other.ok and other.reason=="他人个人床" and owners==x.world.facts.staff_life.personal_beds and x.w.validate(x.world).is_empty(),{"fixed":fixed,"owners":owners,"other_employee":other,"validation":x.w.validate(x.world)})

func _case_54(t) -> void:
	var input: Dictionary = {"small":[{"bed_id":"A","travel_ticks":1},{"bed_id":"B","travel_ticks":2}],"giant":[{"bed_id":"A","travel_ticks":1}]}
	var before: Dictionary = input.duplicate(true)
	var complete: Dictionary = HospitalPersonalBedMatching.solve(["small","giant"],input)
	var scarce: Dictionary = HospitalPersonalBedMatching.solve(["first","second"],{"first":[{"bed_id":"A","travel_ticks":9}],"second":[{"bed_id":"A","travel_ticks":1}]})
	var tied: Dictionary = HospitalPersonalBedMatching.solve(["first","second"],{"first":[{"bed_id":"A","travel_ticks":1},{"bed_id":"B","travel_ticks":1}],"second":[{"bed_id":"A","travel_ticks":2},{"bed_id":"B","travel_ticks":2}]})
	t.check("STAFF-54",complete=={"B":"small","A":"giant"} and scarce=={"A":"first"} and tied=={"A":"first","B":"second"} and input==before,{"full_compatible_matching":complete,"scarce_priority":scarce,"stable_tie":tied,"input_unchanged":input==before})

func _case_55(t) -> void:
	var x: Dictionary = _beds()
	var owners: Dictionary = x.world.facts.staff_life.personal_beds.duplicate(true)
	var bed_id: String = x.w.personal_beds.bed_for(x.world,"first")
	var builder: BuildService = BuildService.new(_content,x.space)
	var stored: CommandResult = builder.execute(x.world,"build_store",{"target_id":bed_id})
	x.w.ensure(x.world)
	var kept: bool = stored.accepted and owners==x.world.facts.staff_life.personal_beds and HospitalPersonalBeds.validate(x.world).is_empty()
	var item: Dictionary = x.world.facts.inventory.get("build_items",{}).get(bed_id,{})
	var placed: CommandResult = builder.execute(x.world,"build_facility",{"inventory_id":bed_id,"definition_id":"SE04","floor_id":1,"cell":item.get("cell",[40,70]),"room_id":"support_room"})
	x.w.ensure(x.world)
	var same_id: bool = placed.accepted and owners==x.world.facts.staff_life.personal_beds and x.world.facts.facilities.has(bed_id)
	var removed: CommandResult = builder.execute(x.world,"build_demolish",{"target_id":bed_id})
	x.w.ensure(x.world)
	t.check("STAFF-55",kept and same_id and removed.accepted and not x.world.facts.staff_life.personal_beds.has(bed_id) and x.w.personal_beds.bed_for(x.world,"first").is_empty(),{"stored":stored.to_record(),"ownership_kept_in_inventory":kept,"replaced_same_id":placed.to_record(),"same_id":same_id,"removed":removed.to_record(),"owners":x.world.facts.staff_life.personal_beds})

func _case_56(t) -> void:
	var x: Dictionary = _beds()
	var old_id: String = x.world.hospital_id
	var new_id: String = HospitalSnapshots.uuid()
	var old_staff: String = old_id+":staff"
	var old_bed: String = old_id+":bed"
	var data: Dictionary = {"staff_life":{"personal_beds":{old_bed:{"staff_id":old_staff}}},"staff":{old_staff:{"id":old_staff,"life_task":{"phase":"local_wait","area":{"room_id":old_id+":room","floor_id":1,"anchor":[1,1]},"manual_facility_id":old_bed}}}}
	var library: HospitalLibrary = HospitalLibrary.new(_content,HospitalSnapshots.new(_content))
	var ids: Dictionary = {old_staff:new_id+":staff",old_bed:new_id+":bed",old_id+":room":new_id+":room"}
	var rewritten: Dictionary = library._rewrite_ids(data,"",old_id,new_id,ids)
	var owner: Dictionary = rewritten.staff_life.personal_beds.get(new_id+":bed",{})
	var task: Dictionary = rewritten.staff[new_id+":staff"].life_task
	t.check("STAFF-56",owner.get("staff_id","")==new_id+":staff" and task.area.room_id==new_id+":room" and task.manual_facility_id==new_id+":bed" and data.staff_life.personal_beds.has(old_bed),{"owner":owner,"task":task,"source_unchanged":data.staff_life.personal_beds.has(old_bed)})
