from pathlib import Path
import sys,json,subprocess,hashlib
repo=Path('C:/Users/cong/dot-work/oddly-good-hospital-handoff-20261112')
old=Path('C:/Users/cong/dot-work/ogh-fixed-boundary-20261112');project=old/'.cache/boundary-project'
base=Path('C:/Users/cong/dot-work/ogh-transit-recovery-fix-20261112')
sys.path.insert(0,str(old/'tools/performance/current'))
import prepare_builtin_script_profile as guard
engine='C:/programs/Godot/Godot_v4.7.2-stable_win64_console.exe'
rel='game/building/hospital_transit.gd';patched=(repo/rel).read_bytes()
original=subprocess.check_output(['git','show','HEAD:'+rel],cwd=repo)
(project/'tests/acceptance/transit_busy_recovery.gd').write_bytes((repo/'tests/acceptance/transit_busy_recovery.gd').read_bytes())
results=[]
def run(name,script,selectors=None,allowed=(0,)):
 out=base/name/'result.json';command=[engine,'--headless','--path',str(project),'--script','res://tests/acceptance/'+script,'--',str(out)]
 if selectors: command.append(selectors)
 print(name,flush=True)
 r=guard.run_process(command,project,out.parent,120,allowed_returncodes=allowed)
 results.append({'name':name,'script':script,'selectors':selectors,'process':r,'result':str(out)})
 return json.loads(out.read_text(encoding='utf-8'))
try:
 (project/rel).write_bytes(original)
 r=run('baseline-final','transit_busy_recovery.gd',allowed=(0,1));assert not r['ok']
finally:(project/rel).write_bytes(patched)
assert run('fixed-final','transit_busy_recovery.gd')['ok']
assert run('waypoint','transit_waypoint_order.gd','waypoint_solo,waypoint_convoy,aside_solo,aside_convoy')['ok']
assert run('presence','transit_presence.gd','leave_solo,leave_convoy,order_solo,order_convoy')['ok']
assert run('portal','convoy_transit.gd','blocked,ride,opposing')['ok']
(base/'selected-runs.json').write_text(json.dumps(results,indent=2))
print('All final scoped checks passed',flush=True)
