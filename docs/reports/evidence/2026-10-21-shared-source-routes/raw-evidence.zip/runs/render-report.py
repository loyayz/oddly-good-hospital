import json,pathlib
repo=pathlib.Path(r'C:\code\loyayz\oddly-good-hospital')
root=pathlib.Path(__file__).resolve().parent
p=repo/'docs/reports/2026-10-21-shared-source-routes.md'
s=p.read_text(encoding='utf8')
def read(n):return json.loads((root/(n+'.json')).read_text(encoding='utf-8-sig'))
def number(v):return f'{v/1000:.3f}'
lines=['| 指标，毫秒 | 基线E | 修复F | 修复G | 基线H |','| --- | ---: | ---: | ---: | ---: |']
columns=[('public360','公共平均整步','mean_us'),('public360','公共P95','p95_us'),('public360','公共P99','p99_us'),('public360','公共冷首步/最大','max_us'),('gp80','GP平均整步','mean_us'),('gp80','GPP50','p50_us'),('gp80','GPP95','p95_us'),('gp80','GP最大','max_us'),('gp80','GP冷首步','cold_first_us'),('operations40','运营平均整步','mean_us'),('operations40','运营非冷步平均','following_mean_us'),('operations40','运营P95','p95_us'),('operations40','运营冷首步/最大','max_us')]
for w,title,key in columns:lines.append('| '+title+' | '+' | '.join(number(read(x+'-'+w)['metrics'][key]) for x in ['e','f','g','h'])+' |')
s=s.replace('FINAL_PLAIN_TABLE','\n'.join(lines))
summary=json.loads((repo/'docs/reports/evidence/2026-10-21-shared-source-routes/quick-summary.json').read_text(encoding='utf8'))
parts=[]
for w,title in zip(summary['windows'],['公共','GP','运营']):
 pct=w['mean_reduction_percent']
 parts.append(f"{title}{number(w['before_mean_us'])}→{number(w['after_mean_us'])}ms（{'下降' if pct>=0 else '退化'}{abs(pct):.2f}%）")
cold_before=sum(read(x+'-public360')['metrics']['cold_first_us'] for x in ['e','h'])/2
cold_after=sum(read(x+'-public360')['metrics']['cold_first_us'] for x in ['f','g'])/2
text='两次基线与两次修复的窗口平均值分别为：'+'；'.join(parts)+'。公共整步平均实际基本不变，GP普通窗口没有改善证据，GPP50还慢于两次基线。运营变化较小，不能据此解释历史约4%的退化。'
text+=f'公共冷首步{number(cold_before)}→{number(cold_after)}ms（下降{(1-cold_after/cold_before)*100:.2f}%），两次修复均低于两次基线；这是本组快速冷步收益，不能推广为普通步或正式达标。整步时间变化和求解次数下降分别判定。'
s=s.replace('FINAL_PLAIN_SUMMARY',text)
table='''| 同一输出步/窗口的诊断 | 基线 | 最终修复 | 含义 |
| --- | ---: | ---: | --- |
| 公共360窗口，实际Boost求解 | 1933次 | 306次 | 原逻辑请求仍1933次，109次共同树、1627次标签命中 |
| GP80窗口，实际Boost求解 | 426次 | 258次 | 原逻辑请求仍426次，84次共同树、168次标签命中 |
| GP80窗口，层内查询/连接出边准备 | 1846 / 638次 | 1846 / 638次 | 首轮额外112次已经消除，未宣称全部层内查询减少 |
| 公共2624，节点展开回调 | 6472次 / 357.475ms | 152次 / 58.938ms | 共同标签避免重复回调；目标终段仍分别检查 |
| 公共2624，完整点查询 | 2084次 / 611.689ms | 2084次 / 528.986ms | 逻辑目标数未减少，父成本降幅远小于回调次数降幅 |
| 公共2624，候诊调度阶段 | 938.268ms | 859.367ms | 包含点查询及首次区域/图准备，子成本不可相加 |
| GP851，完整点查询 | 1118次 / 416.952ms | 1118次 / 403.220ms | 仍有大量完整不同目标 |
| GP851，层内查询 | 1448次 / 345.757ms | 1448次 / 336.846ms | 目标终段/图取得等仍是实际剩余成本 |
| GP851，入口落脚 | 102次 / 213.066ms | 102次 / 211.697ms | 基本没有时间改善 |
| GP851，首次4张图构建 | 142.485ms | 137.921ms | 本次仍完整构建，未解决冷图成本 |
| GP851，静态等待位置检查 | 514次 / 19.573ms | 514次 / 9.520ms | 检查数不变，缩小门候选；门视图入口另146次/1.276ms |
| 公共2625，无关修订后的区域入口 | 34次 / 30.373ms | 34次 / 9.062ms | 完整依据比较保留，未变映射不再重挂 |
| 公共2624，首次区域入口 | 3332次 / 144.645ms | 3332次 / 144.840ms | 仍4次区域派生，首次整体没有改善 |
| 公共2651，完整点查询 | 885次 / 202.794ms | 885次 / 184.314ms | 原首轮216.142ms的无收益结果另保留 |
| 公共2764，等待签名 | 24次 / 17.707ms | 24次 / 16.932ms | 未因共同树减少普通等待依据核对 |
| 运营1190，完整环境观察 | 120次 / 9.538ms | 120次 / 9.142ms | 本轮未修改环境服务，不将小幅差异归为环境修复 |'''
s=s.replace('FINAL_FUNCTION_TABLE',table)
s=s.replace('FINAL_REMAINING_COST','最终普通公共2764仍有候诊调度21.024ms、移动17.206ms、临床派发15.063ms、科室采样14.441ms；签名16.932ms包含在候诊等父阶段内，环境观察12.101ms包含在科室采样内。GP851仍有候诊调度732.162ms，其中完整查询403.220ms、层内查询336.846ms和四张图137.921ms互相包含。公共冷2624仍有首次区域派生118.815ms及四张图137.100ms。共同网络的重复求解已减，仍占大头的逐目标层内查询、首次派生与普通业务阶段并未随计数同比下降。')
assert not any(x in s for x in ['FINAL_PLAIN_TABLE','FINAL_PLAIN_SUMMARY','FINAL_FUNCTION_TABLE','FINAL_REMAINING_COST'])
p.write_text(s,encoding='utf8')
print('rendered report')
