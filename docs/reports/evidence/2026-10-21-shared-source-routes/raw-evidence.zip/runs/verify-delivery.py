import hashlib
import json
import pathlib
import re
import subprocess

repo = pathlib.Path(r'C:\code\loyayz\oddly-good-hospital')
root = repo / 'docs/reports/evidence/2026-10-21-shared-source-routes'
check = json.loads((root / 'source-check.json').read_text(encoding='utf8'))
rows = check['final_files'] + check['final_test_files']
raw = subprocess.run(['git', 'cat-file', '--batch'], input=''.join(':' + r['path'] + '\n' for r in rows).encode(),
                     cwd=repo, check=True, stdout=subprocess.PIPE).stdout
cursor = 0
exceptions = []
for r in rows:
    end = raw.index(b'\n', cursor)
    size = int(raw[cursor:end].split()[-1])
    cursor = end + 1
    blob = raw[cursor:cursor + size]
    cursor += size + 1
    if hashlib.sha256(blob).hexdigest() != r['sha256']:
        assert r['path'] == 'tests/acceptance/zip_library_boundaries.gd', r['path']
        assert blob.replace(b'\r\n', b'\n') == (repo / r['path']).read_bytes().replace(b'\r\n', b'\n')
        assert not subprocess.run(['git', 'diff', 'HEAD', '--', r['path']], cwd=repo, check=True, stdout=subprocess.PIPE).stdout
        exceptions.append(r['path'])
report = repo / 'docs/reports/2026-10-21-shared-source-routes.md'
text = report.read_text(encoding='utf8')
links = re.findall(r'\]\((evidence/[^)]+)\)', text)
assert links and all((report.parent / name).exists() for name in links)
assert 'FUNCTION_RESULTS' not in text
manifest = json.loads((root / 'raw-manifest.json').read_text(encoding='utf8'))
assert hashlib.sha256((root / manifest['archive']).read_bytes()).hexdigest() == manifest['sha256']
functional = json.loads((root / 'functional-summary.json').read_text(encoding='utf8'))
final = functional['batches'][-1]
assert final['result']['checks'] == 2 and final['result']['failed'] == 0 and final['result']['completed']
assert final['execution']['test_exit'] == 0 and not final['execution']['script_errors']
staged = subprocess.run(['git', 'diff', '--cached', '--name-only'], cwd=repo, check=True, stdout=subprocess.PIPE).stdout.decode().splitlines()
assert len(staged) == 19 and not any(p.endswith('.dll') for p in staged)
print(json.dumps(dict(staged_files=len(staged), checked_source_files=len(rows), unchanged_crlf_exceptions=exceptions,
                      evidence_links=len(links), raw_entries=len(manifest['entries']), final_cases=2)))
