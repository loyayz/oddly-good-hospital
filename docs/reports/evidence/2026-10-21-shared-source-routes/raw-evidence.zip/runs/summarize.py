import hashlib,json,pathlib,statistics,subprocess,zipfile
REPO=pathlib.Path(r'C:\code\loyayz\oddly-good-hospital')
ROOT=pathlib.Path(__file__).resolve().parent
OUT=REPO/'docs/reports/evidence/2026-10-21-shared-source-routes'
BASE='305393872b2164b15c2dfbcaf9b8e5d4024439e0'
OUT.mkdir(parents=True,exist_ok=True)
def read(p):return json.loads(pathlib.Path(p).read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def dump(n,v):(OUT/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def measured(n):
 d=read(ROOT/(n+'.json'))
 assert d['complete'] and d['qualified'] and not d['errors'],n
 assert all(d.get('public_checks',{}).values())
 return dict(run=n,metrics=d['metrics'],execution=d['execution'],launch=read(ROOT/(n+'.launch.json')),qualification=d['qualification'],
   final_hash=d['final_binary_sha256'],input_sha256=d['source_input_sha256'],work=d['final']['work_ticks_by_kind'],query_counts=d['public']['query_counts'],
   public_work={k:d['public'][k] for k in ['actual_use_ticks','queue_actor_ticks','actual_exit_then_reuse_count']},
   starts=len(d['public']['actual_use_starts']),completions=len(d['public']['actual_use_completions']),operations=d['operations'])
windows=[]
for window in ['public360','gp80','operations40']:
 rows=[measured(x+'-'+window) for x in ['e','f','g','h']]
 intermediate=[measured(x+'-'+window) for x in ['a','b','c','d']]
 assert len({r['final_hash'] for r in rows+intermediate})==1
 assert len({r['input_sha256'] for r in rows+intermediate})==1
 assert all(all(r[k]==rows[0][k] for k in ['work','public_work','starts','completions','operations']) for r in rows+intermediate)
 before=statistics.mean(rows[i]['metrics']['mean_us'] for i in [0,3]);after=statistics.mean(rows[i]['metrics']['mean_us'] for i in [1,2])
 windows.append(dict(window=window,runs=rows,intermediate_runs=intermediate,whole_world_equal=True,before_mean_us=before,after_mean_us=after,mean_reduction_percent=(1-after/before)*100))
dump('quick-summary.json',dict(baseline=BASE,formal_pass=False,formal_acceptance_paused=True,windows=windows,
 caution='Final e/f/g/h plain A/B/B/A windows retain all 160 actors and original operations. a/b/c/d retain the intermediate source tree which redundantly expanded sole-lift arrival nodes. Default affinity/priority unchanged, actual engine CPU and wall lifecycle recorded separately. Window averages and percentiles are not pooled formal results.'))
profiles=[]
for side in ['before','after','final']:
 for window in ['public360','gp80','operations40']:
  name=side+'-all-'+window;d=read(ROOT/(name+'.json'));p=d['profile']
  assert d['complete'] and d['qualified'] and not d['errors'] and not p['errors']
  assert d['final_binary_sha256']==read(ROOT/('a-'+window+'.json'))['final_binary_sha256']
  indices={s['tick']:s['index'] for s in d['samples']}
  steps=[dict(index=indices[s['tick']],tick=s['tick'],outer_us=s['outer_elapsed_us'],observer_us=s['observer_handler_us'],stages=s['stages'],calls=s['calls']) for s in p['step_records'] if s['calls']]
  profiles.append(dict(run=name,hash=d['final_binary_sha256'],errors=p['errors'],steps=steps,query_counts=d['public']['query_counts']))
dump('function-summary.json',dict(profiles=profiles,caution='Independent all-instance instrumentation perturbs timings. Inclusive times contain child calls and must not be summed. Whole-step effects use plain windows only. transport_requests counts logical requests; transport_searches now counts actual Boost calls, including point_source_builds, not each source-tree answer.'))
batches=[]
for line in (ROOT/'batches.txt').read_text(encoding='utf8').splitlines():
 if not line.strip():continue
 directory=REPO/'.cache/acceptance'/line.strip()
 batches.append(dict(batch=line.strip(),result=read(directory/'acceptance-results.json'),timing=read(directory/'timing-summary.json'),execution=read(directory/'execution-status.json')))
assert len(batches)==3 and batches[0]['result']['checks']==18 and batches[0]['result']['failed']==1
assert batches[0]['result']['results']['SPACE-51']['passed']==False
assert all(v['passed'] for k,v in batches[0]['result']['results'].items() if k!='SPACE-51')
assert batches[1]['result']['checks']==1 and batches[1]['result']['failed']==0
assert batches[-1]['result']['checks']==2 and batches[-1]['result']['failed']==0 and batches[-1]['result']['completed']
assert batches[-1]['execution']['test_exit']==0 and not batches[-1]['execution']['script_errors']
dump('functional-summary.json',dict(batches=batches,formal_pass=False,
 caution='Initial 18 cases: 17 PASS; SPACE-51 failed only an old counter assertion demanding connector-edge hits on every later goal, even when a source-tree hit skips the edge lookup entirely. All complete-result comparisons and new source-tree tests already passed. Assertion now accepts proven cost-only source hits, retains no-rebuild and all result checks; SPACE-51 rerun passed. Final sole-lift arrival leaf fix was then covered by SPACE-51 and STAFF-75, both clean PASS. Other unchanged interfaces/case semantics reuse the initial valid evidence; this is not a new full 18-case batch.'))
before=read(ROOT/'before-project/source-identity.json');after=read(ROOT/'final-project/source-identity.json')
rows=[r for r in before['source'] if r['path'].startswith(('game/','content/','tools/performance/'))]
raw=subprocess.run(['git','cat-file','--batch'],input=''.join(BASE+':'+r['path']+'\n' for r in rows).encode(),cwd=REPO,check=True,stdout=subprocess.PIPE).stdout
cursor=0
for r in rows:
 end=raw.index(b'\n',cursor);size=int(raw[cursor:end].split()[-1]);cursor=end+1;blob=raw[cursor:cursor+size];cursor+=size+1
 assert hashlib.sha256(blob).hexdigest()==r['sha256'],r['path']
 assert sha(ROOT/'before-project'/r['path'])==r['sha256'],r['path']
current=[dict(**r,match=sha(REPO/r['path'])==r['sha256'] and sha(ROOT/'final-project'/r['path'])==r['sha256']) for r in after['source'] if r['path'].startswith(('game/','content/','tools/performance/'))]
assert all(r['match'] for r in current)
binary={k:before[k]==after[k] for k in ['engine_sha256','native_sha256','gmp_sha256','mpfr_sha256','runtime_sha256']}
assert all(v for k,v in binary.items() if k!='native_sha256') and not binary['native_sha256']
assert sha(REPO/'game/platform/windows/bin/oddly_good_platform.windows.x86_64.dll').upper()==after['native_sha256'].upper()
for side,identity in [('before',before),('final',after)]:
 assert sha(ROOT/(side+'-project')/'game/platform/windows/bin/oddly_good_platform.windows.x86_64.dll').upper()==identity['native_sha256'].upper()
transforms=[]
for side in ['before','after','final']:
 directory=ROOT/(side+'-all-project');identity=read(directory/'all-instance-profile-identity.json')
 for r in identity['files']:
  assert sha(ROOT/(side+'-project')/r['path'])==r['original_sha256']
  assert sha(directory/'.cache/tail-profile-originals'/r['path'])==r['original_sha256']
  assert sha(directory/r['path'])==r['generated_sha256']
 transforms.append(dict(side=side,files=identity['transformed_file_count'],methods=identity['actual_method_count'],all_originals_match=True))
test_identity=read(REPO/'.cache/acceptance'/batches[-1]['batch']/'source-identity.json')
executed_test_rows=[r for r in test_identity['source'] if r['path'].startswith('tests/acceptance/')]
test_rows=[]
eof_only=[]
for r in executed_test_rows:
 current_sha=sha(REPO/r['path'])
 if current_sha!=r['sha256']:
  assert r['path']=='tests/acceptance/navigation_source_tree.gd'
  original=REPO/'.cache/acceptance'/batches[-1]['batch']/r['path']
  assert sha(original)==r['sha256']
  assert original.read_bytes()==(REPO/r['path']).read_bytes()+b'\n'
  eof_only.append(r['path'])
 test_rows.append(dict(**dict(r,sha256=current_sha),executed_sha256=r['sha256'],eof_blank_removed=current_sha!=r['sha256']))
assert all(sha(REPO/r['path'])==r['sha256'] for r in test_identity['source'] if r['path'].startswith(('game/','content/')))
test_binary={k:after[k]==test_identity[k] for k in binary};assert all(test_binary.values())
engines={measured(x+'-'+w)['launch']['engine_executable_sha256'] for x in ['a','b','c','d','e','f','g','h'] for w in ['public360','gp80','operations40']};assert len(engines)==1
dump('source-check.json',dict(baseline=BASE,baseline_files=rows,final_files=current,binary_equal=binary,before_native=before['native_sha256'],after_native=after['native_sha256'],actual_engine_sha256=next(iter(engines)),test_binary_equal=test_binary,transform_originals=transforms,final_test_files=test_rows,executed_test_files=executed_test_rows,test_eof_only_cleanup=eof_only,test_game_matches=True))
files=[]
for p in ROOT.iterdir():
 if p.is_file() and p.suffix in ['.json','.bin','.ndjson','.log','.py','.ps1','.txt']:files.append(p)
 if p.is_dir() and p.name.endswith('.sources'):files.extend(x for x in p.rglob('*') if x.is_file())
for side in ['before','after','final']:
 directory=ROOT/(side+'-project')
 files.extend([directory/'source-identity.json',directory/'import.log'])
 directory=ROOT/(side+'-all-project');files.append(directory/'all-instance-profile-identity.json');files.append(directory/'import.log')
 for r in read(directory/'all-instance-profile-identity.json')['files']:files.extend([directory/r['path'],directory/'.cache/tail-profile-originals'/r['path']])
archive=OUT/'raw-evidence.zip';manifest=[]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 def add(p,name):
  z.write(p,name);manifest.append(dict(path=name,sha256=sha(p),bytes=p.stat().st_size))
 for p in sorted(set(files)):add(p,'runs/'+p.relative_to(ROOT).as_posix())
 for name in ['public-v6.input.bin','gp.input.bin','op.input.bin']:add(REPO/'.cache/task-navigation-20261019'/name,'inputs/'+name)
 for b in batches:
  directory=REPO/'.cache/acceptance'/b['batch']
  for name in ['acceptance-results.json','execution.log','execution-status.json','source-identity.json','timing-summary.json','import.log']:add(directory/name,'acceptance/'+b['batch']+'/'+name)
 for name in ['game/building/hospital_navigation.gd','game/life/public_areas.gd','game/platform/windows/platform_route_search.h','tests/acceptance/navigation_source_tree.gd','tests/acceptance/route_search_boundaries.gd','tests/acceptance/public_region_refresh_and_doors.gd','tests/acceptance/connector_expansion_scope.gd']:add(REPO/name,'final-source/'+name)
 for name in eof_only:add(REPO/'.cache/acceptance'/batches[-1]['batch']/name,'executed-source/'+name)
 for name in ['.cache/platform-guard/abi/platform_guard_abi.h','tools/build-platform-guard.ps1']:add(REPO/name,'build/'+pathlib.Path(name).name)
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(manifest)
 for r in manifest:assert hashlib.sha256(z.read(r['path'])).hexdigest()==r['sha256']
dump('raw-manifest.json',dict(archive='raw-evidence.zip',sha256=sha(archive),bytes=archive.stat().st_size,entries=manifest))
print(json.dumps(dict(archive_entries=len(manifest),archive_bytes=archive.stat().st_size,baseline_files=len(rows),final_files=len(current),test_files=len(test_rows))))
for w in windows:print(w['window'],w['before_mean_us'],w['after_mean_us'],w['mean_reduction_percent'])
