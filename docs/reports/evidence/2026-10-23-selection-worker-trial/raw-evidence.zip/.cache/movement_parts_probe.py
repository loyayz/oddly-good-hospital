from pathlib import Path
from types import SimpleNamespace
import importlib.util
import json
import re

REPO=Path(__file__).resolve().parent.parent
spec=importlib.util.spec_from_file_location('movement_parts_trial',REPO/'.cache/worker_select_round.py')
trial=importlib.util.module_from_spec(spec)
spec.loader.exec_module(trial)
variant='baselinemoveparts'
trial.prepare(SimpleNamespace(variant=variant,tasks=4))
project=trial.ROOT/(variant+'-project')
helper=(REPO/'.cache/occupied_queue_probe.py').read_text(encoding='utf-8')
scope=dict(json=json,re=re,TICKS=[850,866,2758,2759,2763,2878])
exec(helper[helper.index('def mark('):helper.index('\nfor variant,parent')],scope)
instrument=scope['instrument']
relative='game/building/hospital_movement.gd'
original=(project/relative).read_text(encoding='utf-8')
generated=original
changes=[]
for method in ['advance','_move_step']:
    generated,patch=instrument(generated,method,'movement.parts.'+method)
    if method=='_move_step':
        replacement=patch['generated']
        replacement=replacement.replace('\tvar result: MotionResult = MotionResult.new()', '\tvar _movement_part_started: int = _waiting_probe_started\n\tvar result: MotionResult = MotionResult.new()',1)
        boundaries=[
            ('\tvar doors: Array[Dictionary] =','prepare'),
            ('\tif not _reserve_doors(','door_candidates'),
            ('\t_movement_contacts(','door_reservation'),
            ('\tif result.blocked:','contacts'),
            ('\tfor sweep: BodyIndex.Record in sweeps:\n\t\t_accepted_sweeps','body_commit'),
            ('\tif next.is_equal_approx(target):','index_updates'),
            ('\tvar _waiting_probe_return_3: Variant = result','route_tail'),
        ]
        for anchor,label in boundaries:
            assert replacement.count(anchor)==1,(anchor,replacement)
            marker=scope['mark']('movement.part.'+label).replace('_waiting_probe_started','_movement_part_started')
            marker+='\tif _movement_part_started>0: _movement_part_started = Time.get_ticks_usec()\n'
            replacement=replacement.replace(anchor,marker+anchor,1)
        counter='''\tif _waiting_probe_started>0:
\t\tvar _move_count_key: String = "diag_wait/"+str(world.sim_tick+1)+"/movement.part.doors_count"
\t\tspace.query_counts[_move_count_key] = int(space.query_counts.get(_move_count_key,0))+doors.size()
'''
        replacement=replacement.replace('\tif not _reserve_doors(',counter+'\tif not _reserve_doors(',1)
        generated=generated.replace(patch['generated'],replacement,1)
        patch['generated']=replacement
    changes.append(patch)
restored=generated
for patch in reversed(changes):restored=restored.replace(patch['generated'],patch['original'],1)
assert restored==original
(project/relative).write_bytes(generated.encode('utf-8'))
identity_path=trial.ROOT/(variant+'-identity.json')
identity=trial.read(identity_path)
identity['patches']=[dict(path=relative,replacements=changes,inverse_equal=True)]
identity['return_expressions_evaluated_before_clock_stop']=True
for row in identity['sources']:row['sha256']=trial.sha(project/row['path'])
identity_path.rename(identity_path.with_name(variant+'-initial-identity.json'))
trial.write(identity_path,identity)
print(json.dumps(dict(variant=variant,parts=len(boundaries))))
