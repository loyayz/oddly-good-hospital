func dispatch(world: WorldState) -> void:
	ensure(world)
	var first_scan: bool = true
	var visits: Array = world.active_visit_ids()
	var select_active: bool = false
	var batch_end: int = -1
	for visit_index: int in visits.size():
		if select_active and visit_index>batch_end:
			select_batch.finish()
			select_active = false
		var visit_id: String = str(visits[visit_index])
		var visit: Dictionary = world.facts.visits[visit_id]
		if world.facts.waiting_life.needs.has(visit_id):
			_dispatch_need(world,visit,world.facts.waiting_life.needs[visit_id])
			continue
		if not _waiting(world,visit):
			_release_seat(world,visit_id)
			continue
		var ticket: Dictionary = world.facts.tickets[visit.ticket_id]
		if ticket.get("service_assigned",false) and int(ticket.get("called_tick",-1))>=0:
			continue
		if world.sim_tick>=int(world.facts.waiting_life.clocks[visit_id].next_need_tick) and not world.facts.moves.has(visit.actor_id):
			_begin_need(world,visit)
			continue
		var seat: Dictionary = world.facts.waiting_life.seats.get(visit_id,{})
		if not seat.is_empty():
			_dispatch_public_seat(world,visit,seat)
			continue
		if world.sim_tick%_ticks(content.balance.patient_behavior.scan_seconds)==0 and not world.facts.moves.has(visit.actor_id):
			if not select_active and visit_index>batch_end and space.get_script()==preload("res://game/building/hospital_space.gd") and space.public_areas.get_script()==preload("res://game/life/public_areas.gd"):
				var actors: Array = []
				batch_end = _selection_batch_candidates(world,visits,visit_index,actors)
				if actors.size()>1:
					if select_batch==null: select_batch = preload("res://tools/performance/seat_selection_batch.gd").new()
					select_active = select_batch.prepare(world,space,actors,PUBLIC_SEAT_DEFINITIONS,["waiting","waiting_area","public","lobby","garden",""],select_tasks)
			space.begin_dynamic_route_query(world,first_scan)
			var prepared: Dictionary = select_batch.consume(world,space,str(visit.actor_id)) if select_active else {}
			var area: Dictionary = prepared.selection if prepared.get("ready",false) else space.public_areas.select(world,visit.actor_id,PUBLIC_SEAT_DEFINITIONS,["waiting","waiting_area","public","lobby","garden",""],"seat")
			space.end_route_query()
			first_scan = false
			if not area.is_empty():
				var intent: Dictionary = {"id":"seat_"+visit.id,"actor_id":visit.actor_id,"ticket_id":visit.ticket_id,"facility_id":"","public_purpose":"seat","mode":"auto","area":area.area,"phase":"area_travel","continuous_ticks":0,"arrived_tick":-1,"area_travel_ticks":int(area.travel_ticks),"started_tick":world.sim_tick,"floor_id":area.floor_id,"cell":area.cell}
				world.facts.waiting_life.seats[visit.id] = intent
				space.public_areas.changed(world)
				_dispatch_public_seat(world,visit,intent,area)
	if select_batch!=null: select_batch.finish()

# A chunk ends before any handler that can commit a body, use or reservation.
# Ordinary queued movement goals have no body or transit-ticket ownership yet.
func _selection_batch_candidates(world: WorldState, visits: Array, first: int, actors: Array) -> int:
	var last: int = first
	for index: int in range(first,visits.size()):
		var visit: Dictionary = world.facts.visits[visits[index]]
		if world.facts.waiting_life.needs.has(visit.id): break
		var seat: Dictionary = world.facts.waiting_life.seats.get(visit.id,{})
		if not _waiting(world,visit):
			if not seat.is_empty(): break
			last = index
			continue
		var ticket: Dictionary = world.facts.tickets[visit.ticket_id]
		if ticket.get("service_assigned",false) and int(ticket.get("called_tick",-1))>=0:
			last = index
			continue
		if world.sim_tick>=int(world.facts.waiting_life.clocks[visit.id].next_need_tick) and not world.facts.moves.has(visit.actor_id): break
		if not seat.is_empty(): break
		if world.facts.moves.has(visit.actor_id):
			last = index
			continue
		if _selection_may_claim_here(world,str(visit.actor_id)): break
		actors.append(str(visit.actor_id))
		last = index
	return last

func _selection_may_claim_here(world: WorldState, actor_id: String) -> bool:
	space.query_counts["public_select_planning_actors"] = int(space.query_counts.get("public_select_planning_actors",0))+1
	space.public_areas._ensure(world)
	for area: Dictionary in space.public_areas._candidate_regions(PUBLIC_SEAT_DEFINITIONS):
		space.query_counts["public_select_planning_contains"] = int(space.query_counts.get("public_select_planning_contains",0))+1
		# Full-body containment includes offset envelopes, rather than the anchor.
		if space.public_areas.contains(world,area.ref,actor_id): return true
	return false

