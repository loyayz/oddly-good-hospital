from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import shutil
import subprocess
import sys
import time

sys.dont_write_bytecode=True
REPO=Path(__file__).resolve().parent.parent
ROOT=REPO/'.cache/worker-select-afff405-20261023'
PRIOR=REPO/'.cache/queue-view-5712c6f-20261023'
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(path,value):
    path=Path(path)
    assert not path.exists(),path
    path.write_bytes((json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
def module(path,name):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod
PREDICATE='''func _public_scan_due(world: WorldState, visit: Dictionary) -> bool:
\tif world.sim_tick%_ticks(content.balance.patient_behavior.scan_seconds)!=0: return false
\tif world.facts.waiting_life.needs.has(visit.id) or not _waiting(world,visit): return false
\tvar ticket: Dictionary = world.facts.tickets[visit.ticket_id]
\tif ticket.get("service_assigned",false) and int(ticket.get("called_tick",-1))>=0: return false
\tif world.facts.moves.has(visit.actor_id) or not world.facts.waiting_life.seats.get(visit.id,{}).is_empty(): return false
\treturn world.sim_tick<int(world.facts.waiting_life.clocks[visit.id].next_need_tick)

'''
def prepare(args):
    started=time.perf_counter()
    ROOT.mkdir(exist_ok=True)
    target=ROOT/(args.variant+'-project')
    assert not target.exists()
    origin=PRIOR/'baseline-project'
    identity=read(PRIOR/'baseline-identity.json')
    shutil.copytree(origin,target)
    rows=[]
    for row in identity['sources']:
        path=row['path']
        assert sha(origin/path)==row['sha256'],path
        if path not in ['project.godot','export_presets.cfg']:assert sha(REPO/path)==row['sha256'],path
        rows.append(dict(path=path,sha256=sha(target/path)))
    tests=[]
    for path in subprocess.check_output(['git','ls-files','tests'],cwd=REPO,text=True).splitlines():
        if (REPO/path).is_file():
            shutil.copy2(REPO/path,target/path)
            tests.append(dict(path=path,sha256=sha(target/path)))
    patches=[]
    if not args.variant.startswith('baseline'):
        helper='tools/performance/seat_selection_batch.gd'
        shutil.copy2(REPO/('.cache/seat_selection_batch_handoff.gd' if args.variant.startswith('lazyhandoff') else '.cache/seat_selection_batch_shared.gd' if args.variant.startswith('lazyshared') else '.cache/seat_selection_batch.gd'),target/helper)
        rows.append(dict(path=helper,sha256=sha(target/helper)))
        path='game/life/waiting_life.gd'
        original=(target/path).read_text(encoding='utf-8')
        source=original.replace('var visitors: HospitalVisitors\n','var visitors: HospitalVisitors\nvar select_batch: RefCounted\nvar select_tasks: int = '+str(args.tasks)+'\n',1)
        source=source.replace('\tvar first_scan: bool = true\n','''\tvar first_scan: bool = true
\tvar actors: Array = []
\tif world.sim_tick%_ticks(content.balance.patient_behavior.scan_seconds)==0:
\t\tfor id: String in world.active_visit_ids():
\t\t\tvar candidate: Dictionary = world.facts.visits[id]
\t\t\tif _public_scan_due(world,candidate): actors.append(str(candidate.actor_id))
\tvar select_active: bool = false
\tif actors.size()>1 and space.get_script()==preload("res://game/building/hospital_space.gd") and space.public_areas.get_script()==preload("res://game/life/public_areas.gd"):
\t\tif select_batch==null: select_batch = preload("res://tools/performance/seat_selection_batch.gd").new()
\t\tselect_active = select_batch.prepare(world,space,actors,PUBLIC_SEAT_DEFINITIONS,["waiting","waiting_area","public","lobby","garden",""],select_tasks)
''',1)
        source=source.replace('if world.sim_tick%_ticks(content.balance.patient_behavior.scan_seconds)==0 and not world.facts.moves.has(visit.actor_id):','if _public_scan_due(world,visit):',1)
        old='\t\t\tvar area: Dictionary = space.public_areas.select(world,visit.actor_id,PUBLIC_SEAT_DEFINITIONS,["waiting","waiting_area","public","lobby","garden",""],"seat")'
        new='''\t\t\tvar prepared: Dictionary = select_batch.consume(world,space,str(visit.actor_id)) if select_active else {}
\t\t\tvar area: Dictionary = prepared.selection if prepared.get("ready",false) else space.public_areas.select(world,visit.actor_id,PUBLIC_SEAT_DEFINITIONS,["waiting","waiting_area","public","lobby","garden",""],"seat")'''
        assert source.count(old)==1
        source=source.replace(old,new,1)
        source=source.replace('\nfunc advance(world: WorldState) -> void:', '\n\tif select_batch!=null: select_batch.finish()\n\n'+PREDICATE+'func advance(world: WorldState) -> void:',1)
        if args.variant.startswith('lazy'):
            source=original.replace('var visitors: HospitalVisitors\n','var visitors: HospitalVisitors\nvar select_batch: RefCounted\nvar select_tasks: int = '+str(args.tasks)+'\n',1)
            begin=source.index('func dispatch(world: WorldState) -> void:')
            end=source.index('func advance(world: WorldState) -> void:',begin)
            integration=(REPO/'.cache/seat_selection_lazy_integration.gd').read_text(encoding='utf-8')
            source=source[:begin]+integration+'\n'+source[end:]
        assert source!=original
        (target/path).write_bytes(source.encode('utf-8'))
        for row in rows:
            if row['path']==path:row['sha256']=sha(target/path)
        patches.append(dict(path=path,original=original,generated=source))
    runner='tools/performance/representative_worker.gd'
    original=(target/runner).read_text(encoding='utf-8')
    anchor='\treport.worker_sample = '
    # The prepared environment runner owns the report serialization point.
    assert anchor in original
    offset=original.index(anchor)
    generated=original[:offset]+'\tif clinical.simulation.services.waiting.select_batch!=null: report["worker_select"] = clinical.simulation.services.waiting.select_batch.report()\n'+original[offset:] if not args.variant.startswith('baseline') else original
    (target/runner).write_bytes(generated.encode('utf-8'))
    for row in rows:
        if row['path']==runner:row['sha256']=sha(target/runner)
    write(ROOT/(args.variant+'-identity.json'),dict(sources=rows,tests=tests,patches=patches,runner_original=original,runner_generated=generated,
        workspace_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip(),tasks=args.tasks,
        preparation_wall_ms=(time.perf_counter()-started)*1000,diagnostic_only=True,formal_pass=False,runtime_caches_restored=False))
    print(json.dumps(dict(prepared=args.variant,sources=len(rows),tasks=args.tasks)),flush=True)
def measure(args):
    project=ROOT/(args.variant+'-project')
    identity=read(ROOT/(args.variant+'-identity.json'))
    for row in identity['sources']:assert sha(project/row['path'])==row['sha256'],row['path']
    launch=module(REPO/'.cache/wait-signature-031e1f7-20261022/run.py','select_launcher')
    launch.ROOT=ROOT
    filename,steps=launch.WINDOWS[args.window]
    source_input=REPO/'.cache/task-navigation-20261019'/filename
    output=ROOT/(args.label+'-'+args.window+'.json')
    write(output.with_suffix('.source-check.json'),dict(actual_sources=identity['sources'],input_sha256=sha(source_input),variant=args.variant,
        runner_sha256=sha(project/'tools/performance/representative_worker.gd'),diagnostic_only=True,formal_pass=False,runtime_caches_restored=False))
    launch.launch(['--headless','--path',project,'--script','res://tools/performance/representative_worker.gd','--','--input='+str(source_input),
        '--output='+str(output),'--steps='+str(steps),'--profile='+args.profile],output)
    actual=read(output)
    expected=read(REPO/'.cache/queue-signature-26bcc0f-20261023'/(( 'e3-' if args.window=='gp80' else 'e1-')+args.window+'.json'))
    checks=dict(complete=actual['complete'],qualified=actual['qualified'],errors_empty=not actual['errors'])
    for key in ['source_input_sha256','initial','final','qualification','operations','event_records','final_binary_sha256']:
        checks[key]=actual.get(key)==expected.get(key)
    ap,bp=actual['public'].copy(),expected['public'].copy()
    ac,bc=ap.pop('query_counts'),bp.pop('query_counts')
    checks['public_business']=ap==bp
    checks['non_timing_samples']=[{k:v for k,v in x.items() if k!='elapsed_us'} for x in actual['samples']]==[{k:v for k,v in x.items() if k!='elapsed_us'} for x in expected['samples']]
    differences={k:dict(actual=ac.get(k),expected=bc.get(k)) for k in ac.keys()|bc.keys() if ac.get(k)!=bc.get(k)}
    workers=actual['worker_sample']
    checks['environment_workers_complete']=workers['batches']==steps and workers['processed']==workers['consumed'] and workers['failed_batches']==0
    selection=actual.get('worker_select',{})
    if not args.variant.startswith('baseline'):
        checks['selection_completed']=selection['requested']==selection['processed'] and selection['failed_batches']==0
        checks['every_result_accounted']=selection['requested']==selection['consumed']+selection['rejected']+selection['unused']
        checks['distinct_nonmain_workers']=len(selection['threads'])>1 and str(selection['last_batch']['main_thread_id']) not in selection['threads']
    summary=dict(passed=all(checks.values()),checks=checks,metrics=actual['metrics'],selection=selection,query_count_differences=differences)
    write(output.with_suffix('.semantic-check.json'),summary)
    print(json.dumps(summary),flush=True)
    assert all(checks.values())
if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('action',choices=['prepare','measure'])
    parser.add_argument('--variant',default='baseline')
    parser.add_argument('--tasks',type=int,default=4)
    parser.add_argument('--window',default='gp80')
    parser.add_argument('--label',default='a1')
    parser.add_argument('--profile',default='plain')
    args=parser.parse_args()
    if args.action=='prepare':prepare(args)
    else:measure(args)
