from pathlib import Path
from types import SimpleNamespace
import hashlib
import importlib.util
import json
import re

REPO=Path(__file__).resolve().parent.parent
spec=importlib.util.spec_from_file_location('movement_trial',REPO/'.cache/worker_select_round.py')
trial=importlib.util.module_from_spec(spec)
spec.loader.exec_module(trial)
variant='baselinemoveprobe'
trial.prepare(SimpleNamespace(variant=variant,tasks=4))
project=trial.ROOT/(variant+'-project')
helper=(REPO/'.cache/occupied_queue_probe.py').read_text(encoding='utf-8')
scope=dict(json=json,re=re,TICKS=[850,866,2758,2759,2763,2878])
exec(helper[helper.index('def mark('):helper.index('\nfor variant,parent')],scope)
instrument=scope['instrument']
patches=[]
for relative,names in {
    'game/building/hospital_movement.gd':['advance','_move_step','_unit_sweeps','_active_route_clear','_dispatch_routes','_movement_contacts','_reserve_doors','_mark_door_use'],
    'game/building/hospital_space.gd':['_ensure_actor_index','_reservation_regions','movement_doors','_sync_actor'],
}.items():
    original=(project/relative).read_text(encoding='utf-8')
    generated=original
    changes=[]
    for name in names:
        generated,patch=instrument(generated,name,'movement.'+relative.rsplit('/',1)[-1]+'.'+name)
        if relative.endswith('hospital_space.gd'):
            replacement=patch['generated'].replace('space.query_counts','self.query_counts')
            generated=generated.replace(patch['generated'],replacement,1)
            patch['generated']=replacement
        changes.append(patch)
    restored=generated
    for patch in reversed(changes):restored=restored.replace(patch['generated'],patch['original'],1)
    assert restored==original
    (project/relative).write_bytes(generated.encode('utf-8'))
    patches.append(dict(path=relative,replacements=changes,inverse_equal=True))
identity_path=trial.ROOT/(variant+'-identity.json')
identity=trial.read(identity_path)
identity['patches']=patches
identity['return_expressions_evaluated_before_clock_stop']=True
for row in identity['sources']: row['sha256']=trial.sha(project/row['path'])
# Preserve the initial prepare identity separately; the measured manifest is new.
identity_path.rename(identity_path.with_name(variant+'-initial-identity.json'))
trial.write(identity_path,identity)
print(json.dumps(dict(variant=variant,methods=sum(len(p['replacements']) for p in patches))))
