from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import zipfile

REPO=Path(__file__).resolve().parent.parent
ROOT=REPO/'.cache/worker-select-afff405-20261023'
OUT=REPO/'docs/reports/evidence/2026-10-23-selection-worker-trial'
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
digest=lambda b:hashlib.sha256(b).hexdigest()
sha=lambda p:digest(Path(p).read_bytes())
rel=lambda p:Path(p).relative_to(REPO).as_posix()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()
assert head=='afff405b1f6f66e51a95fe76bf77ef35924516b2',head
subprocess.check_call(['git','diff','--exit-code','--','game','tests','project.godot'],cwd=REPO)
assert subprocess.check_output(['git','branch','--show-current'],cwd=REPO,text=True).strip()=='dev'
baseline=read(ROOT/'baseline02-identity.json')
for row in baseline['sources']:
    if row['path'] not in ['project.godot','export_presets.cfg']:
        assert sha(REPO/row['path'])==row['sha256'],row['path']
for row in baseline['tests']:assert sha(REPO/row['path'])==row['sha256'],row['path']
prior=REPO/'docs/reports/evidence/2026-10-23-queue-value-view-trial/raw-evidence.zip'
assert sha(prior)=='8b4a268736cb215558c7c9981eb34217e86684cfc625a23181603a3e9d17f5d3'
baseline_rows={r['path']:r['sha256'] for r in baseline['sources']}
aliases=[]
members={}
def add(path,name=None):
    path=Path(path)
    name=name or rel(path)
    data=path.read_bytes()
    if name in members:assert members[name]==data,name
    members[name]=data

identities={}
for path in sorted(ROOT.glob('*-identity.json')):
    if path.name.endswith('-initial-identity.json'):continue
    identity=read(path)
    variant=path.name.removesuffix('-identity.json')
    project=ROOT/(variant+'-project')
    for row in identity['sources']:
        source=project/row['path']
        assert sha(source)==row['sha256'],source
        if baseline_rows.get(row['path'])!=row['sha256']:
            member='source-blobs/'+row['sha256']+source.suffix
            add(source,member)
            aliases.append(dict(path=rel(source),member=member,sha256=row['sha256']))
    for row in identity['tests']:assert sha(project/row['path'])==row['sha256'],row['path']
    identities[variant]=dict(sources=len(identity['sources']),tests=len(identity['tests']),tasks=identity['tasks'],all_files_verified=True)

runs={}
intervals=[]
for path in sorted(ROOT.glob('*.semantic-check.json')):
    label=path.name.removesuffix('.semantic-check.json')
    check=read(path)
    assert check['passed'] and all(check['checks'].values()),label
    result=read(ROOT/(label+'.json'))
    source=read(ROOT/(label+'.source-check.json'))
    launch=read(ROOT/(label+'.launch.json'))
    assert launch['exit_code']==0 and not launch['timed_out'] and not launch['errors'],label
    assert sha(launch['engine'])==launch['engine_sha256']
    assert source['actual_sources']==read(ROOT/(source['variant']+'-identity.json'))['sources'],label
    assert result['metrics']['count']==result['requested_steps'] and len(result['samples'])==result['requested_steps']
    assert sha(ROOT/(label+'.json.final.bin'))==result['final_binary_sha256']
    assert all(s['present']==160 and s['complete'] for s in result['samples'])
    if source['variant'].startswith('baseline'):
        assert all(k.startswith('diag_wait/') for k in check['query_count_differences']),label
    selection=result.get('worker_select',{})
    if selection:
        assert selection['failed_batches']==0 and selection['processed']==selection['requested']
        assert selection['requested']==selection['consumed']+selection['rejected']+selection['unused']
        assert selection['last_batch']['peak_charge_sum']<=134217728
    profile=result.get('profile',{})
    roots={}
    if profile:
        assert profile['steps']==result['requested_steps'] and profile['step_records_complete'] and not profile['errors']
        for record in profile['step_records']:
            if record['tick'] in [851,867,2759,2760,2764,2879]:
                roots[str(record['tick'])]=dict(outer_elapsed_us=record['outer_elapsed_us'],
                    stages=record['stages'],observer_handler_us=record['observer_handler_us'],residual_us=record['residual_us'])
    intervals.append((launch['started_at_utc'],launch['ended_at_utc'],label))
    runs[label]=dict(variant=source['variant'],mode=result['mode'],metrics_us=result['metrics'],
        steps=result['requested_steps'],checks=check['checks'],selection=selection,
        query_count_differences=check['query_count_differences'],roots=roots,
        diagnostic_counts={k:v for k,v in result['public']['query_counts'].items() if k.startswith('diag_wait/')},
        query_counts={k:v for k,v in result['public']['query_counts'].items() if not k.startswith('diag_wait/')},
        input_sha256=result['source_input_sha256'],final_binary_sha256=result['final_binary_sha256'],
        process_cpu_ms=launch['child_cpu_ms'],process_wall_ms=launch['wall_ms'])
intervals.sort()
for a,b in zip(intervals,intervals[1:]):assert a[1]<=b[0],(a,b)
assert len(runs)==10 and sum(r['steps'] for r in runs.values())==1080

failed_project=ROOT/'baseline-project'
assert failed_project.is_dir() and not (ROOT/'baseline-identity.json').exists()
failure=dict(stage='experiment_preparation',variant='baseline',engine_started=False,
    error='AssertionError: report["worker_sample"] runner anchor was absent; prepared runner uses report.worker_sample.',
    retained_project=rel(failed_project),resolution='Corrected the generator anchor and prepared a separate baseline02 project. The original folder was retained.')
for row in baseline['sources']:assert sha(failed_project/row['path'])==row['sha256'],row['path']
members['failures/initial-prepare.json']=(json.dumps(failure,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
for path in ROOT.iterdir():
    if path.is_file() and not path.name.endswith('.final.bin'):add(path)
for path in ROOT.glob('*.json.final.bin'):
    member='final-states/'+sha(path)+'.bin'
    add(path,member)
    aliases.append(dict(path=rel(path),member=member,sha256=sha(path)))
for name in ['worker_select_round.py','seat_selection_batch.gd','seat_selection_lazy_integration.gd',
    'seat_selection_batch_shared.gd','seat_selection_batch_handoff.gd','movement_cost_probe.py',
    'movement_parts_probe.py','occupied_queue_probe.py']:
    add(REPO/'.cache'/name)
add(REPO/'.cache/wait-signature-031e1f7-20261022/run.py')
add(REPO/'.cache/queue-view-5712c6f-20261023/baseline-identity.json')
add(Path(__file__))
for name in ['public-v6.input.bin','gp.input.bin','op.input.bin']:add(REPO/'.cache/task-navigation-20261019'/name)
members['source-aliases.json']=(json.dumps(aliases,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
OUT.mkdir(parents=True,exist_ok=True)
archive=OUT/'raw-evidence.zip'
assert not archive.exists()
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(members.items()):z.writestr(name,data)
with zipfile.ZipFile(archive) as z:
    assert set(z.namelist())==set(members)
    for name,data in members.items():assert digest(z.read(name))==digest(data),name
manifest=dict(schema_version=1,archive_sha256=sha(archive),archive_bytes=archive.stat().st_size,
    members=[dict(path=k,bytes=len(v),sha256=digest(v)) for k,v in sorted(members.items())],
    baseline_reference=dict(path=rel(prior),sha256=sha(prior),identity_path=rel(REPO/'.cache/queue-view-5712c6f-20261023/baseline-identity.json')))
summary=dict(schema_version=1,generated_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    baseline_commit=head,production_commit='5712c6f7fbc7e222e2a483bc376201352fd5ffc2',
    diagnostic_only=True,formal_pass=False,fixed_load=dict(people=160,patients=120,staff=32,visitors=8,floors=4,rooms=64,facilities=1336,tick_seconds=0.1),
    successful_engine_windows=len(runs),measured_steps=sum(r['steps'] for r in runs.values()),
    all_engine_intervals_disjoint=True,production_and_tests_unchanged=True,identities=identities,runs=runs,
    failures=[failure],functional=dict(experimental_cases_run=False,reason='All selection worker variants were rejected for whole-step regression; no production or test change was adopted.',
        selected_but_not_executed=['STAFF-48','STAFF-57','STAFF-61','STAFF-69','STAFF-75','SPACE-51'],
        unchanged_production_evidence='docs/reports/evidence/2026-10-23-occupied-seat-dependencies/summary.json'),
    raw_archive=dict(path=rel(archive),sha256=sha(archive),bytes=archive.stat().st_size,members=len(members)),
    notes=['Function intervals are nested wall durations with measurement overhead, not additive CPU self time.',
        'No Release, rendering, capacity, memory or two-hour formal acceptance run was performed.',
        'Semantic equality is isolation evidence and does not replace independent experimental functional regression.',
        'Peak cache charges are sampled after requests and checked against the existing eviction allowance, not a measured resident-memory maximum.',
        'The first prepare failure did not start an engine; read-only source lookup mistakes do not constitute game-run failures.'])
for name,value in [('raw-manifest.json',manifest),('summary.json',summary)]:
    target=OUT/name
    assert not target.exists(),target
    target.write_bytes((json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
print(json.dumps(dict(archive_sha256=sha(archive),bytes=archive.stat().st_size,members=len(members),windows=len(runs),steps=summary['measured_steps'])))
for label in ['a1-gp80','a2-gp80','a3-gp80','b1-gp80','c1-gp80','d1-gp80','e1-gp80']:
    r=runs[label]
    print(label,json.dumps(dict(mean=r['metrics_us']['mean_us']/1000,p99=r['metrics_us']['p99_us']/1000,selection=r['selection'].get('timings_us',{}))))
for label in ['moves01-gp80','parts01-gp80','parts01-public360']:
    for tick,r in runs[label]['roots'].items():
        stages=sorted(r['stages'].items(),key=lambda x:x[1]['total_us'],reverse=True)[:8]
        print(label,tick,json.dumps(dict(whole=r['outer_elapsed_us'],stages=[(k,v['total_us']) for k,v in stages])))
