#requires -Version 7.0
$ErrorActionPreference='Stop'
$identity=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'build-identity.json') -Raw|ConvertFrom-Json
foreach($property in $identity.environment.PSObject.Properties){[Environment]::SetEnvironmentVariable($property.Name,$property.Value,'Process')}
$record=[ordered]@{started_utc=[DateTimeOffset]::UtcNow.ToString('o');context='require_escalated after identical single-file default denied / approved succeeded';compiler=$identity.compiler;compiler_sha256=$identity.compiler_sha256;compiler_version=$identity.compiler_version;source=$identity.source;environment=$identity.environment;command=$identity.command;old_native=$identity.old_native;ok=$false;elapsed_ms=$null;error='';new_native=@{}}
$clock=[Diagnostics.Stopwatch]::StartNew()
try {
    & C:/code/loyayz/oddly-good-hospital/tools/build-platform-guard.ps1 -GodotPath $identity.godot *>&1|Tee-Object -FilePath (Join-Path $PSScriptRoot 'build-escalated.log')
    $record.ok=$true
} catch {$record.error=$_.Exception.Message;throw} finally {
    $record.elapsed_ms=$clock.ElapsedMilliseconds
    $record.ended_utc=[DateTimeOffset]::UtcNow.ToString('o')
    foreach($name in $identity.old_native.PSObject.Properties.Name){$record.new_native[$name]=(Get-FileHash -LiteralPath (Join-Path C:/code/loyayz/oddly-good-hospital/game/platform/windows/bin $name) -Algorithm SHA256).Hash.ToLowerInvariant()}
    $record|ConvertTo-Json -Depth 5|Set-Content -LiteralPath (Join-Path $PSScriptRoot 'build-escalated-status.json') -Encoding utf8NoBOM
}
Write-Output ('RESIDENT_MASK_BUILD_COMPLETE='+$PSScriptRoot)
