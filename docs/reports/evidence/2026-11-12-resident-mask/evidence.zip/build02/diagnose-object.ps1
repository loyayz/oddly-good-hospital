#requires -Version 7.0
param([string]$Label='default')
$ErrorActionPreference='Stop'
$identity=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'build-identity.json') -Raw|ConvertFrom-Json
foreach($property in $identity.environment.PSObject.Properties){[Environment]::SetEnvironmentVariable($property.Name,$property.Value,'Process')}
$repo='C:/code/loyayz/oddly-good-hospital'
$math=Join-Path $repo '.cache/native-math'
$arguments=@('c++','-I'+(Join-Path $math 'soplex-native'),'-I'+(Join-Path $math 'soplex-a00610534e044f35aa298059eb963312336c4c9c/src'),'-isystem',(Join-Path $math 'ucrt64/include'),'-target','x86_64-windows-gnu','-Wall','-Wno-strict-overflow','-fdiagnostics-color=always','-O3','-DNDEBUG','-std=gnu++14','-fvisibility=hidden','-fvisibility-inlines-hidden','-ffp-contract=off','-MD','-MT','src/CMakeFiles/libsoplex.dir/soplex/spxgithash.cpp.obj','-MF','src/CMakeFiles/libsoplex.dir/soplex/spxgithash.cpp.obj.d','-o','src/CMakeFiles/libsoplex.dir/soplex/spxgithash.cpp.obj','-c',(Join-Path $math 'soplex-a00610534e044f35aa298059eb963312336c4c9c/src/soplex/spxgithash.cpp'),'-v')
$clock=[Diagnostics.Stopwatch]::StartNew()
& $identity.compiler @arguments *>&1 | Tee-Object -FilePath (Join-Path $PSScriptRoot ($Label+'.compiler.log'))
$code=$LASTEXITCODE
[ordered]@{compiler=$identity.compiler;arguments=$arguments;environment=$identity.environment;exit=$code;elapsed_ms=$clock.ElapsedMilliseconds}|ConvertTo-Json -Depth 5|Set-Content -LiteralPath (Join-Path $PSScriptRoot ($Label+'.compiler-status.json')) -Encoding utf8NoBOM
exit $code
