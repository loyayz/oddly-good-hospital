import pathlib,json,shutil,hashlib
repo=pathlib.Path('C:/code/loyayz/oddly-good-hospital')
base=repo/'.cache/resident-mask-source-nativefix01'
target=repo/'.cache/resident-mask-source-hybrid01'
m=json.loads((base/'source-identity.json').read_text(encoding='utf-8'))
target.mkdir(parents=True,exist_ok=False)
for row in m['source']:
    path=target/row['path'];path.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(base/row['path'],path)
for name in ['.godot/imported','game/platform/windows/bin']:shutil.copytree(base/name,target/name,dirs_exist_ok=True)
for name in ['.godot/global_script_class_cache.cfg','.godot/extension_list.cfg']:shutil.copy2(base/name,target/name)
updates=[]
for name in ['game/building/route_clearance.gd','tests/acceptance/resident_static_rectangle.gd','tools/performance/resident_rectangle_trace.gd','tools/performance/prepare_resident_rectangle_probe.py']:
    before=hashlib.sha256((target/name).read_bytes()).hexdigest();shutil.copy2(repo/name,target/name);after=hashlib.sha256((target/name).read_bytes()).hexdigest();updates.append({'path':name,'before':before,'after':after})
    for row in m['source']:
        if row['path']==name:row['sha256']=after
m['project']=str(target);m['hybrid']={'base':str(base),'updates':updates,'reason':'Measured native benefit starts at five origins; retain all smaller requests through complete script fallback. Position reason restored verbatim; sweep hoists identical inclusive bounds.'}
(target/'source-identity.json').write_text(json.dumps(m,ensure_ascii=False,indent=2),encoding='utf-8')
print(str(target))
