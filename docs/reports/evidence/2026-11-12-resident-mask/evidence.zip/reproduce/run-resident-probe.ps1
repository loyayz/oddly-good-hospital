#requires -Version 7.0
param([Parameter(Mandatory)][string]$Project,[Parameter(Mandatory)][string]$Name,[string]$Mode='counts',[int]$Warmup=0,[string]$ScenarioInput='C:/code/loyayz/oddly-good-hospital/.cache/performance160-clinical-family-20261112-v3-candidate01/qualification-r1/r1.json.final.bin',[string]$Expected='')
$ErrorActionPreference='Stop'
$engine='C:/programs/godot/Godot_v4.7.2-stable_win64_console.exe'
$project=[IO.Path]::GetFullPath($Project)
$runtime=Join-Path $project 'runtime'
$env:APPDATA=Join-Path $runtime 'Roaming';$env:LOCALAPPDATA=Join-Path $runtime 'Local'
New-Item -ItemType Directory -Path $env:APPDATA,$env:LOCALAPPDATA -Force|Out-Null
$output=Join-Path $project ($Name+'.json');$log=Join-Path $project ($Name+'.log')
if((Test-Path -LiteralPath $output) -or (Test-Path -LiteralPath $log)){throw 'Preserve existing actual-query evidence'}
$arguments=@('--headless','--path',$project,'--script','res://tools/performance/resident_rectangle_probe.gd','--',('--input='+$ScenarioInput),('--output='+$output),('--mode='+$Mode),('--warmup='+$Warmup))
$start=[Diagnostics.ProcessStartInfo]::new($engine);$start.UseShellExecute=$false;$start.CreateNoWindow=$true;$start.RedirectStandardOutput=$true;$start.RedirectStandardError=$true
foreach($argument in $arguments){$start.ArgumentList.Add($argument)}
$process=[Diagnostics.Process]::new();$process.StartInfo=$start
$clock=[Diagnostics.Stopwatch]::StartNew();$writer=[IO.StreamWriter]::new($log,$false,[Text.UTF8Encoding]::new($false));$fatal=$false
try {
    $null=$process.Start();$out=$process.StandardOutput.ReadLineAsync();$err=$process.StandardError.ReadLineAsync();$outEnded=$false;$errEnded=$false
    while(-not $process.HasExited -or -not $outEnded -or -not $errEnded){
        foreach($stream in @('out','err')){$task=if($stream -eq 'out'){$out}else{$err};if($task.IsCompleted){$line=$task.GetAwaiter().GetResult();if($null -eq $line){if($stream -eq 'out'){$outEnded=$true}else{$errEnded=$true}}else{$writer.WriteLine($line);$writer.Flush();if($line -match 'SCRIPT ERROR:|Parse Error:|ERROR:'){$fatal=$true;if(-not $process.HasExited){$process.Kill($true)}};if($stream -eq 'out'){$out=$process.StandardOutput.ReadLineAsync()}else{$err=$process.StandardError.ReadLineAsync()}}}}
        if($clock.Elapsed.TotalSeconds -gt 300 -and -not $process.HasExited){$fatal=$true;$process.Kill($true)}
        Start-Sleep -Milliseconds 10
    }
    $process.WaitForExit();[ordered]@{mode=$Mode;exit=$process.ExitCode;fatal=$fatal;elapsed_ms=$clock.ElapsedMilliseconds;arguments=$arguments;APPDATA=$env:APPDATA;LOCALAPPDATA=$env:LOCALAPPDATA}|ConvertTo-Json -Depth 4|Set-Content -LiteralPath (Join-Path $project ($Name+'.status.json')) -Encoding utf8NoBOM
    if($fatal -or $process.ExitCode -ne 0){Get-Content -LiteralPath $log -Tail 25;throw "Actual query probe failed: $Name"}
    $result=Get-Content -LiteralPath $output -Raw|ConvertFrom-Json
    if(-not $result.complete -or -not $result.ok){throw "Incomplete actual-query result: $Name"}
    if($Expected -ne '' -and $result.full_world_and_ordered_events_sha256 -ne $Expected){throw "Full World/events mismatch: $Name"}
    [ordered]@{name=$Name;elapsed_ms=$clock.ElapsedMilliseconds;mode=$Mode;tick=$result.final_tick;actors=$result.actors;present=$result.present_actors;hash=$result.full_world_and_ordered_events_sha256;calls=$result.trace.calls;eligible=$result.trace.eligible;old_reason_calls=$result.trace.legacy_origin_reason_calls;actual_reason_calls=$result.trace.actual_origin_reason_calls;replaced=$result.trace.replaced_origin_calls}|ConvertTo-Json
} finally {$writer.Dispose();$process.Dispose()}
