import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import tarfile
import uuid

repo = Path('C:/code/loyayz/oddly-good-hospital')
target = repo/'.cache/resident-mask-source-6e8d59c'
archive = repo/'.cache/resident-mask-source-6e8d59c.tar'
imported = repo/'.cache/acceptance/a0ee0d7716f84ccb9693ebf5f210106e'
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
subprocess.run(['git','-C',str(repo),'archive','--format=tar','--output='+str(archive),'6e8d59c'],check=True)
target.mkdir(parents=True,exist_ok=True)
with tarfile.open(archive) as source:
    source.extractall(target,filter='data')
owned = ['game/building/floor_navigation.gd','game/building/route_clearance.gd','game/platform/windows/platform_arrivals.cpp','game/platform/windows/platform_grid_distance.h','tests/acceptance/resident_static_rectangle.gd','tests/acceptance/resident_static_rectangle_runner.gd','tools/performance/resident_rectangle_trace.gd','tools/performance/resident_rectangle_probe.gd','tools/performance/prepare_resident_rectangle_probe.py']
overlay = {}
for name in owned:
    path = target/name
    overlay[name]={'base_sha256':digest(path) if path.exists() else None,'candidate_sha256':digest(repo/name)}
    path.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(repo/name,path)
for name in ['.godot/imported','game/platform/windows/bin']:
    shutil.copytree(imported/name,target/name,dirs_exist_ok=True)
for name in ['.godot/global_script_class_cache.cfg','.godot/extension_list.cfg']:
    shutil.copy2(imported/name,target/name)
cache = (target/'.godot/global_script_class_cache.cfg').read_text(encoding='utf-8')
assert all((target/name).exists() for name in re.findall(r'"path": "res://([^"]+)"',cache)), 'Imported class directory contains an excluded unfinished script'
paths = [path.relative_to(target).as_posix() for path in target.rglob('*') if path.is_file() and not path.is_relative_to(target/'.godot') and not path.is_relative_to(target/'game/platform/windows/bin')]
initial = json.loads((imported/'source-identity.json').read_text(encoding='utf-8-sig'))
participating = [row for row in initial['source'] if row['path'].startswith(('game/','content/','tests/')) and not row['path'].endswith('.gd.uid')]
mismatches = [row['path'] for row in participating if not (target/row['path']).exists() or digest(target/row['path'])!=row['sha256']]
eol_mapping = []
for name in mismatches:
    assert (target/name).read_bytes().replace(b'\r\n',b'\n')==(imported/name).read_bytes().replace(b'\r\n',b'\n'), ('Content differs from Git6e',name)
    eol_mapping.append({'path':name,'git_sha256':digest(target/name),'tested_sha256':digest(imported/name),'difference':'CRLF only; exact tested bytes retained'})
    shutil.copy2(imported/name,target/name)
mismatches = [row['path'] for row in participating if not (target/row['path']).exists() or digest(target/row['path'])!=row['sha256']]
assert not mismatches, ('Initial four-case runtime source differs',mismatches)
profile = 'OddlyGoodHospital ResidentMask '+uuid.uuid4().hex
project = target/'project.godot'
text,count = re.subn(r'config/custom_user_dir_name="[^"]*"','config/custom_user_dir_name="'+profile+'"',project.read_text(encoding='utf-8'))
assert count==1
project.write_text(text,encoding='utf-8',newline='')
identity = {'head':'6e8d59c4e451ad93fd9bd3db483a44da21e64598','project':str(target),'source':[{'path':name,'sha256':digest(target/name)} for name in sorted(paths)],'engine':initial['engine'],'engine_sha256':initial['engine_sha256'],'native_sha256':initial['native_sha256'],'native':{path.name:digest(path) for path in (target/'game/platform/windows/bin').glob('*.dll')},'overlay':overlay,'shared_import':str(imported),'participating_game_content_test_files_equal':len(participating),'participating_mismatches':mismatches,'profile':profile,'scope':'Exact Git6e source plus nine explicitly owned files; unrelated worktree and in-progress mixed tools are excluded. Existing four-case evidence reused only after all participating game/content/tests hashes match.'}
identity['eol_mapping']=eol_mapping
(target/'source-identity.json').write_text(json.dumps(identity,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'project':str(target),'source_files':len(paths),'participating_files_same':len(participating),'mismatches':mismatches,'native':identity['native']}))
