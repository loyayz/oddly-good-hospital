"""Run the fixed resident-mask gate reorder batch once; stop on any failure."""
import argparse
import collections
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import traceback

ROOT = Path(__file__).resolve().parent.parent
COMMIT = "7b2a7352f9e0c5af54024521a106a307e97fbd22"
BASE = ROOT / ".cache/performance160-clinical-family-20261112-v3-candidate02/project"
INPUT = ROOT / ".cache/performance160-clinical-family-20261112-v3-candidate02/qualification-r1/r1.json.final.bin"
INPUT_SHA = "0afa344f973e4ce8b12ce46a034f3dc754f43e42e446938e94f4ed47163aaf74"
OUTCOME_SHA = "f8f05675796b87493715f06af53bc4cb43af54b094ccce828d6876a736bb79a2"
MASKS = ["MASK-LIFETIME", "MASK-BOUNDARIES", "MASK-FIRST-REASON"]


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def write(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def processes():
    code = "@(Get-Process | Where-Object {$_.ProcessName -match '^(Godot.*|zig|clang.*|gcc|g\\+\\+|ninja|cmake)$'} | Select-Object Id,ProcessName,CPU)|ConvertTo-Json -Compress"
    raw = subprocess.check_output(["pwsh", "-NoProfile", "-Command", code], encoding="utf-8")
    return json.loads(raw) if raw.strip() else []


def run(args):
    output = args.output.resolve()
    assert output.is_relative_to(ROOT / ".cache") and not output.exists(), "Use a new .cache evidence directory"
    output.mkdir(parents=True)
    stage, command, log_path = "preflight", [], output / "preflight.log"
    started = time.perf_counter()
    records = []
    try:
        assert not processes(), "Another engine/compiler is active; no automatic retry"
        base, scenario, candidate = args.base_project.resolve(), args.input.resolve(), args.candidate_source.resolve()
        metadata = read(base / "source-identity.json")
        authority = read(base.parent / "profiler-authority.json")
        commit = subprocess.check_output(["git", "-C", str(ROOT), "rev-parse", args.reference_commit + "^{commit}"], encoding="utf-8").strip()
        assert commit == COMMIT == metadata["head"], "This batch compares only the frozen B02 gate"
        assert sha(base / "source-identity.json") == authority["stage_identity_sha256"]
        assert sha(scenario) == INPUT_SHA
        engine = Path(metadata["engine"]).resolve()
        engines = metadata["engine_executables"]
        native = authority["native"]
        assert len(engines) == 2 and len(native) == 5
        assert all(sha(Path(name)) == value for name, value in engines.items())
        assert all(sha(base / "game/platform/windows/bin" / name) == value for name, value in native.items())
        preparer = ROOT / "tools/performance/prepare_resident_rectangle_probe.py"
        protocol = {"reference_commit": commit, "base_project": str(base), "base_identity_sha256": sha(base / "source-identity.json"),
                    "authority": str(base.parent / "profiler-authority.json"), "authority_sha256": sha(base.parent / "profiler-authority.json"),
                    "input": str(scenario), "input_sha256": INPUT_SHA, "expected_outcome_sha256": OUTCOME_SHA,
                    "candidate_source": str(candidate), "candidate_source_sha256": sha(candidate), "preparer_sha256": sha(preparer),
                    "mechanical_batch_sha256": sha(Path(__file__)), "engine_executables": engines, "native": native,
                    "selected_cases": MASKS, "OMP_NUM_THREADS": "1", "worker_tasks": 4, "warmup": 0,
                    "scope": "One complete B02 input (byte-identical to the earlier 0afa boundary), all actual requests, existing per-request three alternating pairs. Separate counts process. No retries, compiler, load change or full-window CPU claim."}
        write(output / "protocol.json", protocol)

        def execute(name, argv, engine_run=False):
            nonlocal stage, command, log_path
            stage, command = name, [str(item) for item in argv]
            log_path = output / (name + ".log")
            if engine_run:
                assert not processes(), "Another engine/compiler is active; no automatic retry"
            environment = dict(os.environ, OMP_NUM_THREADS="1")
            isolated = output / "environment" / name
            env_paths = {"APPDATA": isolated / "appdata", "LOCALAPPDATA": isolated / "localappdata", "TEMP": isolated / "temp", "TMP": isolated / "temp", "TMPDIR": isolated / "temp"}
            for key, path in env_paths.items():
                path.mkdir(parents=True, exist_ok=True)
                environment[key] = str(path)
            record = {"stage": name, "command": command, "cwd": str(ROOT), "log": str(log_path), "environment": {key: environment[key] for key in [*env_paths, "OMP_NUM_THREADS"]}, "started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat()}
            write(output / "status.json", {"state": "running", **record})
            began = time.perf_counter()
            with log_path.open("wb") as log:
                process = subprocess.Popen(command, cwd=ROOT, env=environment, stdout=log, stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW)
                try:
                    code = process.wait(timeout=args.stage_timeout)
                except subprocess.TimeoutExpired:
                    # Stop this launched process tree only; never global Godot/CPU processes.
                    subprocess.run(["pwsh", "-NoProfile", "-Command", f"$ownedProcess=[System.Diagnostics.Process]::GetProcessById({process.pid}); $ownedProcess.Kill($true); if (-not $ownedProcess.WaitForExit(10000)) {{ throw 'Owned stage did not exit' }}"], stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, check=True, timeout=15)
                    process.wait(timeout=10)
                    raise AssertionError("Owned stage timed out; no retry")
            record.update({"exit_code": code, "wall_seconds": time.perf_counter() - began})
            records.append(record)
            write(output / (name + ".execution.json"), record)
            assert code == 0, "Stage returned nonzero"
            messages = log_path.read_text(encoding="utf-8", errors="replace")
            assert "SCRIPT ERROR:" not in messages and not any(line.startswith("ERROR:") for line in messages.splitlines()), "Engine reported an error"

        projects = {}
        for mode in ("counts", "timing"):
            project = output / mode / "project"
            projects[mode] = project
            execute("prepare-" + mode, [sys.executable, "-X", "utf8", preparer, "--base-project", base, "--output", project, "--overlay", mode, "--reference-commit", commit, "--candidate-source", candidate])
            identity = read(project / "resident-rectangle-identity.json")
            assert identity["reference_commit"] == commit and identity["candidate_overlay"]["only_condition_reordered"]
            assert identity["candidate_overlay"]["candidate_sha256"] == protocol["candidate_source_sha256"]
            assert identity["native"] == native and identity["hooks"]["complete_source_restores_exactly"]
            assert identity["hooks"]["reason_and_resident_helper_uninstrumented_for_timing"] == (mode == "timing")

        execute("mask", [engine, "--headless", "--path", projects["counts"], "--script", "res://tests/acceptance/resident_static_rectangle_runner.gd", "--", output / "mask.json", *MASKS], True)
        masks = read(output / "mask.json")
        assert masks["complete"] and masks["ok"] and [row["case"] for row in masks["cases"]] == MASKS
        assert all(row["ok"] and all(value is True for value in row["checks"].values()) for row in masks["cases"])

        results = {}
        for mode in ("counts", "timing", "baseline"):
            project = projects["counts" if mode == "counts" else "timing"]
            execute(mode, [engine, "--headless", "--path", project, "--script", "res://tools/performance/resident_rectangle_probe.gd", "--", "--input=" + str(scenario), "--output=" + str(output / (mode + ".json")), "--mode=" + mode, "--warmup=0"], True)
            result = read(output / (mode + ".json"))
            assert result["complete"] and result["ok"] and not result["trace"].get("errors", [])
            assert result["initialized_facts_unchanged"] and result["input_sha256"] == INPUT_SHA and not result["world_validation"]
            assert result["initial_tick"] == result["boundary_tick"] == 7633 and result["final_tick"] == 7634
            assert result["actors"] == 179 and result["present_actors"] == 169 and result["worker_tasks"] == 4 and result["ordinary_warmup_steps"] == 0
            assert sha(output / (mode + ".json.bin")) == result["full_world_and_ordered_events_sha256"] == OUTCOME_SHA
            results[mode] = result

        stage, command, log_path = "summary", [], output / "summary-validation.log"
        counted, timed = results["counts"]["trace"]["queries"], results["timing"]["trace"]["queries"]
        assert counted and len(counted) == len(timed)
        keys = ("kind", "depth", "arguments", "size", "eligible", "reason", "blocked_id")
        assert all({key: a[key] for key in keys} == {key: b[key] for key in keys} for a, b in zip(counted, timed)), "Complete request/typed-result metadata differs"
        groups = {}
        for row in timed:
            assert isinstance(row["reason"], str) and len(row["timing"]) == 6
            labels = [(sample["repeat"], sample["variant"]) for sample in row["timing"]]
            assert sorted(labels) == [(repeat, variant) for repeat in (1, 2, 3) for variant in ("candidate", "reference")]
            kind = "position" if row["kind"] == "position_reason" else ("early_branch" if "origin_area" not in row else ("small_sweep" if row["origin_area"] < 5 else ("large_native_sweep" if row["eligible"] else "large_fallback_sweep")))
            for group in ("all", kind):
                totals = groups.setdefault(group, {"calls": 0, "reference_usec": [0, 0, 0], "candidate_usec": [0, 0, 0]})
                totals["calls"] += 1
                for sample in row["timing"]:
                    totals[sample["variant"] + "_usec"][sample["repeat"] - 1] += sample["elapsed_usec"]
        for totals in groups.values():
            totals["reference_mean_usec"] = sum(totals["reference_usec"]) / 3
            totals["candidate_mean_usec"] = sum(totals["candidate_usec"]) / 3
        assert all(sha(Path(name)) == value for name, value in engines.items()) and sha(scenario) == INPUT_SHA
        for project in projects.values():
            identity = read(project / "resident-rectangle-identity.json")
            assert all(sha(project / name) == value for name, value in identity["source"].items()), "Measured source changed"
            assert all(sha(project / "game/platform/windows/bin" / name) == value for name, value in native.items())
        summary = {"complete": True, "ok": True, "protocol_sha256": sha(output / "protocol.json"), "selected_masks": MASKS,
                   "requests": len(timed), "typed_results_equal": True, "counts_timing_complete_request_metadata_equal": True,
                   "depth_counts": dict(collections.Counter(row["depth"] for row in timed)), "full_world_and_ordered_events_sha256": OUTCOME_SHA,
                   "independent_counts": {"actual_origin_reason_calls": sum(row["actual_origin_reason_calls"] for row in counted), "actual_helper_queries": sum("low" in row for row in counted), "eligible": sum(row["eligible"] for row in counted)},
                   "groups": groups, "stage_execution": records, "wall_seconds": time.perf_counter() - started,
                   "scope": "Mechanical data only. Per-request three-pair timers exclude reason/helper counters. Totals include all recorded requests (nested depths, if any, are explicit). Count-gate comparison counts are not instrumented or asserted. This is not full-window CPU acceptance."}
        write(output / "summary.json", summary)
        write(output / "status.json", {"state": "complete", "ok": True, "summary": str(output / "summary.json"), "wall_seconds": summary["wall_seconds"]})
        print(json.dumps({"state": "complete", "ok": True, "summary": str(output / "summary.json"), "requests": len(timed)}), flush=True)
    except BaseException as error:
        write(output / "failure-exception.json", {"traceback": traceback.format_exc()})
        if not log_path.exists():
            log_path.write_text(traceback.format_exc(), encoding="utf-8")
        failure = {"state": "failed", "ok": False, "stage": stage, "command": command, "log": str(log_path), "error_type": type(error).__name__, "error": str(error), "completed_stages": records, "wall_seconds": time.perf_counter() - started, "retry": False}
        write(output / "status.json", failure)
        print(json.dumps(failure, ensure_ascii=False), flush=True)
        raise


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--base-project", type=Path, default=BASE)
    parser.add_argument("--input", type=Path, default=INPUT)
    parser.add_argument("--reference-commit", default=COMMIT)
    parser.add_argument("--candidate-source", type=Path, default=ROOT / "game/building/route_clearance.gd")
    parser.add_argument("--stage-timeout", type=int, default=120)
    run(parser.parse_args())
