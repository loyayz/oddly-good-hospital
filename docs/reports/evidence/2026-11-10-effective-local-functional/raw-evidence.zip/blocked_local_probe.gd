extends SceneTree
func _initialize() -> void: call_deferred("_run")
func _run() -> void:
	var args: PackedStringArray=OS.get_cmdline_user_args()
	var content:=HospitalContent.new()
	var suite: RefCounted=load("res://tests/acceptance/space.gd").new();suite.content=content
	var sim: HospitalSimulation=suite._fixture()
	for item: Array in [["upper",[38,69]],["lower",[38,71]],["back",[37,70]]]:
		HospitalFactory._add_facility(sim.world,{"id":item[0],"definition_id":"FUR05","anchor":item[1],"size":[2,1],"room_id":null},content)
	sim.world.touch()
	suite._add_actor(sim,"a","S49",[39.4,70])
	suite._add_actor(sim,"b","S49",[40,70])
	var initial_validation: String=sim.world.validate(content)
	var requests: Array=[sim.space.request_move(sim.world,"a",1,[43,70]),sim.space.request_move(sim.world,"b",1,[39,70])]
	var input: Dictionary=sim.world.freeze()
	var probe: RefCounted=load("res://tests/acceptance/movement_detour.gd").new()
	var errors: Array=[]
	var trace: Array=[]
	for tick: int in 300:
		var error: String=probe._tick(suite,sim,["a","b"])
		if not error.is_empty():errors.append(error);break
		if tick<12 or tick%20==0:trace.append({"tick":tick,"a":sim.world.facts.actors.a.location.cell.duplicate(),"b":sim.world.facts.actors.b.location.cell.duplicate(),"a_move":sim.world.facts.moves.get("a",{}).duplicate(true),"b_move":sim.world.facts.moves.get("b",{}).duplicate(true)})
		if sim.world.facts.moves.is_empty():break
	var arrived: bool=sim.space.at(sim.world,"a",1,[43,70]) and sim.space.at(sim.world,"b",1,[39,70]) and sim.world.facts.moves.is_empty()
	var result: Dictionary={"ok":arrived and errors.is_empty() and initial_validation.is_empty() and requests==["",""],"arrived":arrived,"errors":errors,"requests":requests,"initial_validation":initial_validation,"input":input,"trace":trace,"final":sim.world.freeze()}
	FileAccess.open(args[0],FileAccess.WRITE).store_string(JSON.stringify(result,"\t"))
	print("BLOCKED_LOCAL ",JSON.stringify({"arrived":arrived,"errors":errors,"validation":initial_validation,"requests":requests}))
	sim.dispose();quit(0 if result.ok else 1)
