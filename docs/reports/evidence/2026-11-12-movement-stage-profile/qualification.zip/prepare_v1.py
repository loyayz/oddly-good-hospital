"""Narrow reversible observer v1; no engine execution."""
from pathlib import Path
import json,hashlib,re,shutil,runpy
BASE=Path(__file__).resolve().parent
OLD=BASE.parent/'root-stage-recovery-20261112'
REL='game/building/hospital_movement.gd'
DRIVER='tools/performance/current/plain_v4.gd'
TIMER='tools/performance/current/movement_stage_timer.gd'
NAMES=['_active_route_clear','_replan_goal','_local_resume','_continue_detour','_local_collision','_convoy_turn_contact','_move_step']
PREFIX='_narrow_original_'
MARK='# narrow-observer-v1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def transform(original,split):
    source=original;headers=[];wrappers=[]
    for name in NAMES:
        hits=list(re.finditer(r'^func '+re.escape(name)+r'\((.*)\) -> ([^:\n]+):$',source,re.M));assert len(hits)==1
        m=hits[0];header=m[0];renamed=header.replace('func '+name,'func '+PREFIX+name,1);source=source[:m.start()]+renamed+source[m.end():];headers.append((header,renamed))
        args=[a.split(':',1)[0].strip() for a in split(m[1])];result=m[2]
        w=header+'\n\tvar traced: bool=_NarrowTimer.enter("'+name+'")\n'
        w+='\t'+('var value: '+result+'=' if result!='void' else '')+PREFIX+name+'('+','.join(args)+')\n'
        w+='\tif traced:_NarrowTimer.leave("'+name+'")\n'
        if result!='void':w+='\treturn value\n'
        wrappers.append(w)
    def insert(anchor,lines):
        nonlocal source
        start=source.index("func advance(");end=source.index("\nfunc ",start+1)
        body=source[start:end];assert body.count(anchor)==1,anchor
        source=source[:start]+body.replace(anchor,lines+anchor,1)+source[end:]
    insert('\t# Read-only facility projections can temporarily replace the geometry\n','\t_NarrowTimer.begin_advance() '+MARK+'\n\t_NarrowTimer.mark("setup.projection") '+MARK+'\n')
    for anchor,name in [('\tHospitalTransit.advance(space,world)\n','transit.advance'),('\t_dispatch_routes(world,world.present_actor_count() if present_at_start<0 else present_at_start)\n','route.dispatch'),('\tfor id: String in _route_checks.keys():\n','route.cleanup'),('\tvar floor_versions: Dictionary = {}\n','actor.loop'),('\tHospitalTransit.cancel_absent_waiters(space,world)\n','boundary.cleanup')]:insert(anchor,'\t_NarrowTimer.mark("'+name+'") '+MARK+'\n')
    anchor='\t_movement_reservations = {}\n';assert source.count(anchor)==1;source=source.replace(anchor,anchor+'\t_NarrowTimer.end_advance() '+MARK+'\n')
    source=source.replace('extends RefCounted\n','extends RefCounted\nconst _NarrowTimer=preload("res://'+TIMER+'") '+MARK+'\n',1)
    source+='\n# narrow-wrappers-v1\n'+'\n'.join(wrappers)
    undo=source.split('\n# narrow-wrappers-v1\n')[0];undo=''.join(l for l in undo.splitlines(True) if MARK not in l)
    for header,renamed in headers:undo=undo.replace(renamed,header,1)
    assert undo==original
    return source

def driver_transform(original):
    s=original.replace('extends SceneTree\n','extends SceneTree\nconst _NarrowTimer=preload("res://'+TIMER+'") '+MARK+'\n',1)
    a='\t\tvar started: int = Time.get_ticks_usec()\n';assert s.count(a)==1;s=s.replace(a,'\t\tif index>=prefix_steps:_NarrowTimer.start_step() '+MARK+'\n'+a)
    a='\t\tvar elapsed: int = Time.get_ticks_usec()-started\n';assert s.count(a)==1;s=s.replace(a,a+'\t\tif index>=prefix_steps:_NarrowTimer.end_step(world.sim_tick,elapsed) '+MARK+'\n')
    a='\tvar window_end: int = Time.get_ticks_usec()\n';assert s.count(a)==1;s=s.replace(a,a+'\twrite_json(output+".movement-stages.json",_NarrowTimer.report()) '+MARK+'\n')
    assert ''.join(l for l in s.splitlines(True) if MARK not in l)==original
    return s

def main():
    cfg=json.loads((OLD/'config.json').read_text());src=Path(cfg['project']);project=BASE/'project'
    if not project.exists():shutil.copytree(src,project,ignore=shutil.ignore_patterns('.cache'))
    else:
        for rel in [REL,DRIVER]:assert (project/rel).read_bytes()==(src/rel).read_bytes(), 'existing project is not pristine'
    split=runpy.run_path(str(src/'tools/performance/instrument_all_instances.py'))['split_arguments']
    changes={}
    for rel,fn in [(REL,lambda s:transform(s,split)),(DRIVER,driver_transform)]:
        p=project/rel;original=p.read_bytes();assert b'\r' not in original
        (BASE/(p.name+'.original')).write_bytes(original);p.write_bytes(fn(original.decode()).encode());changes[rel]={'original_sha256':hashlib.sha256(original).hexdigest(),'observer_sha256':sha(p),'undo_exact':True}
    shutil.copy2(BASE/'movement_stage_timer.gd',project/TIMER)
    shutil.copy2(OLD/'mixed160.input.bin',BASE/'mixed160.input.bin');shutil.copy2(OLD/'linux_guard_v2.py',BASE/'linux_guard_v2.py')
    (BASE/'source-transform.json').write_text(json.dumps({'changes':changes,'timer_sha256':sha(project/TIMER),'methods':NAMES,'static_transit_calls_unchanged':True},indent=2))
    print('Prepared isolated observer; exact reverse-transform assertions passed')
if __name__=='__main__':main()
