"""Narrow movement qualification v1, only 0+2 pair; no full-window entry."""
from pathlib import Path
import os,sys,json,shutil,platform,zipfile,traceback
BASE=Path(__file__).resolve().parent;OLD=BASE.parent/'root-stage-recovery-20261112'
sys.path.insert(0,str(OLD));import controller_v2 as checks
sys.path.insert(0,str(BASE));import linux_guard_v2 as guard
import prepare_v1 as prep
sha=checks.sha;write=checks.write;read=checks.read
PHASES={'setup.projection','transit.advance','route.dispatch','route.cleanup','actor.loop','boundary.cleanup'}
def host():
    data={'kernel':platform.uname()._asdict(),'logical_cpu_count':os.cpu_count()}
    try:data['affinity']=sorted(os.sched_getaffinity(0))
    except Exception as e:data['affinity']='unavailable: '+str(e)
    for name in ['/proc/cpuinfo','/proc/loadavg','/proc/meminfo','/proc/self/cgroup','/sys/fs/cgroup/cpu.max','/sys/fs/cgroup/cpu.stat','/sys/fs/cgroup/cpuset.cpus.effective','/sys/fs/cgroup/memory.max','/sys/fs/cgroup/memory.current']:
        try:data[name]=Path(name).read_text()
        except OSError as e:data[name]='unavailable: '+str(e)
    return data

def validate_narrow(folder):
    data=read(folder/'result.json.movement-stages.json');assert not data['errors']
    rows=[json.loads(x)['sample'] for x in (folder/'result.json.steps.ndjson').read_text().splitlines() if json.loads(x)['kind']=='complete']
    rec=data['records'];assert len(rec)==len(rows)==2
    for r,row in zip(rec,rows):
        assert r['tick']==row['tick'] and r['outer_elapsed_us']==row['elapsed_us']
        assert r['advance_count']==1 and set(r['phases'])==PHASES
        assert sum(r['phases'].values())==r['phase_sum_us']
        assert r['outer_elapsed_us']==r['phase_sum_us']+r['handler_us']+r['outside_spans_and_gaps_us']
        covered={p:0 for p in PHASES}
        for key,v in r['calls'].items():
            assert v['method'] in prep.NAMES and v['phase'] in PHASES
            assert key==v['phase']+':'+v['method']
            assert 0<=v['exclusive_us']<=v['inclusive_us'] and v['calls']>0
            covered[v['phase']]+=v['exclusive_us']
        for p in PHASES:assert r['uncovered_by_selected_calls_us'][p]==r['phases'][p]-covered[p]>=0
    return {'records':len(rec),'scope_and_partition_checks':True,'observed_methods':sorted({v['method'] for r in rec for v in r['calls'].values()}),'not_proven':'Unexercised methods/branches are not qualified for business correctness by this short window.'}

def checkpoint():
    paths=[p for p in BASE.rglob('*') if p.is_file() and p.relative_to(BASE).parts[0] not in ['project','plain-project'] and p.suffix!='.zip' and p.name not in ['members.json','checkpoint.json']]
    members={str(p.relative_to(BASE)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in paths};write(BASE/'members.json',members)
    with zipfile.ZipFile(BASE/'qualification.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
        for p in paths:z.write(p,str(p.relative_to(BASE)))
        z.write(BASE/'members.json','MEMBERS.json')
    import hashlib
    with zipfile.ZipFile(BASE/'qualification.zip') as z:
        assert z.testzip() is None
        for n,v in members.items():assert hashlib.sha256(z.read(n)).hexdigest()==v['sha256']
    write(BASE/'checkpoint.json',{'archive_sha256':sha(BASE/'qualification.zip'),'bytes':(BASE/'qualification.zip').stat().st_size,'members':len(members),'local_readback_verified':True,'durable_verified':False})

def main():
    cfg=read(OLD/'config.json');checks.verify(cfg);checks.idle()
    plain=BASE/'plain-project';shutil.copytree(Path(cfg['project']),plain,ignore=shutil.ignore_patterns('.cache'))
    observed=BASE/'project';before={str(p):sha(p) for p in [BASE/'prepare_v1.py',BASE/'qualify_v1.py',BASE/'movement_stage_timer.gd',BASE/'linux_guard_v2.py']}
    inventories={n:checks.inventory(p) for n,p in [('plain',plain),('narrow',observed)]}
    write(BASE/'identity.json',{'tool_sha256':before,'runtime_config':cfg,'project_inventories':inventories,'input_sha256':sha(BASE/'mixed160.input.bin'),'baseline_durable_receipt':read(OLD/'full-plain.durable-receipt.json'),'runtime_caveat':'Current host snapshots cannot reconstruct lost prior executor conditions.'})
    for rel in [prep.REL,prep.DRIVER]:shutil.copy2(observed/rel,BASE/(Path(rel).name+'.observer'))
    guard.LIBRARY_PATH=cfg['library_path']
    try:
        for name,project in [('plain',plain),('narrow',observed)]:
            checks.idle();checks.verify(cfg);assert checks.inventory(project)==inventories[name]
            guard.PROJECT=project;folder=BASE/name;write(BASE/(name+'.host-before.json'),host())
            cmd=[cfg['engine'],'--headless','--path',str(project),'--script','res://'+prep.DRIVER,'--','--input='+str(BASE/'mixed160.input.bin'),'--output='+str(folder/'result.json'),'--prefix-steps=0','--steps=2','--observed-floor=1','--worker-tasks=4','--main-thread-policy=app','--expected-scenario=mixed160-clinical-ops-v1']
            try:guard.run(cmd,folder,timeout=180,allowed_exits=(0,1))
            finally:write(BASE/(name+'.host-after.json'),host())
            assert checks.inventory(project)==inventories[name];checks.result_checks(folder,2,False)
        assert read(BASE/'plain/result.json')['complete'] and read(BASE/'narrow/result.json')['complete']
        write(BASE/'narrow-checks.json',validate_narrow(BASE/'narrow'));write(BASE/'comparison.json',checks.pair(BASE/'plain',BASE/'narrow'))
    except BaseException:
        write(BASE/'error.json',{'error':traceback.format_exc()});raise
    finally:
        for rel in [prep.REL,prep.DRIVER]:(observed/rel).write_bytes((BASE/(Path(rel).name+'.original')).read_bytes())
        assert all((observed/rel).read_bytes()==(plain/rel).read_bytes() for rel in [prep.REL,prep.DRIVER])
        checks.verify(cfg);write(BASE/'restoration.json',{'production_method_and_driver_bytes_restored':True,'archived_root_project_unchanged':True,'timer_file_dormant':True})
        checkpoint()
if __name__=='__main__':main()
