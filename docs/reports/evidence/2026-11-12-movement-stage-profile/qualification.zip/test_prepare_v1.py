import ast,runpy,hashlib,unittest
from pathlib import Path
import prepare_v1 as p
class Tests(unittest.TestCase):
 def test_actual_reverse_and_static_calls(self):
  split=runpy.run_path(str(p.OLD/'project/tools/performance/instrument_all_instances.py'))['split_arguments']
  original=(p.BASE/'hospital_movement.gd.original').read_text();result=p.transform(original,split)
  self.assertEqual(result,(p.BASE/'hospital_movement.gd.observer').read_text() if (p.BASE/'hospital_movement.gd.observer').exists() else (p.BASE/'project'/p.REL).read_text())
  for line in original.splitlines():
   if 'HospitalTransit.' in line:self.assertIn(line,result.splitlines())
  with self.assertRaises(AssertionError):p.transform(original.replace('func _move_step(', 'func _missing_move_step('),split)
 def test_driver_undo(self):
  original=(p.BASE/'plain_v4.gd.original').read_text();p.driver_transform(original)
  with self.assertRaises(AssertionError):p.driver_transform(original.replace('var elapsed: int = Time.get_ticks_usec()-started','var elapsed: int = 1'))
 def test_identity_and_syntax(self):
  for f in p.BASE.glob('*.py'):ast.parse(f.read_text())
  self.assertEqual(p.sha(p.BASE/'mixed160.input.bin'),'75f5e1d922f39f12382c0ceb74806bda0293251189f68a1ac158842f65fa78ca')
if __name__=='__main__':unittest.main()
