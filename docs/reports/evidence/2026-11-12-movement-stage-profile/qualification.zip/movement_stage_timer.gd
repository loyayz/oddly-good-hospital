extends RefCounted
# Diagnostic main-thread elapsed spans; dispatch/timer overhead is not fully removed.
static var enabled: bool=false
static var active: bool=false
static var owner: int=0
static var phase: String=""
static var phase_started: int=0
static var phase_observer: int=0
static var observer: int=0
static var stack: Array=[]
static var phases: Dictionary={}
static var calls: Dictionary={}
static var errors: Array=[]
static var records: Array=[]
static var advance_count: int=0
static func start_step() -> void:
	if active or not stack.is_empty(): errors.append("unclosed advance at step start")
	enabled=true;active=false;owner=OS.get_thread_caller_id();observer=0;stack=[];phases={};calls={};phase="";advance_count=0
static func begin_advance() -> void:
	if not enabled or OS.get_thread_caller_id()!=owner: return
	var t: int=Time.get_ticks_usec()
	if active: errors.append("nested advance");return
	active=true;advance_count+=1
	observer+=Time.get_ticks_usec()-t
static func _close(now: int) -> void:
	if phase.is_empty(): return
	phases[phase]=int(phases.get(phase,0))+now-phase_started-(observer-phase_observer)
static func mark(name: String) -> void:
	if not active or OS.get_thread_caller_id()!=owner:return
	var t: int=Time.get_ticks_usec()
	if not stack.is_empty():errors.append("phase changed inside selected call")
	_close(t);phase=name
	var end: int=Time.get_ticks_usec();observer+=end-t;phase_started=end;phase_observer=observer
static func end_advance() -> void:
	if not active or OS.get_thread_caller_id()!=owner:return
	var t: int=Time.get_ticks_usec()
	_close(t)
	if not stack.is_empty(): errors.append("unclosed method in advance")
	active=false;phase="";observer+=Time.get_ticks_usec()-t
static func enter(name: String) -> bool:
	if not active or OS.get_thread_caller_id()!=owner:return false
	var t: int=Time.get_ticks_usec()
	var frame: Dictionary={"name":name,"phase":phase,"children":0,"started":0,"observer":0}
	stack.append(frame)
	var end: int=Time.get_ticks_usec();observer+=end-t;frame.started=end;frame.observer=observer
	return true
static func leave(name: String) -> void:
	var t: int=Time.get_ticks_usec()
	if not active or stack.is_empty() or stack.back().name!=name:errors.append("method stack mismatch");return
	var frame: Dictionary=stack.pop_back()
	if frame.phase!=phase:errors.append("method crossed phase")
	var elapsed: int=t-int(frame.started)-(observer-int(frame.observer))
	var key: String=frame.phase+":"+name
	var row: Dictionary=calls.get(key,{"phase":frame.phase,"method":name,"calls":0,"inclusive_us":0,"exclusive_us":0,"max_us":0})
	row.calls+=1;row.inclusive_us+=elapsed;row.exclusive_us+=elapsed-int(frame.children);row.max_us=maxi(row.max_us,elapsed);calls[key]=row
	if not stack.is_empty():stack.back().children+=elapsed
	observer+=Time.get_ticks_usec()-t
static func end_step(tick: int, elapsed: int) -> void:
	if active or not stack.is_empty():errors.append("unclosed advance at step end")
	enabled=false
	var total: int=0
	var uncovered: Dictionary={}
	for key: String in phases:
		total+=int(phases[key]);uncovered[key]=int(phases[key])
	for row: Dictionary in calls.values():uncovered[row.phase]-=int(row.exclusive_us)
	for key: String in uncovered:
		if int(uncovered[key])<0:errors.append("negative uncovered "+key)
	records.append({"tick":tick,"outer_elapsed_us":elapsed,"advance_count":advance_count,"phases":phases.duplicate(true),"calls":calls.duplicate(true),"phase_sum_us":total,"handler_us":observer,"outside_spans_and_gaps_us":elapsed-total-observer,"uncovered_by_selected_calls_us":uncovered})
static func report() -> Dictionary:
	return {"records":records,"errors":errors,"scope":"Six disjoint advance spans. Seven selected methods are counted only inside advance and bucketed by entry phase. Method inclusive/exclusive is a separate layer, never additive to spans. Handler bodies removed from spans/method elapsed; dispatch and timer-read overhead not fully removed. Outside spans includes all other simulation phases and gaps."}
