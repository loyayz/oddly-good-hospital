extends SceneTree
func _initialize()->void:call_deferred("_run")
func _run()->void:
 var c:HospitalContent=HospitalContent.new();var helper:RefCounted=preload("res://tests/acceptance/waiting_query_batches.gd").new();helper._content=c
 var rows:Array=[]
 for kind:String in ["wall","bucket_float_boundary"]:
  var x:Dictionary=helper._input(kind);var w:WorldState=x.world;var before:Dictionary=w.freeze();var actor:Dictionary=w.facts.actors.z_neighbor
  var point:=Vector2i(roundi(actor.location.cell[0]),roundi(actor.location.cell[1]))
  rows.append({"kind":kind,"raw_cell":actor.location.cell,"queried_point":point,"room_public_point":x.space.room_use.public_point(w,1,point),"public_areas_public_point":x.space.public_areas.public_point(w,1,point),"room_id":x.space.room_use.room_at(w,1,point),"current_area":x.space.public_areas.current_area(w,actor.id),"moving":w.facts.moves.has(actor.id),"readonly":before==w.freeze(),"validation":w.validate(c)})
 var args:PackedStringArray=OS.get_cmdline_user_args();FileAccess.open(args[0],FileAccess.WRITE).store_string(JSON.stringify({"rows":rows},"\t"));quit(0)
