from pathlib import Path
import json,hashlib,zipfile,subprocess
root=Path('/workspace/scratch/6962cc21ddf3');r=root/'oddly-good-hospital-cloud-recovery-20261112';b=root/'upgrade-handoff-20261112';out=b/'continuation01';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
result=json.loads((out/'result.json').read_text());process=json.loads((out/'engine/process.json').read_text());facts=[json.loads(s) for s in (out/'phase-facts.ndjson').read_text().splitlines()];events=[json.loads(s) for s in (out/'ordered-events.ndjson').read_text().splitlines()]
assert len(facts)==3588 and [x['tick'] for x in facts]==list(range(4046,7634));assert len(events)==3587 and [x['tick'] for x in events]==list(range(4047,7634));assert process['reaped'] and process['returncode']==1
assert json.loads((out/'commands.json').read_text())==[]
uid=json.loads((b/'uid-before.json').read_text());now={str(p.relative_to(r)):sha(p) for p in r.rglob('*.uid')};assert uid==now
summary={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'production_sha256':sha(r/'game/clinic/clinical_runtime.gd'),'test_sha256':sha(r/'tests/acceptance/run_upgrade_continuation.gd'),'parent_runner_sha256':sha(r/'tests/acceptance/run_upgrade_handoff.gd'),'start_input_sha256':sha(b/'observe8-01/cold-final.bin'),'restored_start_sha256':sha(out/'start.bin'),'final_sha256':sha(out/'final.bin'),'fact_rows':len(facts),'ordered_tick_event_rows':len(events),'no_commands':True,'uid_count':len(uid),'uids_unchanged':True,'result':result,'process_wall_seconds':process['wall_seconds'],'stage2_archive_sha256':sha(b/'stage2-observation.zip')}
(b/'continuation-summary.json').write_text(json.dumps(summary,indent=2))
p=r/'docs/reports/2026-11-12-upgrade-handoff.md';p.write_text(p.read_text()+'''\n## 原预算剩余3587步续接结果：升级仍未完成\n- 经stage2远端175项CRC/SHA读回后，按授权从4046完整事实冷恢复；所有World/RNG精确等于输入，原upgrade225/420材料账目/30000余量原样。新独立runner不改已发布父runner或生产，commands.json为空，未重复提交任何命令。\n- 正式全World .1s步进3587次，严格止于7633；133.589145秒功能进程，exit1，reaped，无timeout。保存3588帧逐步worker/request/local/ticket/lift/order直接事实、3587组按tick有序事件、完整起终World以及初始命令/账目依据。不是额外性能窗或原热史连续运行。\n- 终态仍travelling：226在1F[86.3999939,44]，目标2F[73,71]；remaining30000、started=false、工时0、等级0、无完成凭据。材料只原支付420，没有重复付款。原coverage要求≥1ms也未达到，真正升级完成、新病例读等级均不能声称通过。\n- 没有实际开工，部分施工保存恢复没有触发，明确未完成而非通过；actual_attendance_for_work的布尔未失败仅因无工作，不能视为已证明开工到场。未提前升等级、支付不重复、终态合法、原tick上限均通过。没有在运行中改源码、减负载、换目标或强清交通。\n- 完整末态已存，执行已停止、engine空闲，先封不可覆盖阶段3并等待持久备份，不追加重跑/长窗。后续仅按明确诊断证据决定下一步，不能把未到场自动归为死锁。\n''')
stage=b/'stage3-source'
for rel in ['tests/acceptance/run_upgrade_continuation.gd','tests/acceptance/run_upgrade_handoff.gd','game/clinic/clinical_runtime.gd','docs/reports/2026-11-12-upgrade-handoff.md']:
 q=stage/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes((r/rel).read_bytes())
(stage/'run_continuation.py').write_bytes((b/'run_continuation.py').read_bytes());(stage/'lifecycle_guard.py').write_bytes((root/'root-stage-recovery-20261112/linux_guard_v2.py').read_bytes());(stage/'package.py').write_bytes(Path('/tmp/package_upgrade_continuation.py').read_bytes())
subprocess.run(['git','diff','--check'],cwd=r,check=True)
allowed={'node_sha256','cpu_count','affinity','/proc/meminfo','/proc/stat','/sys/fs/cgroup/cpu.max','/sys/fs/cgroup/cpu.stat','/sys/fs/cgroup/memory.max','/sys/fs/cgroup/memory.current'}
for d in [out,b/'continue-parse01']:
 for p in d.glob('host-*.json'):assert set(json.loads(p.read_text()))==allowed
files=[p for d in [out,b/'continue-parse01',stage] for p in d.rglob('*') if p.is_file()]+[b/'continuation-summary.json',b/'stage2.durable-receipt.json',b/'uid-before.json']
members=[{'path':str(p.relative_to(b)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(files)];(b/'stage3-members.json').write_text(json.dumps(members,indent=2));files.append(b/'stage3-members.json')
with zipfile.ZipFile(b/'stage3-continuation.zip','x',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,p.relative_to(b))
with zipfile.ZipFile(b/'stage3-continuation.zip') as z:
 assert z.testzip() is None
 for m in members:assert hashlib.sha256(z.read(m['path'])).hexdigest()==m['sha256']
print(json.dumps({'archive_bytes':(b/'stage3-continuation.zip').stat().st_size,'archive_sha256':sha(b/'stage3-continuation.zip'),'members':len(files),'test_sha256':summary['test_sha256'],'final_sha256':summary['final_sha256'],'uid_count':len(uid)},indent=2))
