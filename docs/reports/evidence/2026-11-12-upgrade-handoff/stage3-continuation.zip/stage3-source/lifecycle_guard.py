"""Recovery v2: published guard, configurable library path and recorded exit 1 support."""
import os,sys,json,hashlib,subprocess,time,signal,datetime
from pathlib import Path
PROJECT=None
LIBRARY_PATH=None
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2))
def run(command,directory,timeout=180,expect_timeout=False, allowed_exits=(0,)):
 directory.mkdir(exist_ok=False)
 env=dict(os.environ,OMP_NUM_THREADS='1',PYTHONUTF8='1',LD_LIBRARY_PATH=LIBRARY_PATH)
 for key,name in [('HOME','home'),('XDG_DATA_HOME','data'),('XDG_CONFIG_HOME','config'),('XDG_CACHE_HOME','cache'),('TMPDIR','tmp')]:
  p=directory/name;p.mkdir();env[key]=str(p)
 record={'command':command,'cwd':str(PROJECT),'environment':{k:env[k] for k in ['HOME','XDG_DATA_HOME','XDG_CONFIG_HOME','XDG_CACHE_HOME','TMPDIR','OMP_NUM_THREADS','LD_LIBRARY_PATH']},'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'guard_sha256':sha(Path(__file__))}
 started=time.monotonic();timedout=False
 with (directory/'engine.log').open('wb') as log:
  p=subprocess.Popen(command,cwd=PROJECT,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);record['owned_pid']=p.pid;write(directory/'process.json',record)
  try:
   while p.poll() is None:
    time.sleep(.1)
    raw=(directory/'engine.log').read_bytes()
    if b'SCRIPT ERROR:' in raw or b'\nERROR:' in b'\n'+raw:raise RuntimeError('engine errors; inspect preserved log')
    if time.monotonic()-started>timeout:timedout=True;raise TimeoutError('owned process timeout')
  except TimeoutError:
   if not expect_timeout:raise
  finally:
   if p.poll() is None:
    os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=5)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
   record.update(returncode=p.returncode,timed_out=timedout,reaped=p.poll() is not None,wall_seconds=time.monotonic()-started,log_sha256=sha(directory/'engine.log'));write(directory/'process.json',record)
 assert record['reaped'] and (timedout if expect_timeout else p.returncode in allowed_exits)
 return record
