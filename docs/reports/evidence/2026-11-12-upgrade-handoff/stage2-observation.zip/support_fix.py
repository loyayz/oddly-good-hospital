from pathlib import Path
r=Path('oddly-good-hospital-cloud-recovery-20261112');b=Path('upgrade-handoff-20261112');p=r/'game/clinic/clinical_runtime.gd';s=p.read_text();(b/'clinical_runtime.before.gd').write_bytes(p.read_bytes())
old='''\t\tworld.facts.actors[visit.actor_id].posture = "standing"
\t\tspace.sync_actor(world,visit.actor_id)''';new='''\t\tworld.facts.actors[visit.actor_id].posture = "standing"
\t\tworld.facts.actors[visit.actor_id].erase("support_facility_id")
\t\tspace.sync_actor(world,visit.actor_id)''';assert s.count(old)==1;s=s.replace(old,new)
mark='func dispatch(world: WorldState) -> void:'
helper='''# Compatibility for completed historical outpatient seating. Reconcile only
# a proved clinical owner during normal dispatch, never a generic actor sweep.
func _release_completed_seated_support(world: WorldState, visit: Dictionary) -> void:
	var actor: Dictionary = world.facts.actors[visit.actor_id]
	var support_id: String = str(actor.get("support_facility_id",""))
	if support_id.is_empty() or not world.facts.facilities.has(support_id): return
	if actor.get("posture","standing")!="standing" or actor.location.kind!="floor" or float(actor.location.get("height_m",0.0))!=0.0: return
	var receipt: Dictionary = visit.get("result_receipt",{})
	var attempt_id: String = str(receipt.get("attempt_id",""))
	var attempt: Dictionary = world.facts.attempts.get(attempt_id,{})
	if attempt.is_empty() or not attempt_id in visit.get("attempt_ids",[]) or attempt.get("visit_id","")!=visit.id or attempt.get("facility_id","")!=support_id: return
	if content.definition("treatment_protocols",str(attempt.get("protocol_id",""))).get("kind","")!="outpatient": return
	for session: Dictionary in world.facts.sessions.values():
		if session.get("visit_id","")==visit.id or actor.id in session.get("resources",[]): return
	for stay: Dictionary in world.facts.ward_stays.values():
		if stay.get("visit_id","")==visit.id: return
	if world.facts.preparations.has(visit.id) or world.facts.get("waiting_life",{}).get("needs",{}).has(visit.id) or world.facts.get("waiting_life",{}).get("seats",{}).has(visit.id): return
	var movement: Dictionary = world.facts.moves.get(actor.id,{})
	var cursor: int = int(movement.get("cursor",-1))
	var path: Array = movement.get("path",[])
	if cursor>=0 and cursor<path.size() and path[cursor].kind=="support_exit": return
	var reservation: Dictionary = world.facts.adaptations.get(support_id,{})
	if reservation.get("actor_id","")==actor.id or actor.id in reservation.get("staff_ids",[]): return
	var layout: Dictionary = space.facility_layout(world,support_id)
	if int(actor.location.floor_id)==int(layout.floor_id):
		var body: Rect2 = space.body_rectangle(actor)
		var regions: Array = reservation.get("regions",[]).duplicate()
		regions.append([layout.cell[0],layout.cell[1],layout.footprint[0],layout.footprint[1]])
		for cell: Array in [layout.patient_cell,layout.repair_cell]+layout.operator_cells: regions.append([cell[0],cell[1],1,1])
		for region: Array in regions:
			if body.intersects(Rect2(float(region[0]),float(region[1]),float(region[2]),float(region[3])),false): return
	actor.erase("support_facility_id")
	space.sync_actor(world,actor.id)

'''
assert mark in s;s=s.replace(mark,helper+mark)
needle='''\tfor visit_id: String in world.active_visit_ids():
\t\tvar visit: Dictionary = world.facts.visits[visit_id]''';assert s.count(needle)==1;s=s.replace(needle,needle+'\n\t\t_release_completed_seated_support(world,visit)');p.write_bytes(s.encode())
p=r/'docs/reports/2026-11-12-upgrade-handoff.md';p.write_text(p.read_text()+'''\n## 承托生命周期最小修复（执行前增补）\n- 已独立审查：_settle的seated→standing原转换应清support引用，按现有suspend_outpatient同样同步；不释放adaptation、不改身体位置、不放宽build._unused。\n- 历史兼容落在正式clinical dispatch既有active_visit循环，不读档全actor猜测改事实。要求已结算result_receipt与原visit/Attempt/同设备/outpatient协议关联；standing+floor+height0；无活跃session/住院/preparation/生活need/seat/本actor设备预约/current support_exit；完整body离开设备与patient/operator/repair岗位和现有预约区域。只清该引用并sync，条件不足保留，幂等。\n- 补实际完整负载座式结算场景：真实成功/可观察失败分支，刚起身原预约/身体仍阻止改建，实际离位才解除；旧before恢复后正式协调清85引用，真实seated/lying/当前support_exit（输入若有）拒绝且其它事实不变。不重写Attempt结果以造失败。\n- 原升级用例改为观察暂停与同Attempt真实接续，允许同型替代设备完成；只在暂停期间余量冻结，实际工作才减少。升级原目标不变。\n''')
