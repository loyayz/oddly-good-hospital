from pathlib import Path
p=Path('oddly-good-hospital-cloud-recovery-20261112/tests/acceptance/run_upgrade_handoff.gd');s=p.read_text();Path('upgrade-handoff-20261112/runner-settle01.gd').write_bytes(p.read_bytes())
s=s.replace('var trace: Array=[]','var trace: Array=[]\nvar watched_session: String=""\nvar watched_attempt: String=""')
start='''func _promise_equal(actual: Dictionary, promised: Dictionary) -> bool:
	var expected: Dictionary=promised.duplicate(true)
	# Existing one-time staff experience settlement receipt is not a quoted
	# clinical promise; no other field or value may differ.
	if actual.has("plan_experience_awarded") and not expected.has("plan_experience_awarded"):
		if actual.plan_experience_awarded!=true:return false
		expected.plan_experience_awarded=true
	return actual==expected
func _clinical_state() -> Dictionary:
	if watched_session.is_empty():return {}
	var world: WorldState=sim.world
	var record: Dictionary=world.facts.sessions.get(watched_session,{})
	if not record.is_empty():return {"kind":"working","attempt_id":record.get("attempt_id",""),"remaining":record.remaining_ticks,"facility":record.facility_id}
	record=world.facts.clinical_suspensions.get(watched_session,{})
	if not record.is_empty():return {"kind":"paused","attempt_id":record.get("attempt_id",""),"remaining":record.remaining_ticks,"facility":record.facility_id}
	return {"kind":"finished"}
'''
s=s.replace('func _step(phase: String) -> void:',start+'func _step(phase: String) -> void:\n\tvar before: Dictionary=_clinical_state()')
s=s.replace('trace.append({"tick":sim.world.sim_tick,"phase":phase,"actors":sim.world.present_actor_count()})','''var after: Dictionary=_clinical_state()
	if not watched_session.is_empty():
		checks.paused_remaining_frozen=checks.get("paused_remaining_frozen",true) and (before.get("remaining")==after.get("remaining") if before.kind=="paused" and after.kind=="paused" else true)
		checks.original_session_identity=checks.get("original_session_identity",true) and after.get("attempt_id",watched_attempt)==watched_attempt
		if before.has("remaining") and after.has("remaining"):
			var decrease: int=int(before.remaining)-int(after.remaining)
			checks.remaining_only_real_work=checks.get("remaining_only_real_work",true) and decrease>=0 and decrease<=1 and (decrease==0 or before.kind=="working" or after.kind=="working")
	trace.append({"tick":sim.world.sim_tick,"phase":phase,"actors":sim.world.present_actor_count(),"clinical_before":before,"clinical_after":after})''')
s=s.replace('var attempt_id: String=session.attempt_id','var attempt_id: String=session.attempt_id\n\twatched_session=session.id;watched_attempt=attempt_id')
s=s.replace('world.facts.attempts[attempt_id]==promised','_promise_equal(world.facts.attempts[attempt_id],promised)').replace('world.facts.attempts[before[visit_id].attempt.id]==before[visit_id].attempt','_promise_equal(world.facts.attempts[before[visit_id].attempt.id],before[visit_id].attempt)')
method='''func _audit_settlement(source: String) -> Dictionary:
	var f:=FileAccess.open(source,FileAccess.READ);var raw: Dictionary=f.get_var(false);f.close()
	var before: Dictionary=raw.before
	var rows: Array=[]
	for id: String in ["bench_visit_0065","bench_visit_0063","bench_visit_0109"]:
		var visit: Dictionary=sim.world.facts.visits[id]
		var actor: Dictionary=sim.world.facts.actors[visit.actor_id]
		var aid: String=visit.result_receipt.attempt_id
		var a: Dictionary=sim.world.facts.attempts[aid]
		var p: Dictionary=before.attempts[aid]
		var changes: Array=[]
		for key: String in a:
			if a[key]!=p.get(key):changes.append(key)
		rows.append({"visit":id,"result":visit.final_result,"changed_attempt_fields":changes,"frozen_promise_equal":_promise_equal(a,p),"support_cleared":not actor.has("support_facility_id")})
	checks.recorded_success_retry_settlements=rows.all(func(row:Dictionary)->bool:return row.frozen_promise_equal and row.support_cleared)
	checks.still_occupied=sim.world.facts.adaptations.has(TARGET) and not sim.services.building._busy(sim.world,TARGET).is_empty()
	return {"rows":rows,"uses_saved_real_step_result":true}

'''
s=s.replace('func _run() -> void:',method+'func _run() -> void:').replace('elif args[0]=="compat":','elif args[0]=="audit_settle":result=_audit_settlement(args[3])\n\telif args[0]=="compat":')
p.write_bytes(s.encode())
