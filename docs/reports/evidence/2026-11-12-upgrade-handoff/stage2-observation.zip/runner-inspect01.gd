extends SceneTree
const TARGET: String="bench_room_2_15_0"
var content: HospitalContent
var sim: HospitalSimulation
var directory: String
var serial: int=0
var commands: Array=[]
var events: Array=[]
var checks: Dictionary={}
var trace: Array=[]
func _initialize() -> void:call_deferred("_run")
func _json(name: String,value: Variant) -> void:
	var f:=FileAccess.open(directory+"/"+name,FileAccess.WRITE);f.store_string(JSON.stringify(value,"\t"));f.close()
func _save(name: String) -> void:
	var f:=FileAccess.open(directory+"/"+name+".bin",FileAccess.WRITE);f.store_var(sim.world.freeze(),false);f.close()
func _record(kind: String,payload: Dictionary) -> Dictionary:
	serial+=1
	return {"id":"upgrade-handoff-%d"%serial,"hospital_id":sim.world.hospital_id,"expected_revision":-1,"kind":kind,"typed_payload":payload,"loading_session_id":"upgrade-handoff"}
func _batch(records: Array) -> Array:
	for record: Dictionary in records:sim.enqueue(record)
	var results: Array=sim.drain_commands()
	for i: int in records.size():commands.append({"tick":sim.world.sim_tick,"command":records[i],"result":results[i].to_record()})
	_json("commands.json",commands)
	return results
func _step(phase: String) -> void:
	var result: TickResult=sim.step()
	for event: SimEvent in result.facts:events.append(event.to_record())
	trace.append({"tick":sim.world.sim_tick,"phase":phase,"actors":sim.world.present_actor_count()})
func _restore(name: String) -> bool:
	_save(name)
	var frozen: Dictionary=sim.world.freeze()
	sim.dispose();sim=HospitalSimulation.new(WorldState.new(frozen),content)
	return sim.world.freeze()==frozen
func _inspect() -> Dictionary:
	var sessions: Array=[]
	for session: Dictionary in sim.world.facts.sessions.values():
		if session.get("facility_id","")==TARGET:sessions.append(session)
	return {"tick":sim.world.sim_tick,"validation":sim.world.validate(content),"target":sim.world.facts.facilities.get(TARGET,{}),"sessions":sessions,"adaptation":sim.world.facts.adaptations.get(TARGET,{}),"actors":sim.world.present_actor_count(),"upgrade_preview":sim.services.maintenance.upgrade_preview(sim.world,TARGET,1)}
func _run() -> void:
	var args:=OS.get_cmdline_user_args();directory=args[1];content=HospitalContent.new()
	var f:=FileAccess.open(args[2],FileAccess.READ);var raw: Dictionary=f.get_var(false);f.close()
	var facts: Dictionary=raw.get("before",raw.get("facts",raw))
	sim=HospitalSimulation.new(WorldState.new(facts),content)
	_json("input-inspection.json",_inspect())
	if args[0]=="inspect":
		_save("input");sim.dispose();quit(0);return
	checks.legal_input=sim.world.validate(content).is_empty()
	_json("result.json",{"ok":false,"checks":checks,"reason":"implementation not yet enabled"})
	sim.dispose();quit(1)
