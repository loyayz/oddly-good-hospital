from pathlib import Path
p=Path('oddly-good-hospital-cloud-recovery-20261112/tests/acceptance/run_upgrade_handoff.gd');s=p.read_text()
method='''func _observation_facts() -> Dictionary:
	var world: WorldState=sim.world
	var nearby: Array=[]
	for actor: Dictionary in world.facts.actors.values():
		var loc: Dictionary=actor.location
		if loc.kind=="floor" and int(loc.floor_id) in [1,3,4] and absf(float(loc.cell[0])-86)<8 and absf(float(loc.cell[1])-44)<8:nearby.append(actor.duplicate(true))
	var tickets: Array=[]
	for move: Dictionary in world.facts.moves.values():
		if move.get("transit_ticket",{}).get("connector_id","")=="benchmark_lift":tickets.append({"actor_id":move.actor_id,"ticket":move.transit_ticket.duplicate(true)})
	return {"tick":world.sim_tick,"worker":world.facts.actors.get("maintenance_contractor_00000226",{}).duplicate(true),"worker_move":world.facts.moves.get("maintenance_contractor_00000226",{}).duplicate(true),"lift":world.facts.connectors.benchmark_lift.duplicate(true),"patient0003":world.facts.actors.bench_patient_0003.duplicate(true),"patient0003_move":world.facts.moves.get("bench_patient_0003",{}).duplicate(true),"nearby_floor_bodies":nearby,"lift_tickets":tickets}
func _observe_eight(input_facts: Dictionary) -> void:
	var unchanged: bool=sim.world.freeze()==input_facts
	_save("cold-start")
	var rows: Array=[_observation_facts()]
	var ordered: Array=[]
	for i: int in 8:
		var result: TickResult=sim.step()
		var tick_events: Array=[]
		for event: SimEvent in result.facts:tick_events.append(event.to_record())
		ordered.append({"tick":result.sim_tick,"events":tick_events})
		rows.append(_observation_facts())
	_save("cold-final")
	_json("observations.json",rows);_json("ordered-events.json",ordered)
	_json("result.json",{"ok":unchanged and rows.size()==9,"cold_restore_identity":unchanged,"step_count":8,"tick_seconds":WorldState.TICK_SECONDS,"start_tick":rows[0].tick,"end_tick":rows[-1].tick,"scope":"cold diagnostic branch; direct fact snapshots only; no commands or extra business/navigation/safety queries"})
	sim.dispose();quit(0 if unchanged else 1)

'''
s=s.replace('func _run() -> void:',method+'func _run() -> void:').replace('\t_json("input-inspection.json",_inspect())','\tif args[0]=="observe8":\n\t\t_observe_eight(facts);return\n\t_json("input-inspection.json",_inspect())');p.write_bytes(s.encode())
