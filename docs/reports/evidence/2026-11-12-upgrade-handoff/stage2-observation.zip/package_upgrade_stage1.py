from pathlib import Path
import json,hashlib,subprocess,zipfile
root=Path('/workspace/scratch/6962cc21ddf3');r=root/'oddly-good-hospital-cloud-recovery-20261112';b=root/'upgrade-handoff-20261112';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before=json.loads((b/'uid-before.json').read_text());after={str(p.relative_to(r)):sha(p) for p in r.rglob('*.uid')};assert before==after
(b/'uid-check-stage1.json').write_text(json.dumps({'count':len(before),'all_unchanged':True,'added':[],'removed':[]},indent=2))
runs=[]
for d in sorted(b.iterdir()):
 p=d/'engine/process.json'
 if p.exists():
  v=json.loads(p.read_text());runs.append({'run':d.name,'returncode':v['returncode'],'wall_seconds':v['wall_seconds'],'reaped':v['reaped'],'guard_error':(d/'error.json').exists()})
production=r/'game/clinic/clinical_runtime.gd';test=r/'tests/acceptance/run_upgrade_handoff.gd';head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()
summary={'head':head,'production_sha256':sha(production),'runner_sha256':sha(test),'runs':runs,'uid_count':len(before),'upgrade_complete':False,'last_business_tick':4038,'next_blocker':'worker226 actual arrival; travelling, work 0 / 30000, no completion receipt','engine_slot':'free','privacy':'source allowlist host only; node hash; no mount/cgroup mapping reads'};(b/'stage1-summary.json').write_text(json.dumps(summary,indent=2))
p=r/'docs/reports/2026-11-12-upgrade-handoff.md';s=p.read_text().replace('build_service._unused','build_service._busy').replace('build._unused','build._busy')+'''\n## 生命周期修复与选择性验证阶段1\n- 当前生产仅clinical_runtime.gd：正式_settle中seated→standing清support字段；已有active_visit循环中的历史兼容按上述窄条件执行。不改任何位置、预约、账目、Attempt、步长、排序或benchmark动作。\n- 原实现settle-baseline01：完整原1633前提实际推进，1650病例0065 cured、1657病例0063 retry、1781病例0109 cured；三例起身仍残留ref。补丁settle-patched01同三例全部清ref。目标109刚起身仍实际在[72,74]，原adaptation全保留，build._busy仍以真实预约拒绝，不能立即搬机器。\n- settle两轮整体exit1中的额外失败是测试把既有一次plan_experience_awarded从缺省到true也当成冻结承诺。保留原runner/失败。settle-audit02从已存真实结果只读核验，三例唯一变化字段均为该flag且值必须true，其余Attempt键/值严格全等，ref均清、真实在位仍拒改建，exit0；没有重抽结果、修改旧事实或为测试补造失败分支。最终断言只允许缺省→true，不忽略任意flag差异。\n- compat01 exit0：0085真实leaving/cured且仍在active_visit_ids；原result_receipt→attempt183→visit85→同M09→outpatient证据来自原事实。直接兼容调用仅删该actor的ref，完整World其它事实/RNG精确不变，第二次幂等。真实seated109与lying0004全不变。原baseline实际生成的standing仍在岗位/持预约1781边界也不清。当前support_exit独立负例未造假构造，仅保持明确代码拒绝；不声称本轮实跑所有保护组合。\n- 新生成与历史兼容均已通过关键选例。失败原始前提/结果/bin保留。准备中读档仍全事实等于保存边界，不在读档初始化泛扫清引用。\n\n## 原固定目标升级02（仍未补齐）\n- 相同完整before，直接升级拒绝原子性仍PASS；正式remodel_prepare接受、准备中cold restore全等。5个真实.1s安全交接步骤后可应用，tick1638同一次drain_commands按remodel_apply最新price/refund/layout后machine_upgrade，两条都接受，创建唯一upgrade225，420只支付一次。真实dispatch已处理85历史ref，未改输入。\n- 后续2400个真实步骤至4038，原负载没有删减。原session/Attempt身份保持；暂停连续阶段remaining精确不变；若减少只能发生有实际工作session的步骤且每步至多1tick。允许同型替代设备接续；原Attempt仅允许已述一次结算flag，原领料不变。\n- 目标升级订单仍travelling，维修员226在1F[83,43.6000023]，目标2F[73,71]；remaining30000、started=false、work0、grade0、无完成凭据。未到场前零工时保护PASS，部分付费施工恢复没有触发，后续新病例读取等级也未验证。现行coverage≥1ms也未满足，不能称升级已补齐。\n- 只读inspect-worker02：request634/cursor84仍原1→2F路线；floor点[86,44]后为电梯段，无领票。local rejoin index84；travelled累计265点，末段83–84/43–45反复侧让。旧trace未记每步worker位置，累计运动不能证明最近连续进展，不能从2400上限自动断言死锁。电梯trip24 alighting，患者0003，from4/to3、remaining1。已存完整4038World，不继续盲跑，待短观察方案批准。\n- 所有进程已reaped、engine槽空闲；未stage/commit/push。本阶段只封不可覆盖备份，升级还未完成。\n\n## 阶段身份、隐私及耗时\nhost采集新wrapper只读取CPU/内存/affinity/固定配额统计；node仅SHA256；进程环境输出固定allowlist。没有导入旧host函数，没有读取/proc/mounts、/proc/self/mountinfo、/proc/self/cgroup或旧Windows host记录。旧archive仅抽取已校验的业务bin。以下时间为功能进程wall time，不作性能优化结论。\n\n'''
for v in runs:s+=f"- {v['run']}: exit {v['returncode']}, guard_error {v['guard_error']}, {v['wall_seconds']:.6f}s, reaped {v['reaped']}\n"
s+=f"\n阶段HEAD `{head}`；生产SHA256 `{sha(production)}`；最终runnerSHA256 `{sha(test)}`。全部{len(before)}个UID字节不变，无新增/移除。\n";p.write_text(s)
for rel in ['game/clinic/clinical_runtime.gd','game/building/build_service.gd','game/building/hospital_space.gd','game/building/remodel_service.gd','tests/acceptance/run_upgrade_handoff.gd','docs/reports/2026-11-12-upgrade-handoff.md']:
 q=b/'stage1-source'/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes((r/rel).read_bytes())
(b/'stage1-production.patch').write_bytes(subprocess.check_output(['git','diff','--','game/clinic/clinical_runtime.gd'],cwd=r));subprocess.run(['git','diff','--check'],cwd=r,check=True)
for name in ['support_fix.py','implement_upgrade.py','update_upgrade_tests.py','upgrade_audit.py','package_upgrade_stage1.py']:(b/name).write_bytes((Path('/tmp')/name).read_bytes())
# Host records must have only our source-approved fields.
allowed={'node_sha256','cpu_count','affinity','/proc/meminfo','/proc/stat','/sys/fs/cgroup/cpu.max','/sys/fs/cgroup/cpu.stat','/sys/fs/cgroup/memory.max','/sys/fs/cgroup/memory.current'}
for p in b.rglob('host-*.json'):assert set(json.loads(p.read_text()))==allowed,p
files=[p for p in b.rglob('*') if p.is_file() and p.name not in ['stage1.zip','stage1-members.json']];members=[{'path':str(p.relative_to(b)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(files)];(b/'stage1-members.json').write_text(json.dumps(members,indent=2));files.append(b/'stage1-members.json')
with zipfile.ZipFile(b/'stage1.zip','x',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,p.relative_to(b))
with zipfile.ZipFile(b/'stage1.zip') as z:
 assert z.testzip() is None
 for m in members:assert hashlib.sha256(z.read(m['path'])).hexdigest()==m['sha256']
print(json.dumps({'source_sha':sha(production),'test_sha':sha(test),'archive_bytes':(b/'stage1.zip').stat().st_size,'archive_sha':sha(b/'stage1.zip'),'members':len(files)},indent=2))
