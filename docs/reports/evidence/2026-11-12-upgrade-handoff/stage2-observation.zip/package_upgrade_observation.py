from pathlib import Path
import json,hashlib,zipfile,subprocess
root=Path('/workspace/scratch/6962cc21ddf3');r=root/'oddly-good-hospital-cloud-recovery-20261112';b=root/'upgrade-handoff-20261112';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(b/'stage1.zip')=='927eff463edb0325eac7a2a27c28ed7a2581389e9bc9d8ff2d802c3d4c971313'
rows=json.loads((b/'observe8-01/observations.json').read_text());steps=[]
for a,c in zip(rows,rows[1:]):
 p=a['worker']['location']['cell'];q=c['worker']['location']['cell'];steps.append(((q[0]-p[0])**2+(q[1]-p[1])**2)**.5)
old=(b/'stage1-source/tests/acceptance/run_upgrade_handoff.gd').read_text();p=r/'tests/acceptance/run_upgrade_handoff.gd';s=p.read_text();i=s.index('func _observation_facts()');j=s.index('func _run() -> void:',i);stripped=(s[:i]+s[j:]).replace('\tif args[0]=="observe8":\n\t\t_observe_eight(facts);return\n','');assert stripped==old
before=json.loads((b/'uid-before.json').read_text());after={str(p.relative_to(r)):sha(p) for p in r.rglob('*.uid')};assert before==after
summary={'worker_step_distances':steps,'moved_steps':sum(v>0 for v in steps),'total_distance':sum(steps),'lift_unchanged':all(x['lift']==rows[0]['lift'] for x in rows),'patient0003_location_unchanged':all(x['patient0003']['location']==rows[0]['patient0003']['location'] for x in rows),'only_observe_mode_added':True,'uid_count':len(before),'all_uids_unchanged':True,'stage1_sha256':sha(b/'stage1.zip'),'production_sha256':sha(r/'game/clinic/clinical_runtime.gd'),'runner_sha256':sha(r/'tests/acceptance/run_upgrade_handoff.gd'),'engine_reaped':json.loads((b/'observe8-01/engine/process.json').read_text())['reaped']};(b/'observe8-summary.json').write_text(json.dumps(summary,indent=2))
p=r/'docs/reports/2026-11-12-upgrade-handoff.md';p.write_text(p.read_text()+'''\n## 批准的8步冷恢复诊断（停止于4046）\n- 仅从完整4038终态独立冷恢复，freeze与输入全等。未重复命令、未额外调用业务/寻路/安全查询，仅正式全World .1s step与直接事实快照。保存起终完整World/RNG、每tick有序事件及9帧actor/move/tickets/lift/出口邻近身体事实。不是原连续热史或性能测量。\n- 226在8/8步均移动，累计约1.6格，从[83,43.6000023]经[83,44]到[84.1999817,44]；原request634与rejoin84保持，未取得电梯票。该短窗不是226零位移卡死，不能由2400上限自动判业务故障。\n- lift trip24保持alighting/remaining1，患者0003仍transit4→3；3F出口真实多身体，0025在[85.6000061,44.2000008]等身体8步未动。没有调用contact/safe判断，不宣称唯一阻挡或死锁根因，不据此偷偷改交通规则。\n- 观察只证明该冷分支8步事实，不证明后续电梯一定释放或升级一定完成。升级仍未补齐，未续跑至7633。\n- parser06与observe8-01均exit0，进程reaped。最终runner相对stage1仅新增两个直接观察函数与一个mode分支，逆变换后旧方法逐字相同；未改变此前升级/settle/compat逻辑。生产SHA不变，全部663 UID不变。stage1.zip未覆盖；增量完整包包含该不可变阶段备份及本次原始结果。\n''')
for rel in ['tests/acceptance/run_upgrade_handoff.gd','docs/reports/2026-11-12-upgrade-handoff.md','game/clinic/clinical_runtime.gd']:
 q=b/'observation-source'/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes((r/rel).read_bytes())
(b/'add_observe8.py').write_bytes(Path('/tmp/add_observe8.py').read_bytes());(b/'package_upgrade_observation.py').write_bytes(Path('/tmp/package_upgrade_observation.py').read_bytes())
subprocess.run(['git','diff','--check'],cwd=r,check=True)
files=[p for p in b.rglob('*') if p.is_file() and p.name not in ['stage2-observation.zip','stage2-members.json']];members=[{'path':str(p.relative_to(b)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(files)];(b/'stage2-members.json').write_text(json.dumps(members,indent=2));files.append(b/'stage2-members.json')
with zipfile.ZipFile(b/'stage2-observation.zip','x',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,p.relative_to(b))
with zipfile.ZipFile(b/'stage2-observation.zip') as z:
 assert z.testzip() is None
 for m in members:assert hashlib.sha256(z.read(m['path'])).hexdigest()==m['sha256']
print(json.dumps({'archive_bytes':(b/'stage2-observation.zip').stat().st_size,'archive_sha':sha(b/'stage2-observation.zip'),'members':len(files),'summary':summary},indent=2))
