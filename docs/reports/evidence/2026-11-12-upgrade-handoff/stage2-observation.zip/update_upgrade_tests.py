from pathlib import Path
p=Path('oddly-good-hospital-cloud-recovery-20261112/tests/acceptance/run_upgrade_handoff.gd');s=p.read_text();Path('upgrade-handoff-20261112/runner-before-support-tests.gd').write_bytes(p.read_bytes())
methods='''func _settlement() -> Dictionary:
	var world: WorldState=sim.world
	var observed: Array=[]
	for i: int in 350:
		var before: Dictionary={}
		for session: Dictionary in world.facts.sessions.values():
			if session.kind=="outpatient":
				var visit: Dictionary=world.facts.visits[session.visit_id]
				before[visit.id]={"receipt":visit.get("result_receipt",{}).duplicate(true),"support":world.facts.actors[visit.actor_id].get("support_facility_id",""),"posture":world.facts.actors[visit.actor_id].posture,"attempt":world.facts.attempts[session.attempt_id].duplicate(true)}
		_step("real_settlement")
		for visit_id: String in before:
			var visit: Dictionary=world.facts.visits[visit_id]
			if visit.get("result_receipt",{})==before[visit_id].receipt:continue
			var actor: Dictionary=world.facts.actors[visit.actor_id]
			observed.append({"visit":visit_id,"result":visit.final_result,"previous_posture":before[visit_id].posture,"posture":actor.posture,"reference_cleared":not actor.has("support_facility_id"),"attempt_unchanged":world.facts.attempts[before[visit_id].attempt.id]==before[visit_id].attempt,"tick":world.sim_tick})
			if visit_id=="bench_visit_0109":
				_save("settled-at-post")
				var blocked: String=sim.services.building._unused(world,TARGET)
				checks.actual_seated_settlement=before[visit_id].posture=="seated" and actor.posture=="standing" and not actor.has("support_facility_id")
				checks.still_physically_protected=not blocked.is_empty() and world.facts.adaptations.has(TARGET)
				checks.settlement_promise_unchanged=world.facts.attempts[before[visit_id].attempt.id]==before[visit_id].attempt
				checks.valid_settlement=world.validate(content).is_empty()
				return {"observed":observed,"blocked_reason":blocked,"actor":actor,"adaptation":world.facts.adaptations.get(TARGET,{})}
	return {"reason":"target did not settle within bound","observed":observed}
func _compatibility(post_path: String) -> Dictionary:
	var world: WorldState=sim.world
	var visit: Dictionary=world.facts.visits.bench_visit_0085
	var actor: Dictionary=world.facts.actors[visit.actor_id]
	var original: Dictionary=world.freeze()
	var expected: Dictionary=original.duplicate(true);expected.actors[actor.id].erase("support_facility_id")
	checks.old_visit_in_active_loop=visit.id in world.active_visit_ids()
	var matching: Dictionary={"visit":visit.id,"phase":visit.phase,"receipt":visit.result_receipt.duplicate(true),"attempt":world.facts.attempts[visit.result_receipt.attempt_id].duplicate(true),"actor":actor.duplicate(true)}
	sim.clinic._release_completed_seated_support(world,visit)
	checks.exact_compatibility_change=world.freeze()==expected
	sim.clinic._release_completed_seated_support(world,visit)
	checks.compatibility_idempotent=world.freeze()==expected
	var negatives: Array=[]
	for id: String in ["bench_visit_0109","bench_visit_0004"]:
		var negative: Dictionary=world.facts.visits[id]
		var before: Dictionary=world.freeze()
		sim.clinic._release_completed_seated_support(world,negative)
		negatives.append({"visit":id,"posture":world.facts.actors[negative.actor_id].posture,"unchanged":world.freeze()==before})
	checks.real_seated_lying_preserved=negatives.all(func(row:Dictionary)->bool:return row.unchanged)
	if not post_path.is_empty():
		var f:=FileAccess.open(post_path,FileAccess.READ);var post: Dictionary=f.get_var(false);f.close()
		var restored:=HospitalSimulation.new(WorldState.new(post),content)
		var v: Dictionary=restored.world.facts.visits.bench_visit_0109
		var before: Dictionary=restored.world.freeze()
		restored.clinic._release_completed_seated_support(restored.world,v)
		checks.real_standing_at_post_preserved=restored.world.facts.actors[v.actor_id].posture=="standing" and restored.world.facts.actors[v.actor_id].has("support_facility_id") and restored.world.facts.adaptations.has(TARGET) and restored.world.freeze()==before and restored.world.validate(content).is_empty()
		restored.dispose()
	return {"matching_history":matching,"negative_real_states":negatives}

'''
s=s.replace('func _upgrade() -> Dictionary:',methods+'func _upgrade() -> Dictionary:')
# Allow the full-load legitimate migrated/completed original case, while preserving frozen terms.
s=s.replace('checks.frozen_safe_release=quote.get("ok",false) and not world.facts.adaptations.has(TARGET) and suspended.get("attempt_id","")==attempt_id and suspended.get("remaining_ticks",-1)==session.remaining_ticks and world.facts.attempts[attempt_id]==promised and world.facts.inventory.issues[attempt_id]==issue','checks.frozen_safe_release=quote.get("ok",false) and not world.facts.adaptations.has(TARGET) and world.facts.attempts[attempt_id]==promised and world.facts.inventory.issues[attempt_id]==issue\n\tchecks.compatibility_reached_by_dispatch=not world.facts.actors.bench_patient_0085.has("support_facility_id")')
s=s.replace('checks.suspended_work_kept=checks.suspended_work_kept and held.get("attempt_id","")==attempt_id and held.get("remaining_ticks",-1)==session.remaining_ticks','if not held.is_empty():checks.suspended_work_kept=checks.suspended_work_kept and held.get("attempt_id","")==attempt_id and int(held.get("remaining_ticks",-1))<=int(session.remaining_ticks)')
s=s.replace('var resumed: bool=false','var resumed: bool=world.facts.visits[visit_id].get("result_receipt",{}).get("attempt_id","")==attempt_id')
s=s.replace('var result: Dictionary=_upgrade()','var result: Dictionary\n\tif args[0]=="settle":result=_settlement()\n\telif args[0]=="compat":result=_compatibility(args[3] if args.size()>3 else "")\n\telse:result=_upgrade()')
s=s.replace('and checks.get("completed_real_30000",false) and checks.get("new_case_uses_upgrade",false)','and (checks.get("completed_real_30000",false) and checks.get("new_case_uses_upgrade",false) if args[0]=="upgrade" else true)')
p.write_bytes(s.encode())
