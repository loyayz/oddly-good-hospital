from pathlib import Path
import subprocess,hashlib,json
B=Path(__file__).resolve().parent;R=B.parent/'oddly-good-hospital-cloud-recovery-20261112';p=R/'game/building/hospital_movement.gd';original=p.read_bytes();source=original.decode();start=source.index('func _local_collision(');end=source.index('\n# A real fixed-body collision',start);chunk=source[start:end];lines=chunk.splitlines();out=[];labels=[]
for n,line in enumerate(lines):
 if n==0:
  out += [line,'\t_probe_collision("entry",world,actor,movement,contact)'];continue
 if line.lstrip().startswith('#'):out.append(line);continue
 indent=line[:len(line)-len(line.lstrip())]
 if ': return' in line:
  label='return_line_'+str(n);labels.append({'label':label,'source':line});out += [line.split(': return')[0]+':',indent+'\t_probe_collision("'+label+'",world,actor,movement,contact)',indent+'\treturn'];continue
 if line.strip()=='return':
  label='return_line_'+str(n);labels.append({'label':label,'source':line});out.append(indent+'_probe_collision("'+label+'",world,actor,movement,contact)')
 out.append(line)
 if 'if not _local_movable(world,other,journey):' in line:
  out.append(indent+'\t_probe_collision("retreat_immovable:"+id,world,actor,movement,contact)')
helper='''
func _probe_collision(label: String, world: WorldState, actor: Dictionary, movement: Dictionary, contact: MotionResult) -> void:
	if actor.id!="maintenance_contractor_00000226": return
	var blockers: Dictionary={}
	for id: String in contact.blocker_actor_ids: blockers[id]={"actor":world.facts.actors.get(id,{}),"move":world.facts.moves.get(id,{})}
	print("UPGRADE_COLLISION "+JSON.stringify({"label":label,"tick":world.sim_tick,"actor":actor,"move":movement,"requested":[contact.requested_motion.x,contact.requested_motion.y],"actual":[contact.actual_motion.x,contact.actual_motion.y],"blocker_actor_ids":contact.blocker_actor_ids,"reservation_ids":contact.reservation_ids,"static_reason":contact.static_reason,"door_id":contact.door_id,"blockers":blockers}))
'''
observed=(source[:start]+'\n'.join(out)+'\n'+helper+source[end:]).encode();(B/'collision-movement.original.gd').write_bytes(original);(B/'collision-movement.observer.gd').write_bytes(observed);(B/'collision-labels.json').write_text(json.dumps(labels,indent=2));sha=lambda x:hashlib.sha256(x).hexdigest()
input=str(B/'continuation01/final.bin')
subprocess.run(['python',str(B/'run_collision_probe.py'),'step','plain1-7633',input],check=True)
try:
 p.write_bytes(observed)
 subprocess.run(['python',str(B/'run_collision_probe.py'),'parse','collision-observer-parse01'],check=True)
 subprocess.run(['python',str(B/'run_collision_probe.py'),'step','observer1-7633',input],check=True)
finally:
 p.write_bytes(original)
 (B/'collision-overlay-restored.json').write_text(json.dumps({'original_sha256':sha(original),'observer_sha256':sha(observed),'restored_sha256':sha(p.read_bytes()),'exact_restore':p.read_bytes()==original},indent=2))
