from pathlib import Path
import hashlib,json,zipfile,subprocess
root=Path('/workspace/scratch/6962cc21ddf3');r=root/'oddly-good-hospital-cloud-recovery-20261112';b=root/'upgrade-handoff-20261112';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p=b/'plain1-7633/final.bin';o=b/'observer1-7633/final.bin';assert p.read_bytes()==o.read_bytes()
restored=json.loads((b/'collision-overlay-restored.json').read_text());assert restored['exact_restore'];assert sha(r/'game/building/hospital_movement.gd')==restored['original_sha256']
uid=json.loads((b/'uid-before.json').read_text());now={str(p.relative_to(r)):sha(p) for p in r.rglob('*.uid')};assert uid==now
records=[]
for line in (b/'observer1-7633/engine/engine.log').read_text().splitlines():
 if line.startswith('UPGRADE_COLLISION '):records.append(json.loads(line[len('UPGRADE_COLLISION '):]))
assert [x['label'] for x in records]==['entry','retreat_immovable:maintenance_contractor_00000276','return_line_63']
q={'qualified':True,'complete_serialized_world_rng_ordered_events_byte_identical':True,'final_output_sha256':sha(p),'input_sha256':sha(b/'continuation01/final.bin'),'cold_restore_exact_plain':json.loads((b/'plain1-7633/result.json').read_text())['cold_restore_exact'],'cold_restore_exact_observer':json.loads((b/'observer1-7633/result.json').read_text())['cold_restore_exact'],'source_restored':restored,'uid_count':len(uid),'uid_unchanged':True,'observed_labels':[x['label'] for x in records],'query_scope':'existing actual MotionResult and _local_collision branches; no extra queries','head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()};(b/'collision-qualification.json').write_text(json.dumps(q,indent=2));(b/'collision-records.json').write_text(json.dumps(records,indent=2))
p=r/'docs/reports/2026-11-12-upgrade-handoff.md';p.write_text(p.read_text()+'''\n## 7633碰撞最小诊断（不是修复）\n- 先0步decoder直接读取原始终态，未构造Simulation、未调用business query：226原request634/owner upgrade225，retreat从[86,44]意图去[88.8000183,44]，实际[86.3999939,44]；276实际[87,44]，cursor1当前connector段、无local_move，无transit_ticket。trip65患者0115 alighting4→1。完整Move/path和邻近actor/move/owner事实保留。\n- 根据0步不足以证明实际接触，按授权各执行一个全World .1s plain/observer冷分支。observer只在真正_local_collision入口读取现成MotionResult、原return及不可移动分支打印参数；没有新增业务/寻路/安全查询。\n- 资格：plain和observer最终完整facts（含RNG）及有序事件共同序列化bin逐字节相等；SHA256335aa434e72d554b521181bbe20a3f5dbdb4379781943c72b0e1d4353d79bd03。两者冷恢复facts均精确等于7633输入。只代表这个冷一步，不称连续热史/性能。\n- 实际入口contact：requested=(0.199996948242188,0)，actual=(0,0)，blocker_actor_ids仅maintenance_contractor_00000276；static_reason、door_id、reservation_ids全空。真正命中retreat_immovable:276后return_line63，保留226原retreat请求与位置。\n- _local_movable要求当前same-floor walking段；276当前connector段不属于该权限。design01:116要求真实后退遇可移动身体才让对方绕开，固定/排队归属不强推。所以目前实证是合法身体碰撞和原权限保护导致无进展，不能直接把276作为可推动者，也不能因此让226违反原后退规则再左右试探。跨owner出口/退让交接仍需独立规则判断；本次没有观测0115实际alight拒绝来源，不称226为唯一出口阻挡或已证死锁。\n- observer首版生成器误把多行插桩加到一个inline if后导致parser错误；无observer模拟步执行，失败源码/日志保存，finally原字节恢复。修正为仅完整多行条件后，parser02及observer一步通过；plain已完成一次结果复用，未重复步。两次finally恢复proof均保存，最终movement源码与原SHA a78fe4548f5b2402578d5601e8841aea10ccdcaa6cb195c2a21e00c88297b96c完全一致。\n- 未修复业务、未扩长跑、未改变出/撤票或近距离出票规则。所有663 UID字节不变，引擎全部回收，封存后停。\n''')
stage=b/'stage4-source';stage.mkdir(exist_ok=True)
for src,name in [(r/'tests/acceptance/run_upgrade_collision_probe.gd','run_upgrade_collision_probe.gd'),(r/'docs/reports/2026-11-12-upgrade-handoff.md','report.md'),(b/'run_collision_probe.py','run_collision_probe.py'),(b/'run_collision_pair.py','run_collision_pair.py'),(Path('/tmp/package_collision_probe.py'),'package.py')]: (stage/name).write_bytes(src.read_bytes())
subprocess.run(['git','diff','--check'],cwd=r,check=True)
files=[p for d in [b/'decode7633-01',b/'plain1-7633',b/'collision-observer-parse01',b/'collision-observer-parse02',b/'observer1-7633',stage] for p in d.rglob('*') if p.is_file()]
files += [p for p in b.iterdir() if p.is_file() and (p.name.startswith('collision-') or p.name=='run_collision_pair.failed01.py')]
# No old archive/host is copied; only this batch's safe collector outputs.
allowed={'node_sha256','cpu_count','affinity','/proc/meminfo','/proc/stat','/sys/fs/cgroup/cpu.max','/sys/fs/cgroup/cpu.stat','/sys/fs/cgroup/memory.max','/sys/fs/cgroup/memory.current'}
for p in files:
 if p.name.startswith('host-') and p.suffix=='.json':assert set(json.loads(p.read_text()))==allowed
members=[{'path':str(p.relative_to(b)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(files)];(b/'stage4-members.json').write_text(json.dumps(members,indent=2));files.append(b/'stage4-members.json')
with zipfile.ZipFile(b/'stage4-collision.zip','x',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,p.relative_to(b))
with zipfile.ZipFile(b/'stage4-collision.zip') as z:
 assert z.testzip() is None
 for m in members:assert hashlib.sha256(z.read(m['path'])).hexdigest()==m['sha256']
print(json.dumps({'archive_sha256':sha(b/'stage4-collision.zip'),'archive_bytes':(b/'stage4-collision.zip').stat().st_size,'members':len(files)},indent=2))
