# Upgrade alight single-step diagnosis (stage 5)

Scope: one cold-restored full World step from tick 7633, no commands or extra safety/path/business queries; reuse qualified stage 4 plain1. Existing source compared byte-for-byte with baseline commit 7961b727 for all three instrumented files, engine/native locked hashes and unchanged test/clinical source checked. This is diagnosis, not a continuous hot replay or performance result.

Observed trip65, patient0115: _alight entry at tick7633; original static_reason returned empty. Original BodyIndex.intersects first actual overlap was maintenance_contractor_00000226 on floor1, landing body Rect2(86.23333,44.23333,0.533333,0.533333). Current body index returned false clearance, then egress_clear rejected. Bed-goal/destination checks were not reached. This establishes one actual first blocker, not an exhaustive overlap inventory.

Together with stage4's actual226 east-retreat contact against276 and the independently reviewed276 connector-owner wait for trip65, the dependency cycle is closed. Fixed-body protection itself is not labelled a defect; no repair or longer execution performed.

Qualification: full serialized World/RNG/ordered events bytes equal reused plain1, SHA335aa434e72d554b521181bbe20a3f5dbdb4379781943c72b0e1d4353d79bd03. Observer one step exit0, wall3.212436702s, reaped. Parser01 failed because unscoped textual replacement inserted a logging statement into another occurrence with wrong indentation and an unrelated held branch. No simulation executed in that failure. Scope corrected; parser02 exit0. Both failed/final overlay sources and restoration receipts preserved. All three original production files restored exactly,663UID identities unchanged. No stage/commit/push.
