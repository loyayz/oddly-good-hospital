from pathlib import Path
import json,hashlib,subprocess,zipfile
B=Path(__file__).resolve().parent; R=B.parent/'oddly-good-hospital-cloud-recovery-20261112'
sha=lambda b:hashlib.sha256(b).hexdigest()
files=['hospital_transit.gd','hospital_space.gd','body_index.gd']; orig={n:(R/'game/building'/n).read_bytes() for n in files}
uid={str(p.relative_to(R)):sha(p.read_bytes()) for p in R.rglob('*.uid')}
base=json.loads((B/'plain1-7633/identity.json').read_text())
for p,h in base['locked_files'].items():assert sha(Path(p).read_bytes())==h
assert sha((R/'tests/acceptance/run_upgrade_collision_probe.gd').read_bytes())==base['test_sha']
assert sha((R/'game/clinic/clinical_runtime.gd').read_bytes())==base['clinical_source_sha']
for n in files:
 old=subprocess.check_output(['git','show','7961b7271c772e4acac7697e36ae2b59b5c5bc1d:game/building/'+n],cwd=R);assert old==orig[n]
assert sha((B/'continuation01/final.bin').read_bytes())=='2991f379d1f1fb8eb7c4ca34eb255e9081ba76f8605f3e869f116a2056ba86f6'
s=orig['hospital_transit.gd'].decode()
s=s.replace('if not space.static_reason(world,actor,floor_id,anchor,members,offsets).is_empty():','var observed_reason: String = space.static_reason(world,actor,floor_id,anchor,members,offsets)\n\tif actor_id=="bench_patient_0115": print("UPGRADE_ALIGHT "+JSON.stringify({"label":"static_reason","reason":observed_reason}))\n\tif not observed_reason.is_empty():')
s=s.replace('\t\tconnection.remaining_ticks = 1\n\t\treturn\n\t# If the original goal', '\t\tif primary=="bench_patient_0115": print("UPGRADE_ALIGHT egress_rejected")\n\t\tconnection.remaining_ticks = 1\n\t\treturn\n\tif primary=="bench_patient_0115": print("UPGRADE_ALIGHT egress_passed")\n\t# If the original goal')
s=s.replace('\t\t\tif not held.is_empty():','\t\t\tif primary=="bench_patient_0115": print("UPGRADE_ALIGHT "+JSON.stringify({"label":"bed_destination","held":held}))\n\t\t\tif not held.is_empty():',1)
s=s.replace('\n\tvar primary: String = connection.get("primary_actor_id",connection.riders[0])','\n\tvar primary: String = connection.get("primary_actor_id",connection.riders[0])\n\tif primary=="bench_patient_0115": print("UPGRADE_ALIGHT "+JSON.stringify({"label":"alight_entry","connection":connection,"tick":world.sim_tick}))')
obs={'hospital_transit.gd':s.encode()}
s=orig['hospital_space.gd'].decode();a=s.index('func _dynamic_clear(');z=s.index('\n# Destination claims',a);chunk=s[a:z]
chunk=chunk.replace('\t\t\treturn false','\t\t\tif actor_id=="bench_patient_0115": print("UPGRADE_ALIGHT dynamic_return_false_line")\n\t\t\treturn false')
chunk=chunk.replace('\tif movement._sweep_index.intersects', '\tif actor_id=="bench_patient_0115": print("UPGRADE_ALIGHT actor_index_passed")\n\tif movement._sweep_index.intersects')
chunk=chunk.replace('\t\treturn false','\t\tif actor_id=="bench_patient_0115": print("UPGRADE_ALIGHT sweep_rejected")\n\t\treturn false') if False else chunk
# Label the original actor-index branch without any additional check.
chunk=chunk.replace('if _actor_index.intersects(floor_id,rect,actor_id,ignored):','if _actor_index.intersects(floor_id,rect,actor_id,ignored):\n\t\t\tif actor_id=="bench_patient_0115": print("UPGRADE_ALIGHT current_body_index_rejected")')
obs['hospital_space.gd']=(s[:a]+chunk+s[z:]).encode()
s=orig['body_index.gd'].decode();old='\t\tif record.boundary==_boundary and id!=ignored_id and not id in ignored_ids and _overlap(record,rect): return true';new='\t\tif record.boundary==_boundary and id!=ignored_id and not id in ignored_ids and _overlap(record,rect):\n\t\t\tif ignored_id=="bench_patient_0115": print("UPGRADE_ALIGHT "+JSON.stringify({"label":"index_first_actual_overlap","blocker":id,"floor":floor_id,"rect":str(rect)}))\n\t\t\treturn true';assert old in s;obs['body_index.gd']=s.replace(old,new).encode()
for n in files:
 (B/('alight-original-'+n)).write_bytes(orig[n]);(B/('alight-observer-'+n)).write_bytes(obs[n])
try:
 for n in files:(R/'game/building'/n).write_bytes(obs[n])
 subprocess.run(['python',str(B/'run_collision_probe.py'),'parse','alight-parse02'],check=True)
 subprocess.run(['python',str(B/'run_collision_probe.py'),'step','alight-observer01',str(B/'continuation01/final.bin')],check=True)
finally:
 for n in files:(R/'game/building'/n).write_bytes(orig[n])
 proof={n:{'original':sha(orig[n]),'observer':sha(obs[n]),'restored':sha((R/'game/building'/n).read_bytes()),'exact':(R/'game/building'/n).read_bytes()==orig[n]} for n in files}
 proof['uids_unchanged']=uid=={str(p.relative_to(R)):sha(p.read_bytes()) for p in R.rglob('*.uid')};proof['uid_count']=len(uid)
 (B/'alight-restoration.json').write_text(json.dumps(proof,indent=2))
a=(B/'plain1-7633/final.bin').read_bytes();b=(B/'alight-observer01/final.bin').read_bytes();q={'qualified':a==b,'full_world_rng_events_sha':sha(b),'plain_sha':sha(a),'reused_plain':True,'restoration':proof};(B/'alight-qualification.json').write_text(json.dumps(q,indent=2));assert a==b
print(json.dumps(q))
