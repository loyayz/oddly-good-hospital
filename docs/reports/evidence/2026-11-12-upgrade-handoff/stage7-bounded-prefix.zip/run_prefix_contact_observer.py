from pathlib import Path
import subprocess,json,hashlib
B=Path(__file__).resolve().parent;R=B.parent/'oddly-good-hospital-cloud-recovery-20261112';p=R/'game/building/hospital_movement.gd';original=p.read_bytes();s=original.decode();needle='func _local_collision(world: WorldState, actor: Dictionary, movement: Dictionary, contact: MotionResult) -> void:\n';assert s.count(needle)==1
s=s.replace(needle,needle+'\tif actor.id in ["retreater","role_waiter"]: print("PREFIX_CONTACT "+JSON.stringify({"tick":world.sim_tick,"actor":actor.id,"cell":actor.location.cell,"local":movement.get("local_move",{}),"requested":[contact.requested_motion.x,contact.requested_motion.y],"actual":[contact.actual_motion.x,contact.actual_motion.y],"blockers":contact.blocker_actor_ids,"static":contact.static_reason,"door":contact.door_id}))\n')
sha=lambda b:hashlib.sha256(b).hexdigest()
(B/'prefix-contact-original.gd').write_bytes(original);(B/'prefix-contact-observer.gd').write_text(s)
try:
 p.write_text(s)
 subprocess.run(['python',str(B/'run_prefix_roles.py'),'step','prefix-multiple-observer02','multiple',str(B/'prefix-multiple02/nurse_multiple-preWorld.bin')],check=True)
finally:
 p.write_bytes(original)
 (B/'prefix-contact-restoration.json').write_text(json.dumps({'original':sha(original),'restored':sha(p.read_bytes()),'exact':p.read_bytes()==original},indent=2))
q={}
for n in ['nurse_multiple-preWorld.bin','nurse_multiple-final.bin','nurse_multiple-frames.bin']:
 a=(B/'prefix-multiple-plain02'/n).read_bytes();b=(B/'prefix-multiple-observer02'/n).read_bytes();q[n]={'equal':a==b,'sha256':sha(b)};assert a==b
(B/'prefix-contact-qualification.json').write_text(json.dumps(q,indent=2));print(q)
