extends SceneTree
func _initialize() -> void:call_deferred("_run")
func _save(path: String, value: Variant) -> void:
	var f:=FileAccess.open(path,FileAccess.WRITE);f.store_var(value,false);f.close()
func _run() -> void:
	var args:=OS.get_cmdline_user_args();var out: String=args[1]
	var f:=FileAccess.open(args[2],FileAccess.READ);var input: Dictionary=f.get_var(false);f.close()
	var content:=HospitalContent.new();var world:=WorldState.new(input);var sim:=HospitalSimulation.new(world,content)
	var waiter: Dictionary=world.facts.actors.maintenance_contractor_00000276
	var move: Dictionary=world.facts.moves.maintenance_contractor_00000276
	var retreat: Dictionary=world.facts.actors.maintenance_contractor_00000226
	var journey: Dictionary=world.facts.moves.maintenance_contractor_00000226
	var checks: Dictionary={};var before: Dictionary=world.freeze()
	# Real captured roles: unrelated staff has no matching exit-retreat ownership.
	var staff: Dictionary=world.facts.actors.bench_staff_0025
	checks.unrelated_retreat_rejected=not HospitalTransit.yield_to_retreat(sim.space,world,waiter,move,staff,world.facts.moves.get(staff.id,{}),Vector2.RIGHT) and world.freeze()==before
	checks.floor_owner_rejected=not HospitalTransit.yield_to_retreat(sim.space,world,retreat,journey,waiter,move,Vector2.LEFT) and world.freeze()==before
	var seated: String=""
	for id: String in world.facts.actors:
		if world.facts.actors[id].get("posture")=="seated":seated=id;break
	checks.real_seated_protected=not seated.is_empty() and not HospitalTransit.yield_to_retreat(sim.space,world,world.facts.actors[seated],world.facts.moves.get(seated,{}),retreat,journey,Vector2.RIGHT) and world.freeze()==before
	# Only a real simulation step establishes the positive captured contact.
	var tick: TickResult=sim.step();var events: Array=[]
	for e: SimEvent in tick.facts:events.append(e.to_record())
	_save(out+"/pending.bin",world.freeze());_save(out+"/events.bin",events)
	checks.pending_created=move.get("route_waypoint",{}).has("prefix")
	before=world.freeze()
	checks.duplicate_rejected=not HospitalTransit.yield_to_retreat(sim.space,world,waiter,move,retreat,journey,Vector2.RIGHT) and world.freeze()==before
	checks.pending_validate=world.validate().is_empty()
	# Pure malformed-save validation negatives, not claimed legal flow fixtures.
	var malformed: Dictionary=before.duplicate(true)
	malformed.moves[waiter.id].route_waypoint.prefix=[]
	checks.empty_prefix_invalid=not WorldState.new(malformed).validate().is_empty()
	# Formal retarget must remove stale waypoint authority, even while pending.
	var request_before: int=int(move.request_sequence)
	var reason: String=sim.space.request_move(world,waiter.id,4,[74,6])
	checks.formal_retarget_accepted=reason.is_empty()
	checks.retarget_cleared_prefix=not world.facts.moves[waiter.id].has("route_waypoint")
	checks.retarget_valid=world.validate().is_empty()
	_save(out+"/retarget-final.bin",world.freeze())
	var passed: bool=true
	for value: Variant in checks.values():passed=passed and bool(value)
	f=FileAccess.open(out+"/result.json",FileAccess.WRITE);f.store_string(JSON.stringify({"passed":passed,"checks":checks,"seated_actor":seated,"retarget_reason":reason,"original_request":request_before},"\t"));f.close()
	sim.dispose();quit(0 if passed else 1)
