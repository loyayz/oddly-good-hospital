from pathlib import Path
import subprocess,json,hashlib
B=Path(__file__).resolve().parent;R=B.parent/'oddly-good-hospital-cloud-recovery-20261112';p=R/'game/building/hospital_movement.gd';original=p.read_bytes();s=original.decode();needle='func _local_collision(world: WorldState, actor: Dictionary, movement: Dictionary, contact: MotionResult) -> void:\n';assert s.count(needle)==1
s=s.replace(needle,needle+'\tif actor.id in ["retreater","role_waiter"]: print("PREFIX_CONTACT "+JSON.stringify({"tick":world.sim_tick,"actor":actor.id,"cell":actor.location.cell,"local":movement.get("local_move",{}),"requested":[contact.requested_motion.x,contact.requested_motion.y],"actual":[contact.actual_motion.x,contact.actual_motion.y],"blockers":contact.blocker_actor_ids,"static":contact.static_reason,"door":contact.door_id}))\n')
sha=lambda b:hashlib.sha256(b).hexdigest()
(B/'prefix-deep2-contact-original.gd').write_bytes(original);(B/'prefix-deep2-contact-observer.gd').write_text(s)
try:
 p.write_text(s)
 subprocess.run(['python',str(B/'run_prefix_roles.py'),'step','prefix-deep-observer02','deep',str(B/'prefix-deep02/nurse_deep-preWorld.bin')],check=True)
finally:
 p.write_bytes(original)
 (B/'prefix-deep2-contact-restoration.json').write_text(json.dumps({'original':sha(original),'restored':sha(p.read_bytes()),'exact':p.read_bytes()==original},indent=2))
q={}
for n in ['nurse_deep-preWorld.bin','nurse_deep-final.bin','nurse_deep-frames.bin']:
 a=(B/'prefix-deep02'/n).read_bytes();b=(B/'prefix-deep-observer02'/n).read_bytes();q[n]={'equal':a==b,'sha256':sha(b)};assert a==b
(B/'prefix-deep2-contact-qualification.json').write_text(json.dumps(q,indent=2));print(q)
