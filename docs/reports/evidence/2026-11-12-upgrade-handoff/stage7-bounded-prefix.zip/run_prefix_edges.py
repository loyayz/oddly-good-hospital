from pathlib import Path
import sys,json,hashlib,os,platform,importlib.util,traceback,subprocess
B=Path(__file__).resolve().parent;root=B.parent;R=root/'oddly-good-hospital-cloud-recovery-20261112'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,v):Path(p).write_text(json.dumps(v,indent=2))
def host():
 d={'node_sha256':hashlib.sha256(platform.node().encode()).hexdigest(),'cpu_count':os.cpu_count(),'affinity':sorted(os.sched_getaffinity(0))}
 for path in ['/proc/meminfo','/proc/stat','/sys/fs/cgroup/cpu.max','/sys/fs/cgroup/cpu.stat','/sys/fs/cgroup/memory.max','/sys/fs/cgroup/memory.current']:
  try:d[path]=Path(path).read_text()
  except OSError:d[path]='unavailable'
 return d
cfg=json.loads((root/'root-stage-recovery-20261112/config.json').read_text())
for p,h in cfg['locked_files'].items():assert sha(p)==h,p
for proc in Path('/proc').iterdir():
 if proc.name.isdigit():
  try:comm=(proc/'comm').read_text().strip()
  except OSError:continue
  assert not comm.lower().startswith('godot'),f'engine slot busy: {proc.name}'
spec=importlib.util.spec_from_file_location('safe_lifecycle_guard',root/'root-stage-recovery-20261112/linux_guard_v2.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g);g.PROJECT=R;g.LIBRARY_PATH=cfg['library_path']
mode,runid,*extra=sys.argv[1:];out=B/runid;out.mkdir(exist_ok=False)
write(out/'identity.json',{'engine':cfg['engine'],'locked_files':cfg['locked_files'],'test_sha':sha(R/'tests/acceptance/connector_prefix_edges.gd'),'guard_sha':sha(spec.origin),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'clinical_source_sha':sha(R/'game/clinic/clinical_runtime.gd')})
cmd=[cfg['engine'],'--headless','--path',str(R),'--script','res://tests/acceptance/connector_prefix_edges.gd']
cmd+=['--check-only'] if mode=='parse' else ['--',mode,str(out),*extra]
(out/'source').mkdir()
for n in ['game/building/hospital_movement.gd','game/building/hospital_transit.gd','game/sim/world_state.gd','tests/acceptance/connector_prefix_edges.gd']:
 (out/'source'/Path(n).name).write_bytes((R/n).read_bytes())
write(out/'source/sha256.json',{p.name:sha(p) for p in (out/'source').iterdir()})
write(out/'host-before.json',host())
try:g.run(cmd,out/'engine',timeout=600,allowed_exits=(0,1))
except BaseException:write(out/'error.json',{'traceback':traceback.format_exc()});raise
finally:write(out/'host-after.json',host())
print(mode,json.loads((out/'engine/process.json').read_text())['returncode'])
