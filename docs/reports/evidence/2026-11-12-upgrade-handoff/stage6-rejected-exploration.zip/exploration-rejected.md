# Rejected connector-owner prototype

Not approved for production. Both runs used exactly preserved source under each run/source. flow01 exit1: actual unlock but assertion aliased input facts; immutable original position fixed in flow02. flow02 exit0,15 real ticks7633→7648; original owner/continuation/intent retained, physical step bound and cold continuation facts/events equality passed. This is post-budget boundary diagnosis, not completed upgrade scenario.

Rejected scope: radius1..191 + _floor_route can search whole floor; queue_waypoint replans instead of preserving checked local legs; selected endpoint alone does not prove intermediate legs avoid exit/retreat corridor; additional same-owner validation and complete lifecycle contract required. It must not be submitted as a root-cause fix. Production files remain prototype pending parent durable backup, then only those two files can be restored exactly to HEAD. No further engine runs or edits authorized yet.

All failed/passing results, preWorld, handoff, complete final World, ordered events, frames, engine commands/status/durations, and safe allowlist host raw are included. No mount/cgroup mapping collection. Engine processes reaped. No stage/commit/push.
