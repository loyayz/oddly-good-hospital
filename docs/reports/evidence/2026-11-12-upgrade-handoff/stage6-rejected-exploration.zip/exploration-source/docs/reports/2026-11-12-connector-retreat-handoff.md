# Connector retreat-owner handoff

## Rule, actual handoff and selected validation
Design01 actual-contact retreat permits the encountered walking owner to yield, while connector/support/fixed owners keep their own admission rules. At tick7633, incoming trip65 patient0115 is physically blocked by226;226's actual east retreat collides with276, whose current connector owner waits for that same trip.276 does not itself overlap the exit. Do not enlarge the exit or generic local-movable definition.

A narrow actual-collision request asks the connector owner to place its eligible un-ticketed standing singleton waiter on a temporary public floor waypoint. Validate current trip/landing, actual retreat body versus actual incoming exit, and preserve request/job/target/continuation. Select from the actual waiter's position, never the connection anchor; exclude exit and remaining retreat corridor. Normal movement still owns every physical step. No legal point means no mutation.

Selected: complete saved7633 baseline versus patched short real.1s boundary, original owner/request/target and physical budget, actual alight and continued movement; cold restore after handoff. Direct rejection boundaries only from valid unchanged input actors/roles where possible. Existing stage4/5 baseline evidence is reusable. No long4038 replay before parent backup; no full topic, performance micro, altered load, fabricated tickets or teleports.

Design01 §3 forbids pushing fixed posts/queues; Design11 §167 forbids queue positions blocking an operation/unique exit. This change is the transit owner resolving its own current incoming landing dependency after actual contact, not a generic push permission.276 is an indirect retreat blocker, not a direct exit blocker. No incoming/current exit dependency means no handoff.
