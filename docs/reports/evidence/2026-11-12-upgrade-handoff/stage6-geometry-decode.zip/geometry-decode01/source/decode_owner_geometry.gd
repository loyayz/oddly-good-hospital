extends SceneTree
func _initialize() -> void:
	var a:=OS.get_cmdline_user_args();var out: String=a[1]
	for name: String in ["handoff","frames"]:
		var f:=FileAccess.open(a[2]+"/"+name+".bin",FileAccess.READ);var raw: Variant=f.get_var(false);f.close()
		var value: Variant=raw
		if name=="handoff":
			value={"tick":raw.sim_tick,"actors":{},"moves":{},"lift":raw.connectors.benchmark_lift}
			for id: String in ["maintenance_contractor_00000226","maintenance_contractor_00000276"]:
				value.actors[id]=raw.actors[id];value.moves[id]=raw.moves[id]
		f=FileAccess.open(out+"/"+name+".json",FileAccess.WRITE);f.store_string(JSON.stringify(value,"\t"));f.close()
	quit(0)
