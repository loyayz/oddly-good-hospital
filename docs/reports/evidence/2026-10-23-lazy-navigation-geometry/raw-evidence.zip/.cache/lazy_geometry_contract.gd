extends RefCounted

func _same_nodes(actual: RouteClearance, expected: RouteClearance) -> bool:
	for id: int in FloorNavigation.LIMIT:
		if actual.reason(FloorNavigation._cell(id))!=expected.reason(FloorNavigation._cell(id)): return false
	return true

func run_case(source: Dictionary, content: HospitalContent) -> Dictionary:
	var world: WorldState = WorldState.new(source.duplicate(true))
	var actor: Dictionary = world.facts.actors.permission_peer
	var space: HospitalSpace = HospitalSpace.new(content)
	var before: Dictionary = world.freeze()
	var checks: Dictionary = {"legal_input":world.validate(content).is_empty()}
	var first: RouteClearance = space.navigation.structural_clearance(world,actor,1)
	var entry: Dictionary = space._navigation._entries.values()[0]
	var base_charge: int = space._navigation._charged
	checks.point_geometry_has_no_native_points = not entry.graph._built and entry.graph.get_point_count()==0 and base_charge>0 and base_charge<=int(content.balance.pathfinding.graph_cache_target_bytes)
	var equal: bool = true
	for hit: int in 8: equal = equal and space.navigation.structural_clearance(world,actor,1)==first
	var cold: RouteClearance = RouteClearance.new(HospitalSpace.new(content),world,actor,1,[],{},false)
	checks.repeated_points_reuse_complete_geometry = equal and _same_nodes(first,cold) and space.query_counts.lazy_geometry_builds==1
	var graph: FloorNavigation = space._navigation.graph(space,world,1,actor,[],{})
	checks.actual_graph_uses_same_geometry_and_charges_native_points_once = graph.geometry==first and graph._built and space._navigation._charged==base_charge+graph.get_point_count()*1024
	space._navigation.graph(space,world,1,actor,[],{})
	checks.repeated_graph_does_not_double_charge = space._navigation._charged==base_charge+graph.get_point_count()*1024 and space.query_counts.lazy_geometry_graph_builds==1
	checks.calculation_readonly = before==world.freeze()
	# A second legal calculation starts with geometry only, then edits a target
	# before any graph exists. It must discard the old immutable projection.
	var pending: HospitalSpace = HospitalSpace.new(content)
	var old: RouteClearance = pending.navigation.structural_clearance(world,actor,1)
	world.facts.floors.overrides["1"].blocked.append([40,90])
	world.touch()
	before = world.freeze()
	var stale_rejected: bool = pending._navigation.cached_static_geometry(pending,world,1,actor)==null
	var current: RouteClearance = pending.navigation.structural_clearance(world,actor,1)
	entry = pending._navigation._entries.values()[0]
	cold = RouteClearance.new(HospitalSpace.new(content),world,actor,1,[],{},false)
	checks.unbuilt_source_edit_replaces_geometry_without_building_points = stale_rejected and current!=old and not entry.graph._built and entry.graph.get_point_count()==0 and _same_nodes(current,cold) and before==world.freeze()
	graph = pending._navigation.graph(pending,world,1,actor,[],{})
	var independent: FloorNavigation = FloorNavigation.new(cold)
	checks.first_materialized_nodes_and_edges_match_cold = graph._enabled==independent._enabled and graph._edges==independent._edges and graph.get_point_count()==independent.get_point_count()
	# A later point check must not eagerly repair the existing native graph.
	old = graph.geometry
	var old_charge: int = pending._navigation._charged
	world.facts.floors.overrides["1"].blocked.append([41,90])
	world.touch()
	before = world.freeze()
	current = pending.navigation.structural_clearance(world,actor,1)
	cold = RouteClearance.new(HospitalSpace.new(content),world,actor,1,[],{},false)
	checks.built_source_edit_keeps_original_lazy_repair_boundary = current!=old and graph.geometry==old and pending._navigation._charged==old_charge and _same_nodes(current,cold) and before==world.freeze()
	graph = pending._navigation.graph(pending,world,1,actor,[],{})
	independent = FloorNavigation.new(cold)
	checks.next_graph_repairs_complete_nodes_and_edges = graph.geometry!=old and graph._enabled==independent._enabled and graph._edges==independent._edges and graph.get_point_count()==independent.get_point_count()
	var version: int = pending._navigation.floor_static_version(pending,world,1)
	pending._navigation._trim(0)
	checks.eviction_releases_complete_entry_and_charge = pending._navigation._entries.is_empty() and pending._navigation._charged==0 and pending._navigation._query_charged==0 and pending._navigation.cached_static_geometry(pending,world,1,actor)==null
	current = pending.navigation.structural_clearance(world,actor,1)
	entry = pending._navigation._entries.values()[0]
	checks.evicted_point_rebuild_keeps_source_version = not entry.graph._built and _same_nodes(current,cold) and pending._navigation.floor_static_version(pending,world,1)==version and world.freeze()==before
	return {"ok":not checks.values().has(false),"checks":checks,"initial_geometry_charge":base_charge,"materialized_points":graph.get_point_count()}
