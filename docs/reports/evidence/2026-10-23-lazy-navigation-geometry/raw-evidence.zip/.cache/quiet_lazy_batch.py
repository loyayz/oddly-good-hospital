from pathlib import Path
from types import SimpleNamespace
import argparse
import contextlib
import importlib.util
import io
import json
import time

spec = importlib.util.spec_from_file_location('quiet_lazy_trial', Path(__file__).with_name('lazy_geometry_round.py'))
trial = importlib.util.module_from_spec(spec)
spec.loader.exec_module(trial)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--window', default='gp80')
    parser.add_argument('--batch', default='quiet01')
    args = parser.parse_args()
    plan = [('baseline', args.batch + '-a1'), ('baselinelazy', args.batch + '-b1'), ('baseline', args.batch + '-a2')]
    trial.trial.write(trial.trial.ROOT / (args.batch + '-' + args.window + '.plan.json'),
                      dict(order=plan, settling_seconds_before_each_engine_launch=3, simulation_step_or_polling_changed=False,
                           simulation_input_and_runtime_cache_policy_unchanged=True, stdout_captured_until_measurement_finishes=True))
    completed = []
    for variant, label in plan:
        time.sleep(3)
        stream = io.StringIO()
        try:
            with contextlib.redirect_stdout(stream):
                trial.measure(SimpleNamespace(variant=variant, label=label, window=args.window, profile='plain'))
        finally:
            path = trial.trial.ROOT / (label + '-' + args.window + '.driver.log')
            assert not path.exists()
            path.write_bytes(stream.getvalue().encode('utf-8'))
        report = trial.trial.read(trial.trial.ROOT / (label + '-' + args.window + '.json'))
        completed.append(dict(label=label, variant=variant, metrics=report['metrics']))
    print(json.dumps(completed), flush=True)
