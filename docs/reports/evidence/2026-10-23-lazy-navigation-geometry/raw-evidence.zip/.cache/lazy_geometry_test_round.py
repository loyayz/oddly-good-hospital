from pathlib import Path
from types import SimpleNamespace
import argparse
import importlib.util
import json
import shutil

spec = importlib.util.spec_from_file_location('lazy_contract_trial', Path(__file__).with_name('lazy_geometry_round.py'))
lazy = importlib.util.module_from_spec(spec)
spec.loader.exec_module(lazy)
variant = 'baselinelazytest'


def prepare():
    root = lazy.trial.ROOT
    project = root / (variant + '-project')
    assert not project.exists()
    shutil.copytree(root / 'baselinelazy-project', project)
    identity = lazy.trial.read(root / 'baselinelazy-identity.json')
    helper = project / 'tests/acceptance/lazy_geometry_contract.gd'
    shutil.copy2(lazy.REPO / '.cache/lazy_geometry_contract.gd', helper)
    relative = 'tests/acceptance/reference_route_permissions.gd'
    original = (project / relative).read_text(encoding='utf-8')
    generated = original.replace('\treturn {"ok":valid and fields.ok and reverse.ok and masks.ok and projections.ok and reuse.ok,"details":{',
        '\tvar lazy_geometry: Dictionary = preload("res://tests/acceptance/lazy_geometry_contract.gd").new().run_case(source,content)\n\treturn {"ok":valid and fields.ok and reverse.ok and masks.ok and projections.ok and reuse.ok and lazy_geometry.ok,"details":{"lazy_geometry":lazy_geometry,', 1)
    assert generated != original
    (project / relative).write_bytes(generated.encode('utf-8'))
    identity['patches'] = identity['patches'] + [dict(path=relative, original=original, generated=generated)]
    identity['tests'] = [dict(path=row['path'], sha256=lazy.trial.sha(project / row['path'])) for row in identity['tests']]
    identity['tests'].append(dict(path='tests/acceptance/lazy_geometry_contract.gd', sha256=lazy.trial.sha(helper)))
    identity['same_production_sources_as'] = 'baselinelazy'
    lazy.trial.write(root / (variant + '-identity.json'), identity)
    print(json.dumps(dict(variant=variant, sources=len(identity['sources']), tests=len(identity['tests']))))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['prepare', 'functional'])
    args = parser.parse_args()
    if args.action == 'prepare':
        prepare()
    else:
        lazy.functional(SimpleNamespace(variant=variant, label='functional01'))
