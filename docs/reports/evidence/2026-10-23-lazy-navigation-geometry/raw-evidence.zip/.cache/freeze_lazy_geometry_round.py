from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import zipfile

REPO = Path(__file__).resolve().parent.parent
ROOT = REPO / '.cache/lazy-geometry-ab07ee7-20261023'
OUT = REPO / 'docs/reports/evidence/2026-10-23-lazy-navigation-geometry'
read = lambda path: json.loads(Path(path).read_text(encoding='utf-8-sig'))
digest = lambda data: hashlib.sha256(data).hexdigest()
sha = lambda path: digest(Path(path).read_bytes())
relative = lambda path: Path(path).relative_to(REPO).as_posix()
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip()
assert head.startswith('ab07ee7'), head
assert subprocess.check_output(['git', 'branch', '--show-current'], cwd=REPO, text=True).strip() == 'dev'
production = '5712c6f7fbc7e222e2a483bc376201352fd5ffc2'
subprocess.check_call(['git', 'diff', '--exit-code', production, '--', 'game', 'tests', 'project.godot'], cwd=REPO)
parent = REPO / 'docs/reports/evidence/2026-10-23-floor-graph-worker-trial/raw-evidence.zip'
assert sha(parent) == '1f2b22e9c384fd2cb56488287a59cf9f130865f1e229d42bd2c8d793f109d465'
baseline = read(ROOT / 'baseline-identity.json')
baseline_rows = {row['path']: row['sha256'] for row in baseline['sources'] + baseline['tests']}
for row in baseline['sources'] + baseline['tests']:
    if row['path'] not in ['project.godot', 'export_presets.cfg']:
        assert sha(REPO / row['path']) == row['sha256'], row['path']
members = {}
aliases = []


def add(path, name=None):
    path = Path(path)
    name = name or relative(path)
    data = path.read_bytes()
    if name in members:
        assert members[name] == data, name
    members[name] = data


def blob(path, expected):
    assert sha(path) == expected, str(path)
    member = 'source-blobs/' + expected + Path(path).suffix
    add(path, member)
    aliases.append(dict(path=relative(path), member=member, sha256=expected))


identities = {}
for variant in ['baseline', 'baselinelazy', 'baselinelazytest']:
    identity = read(ROOT / (variant + '-identity.json'))
    project = ROOT / (variant + '-project')
    for key in ['sources', 'tests']:
        for row in identity[key]:
            source = project / row['path']
            assert sha(source) == row['sha256'], source
            if baseline_rows.get(row['path']) != row['sha256'] or row['path'] in ['project.godot', 'export_presets.cfg']:
                blob(source, row['sha256'])
    identities[variant] = dict(sources=len(identity['sources']), tests=len(identity['tests']), all_files_verified=True)
first_identity = read(ROOT / 'functional01-test-identity.json')
for key in ['sources', 'tests']:
    for row in first_identity[key]:
        source = ROOT / 'baselinelazytest-project' / row['path']
        if row['path'] == 'tests/acceptance/navigation_source_lifecycle.gd':
            source = ROOT / 'functional01-navigation_source_lifecycle.gd'
        assert sha(source) == row['sha256'], source
assert first_identity['sources'] == read(ROOT / 'baselinelazy-identity.json')['sources']
assert first_identity['sources'] == read(ROOT / 'functional02-test-identity.json')['sources']

runs = {}
intervals = []
for path in sorted(ROOT.glob('*.semantic-check.json')):
    label = path.name.removesuffix('.semantic-check.json')
    check = read(path)
    launch = read(ROOT / (label + '.launch.json'))
    source = read(ROOT / (label + '.source-check.json'))
    actual = read(ROOT / (label + '.json'))
    extra = read(ROOT / (label + '.lazy-check.json'))
    assert check['passed'] and all(check['checks'].values()), label
    assert extra['passed'] and all(extra['checks'].values()), label
    assert launch['exit_code'] == 0 and not launch['errors'] and not launch['timed_out'], label
    assert sha(launch['engine']) == launch['engine_sha256']
    assert source['actual_sources'] == read(ROOT / (source['variant'] + '-identity.json'))['sources']
    assert source['runtime_caches_restored'] is False
    assert actual['requested_steps'] == len(actual['samples']) == actual['metrics']['count'] == 80
    assert actual['complete'] and actual['qualified'] and not actual['errors']
    assert all(row['complete'] and row['present'] == 160 for row in actual['samples'])
    assert sha(ROOT / (label + '.json.final.bin')) == actual['final_binary_sha256']
    counts = actual['public']['query_counts']
    if source['variant'] == 'baselinelazy':
        assert counts['lazy_geometry_builds'] == counts['lazy_geometry_graph_builds'] == 4
        assert counts['lazy_geometry_hits'] == 374
        for key in ['door_candidates', 'reservation_candidate_queries']:
            assert check['query_count_differences'][key]['expected'] - counts[key] == 272
    else:
        assert not check['query_count_differences']
    intervals.append((launch['started_at_utc'], launch['ended_at_utc'], label))
    runs[label] = dict(variant=source['variant'], metrics_us=actual['metrics'],
                       tick851_us=next(row['elapsed_us'] for row in actual['samples'] if row['tick'] == 851),
                       input_sha256=actual['source_input_sha256'], final_binary_sha256=actual['final_binary_sha256'],
                       query_counts=counts, query_count_differences=check['query_count_differences'],
                       checks=check['checks'], additional_checks=extra['checks'],
                       process_cpu_ms=launch['child_cpu_ms'], process_wall_ms=launch['wall_ms'])
assert len(runs) == 5
assert len({run['input_sha256'] for run in runs.values()}) == 1
assert len({run['final_binary_sha256'] for run in runs.values()}) == 1
functional = {}
for label in ['functional01', 'functional02']:
    launch = read(ROOT / (label + '.launch.json'))
    result = read(ROOT / (label + '.acceptance-results.json'))
    assert not launch['errors'] and not launch['timed_out']
    assert result['completed']
    assert launch['exit_code'] == (1 if label == 'functional01' else 0)
    assert result['checks'] == (6 if label == 'functional01' else 1)
    assert result['failed'] == (1 if label == 'functional01' else 0)
    assert result['results']['SPACE-51']['details']['reference_permissions']['lazy_geometry']['ok']
    functional[label] = dict(requested_cases=result['requested_cases'], completed=result['completed'],
                             checks=result['checks'], failed=result['failed'], elapsed_ms=result['elapsed_ms'],
                             cases={key: dict(passed=value['passed'], elapsed_ms=value['elapsed_ms'],
                                               setup_ms=value['setup_ms'], body_ms=value['body_ms'], fixtures=value['fixtures'])
                                    for key, value in result['results'].items()},
                             active_path=result['results']['SPACE-51']['details']['navigation_source_lifecycle']['multifloor_active_path'],
                             geometry=result['results']['SPACE-51']['details']['reference_permissions']['lazy_geometry'])
    intervals.append((launch['started_at_utc'], launch['ended_at_utc'], label))
failure = read(ROOT / 'functional01.acceptance-results.json')['results']['SPACE-51']['details']['navigation_source_lifecycle']
assert [key for key, value in failure['checks'].items() if value is False] == ['real_multifloor_path_proof']
recheck = functional['functional02']['active_path']
assert recheck['ok'] and recheck['native_points'] == 0 and recheck['retained_geometry_entries'] == 2
assert recheck['revalidations_including_block_and_restore'] == 3
intervals.sort()
for left, right in zip(intervals, intervals[1:]):
    assert left[1] <= right[0], (left, right)
for path in ROOT.iterdir():
    if path.is_file() and not path.name.endswith('.final.bin'):
        add(path)
for path in ROOT.glob('*.json.final.bin'):
    member = 'final-states/' + sha(path) + '.bin'
    add(path, member)
    aliases.append(dict(path=relative(path), member=member, sha256=sha(path)))
for name in ['lazy_geometry_round.py', 'lazy_geometry_contract.gd', 'lazy_geometry_test_round.py',
             'lazy_geometry_finish_case.py', 'quiet_lazy_batch.py', 'worker_select_round.py']:
    add(REPO / '.cache' / name)
add(REPO / '.cache/wait-signature-031e1f7-20261022/run.py')
add(REPO / '.cache/queue-signature-26bcc0f-20261023/e3-gp80.json')
add(REPO / '.cache/task-navigation-20261019/gp.input.bin')
add(Path(__file__))
members['source-aliases.json'] = (json.dumps(aliases, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
OUT.mkdir(parents=True, exist_ok=True)
archive = OUT / 'raw-evidence.zip'
assert not archive.exists()
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as output:
    for name, data in sorted(members.items()):
        output.writestr(name, data)
with zipfile.ZipFile(archive) as output:
    assert set(output.namelist()) == set(members)
    for name, data in members.items():
        assert digest(output.read(name)) == digest(data), name
manifest = dict(schema_version=1, archive_sha256=sha(archive), archive_bytes=archive.stat().st_size,
                baseline_reference=dict(path=relative(parent), sha256=sha(parent)),
                members=[dict(path=name, bytes=len(data), sha256=digest(data)) for name, data in sorted(members.items())])
summary = dict(schema_version=1, generated_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               baseline_commit=head, production_commit=production, diagnostic_only=True, formal_pass=False,
               fixed_load=dict(people=160, patients=120, staff=32, visitors=8, floors=4, rooms=64, facilities=1336, tick_seconds=0.1),
               performance_engine_windows=5, qualified_measured_steps=400, functional_engine_windows=2,
               all_recorded_engine_intervals_disjoint=True, engine_intervals=intervals,
               production_and_tests_unchanged=True, identities=identities, runs=runs, functional=functional,
               adoption=False, no_public_or_operations_followup=True, no_release_or_formal_acceptance=True,
               raw_archive=dict(path=relative(archive), sha256=sha(archive), bytes=archive.stat().st_size, members=len(members)),
               limitations=[
                   'No stable whole-window improvement was established. Fewer projections and candidate queries do not establish ordinary-step or P99 gains.',
                   'The quiet A/B/A control uses a three-second pause before each engine launch, outside the simulation. Load, input prefix, warmup, polling and cache allowance are unchanged.',
                   'The first six-case run completed with SPACE-51 failing because its old no-graph assertion equated an empty cache with no AStar nodes. It is retained unchanged.',
                   'Only the private trial assertion changed to test actual native point counts; SPACE-51 alone was rerun. The production implementation and production tests are unchanged.',
                   'Functional helper compares all 9216 possible cell reasons; its legal one-plot fixture materializes 1024 native points. This is not a 9216-point functional fixture.',
                   'The repeat active path retains two geometry entries, zero native points and exactly three revalidations over initial proof, actual block and restore.',
                   'No direct timing of geometry-only construction was added to these plain performance runs; query count reduction is not claimed as an elapsed-time saving.',
                   'Normal sandbox process enumeration is restricted. Ordered terminal completion and recorded engine intervals establish non-overlap within this batch only.',
                   'No explanation for the whole-window timing variance was proved. Quiet capture did not eliminate it.',
                   'No push was performed. This round ends in a pause; further optimization and formal acceptance remain unfinished.'])
for name, value in [('raw-manifest.json', manifest), ('summary.json', summary)]:
    path = OUT / name
    assert not path.exists()
    path.write_bytes((json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
print(json.dumps(dict(archive_sha256=sha(archive), bytes=archive.stat().st_size, members=len(members), performance_windows=5, steps=400,
                      functional={key: value['failed'] for key, value in functional.items()})))
