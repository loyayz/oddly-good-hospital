from pathlib import Path
import importlib.util
import json
import shutil
import sys

spec = importlib.util.spec_from_file_location('lazy_finish', Path(__file__).with_name('lazy_geometry_round.py'))
lazy = importlib.util.module_from_spec(spec)
spec.loader.exec_module(lazy)
trial = lazy.trial
root = trial.ROOT
project = root / 'baselinelazytest-project'
identity_path = root / 'baselinelazytest-identity.json'
relative = 'tests/acceptance/navigation_source_lifecycle.gd'
identity = trial.read(identity_path)
for kind in ['sources', 'tests']:
    for row in identity[kind]:
        assert trial.sha(project / row['path']) == row['sha256'], row['path']
shutil.copy2(identity_path, root / 'functional01-test-identity.json')
shutil.copy2(project / relative, root / 'functional01-navigation_source_lifecycle.gd')
original = (project / relative).read_text(encoding='utf-8')
prefix, active = original.split('func _active_path(', 1)
assert active.count('cache._entries.is_empty()') == 3
active = active.replace('cache._entries.is_empty()', '_no_native_graph(cache)')
active = active.replace('"no_graph_built_for_proof":_no_native_graph(cache)',
                        '"no_graph_built_for_proof":_no_native_graph(cache),"retained_geometry_entries":cache._entries.size(),"native_points":_native_points(cache)')
generated = prefix + '''func _native_points(cache: NavigationCache) -> int:
	var count: int = 0
	for entry: Dictionary in cache._entries.values(): count += entry.graph.get_point_count()
	return count

func _no_native_graph(cache: NavigationCache) -> bool:
	return _native_points(cache)==0

func _active_path(''' + active
(project / relative).write_bytes(generated.encode('utf-8'))
identity['patches'].append(dict(path=relative, original=original, generated=generated,
                              reason='Distinguish retained geometry from materialized AStar nodes in the private trial.'))
for row in identity['tests']:
    row['sha256'] = trial.sha(project / row['path'])
identity_path.write_bytes((json.dumps(identity, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
trial.write(root / 'functional02-test-identity.json', identity)
launcher = trial.module(lazy.REPO / '.cache/wait-signature-031e1f7-20261022/run.py', 'lazy_finish_launcher')
launcher.ROOT = root
prefix = root / 'functional02'
try:
    launcher.launch(['--headless', '--path', project, '--script', 'res://tests/acceptance/runner.gd', '--', 'space', '--case=SPACE-51'], prefix)
finally:
    shutil.copy2(project / 'acceptance-results.json', prefix.with_suffix('.acceptance-results.json'))
result = trial.read(prefix.with_suffix('.acceptance-results.json'))
assert result['completed'] and result['checks'] == 1 and result['failed'] == 0
assert list(result['results']) == ['SPACE-51']
print(json.dumps(dict(passed=True, results={key: dict(passed=value['passed'], elapsed_ms=value['elapsed_ms']) for key, value in result['results'].items()},
                      geometry=result['results']['SPACE-51']['details']['reference_permissions']['lazy_geometry'],
                      active_path=result['results']['SPACE-51']['details']['navigation_source_lifecycle']['multifloor_active_path'])))
