from pathlib import Path
from types import SimpleNamespace
import argparse
import importlib.util
import json
import shutil
import subprocess

REPO = Path(__file__).resolve().parent.parent
spec = importlib.util.spec_from_file_location('lazy_geometry_trial', REPO / '.cache/worker_select_round.py')
trial = importlib.util.module_from_spec(spec)
spec.loader.exec_module(trial)
trial.ROOT = REPO / '.cache/lazy-geometry-ab07ee7-20261023'

GEOMETRY = '''# Retain only static geometry inside the existing graph entry and allowance.
# The empty AStar object gains points only on an actual graph acquisition.
func structural_geometry(space: HospitalSpace, world: WorldState, floor_id: int, actor: Dictionary) -> RouteClearance:
\tvar geometry: RouteClearance = cached_static_geometry(space,world,floor_id,actor)
\tif geometry!=null:
\t\tspace.query_counts["lazy_geometry_hits"] = int(space.query_counts.get("lazy_geometry_hits",0))+1
\t\treturn geometry
\tvar current: Dictionary = floor_source(space,world,floor_id)
\tvar key: String = _graph_key(space,world,floor_id,actor,[],{},current)
\tvar entry: Dictionary = _entries.get(key,{})
\tif not entry.is_empty() and entry.graph._built:
\t\t# A local check does not repair a stale native graph. Preserve the old
\t\t# incremental graph repair until an actual search requests it.
\t\tspace.query_counts["lazy_geometry_transient_builds"] = int(space.query_counts.get("lazy_geometry_transient_builds",0))+1
\t\treturn RouteClearance.new(space,world,actor,floor_id,[],{},false,current)
\tvar source_record: Dictionary = _sources[str(world.get_instance_id())+":"+str(floor_id)]
\t_used += 1
\tentry = _refresh_graph(space,world,floor_id,actor,[],{},source_record.static_source,entry,true)
\t_entries.erase(key)
\t_entries[key] = entry
\tsource_record.graphs[key] = entry.graph.geometry.get_instance_id()
\tgeometry = entry.graph.geometry
\t_trim(int(space.content.balance.pathfinding.graph_cache_target_bytes),space.query_counts)
\treturn geometry

'''


def prepare(variant):
    trial.prepare(SimpleNamespace(variant=variant, tasks=4))
    if variant == 'baseline':
        return
    assert variant == 'baselinelazy'
    project = trial.ROOT / (variant + '-project')
    changes = {
        'game/building/floor_navigation.gd': [
            ('var geometry: RouteClearance\n', 'var geometry: RouteClearance\nvar _built: bool = false\n'),
            ('func _init(projection: RouteClearance) -> void:\n\tgeometry = projection\n\t_enabled.resize(LIMIT)',
             'func _init(projection: RouteClearance, defer_build: bool = false) -> void:\n\tgeometry = projection\n\tif not defer_build: materialize()\n\nfunc materialize() -> void:\n\tif _built: return\n\t_enabled.resize(LIMIT)'),
            ('\tneighbor_filter_enabled = true\n\nfunc _build()', '\tneighbor_filter_enabled = true\n\t_built = true\n\nfunc _build()'),
            ('func refresh(projection: RouteClearance) -> void:\n\tvar regions:',
             'func refresh(projection: RouteClearance) -> void:\n\tif not _built:\n\t\tgeometry = projection\n\t\treturn\n\tvar regions:')],
        'game/building/navigation_cache.gd': [
            ('func query_graphs(space:', GEOMETRY + 'func query_graphs(space:'),
            ('\tvar result: FloorNavigation = entry.graph\n\t_trim(',
             '\tvar result: FloorNavigation = entry.graph\n\tif not result._built:\n\t\tresult.materialize()\n\t\tvar points_charge: int = result.get_point_count()*1024\n\t\tentry.charge += points_charge\n\t\t_charged += points_charge\n\t\tspace.query_counts["lazy_geometry_graph_builds"] = int(space.query_counts.get("lazy_geometry_graph_builds",0))+1\n\t_trim('),
            ('offsets: Dictionary, source: Dictionary, entry: Dictionary) -> Dictionary:\n\tvar geometry:',
             'offsets: Dictionary, source: Dictionary, entry: Dictionary, defer_build: bool = false) -> Dictionary:\n\tspace.query_counts["lazy_geometry_builds"] = int(space.query_counts.get("lazy_geometry_builds",0))+1\n\tvar geometry:'),
            ('\t\tfloor_graph = FloorNavigation.new(geometry)', '\t\tfloor_graph = FloorNavigation.new(geometry,defer_build)')],
        'game/building/hospital_navigation.gd': [
            ('\tvar source: Dictionary = space._navigation.floor_source(space,world,floor_id)\n\tvar query: RouteClearance = space._navigation.cached_static_geometry(space,world,floor_id,actor) if members.is_empty() else null\n\tif query==null: query = RouteClearance.new(space,world,actor,floor_id,members,offsets,false,source)\n\treturn query',
             '\tif members.is_empty() and offsets.is_empty(): return space._navigation.structural_geometry(space,world,floor_id,actor)\n\treturn RouteClearance.new(space,world,actor,floor_id,members,offsets,false,space._navigation.floor_source(space,world,floor_id))')],
    }
    patches = []
    for relative, replacements in changes.items():
        original = (project / relative).read_text(encoding='utf-8')
        generated = original
        for before, after in replacements:
            assert generated.count(before) == 1, (relative, before)
            generated = generated.replace(before, after, 1)
        restored = generated
        for before, after in reversed(replacements):
            restored = restored.replace(after, before, 1)
        assert restored == original
        (project / relative).write_bytes(generated.encode('utf-8'))
        patches.append(dict(path=relative, original=original, generated=generated, inverse_equal=True))
    path = trial.ROOT / (variant + '-identity.json')
    identity = trial.read(path)
    identity.update(patches=patches, original_graph_budget=True, geometry_owned_by_graph_entry=True, native_graph_deferred_until_graph_acquisition=True)
    for row in identity['sources']:
        row['sha256'] = trial.sha(project / row['path'])
    path.rename(path.with_name(variant + '-initial-identity.json'))
    trial.write(path, identity)


def measure(args):
    trial.measure(args)
    prefix = trial.ROOT / (args.label + '-' + args.window)
    check = trial.read(prefix.with_suffix('.semantic-check.json'))
    report = trial.read(prefix.with_suffix('.json'))
    differences = check['query_count_differences']
    checks = dict(all_semantic_checks=check['passed'])
    allowed = {'door_candidates', 'reservation_candidate_queries', 'courtesy_static_geometry_hits', 'courtesy_static_geometry_misses'}
    checks['only_expected_counts'] = all(key.startswith('lazy_geometry_') or key in allowed for key in differences)
    counts = report['public']['query_counts']
    checks['no_added_path_searches'] = all(key not in differences for key in ['routes', 'floor_route_builds', 'floor_route_hits', 'distance_field_builds', 'distance_field_hits', 'static_path_builds', 'static_path_hits'])
    if args.variant == 'baselinelazy':
        checks['geometry_retained_and_materialized'] = counts.get('lazy_geometry_hits', 0) > 0 and counts.get('lazy_geometry_graph_builds', 0) > 0
    trial.write(prefix.with_suffix('.lazy-check.json'), dict(passed=all(checks.values()), checks=checks, differences=differences))
    assert all(checks.values()), checks
    print(json.dumps(dict(lazy_counts={key: value for key, value in counts.items() if key.startswith('lazy_geometry_')}, checks=checks)))


def functional(args):
    project = trial.ROOT / (args.variant + '-project')
    identity = trial.read(trial.ROOT / (args.variant + '-identity.json'))
    for key in ['sources', 'tests']:
        for row in identity[key]:
            assert trial.sha(project / row['path']) == row['sha256'], row['path']
    launcher = trial.module(REPO / '.cache/wait-signature-031e1f7-20261022/run.py', 'lazy_cases')
    launcher.ROOT = trial.ROOT
    prefix = trial.ROOT / args.label
    cases = ['SPACE-46', 'SPACE-51', 'SPACE-55', 'SPACE-57', 'STAFF-57', 'STAFF-61']
    launcher.launch(['--headless', '--path', project, '--script', 'res://tests/acceptance/runner.gd', '--', 'space', 'staff',
                     *['--case=' + case for case in cases]], prefix)
    output = prefix.with_suffix('.acceptance-results.json')
    assert not output.exists()
    shutil.copy2(project / 'acceptance-results.json', output)
    result = trial.read(output)
    assert result['completed'] and result['checks'] == len(cases) and result['failed'] == 0
    assert sorted(result['results']) == sorted(cases)
    print(json.dumps(dict(passed=True, cases={key: dict(body_ms=value['body_ms'], setup_ms=value['setup_ms'])
                                              for key, value in result['results'].items()})))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['prepare', 'measure', 'functional'])
    parser.add_argument('--variant', default='baselinelazy')
    parser.add_argument('--label', default='b1')
    parser.add_argument('--window', default='gp80')
    parser.add_argument('--profile', default='plain')
    args = parser.parse_args()
    if args.action == 'prepare':
        prepare(args.variant)
    elif args.action == 'measure':
        measure(args)
    else:
        functional(args)
