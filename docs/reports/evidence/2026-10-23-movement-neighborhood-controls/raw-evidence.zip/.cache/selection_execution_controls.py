from pathlib import Path
from types import SimpleNamespace
import argparse
import importlib.util
import json
import shutil
import subprocess

REPO=Path(__file__).resolve().parent.parent
spec=importlib.util.spec_from_file_location('selection_execution_trial',REPO/'.cache/worker_select_round.py')
trial=importlib.util.module_from_spec(spec)
spec.loader.exec_module(trial)
PRIOR=trial.ROOT
trial.ROOT=REPO/'.cache/movement-neighborhood-5a7d4b8-20261023'
CONFIG={
    'baselineserialshared':('lazyshared2','d1-gp80','main_serial'),
    'baselineserialhandoff':('lazyhandoff2','e1-gp80','main_serial'),
    'baselineoneworkerhandoff':('lazyhandoff2','e1-gp80','one_worker'),
    'baselineparallelhandoff':('lazyhandoff2','e1-gp80','parallel_workers'),
}

def prepare():
    for variant,(parent,label,mode) in CONFIG.items():
        identity=trial.read(PRIOR/(parent+'-identity.json'))
        origin=PRIOR/(parent+'-project')
        for key in ['sources','tests']:
            for row in identity[key]:assert trial.sha(origin/row['path'])==row['sha256'],row['path']
        project=trial.ROOT/(variant+'-project')
        if project.exists():
            previous=trial.read(trial.ROOT/(variant+'-identity.json'))
            for key in ['sources','tests']:
                for row in previous[key]:assert trial.sha(project/row['path'])==row['sha256'],row['path']
            continue
        shutil.copytree(origin,project)
        relative='tools/performance/seat_selection_batch.gd'
        original=(project/relative).read_text(encoding='utf-8')
        before='\tvar group: int = WorkerThreadPool.add_group_task(_run_job.bind(jobs),count,count,false,"Public seat area selection")\n\tWorkerThreadPool.wait_for_group_task_completion(group)'
        assert original.count(before)==1
        after=('\tvar group: int = -1\n\tfor index: int in count: _run_job(index,jobs)' if mode=='main_serial' else before.replace(',count,count,false,',',count,1,false,') if mode=='one_worker' else before)
        generated=original.replace(before,after,1)
        assert generated.replace(after,before,1)==original
        (project/relative).write_bytes(generated.encode('utf-8'))
        identity['execution_control']=dict(mode=mode,parent_variant=parent,parent_run=label,
            only_execution_site_changed=True,original=original,generated=generated)
        identity['workspace_head']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()
        for row in identity['sources']:row['sha256']=trial.sha(project/row['path'])
        trial.write(trial.ROOT/(variant+'-identity.json'),identity)
        print(json.dumps(dict(prepared=variant,mode=mode)),flush=True)

def measure(args):
    trial.measure(args)
    parent,label,mode=CONFIG[args.variant]
    result=trial.read(trial.ROOT/(args.label+'-gp80.json'))
    expected=trial.read(PRIOR/(label+'.json'))
    selection=result['worker_select']
    thread_keys=list(selection['threads'])
    main=str(selection['last_batch']['main_thread_id'])
    last_threads={str(job['thread_id']) for job in selection['last_batch']['jobs']}
    checks=dict(same_original_query_counts=result['public']['query_counts']==expected['public']['query_counts'],
        same_work_accounting=all(selection[k]==expected['worker_select'][k] for k in ['batches','jobs','requested','processed','consumed','rejected','unused','failed_batches','reject_reasons']),
        intended_execution_thread=(thread_keys==[main] if mode=='main_serial' else len(last_threads)==1 and main not in thread_keys if mode=='one_worker' else len(last_threads)>1 and main not in thread_keys))
    trial.write(trial.ROOT/(args.label+'-gp80.execution-check.json'),dict(passed=all(checks.values()),checks=checks,
        mode=mode,reference=label,selection=selection,reference_selection=expected['worker_select'],metrics=result['metrics']))
    assert all(checks.values()),checks

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('action',choices=['prepare','measure'])
    p.add_argument('--variant',default='baselineserialshared')
    p.add_argument('--label',default='serialshared01')
    p.add_argument('--window',default='gp80')
    p.add_argument('--profile',default='plain')
    args=p.parse_args()
    assert args.window=='gp80' and args.profile=='plain'
    if args.action=='prepare':prepare()
    else:measure(args)
