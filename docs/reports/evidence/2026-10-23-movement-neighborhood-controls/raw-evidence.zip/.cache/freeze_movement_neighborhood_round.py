from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import zipfile

REPO=Path(__file__).resolve().parent.parent
ROOT=REPO/'.cache/movement-neighborhood-5a7d4b8-20261023'
PRIOR=REPO/'.cache/worker-select-afff405-20261023'
OUT=REPO/'docs/reports/evidence/2026-10-23-movement-neighborhood-controls'
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
digest=lambda b:hashlib.sha256(b).hexdigest()
sha=lambda p:digest(Path(p).read_bytes())
rel=lambda p:Path(p).relative_to(REPO).as_posix()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()
assert head=='5a7d4b8d89b725abfc9dbc5eceb3efb52fe7678a',head
subprocess.check_call(['git','diff','--exit-code','--','game','tests','project.godot'],cwd=REPO)
assert subprocess.check_output(['git','branch','--show-current'],cwd=REPO,text=True).strip()=='dev'
baseline=read(ROOT/'baseline-identity.json')
for row in baseline['sources']:
    if row['path'] not in ['project.godot','export_presets.cfg']:
        assert sha(REPO/row['path'])==row['sha256'],row['path']
for row in baseline['tests']:assert sha(REPO/row['path'])==row['sha256'],row['path']
parent=REPO/'docs/reports/evidence/2026-10-23-selection-worker-trial/raw-evidence.zip'
assert sha(parent)=='4d3a6cbc172cec69d000838a07ca87d070720c98d424d4e09d21bd2ae354046c'
baseline_rows={r['path']:r['sha256'] for r in baseline['sources']+baseline['tests']}
members={}
aliases=[]
def add(path,name=None):
    path=Path(path)
    name=name or rel(path)
    data=path.read_bytes()
    if name in members:assert members[name]==data,name
    members[name]=data

identities={}
for path in sorted(ROOT.glob('*-identity.json')):
    if path.name.endswith('-initial-identity.json'):continue
    variant=path.name.removesuffix('-identity.json')
    identity=read(path)
    project=ROOT/(variant+'-project')
    for key in ['sources','tests']:
        for row in identity[key]:
            source=project/row['path']
            assert sha(source)==row['sha256'],source
            if baseline_rows.get(row['path'])!=row['sha256']:
                member='source-blobs/'+row['sha256']+source.suffix
                add(source,member)
                aliases.append(dict(path=rel(source),member=member,sha256=row['sha256']))
    identities[variant]=dict(sources=len(identity['sources']),tests=len(identity['tests']),all_files_verified=True,
        execution_control=identity.get('execution_control',{}).get('mode'))

runs={}
intervals=[]
for path in sorted(ROOT.glob('*.semantic-check.json')):
    label=path.name.removesuffix('.semantic-check.json')
    check=read(path)
    assert check['passed'] and all(check['checks'].values()),label
    actual=read(ROOT/(label+'.json'))
    source=read(ROOT/(label+'.source-check.json'))
    launch=read(ROOT/(label+'.launch.json'))
    variant=source['variant']
    assert launch['exit_code']==0 and not launch['timed_out'] and not launch['errors'],label
    assert sha(launch['engine'])==launch['engine_sha256']
    assert source['actual_sources']==read(ROOT/(variant+'-identity.json'))['sources']
    assert actual['complete'] and actual['qualified'] and not actual['errors']
    assert len(actual['samples'])==actual['metrics']['count']==actual['requested_steps']
    assert all(s['present']==160 and s['complete'] for s in actual['samples'])
    assert sha(ROOT/(label+'.json.final.bin'))==actual['final_binary_sha256']
    extra={}
    if variant in ['baseline','baselinenearby']:
        extra=read(ROOT/(label+'.neighborhood-check.json'))
        assert extra['passed'] and all(extra['checks'].values())
    else:
        extra=read(ROOT/(label+'.execution-check.json'))
        assert extra['passed'] and all(extra['checks'].values())
    intervals.append((launch['started_at_utc'],launch['ended_at_utc'],label))
    runs[label]=dict(variant=variant,steps=actual['requested_steps'],metrics_us=actual['metrics'],checks=check['checks'],
        additional_checks=extra,selection=actual.get('worker_select',{}),query_count_differences=check['query_count_differences'],
        query_counts=actual['public']['query_counts'],input_sha256=actual['source_input_sha256'],final_binary_sha256=actual['final_binary_sha256'],
        process_cpu_ms=launch['child_cpu_ms'],process_wall_ms=launch['wall_ms'])
assert len(runs)==12 and sum(r['steps'] for r in runs.values())==1800
functional=read(ROOT/'functional01.acceptance-results.json')
assert functional['completed'] and functional['checks']==4 and functional['failed']==0
assert sorted(functional['results'])==['SPACE-46','SPACE-56','SPACE-57','STAFF-57']
door=functional['results']['SPACE-56']['details']['door_wait']
assert door['new_door_after_observation_seen'] and door['actual_arrival_after_owner_left']
launch=read(ROOT/'functional01.launch.json')
assert launch['exit_code']==0 and not launch['timed_out'] and not launch['errors']
intervals.append((launch['started_at_utc'],launch['ended_at_utc'],'functional01'))
intervals.sort()
for a,b in zip(intervals,intervals[1:]):assert a[1]<=b[0],(a,b)
for path in ROOT.iterdir():
    if path.is_file() and not path.name.endswith('.final.bin'):add(path)
for path in ROOT.glob('*.json.final.bin'):
    member='final-states/'+sha(path)+'.bin'
    add(path,member)
    aliases.append(dict(path=rel(path),member=member,sha256=sha(path)))
for name in ['movement_neighborhood_round.py','selection_execution_controls.py','worker_select_round.py']:
    add(REPO/'.cache'/name)
add(REPO/'.cache/wait-signature-031e1f7-20261022/run.py')
add(Path(__file__))
for name in ['public-v6.input.bin','gp.input.bin','op.input.bin']:add(REPO/'.cache/task-navigation-20261019'/name)
for label in ['d1-gp80','e1-gp80']:
    for suffix in ['.json','.semantic-check.json','.launch.json']:add(PRIOR/(label+suffix))
members['source-aliases.json']=(json.dumps(aliases,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
OUT.mkdir(parents=True,exist_ok=True)
archive=OUT/'raw-evidence.zip'
assert not archive.exists()
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(members.items()):z.writestr(name,data)
with zipfile.ZipFile(archive) as z:
    assert set(z.namelist())==set(members)
    for name,data in members.items():assert digest(z.read(name))==digest(data),name
manifest=dict(schema_version=1,archive_sha256=sha(archive),archive_bytes=archive.stat().st_size,
    members=[dict(path=k,bytes=len(v),sha256=digest(v)) for k,v in sorted(members.items())],
    baseline_reference=dict(path=rel(parent),sha256=sha(parent),note='References the complete baseline by the preceding archive chain.'))
summary=dict(schema_version=1,generated_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    baseline_commit=head,production_commit='5712c6f7fbc7e222e2a483bc376201352fd5ffc2',diagnostic_only=True,formal_pass=False,
    fixed_load=dict(people=160,patients=120,staff=32,visitors=8,floors=4,rooms=64,facilities=1336,tick_seconds=0.1),
    successful_performance_windows=len(runs),measured_steps=sum(r['steps'] for r in runs.values()),functional_engine_windows=1,
    all_engine_intervals_disjoint=True,production_and_tests_unchanged=True,identities=identities,runs=runs,
    functional=dict(experimental_variant='baselinenearby',cases=functional['results'],new_door_boundary=door,
        note='Experimental checks passed; neither production nor experimental tests were adopted because whole-step benefit was not established.'),
    adoption=dict(neighborhood_reuse=False,selection_worker=False),
    raw_archive=dict(path=rel(archive),sha256=sha(archive),bytes=archive.stat().st_size,members=len(members)),
    notes=['Same-job controls preserve every original query count and work-accounting field; only execution placement changes.',
        'Two-worker group time is lower than one-worker and paired main-serial controls; complete-window mean is not lower than paired main-serial controls.',
        'No operations window was added after the neighborhood trial failed to establish GP/public whole-step benefit.',
        'No Release, rendering, capacity, memory or two-hour formal acceptance run was performed.',
        'Process CPU includes startup and is not function CPU self time.'])
for name,value in [('raw-manifest.json',manifest),('summary.json',summary)]:
    path=OUT/name
    assert not path.exists()
    path.write_bytes((json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
print(json.dumps(dict(archive_sha256=sha(archive),bytes=archive.stat().st_size,members=len(members),windows=len(runs),steps=summary['measured_steps'])))
for label,r in runs.items():
    print(label,json.dumps(dict(mean_ms=r['metrics_us']['mean_us']/1000,p99_ms=r['metrics_us']['p99_us']/1000,
        process_cpu_ms=r['process_cpu_ms'],selection_wait_ms=r['selection'].get('timings_us',{}).get('dispatch_wait',0)/1000)))
