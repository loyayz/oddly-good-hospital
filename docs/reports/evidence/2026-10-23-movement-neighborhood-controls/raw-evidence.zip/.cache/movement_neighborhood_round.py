from pathlib import Path
from types import SimpleNamespace
import argparse
import importlib.util
import json
import shutil

REPO=Path(__file__).resolve().parent.parent
spec=importlib.util.spec_from_file_location('neighborhood_trial',REPO/'.cache/worker_select_round.py')
trial=importlib.util.module_from_spec(spec)
spec.loader.exec_module(trial)
trial.ROOT=REPO/'.cache/movement-neighborhood-5a7d4b8-20261023'

def patch_project(project):
    replacements={
        'game/building/hospital_space.gd':[
            ('func movement_doors(world: WorldState, actor: Dictionary, swept: Rect2, members: Array = [], floor_id: int = 0) -> Array[Dictionary]:',
             'func movement_doors(world: WorldState, actor: Dictionary, swept: Rect2, members: Array = [], floor_id: int = 0, reservation_regions: Variant = null) -> Array[Dictionary]:'),
            ('\tfor region: Dictionary in _reservation_regions(world,floor_id,swept):',
             '\tvar regions: Array = _reservation_regions(world,floor_id,swept) if reservation_regions==null else reservation_regions\n\tfor region: Dictionary in regions:')],
        'game/building/hospital_movement.gd':[
            ('\tvar doors: Array[Dictionary] = space.movement_doors(world,actor,swept,members)',
             '\tvar floor_id: int = int(actor.location.floor_id)\n\tvar reservations: Array = space._reservation_regions(world,floor_id,swept)\n\tvar doors: Array[Dictionary] = space.movement_doors(world,actor,swept,members,floor_id,reservations)'),
            ('\t_movement_contacts(world,actor.id,int(actor.location.floor_id),swept,sweeps,members,result)',
             '\t# With no door candidate, reservation ownership cannot change in this\n\t# attempt. Door processing retains a fresh query after possible acquisition.\n\t_movement_contacts(world,actor.id,floor_id,swept,sweeps,members,result,reservations if doors.is_empty() else null)'),
            ('func _movement_contacts(world: WorldState, actor_id: String, floor_id: int, broad: Rect2, sweeps: Array[BodyIndex.Record], members: Array, result: MotionResult) -> void:',
             'func _movement_contacts(world: WorldState, actor_id: String, floor_id: int, broad: Rect2, sweeps: Array[BodyIndex.Record], members: Array, result: MotionResult, reservation_regions: Variant = null) -> void:'),
            ('\tvar reservations: Array = space._reservation_regions(world,floor_id,broad)',
             '\tvar reservations: Array = space._reservation_regions(world,floor_id,broad) if reservation_regions==null else reservation_regions')],
        'tests/acceptance/movement_goal_wait.gd':[
            ('func _movement_contacts(world: WorldState, actor_id: String, floor_id: int, broad: Rect2, sweeps: Array[BodyIndex.Record], members: Array, result: HospitalMovement.MotionResult) -> void:',
             'func _movement_contacts(world: WorldState, actor_id: String, floor_id: int, broad: Rect2, sweeps: Array[BodyIndex.Record], members: Array, result: HospitalMovement.MotionResult, reservation_regions: Variant = null) -> void:'),
            ('\t\tsuper._movement_contacts(world,actor_id,floor_id,broad,sweeps,members,result)',
             '\t\tsuper._movement_contacts(world,actor_id,floor_id,broad,sweeps,members,result,reservation_regions)')],
        'tests/acceptance/movement_result.gd':[
            ('\tvar acquired: bool = recording._reserve_doors(',
             '''\tvar waiter: Dictionary = sim.world.facts.actors.door_waiter
\tvar passage: BodyIndex.Record = _sweep("door_waiter",sim.space.body_rectangle(waiter),sim.space._actor_rect(waiter,Vector2(x,y+0.1)))
\tvar passage_bounds: Rect2 = passage.sweep_from.merge(passage.sweep_to)
\tvar earlier: Array = sim.space._reservation_regions(sim.world,1,passage_bounds)
\tvar had_door: bool = false
\tfor region: Dictionary in earlier:
\t\tif str(region.reservation_id)==str(door.id): had_door = true
\tvar acquired: bool = recording._reserve_doors('''),
            ('\tvar requested: String = sim.space.request_move(sim.world,"door_waiter",1,[x,y-2])',
             '''\t# This is a read-only calculation from the actual acquired door state.
\t# An observation made before acquisition grants no later passage permission.
\tvar after_acquisition: HospitalMovement.MotionResult = HospitalMovement.MotionResult.new()
\tvar acquired_facts: Dictionary = sim.world.freeze()
\trecording._movement_contacts(sim.world,"door_waiter",1,passage_bounds,[passage],["door_waiter"],after_acquisition)
\tvar new_reservation_seen: bool = not had_door and after_acquisition.reservation_ids.has(str(door.id)) and after_acquisition.blocked and sim.world.freeze()==acquired_facts
\tvar requested: String = sim.space.request_move(sim.world,"door_waiter",1,[x,y-2])'''),
            ('"ok":door.axis=="x" and acquired and requested.is_empty()',
             '"ok":door.axis=="x" and acquired and new_reservation_seen and requested.is_empty()'),
            ('"normal_owner_acquisition":acquired,',
             '"normal_owner_acquisition":acquired,"new_door_after_observation_seen":new_reservation_seen,"new_door_contact_reservations":after_acquisition.reservation_ids.duplicate(),')]
    }
    patches=[]
    for relative,changes in replacements.items():
        original=(project/relative).read_text(encoding='utf-8')
        generated=original
        for before,after in changes:
            assert generated.count(before)==1,(relative,before,generated.count(before))
            generated=generated.replace(before,after,1)
        restored=generated
        for before,after in reversed(changes):
            assert restored.count(after)==1,(relative,after)
            restored=restored.replace(after,before,1)
        assert restored==original,relative
        (project/relative).write_bytes(generated.encode('utf-8'))
        patches.append(dict(path=relative,original=original,generated=generated,inverse_equal=True))
    return patches

def prepare():
    for variant in ['baseline','baselinenearby']:
        trial.prepare(SimpleNamespace(variant=variant,tasks=4))
        if variant=='baseline':continue
        project=trial.ROOT/(variant+'-project')
        patches=patch_project(project)
        path=trial.ROOT/(variant+'-identity.json')
        identity=trial.read(path)
        identity['patches']=patches
        for key in ['sources','tests']:
            for row in identity[key]:row['sha256']=trial.sha(project/row['path'])
        path.rename(path.with_name(variant+'-initial-identity.json'))
        trial.write(path,identity)

def measure(args):
    trial.measure(args)
    path=trial.ROOT/(args.label+'-'+args.window+'.semantic-check.json')
    result=trial.read(path)
    changes=result['query_count_differences']
    checks=dict(all_semantic_checks=result['passed'],
        only_reservation_query_count_changed=set(changes)<={'reservation_candidate_queries'})
    if args.variant=='baselinenearby':
        count=changes['reservation_candidate_queries']
        checks['fewer_duplicate_queries']=count['actual']<count['expected']
    trial.write(path.with_name(path.name.replace('.semantic-check.json','.neighborhood-check.json')),
        dict(passed=all(checks.values()),checks=checks,changes=changes))
    assert all(checks.values()),checks

def functional(args):
    project=trial.ROOT/(args.variant+'-project')
    identity=trial.read(trial.ROOT/(args.variant+'-identity.json'))
    for key in ['sources','tests']:
        for row in identity[key]:assert trial.sha(project/row['path'])==row['sha256'],row['path']
    launcher=trial.module(REPO/'.cache/wait-signature-031e1f7-20261022/run.py','nearby_cases')
    launcher.ROOT=trial.ROOT
    prefix=trial.ROOT/args.label
    cases=['SPACE-46','SPACE-56','SPACE-57','STAFF-57']
    launcher.launch(['--headless','--path',project,'--script','res://tests/acceptance/runner.gd','--','space','staff',
        *['--case='+case for case in cases]],prefix)
    output=project/'acceptance-results.json'
    destination=prefix.with_suffix('.acceptance-results.json')
    assert not destination.exists()
    shutil.copy2(output,destination)
    result=trial.read(destination)
    assert result['completed'] and result['checks']==len(cases) and result['failed']==0
    assert sorted(result['results'])==sorted(cases)
    print(json.dumps(dict(passed=True,cases={key:dict(body_ms=value['body_ms'],setup_ms=value['setup_ms']) for key,value in result['results'].items()})))

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('action',choices=['prepare','measure','functional'])
    p.add_argument('--variant',default='baseline')
    p.add_argument('--label',default='a1')
    p.add_argument('--window',default='gp80')
    p.add_argument('--profile',default='plain')
    args=p.parse_args()
    if args.action=='prepare':prepare()
    elif args.action=='measure':measure(args)
    else:functional(args)
