extends RefCounted

# Experimental read-only selection jobs. Nothing here owns an intent, movement,
# reservation or actual use. Every AStar and derived WorldState index is private.
class JobNavigation extends NavigationCache:
	var allowance: int = 0
	func _trim(target: int, counts: Dictionary = {}) -> void:
		super._trim(mini(target,allowance),counts)

class SelectionJob extends RefCounted:
	var space: HospitalSpace
	var world: WorldState
	var requests: Array = []
	var results: Array = []
	var processed: int = 0
	var thread_id: int = 0
	var elapsed_us: int = 0
	var peak_charge: int = 0
	var allowance: int = 0
	func prepare(content: HospitalContent, source: WorldState, actors: Array, definitions: Array, room_kinds: Array, sweeps: Array, budget: int, origin: HospitalSpace) -> void:
		space = HospitalSpace.new(content)
		var navigation: JobNavigation = JobNavigation.new()
		navigation.allowance = budget
		space._navigation = navigation
		world = WorldState.new(source.facts.duplicate())
		world.geometry_revision = source.geometry_revision
		# Only completed immutable region/source leaves cross the barrier.
		# Mutable lookup containers, graph/AStar objects and permissions stay private.
		var areas: HospitalPublicAreas = space.public_areas
		areas._world = weakref(world)
		areas._revision = world.geometry_revision
		areas._regions = origin.public_areas._regions.duplicate()
		areas._regions_by_definition = origin.public_areas._regions_by_definition.duplicate()
		areas._by_facility = origin.public_areas._by_facility.duplicate()
		areas._derived_floors = origin.public_areas._derived_floors.duplicate()
		areas._floor_regions = origin.public_areas._floor_regions.duplicate()
		var constraints: Dictionary = origin.public_areas._wait_constraints(source)
		areas._wait_geometry = {"points":constraints.points,"doors":constraints.doors}
		for floor_id: int in areas._derived_floors:
			var original: Dictionary = origin._navigation._sources[str(source.get_instance_id())+":"+str(floor_id)]
			navigation._sources[str(world.get_instance_id())+":"+str(floor_id)] = {"source":original.source,"static_source":original.static_source,"version":original.version,"static_version":original.static_version,"world":weakref(world),"floor_id":floor_id,"revision":world.geometry_revision,"graphs":{}}
		navigation._source_version = origin._navigation._source_version
		navigation._static_source_version = origin._navigation._static_source_version
		requests = []
		for actor_id: String in actors: requests.append({"actor_id":actor_id,"definitions":definitions,"room_kinds":room_kinds})
		results = []
		results.resize(requests.size())
		for row: Array in sweeps: space.movement._sweep_index.update(row[0],row[1],row[2])
		allowance = budget
	func run() -> void:
		var started: int = Time.get_ticks_usec()
		for index: int in requests.size():
			var request: Dictionary = requests[index]
			space.begin_dynamic_route_query(world,index==0)
			var selection: Dictionary = space.public_areas.select(world,request.actor_id,request.definitions,request.room_kinds,"seat")
			space.end_route_query()
			results[index] = {"selection":selection,"floors":space.navigation.observed_floors(world,[request.actor_id])}
			processed += 1
			peak_charge = maxi(peak_charge,space._navigation._charged+space._navigation._query_charged)
		elapsed_us = Time.get_ticks_usec()-started
		thread_id = OS.get_thread_caller_id()

var _world: WeakRef
var _tick: int = -1
var _geometry: int = -1
var _basis: Dictionary = {}
var _observations: Dictionary = {}
var _definitions: Array = []
var _last: Dictionary = {}
var _stats: Dictionary = {"batches":0,"jobs":0,"requested":0,"processed":0,"consumed":0,"rejected":0,"unused":0,"failed_batches":0,"threads":{},"timings_us":{},"reject_reasons":{}}

func _public_facilities(world: WorldState) -> Array:
	var rows: Array = []
	for definition: String in _definitions:
		for id: String in world.facility_ids(definition): rows.append([id,world.facts.facilities[id].get("failed",false)])
	return rows

func _transport(world: WorldState) -> Dictionary:
	var moves: Dictionary = {}
	for id: String in world.facts.moves:
		var movement: Dictionary = world.facts.moves[id]
		if movement.has("transit_ticket"): moves[id] = movement
	for connection: Dictionary in world.facts.connectors.values():
		if not connection.phase in ["boarding","riding","alighting"]: continue
		var primary: String = str(connection.get("primary_actor_id",connection.riders[0]))
		moves[primary] = world.facts.moves.get(primary,{})
	return moves

func _sweeps(source: HospitalSpace) -> Array:
	var result: Array = []
	var index: BodyIndex = source.movement._sweep_index
	for record: BodyIndex.Record in index._records.values():
		if record.boundary==index._boundary: result.append([record.id,record.floor_id,record.rect])
	return result

func prepare(world: WorldState, source: HospitalSpace, actor_ids: Array, definitions: Array, room_kinds: Array, task_count: int) -> bool:
	_observations = {}
	_basis = {}
	_world = null
	if actor_ids.size()<2: return false
	var started: int = Time.get_ticks_usec()
	var total_budget: int = int(source.content.balance.pathfinding.graph_cache_target_bytes)
	var main_charge: int = source._navigation._charged+source._navigation._query_charged
	var available: int = total_budget
	var count: int = mini(4,mini(maxi(1,task_count),actor_ids.size()))
	if available<count: return false
	_world = weakref(world)
	_tick = world.sim_tick
	_geometry = world.geometry_revision
	_definitions = definitions
	_basis = {"actors":world.facts.actors.duplicate(true),"adaptations":world.facts.adaptations.duplicate(true),
		"connectors":world.facts.connectors.duplicate(true),"transport":_transport(world).duplicate(true),
		"rooms":world.facts.rooms.duplicate(true),"remodels":world.facts.get("remodels",{}).duplicate(true),
		"research":world.facts.research.duplicate(true),"personal_beds":world.facts.get("staff_life",{}).get("personal_beds",{}).duplicate(true),
		"facilities":_public_facilities(world),"sweeps":_sweeps(source),"content":source.content.content_fingerprint}
	source.public_areas._ensure(world)
	for area: Dictionary in source.public_areas._candidate_regions(definitions):
		# Complete the sole lazy mutation of a derived region before sharing it.
		source.public_areas._entry_geometry_view(world,world.facts.actors[actor_ids[0]],area)
	source.public_areas._wait_constraints(world)
	for floor_id: int in source.public_areas._derived_floors: source._navigation.floor_source(source,world,floor_id)
	var jobs: Array = []
	for index: int in count:
		var job: SelectionJob = SelectionJob.new()
		job.prepare(source.content,world,actor_ids.slice(actor_ids.size()*index/count,actor_ids.size()*(index+1)/count),definitions,room_kinds,_basis.sweeps,available/count,source)
		jobs.append(job)
	# The main thread has no open route query at this dispatch boundary. Move
	# exclusive AStar/cache ownership to job zero until the completion barrier.
	var lent: JobNavigation = jobs[0].space._navigation
	lent._entries = source._navigation._entries
	lent._charged = source._navigation._charged
	lent._query_charged = source._navigation._query_charged
	lent._used = source._navigation._used
	source._navigation._entries = {}
	source._navigation._charged = 0
	source._navigation._query_charged = 0
	lent._trim(total_budget,source.query_counts)
	_stats.timings_us["preparation"] = int(_stats.timings_us.get("preparation",0))+Time.get_ticks_usec()-started
	started = Time.get_ticks_usec()
	var group: int = WorkerThreadPool.add_group_task(_run_job.bind(jobs),count,1,false,"Public seat area selection")
	WorkerThreadPool.wait_for_group_task_completion(group)
	_stats.timings_us["dispatch_wait"] = int(_stats.timings_us.get("dispatch_wait",0))+Time.get_ticks_usec()-started
	started = Time.get_ticks_usec()
	var valid: bool = true
	var processed: int = 0
	var rows: Array = []
	var peak_sum: int = 0
	for index: int in count:
		var job: SelectionJob = jobs[index]
		valid = valid and job.processed==job.requests.size() and job.results.size()==job.requests.size()
		processed += job.processed
		peak_sum += job.peak_charge
		rows.append({"job":index,"thread_id":job.thread_id,"requested":job.requests.size(),"processed":job.processed,"elapsed_us":job.elapsed_us,"peak_charge":job.peak_charge,"allowance":job.allowance})
		for number: int in job.requests.size():
			var item: Variant = job.results[number]
			if not item is Dictionary or not item.get("selection") is Dictionary or not item.get("floors") is Array:
				valid = false
				continue
			_observations[str(job.requests[number].actor_id)] = item
		for key: String in job.space.query_counts:
			source.query_counts[key] = int(source.query_counts.get(key,0))+int(job.space.query_counts[key])
		# Queries have ended and workers are complete. Keep resident entries in
		# the original cache; duplicate keys retain job zero's warmed object.
		for key: String in job.space._navigation._entries:
			if source._navigation._entries.has(key): continue
			var entry: Dictionary = job.space._navigation._entries[key]
			source._navigation._entries[key] = entry
			source._navigation._charged += int(entry.charge)
			source._navigation._query_charged += int(entry.get("query_charge",0))
			source._navigation._used = maxi(source._navigation._used,int(entry.used))
		job.space._navigation._entries = {}
		job.space._navigation._charged = 0
		job.space._navigation._query_charged = 0
		var thread: String = str(job.thread_id)
		_stats.threads[thread] = int(_stats.threads.get(thread,0))+1
		job.space = null
		job.world = null
	source._navigation._trim(total_budget,source.query_counts)
	valid = valid and processed==actor_ids.size() and _observations.size()==actor_ids.size() and peak_sum<=total_budget
	_stats.batches += 1
	_stats.jobs += count
	_stats.requested += actor_ids.size()
	_stats.processed += processed
	_last = {"ok":valid,"group_id":group,"main_thread_id":OS.get_main_thread_id(),"requested":actor_ids.size(),"processed":processed,"jobs":rows,"peak_charge_sum":peak_sum,"total_budget":total_budget}
	_stats.timings_us["harvest"] = int(_stats.timings_us.get("harvest",0))+Time.get_ticks_usec()-started
	if not valid:
		_stats.failed_batches += 1
		_observations = {}
	return valid

func _run_job(index: int, jobs: Array) -> void:
	(jobs[index] as SelectionJob).run()

func consume(world: WorldState, source: HospitalSpace, actor_id: String) -> Dictionary:
	if not _observations.has(actor_id): return {}
	var started: int = Time.get_ticks_usec()
	var reason: String = ""
	if _world==null or _world.get_ref()!=world or _tick!=world.sim_tick: reason = "world_tick"
	elif _geometry!=world.geometry_revision: reason = "geometry"
	elif _basis.actors!=world.facts.actors: reason = "actors"
	elif _basis.adaptations!=world.facts.adaptations: reason = "adaptations"
	elif _basis.connectors!=world.facts.connectors or _basis.transport!=_transport(world): reason = "transport"
	elif _basis.rooms!=world.facts.rooms or _basis.remodels!=world.facts.get("remodels",{}): reason = "rooms_remodels"
	elif _basis.research!=world.facts.research or _basis.personal_beds!=world.facts.get("staff_life",{}).get("personal_beds",{}): reason = "permissions"
	elif _basis.facilities!=_public_facilities(world): reason = "facilities"
	elif _basis.sweeps!=_sweeps(source) or _basis.content!=source.content.content_fingerprint: reason = "sweeps_content"
	_stats.timings_us["validation"] = int(_stats.timings_us.get("validation",0))+Time.get_ticks_usec()-started
	var result: Dictionary = _observations[actor_id]
	_observations.erase(actor_id)
	if not reason.is_empty():
		_stats.rejected += 1
		_stats.reject_reasons[reason] = int(_stats.reject_reasons.get(reason,0))+1
		return {}
	for floor_id: int in result.floors: source.navigation._observe_floor(world,actor_id,floor_id)
	_stats.consumed += 1
	return {"ready":true,"selection":result.selection}

func finish() -> void:
	_stats.unused += _observations.size()
	_observations = {}
	_basis = {}
	_world = null

func report() -> Dictionary:
	var result: Dictionary = _stats.duplicate(true)
	result.last_batch = _last.duplicate(true)
	return result
