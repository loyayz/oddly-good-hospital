param([string]$FinalAcceptance)
$ErrorActionPreference='Stop'
$taskRoot=Split-Path -Parent $PSCommandPath
$repo=[IO.Path]::GetFullPath((Join-Path $taskRoot '../..'))
$evidence=Join-Path $repo 'docs/reports/evidence/2026-10-20-public-facility-phase-reuse'
function ReadJson([string]$p){ Get-Content -Raw -LiteralPath $p | ConvertFrom-Json -AsHashtable }
function SaveJson([string]$name,$data){ $data | ConvertTo-Json -Depth 60 | Set-Content -LiteralPath (Join-Path $evidence $name) -Encoding utf8NoBOM }
$runs=[ordered]@{}
foreach($prefix in 'before','after'){
 foreach($scene in 'public','gp','operations','public360'){
  $path=Join-Path $taskRoot ($prefix+'-'+$scene+'.json')
  $r=ReadJson $path
  if(-not $r.complete -or -not $r.qualified){throw 'Cannot summarize unqualified performance run'}
  $publicAll=($scene -notin @('public','public360')) -or (@($r.public_checks.Values | Where-Object {$_ -ne $true}).Count -eq 0)
  if(-not $publicAll){throw 'Public result checks incomplete'}
  $pub=$r.public
  $runs[$prefix+'-'+$scene]=[ordered]@{source_input_sha256=$r.source_input_sha256;metrics_us=$r.metrics;complete=$r.complete;qualified=$r.qualified;qualification=$r.qualification;public_checks=$r.public_checks;public_checks_all=$publicAll;execution=$r.execution;initial=@{tick=$r.initial.tick;patients=$r.initial.active_patients;staff=$r.initial.staff;visitors=$r.initial.present_visitors;present=$r.initial.present;rooms=$r.initial.rooms;facilities=$r.initial.facilities};final=@{tick=$r.final.tick;present=$r.final.present;minimum_present=$r.final.minimum_present;maximum_present=$r.final.maximum_present;work_ticks_by_kind=$r.final.work_ticks_by_kind;services_started=$r.final.services_started;services_completed=$r.final.services_completed;validation=$r.final.validation};public=@{use_starts=$pub.actual_use_starts.Count;use_completions=$pub.actual_use_completions.Count;use_ticks=$pub.actual_use_ticks;exit_then_reuse=$pub.actual_exit_then_reuse_count;queued_actors=$pub.actual_queued_actors.Count;queue_peak=$pub.queue_peak;queue_actor_ticks=$pub.queue_actor_ticks;used_regions=$pub.used_regions;fallback_starts=$pub.fallback_starts.Count};query_counts=$pub.query_counts;operations=$r.operations;final_sha256=(Get-FileHash -LiteralPath ($path+'.final.bin')).Hash.ToLowerInvariant()}
 }
}
$changes=foreach($scene in 'public','gp','operations','public360'){
 $b=$runs['before-'+$scene];$a=$runs['after-'+$scene]
 if($a.source_input_sha256 -ne $b.source_input_sha256){throw 'Input mismatch'}
 [ordered]@{scene=$scene;mean_percent=100*($a.metrics_us.mean_us/$b.metrics_us.mean_us-1);p95_percent=100*($a.metrics_us.p95_us/$b.metrics_us.p95_us-1);max_percent=100*($a.metrics_us.max_us/$b.metrics_us.max_us-1);final_binary_equal=$a.final_sha256 -eq $b.final_sha256}
}
$failed=ReadJson (Join-Path $taskRoot 'before-public380.json')
SaveJson 'quick-summary.json' ([ordered]@{scope='Fixed legal 160; ordinary complete steps; headless/debug; formal acceptance paused';baseline_dev='913cebef20696b324be4a70268508681d324339e';order='before public/gp/operations; after public/gp/operations; before public380 failed, after public380 not run; before public360, after public360; separate cold services, no concurrent heavy runs';runs=$runs;changes=$changes;failed_runs=@{before_public380=@{complete=$failed.complete;qualified=$failed.qualified;qualification=$failed.qualification;errors=$failed.errors;metrics_us=$failed.metrics;requested_steps=$failed.requested_steps;final_present=$failed.final.present};after_public380=@{executed=$false;reason='Baseline exceeded fixed160 at original arrival tick3001; stopped pair before after run'}}})
$batches=@('2672cd42a94b4945a124a7a52ef23f5b','351d25a9215343a2b902b75564eece4f','ddaf5c120d1948f8aa6dd2a4b1d6fd8b','adb62d2b916d440baf88b10352f9e257','6d550e3bffc94d17a2466899e04d2320',$FinalAcceptance)
$functional=foreach($id in $batches){
 $dir=Join-Path $repo ('.cache/acceptance/'+$id)
 $result=if(Test-Path (Join-Path $dir 'acceptance-results.json')){ReadJson (Join-Path $dir 'acceptance-results.json')}else{@{}}
 [ordered]@{batch=$id;requested_cases=$result.requested_cases;checks=$result.checks;failed=$result.failed;completed=$result.completed;timing=(ReadJson (Join-Path $dir 'timing-summary.json'));status=if(Test-Path (Join-Path $dir 'execution-status.json')){ReadJson (Join-Path $dir 'execution-status.json')}else{@{phase='not_executed_import_failed'}};results=if($result.ContainsKey('results')){@($result.results.GetEnumerator()|ForEach-Object{[ordered]@{case=$_.Key;passed=$_.Value.passed;body_ms=$_.Value.body_ms}})}else{@()}}
}
SaveJson 'functional-summary.json' ([ordered]@{scope='Selected affected cases only';batches=$functional;final_batch=$FinalAcceptance})
$afterIdentity=ReadJson (Join-Path $taskRoot 'after-project/source-identity.json')
$beforeIdentity=ReadJson (Join-Path $repo '.cache/motion-result-20261020/after-project/source-identity.json')
$finalIdentity=ReadJson (Join-Path $repo ('.cache/acceptance/'+$FinalAcceptance+'/source-identity.json'))
$mismatch=@();$compared=0
foreach($row in $afterIdentity.source){
 if($row.path -notmatch '^(game/|content/|tools/performance/)'){continue}
 $compared++
 if((Get-FileHash -LiteralPath (Join-Path $repo $row.path)).Hash.ToLowerInvariant() -ne $row.sha256){$mismatch+=$row.path}
 $accepted=@($finalIdentity.source|Where-Object path -EQ $row.path)
 if($accepted.Count -ne 1 -or $accepted[0].sha256 -ne $row.sha256){$mismatch+='acceptance:'+ $row.path}
}
if($mismatch.Count){throw ('Source mismatch '+($mismatch -join ','))}
$testCount=0
foreach($row in $finalIdentity.source){
 if($row.path -notmatch '^tests/acceptance/'){continue}
 $testCount++
 if((Get-FileHash -LiteralPath (Join-Path $repo $row.path)).Hash.ToLowerInvariant() -ne $row.sha256){$mismatch+='test:'+ $row.path}
}
if($mismatch.Count){throw ('Test source mismatch '+($mismatch -join ','))}
if($beforeIdentity.engine_sha256 -ne $afterIdentity.engine_sha256 -or $beforeIdentity.native_sha256 -ne $afterIdentity.native_sha256 -or $afterIdentity.engine_sha256 -ne $finalIdentity.engine_sha256 -or $afterIdentity.native_sha256 -ne $finalIdentity.native_sha256){throw 'Runtime identity mismatch'}
SaveJson 'source-check.json' ([ordered]@{baseline=(ReadJson (Join-Path $taskRoot 'baseline-identity.json'));after_prepared=$afterIdentity.project;final_acceptance=$FinalAcceptance;compared_paths=$compared;compared_test_paths=$testCount;mismatches=$mismatch;engine_sha256=$afterIdentity.engine_sha256;native_sha256=$afterIdentity.native_sha256;engine_matches_baseline=$beforeIdentity.engine_sha256 -eq $afterIdentity.engine_sha256;native_matches_baseline=$beforeIdentity.native_sha256 -eq $afterIdentity.native_sha256;engine_matches_final_acceptance=$afterIdentity.engine_sha256 -eq $finalIdentity.engine_sha256;native_matches_final_acceptance=$afterIdentity.native_sha256 -eq $finalIdentity.native_sha256;after_source_identity='raw-evidence.zip:sources/after-identity.json'})
$files=[ordered]@{}
foreach($f in Get-ChildItem -LiteralPath $taskRoot -File){if($f.Name -ne 'pack-evidence.ps1'){$files['quick/'+$f.Name]=$f.FullName}}
$files['quick/pack-evidence.ps1']=$PSCommandPath
$files['sources/after-identity.json']=Join-Path $taskRoot 'after-project/source-identity.json'
$files['sources/after-import.log']=Join-Path $taskRoot 'after-project/import.log'
$files['sources/before-identity.json']=Join-Path $repo '.cache/motion-result-20261020/after-project/source-identity.json'
foreach($name in 'gp.input.bin','op.input.bin','public-v6.input.bin'){$files['inputs/'+$name]=Join-Path $repo ('.cache/task-navigation-20261019/'+$name)}
foreach($id in $batches){foreach($name in 'source-identity.json','fixture-config.json','import.log','execution.log','acceptance-results.json','timing-summary.json','execution-status.json'){ $p=Join-Path $repo ('.cache/acceptance/'+$id+'/'+$name);if(Test-Path -LiteralPath $p){$files['functional/'+$id+'/'+$name]=$p}}}
$changed=@(& git -C $repo diff --name-only)
foreach($relative in $changed){if($relative -match '^(game/|tests/acceptance/)'){$files['sources/after/'+$relative]=Join-Path $repo $relative;$prior=Join-Path $repo ('.cache/motion-result-20261020/after-project/'+$relative);if(Test-Path -LiteralPath $prior){$files['sources/before/'+$relative]=$prior}}}
$files['sources/after/tests/acceptance/public_phase_use.gd']=Join-Path $repo 'tests/acceptance/public_phase_use.gd'
$zipPath=Join-Path $evidence 'raw-evidence.zip'
if(Test-Path -LiteralPath $zipPath){throw 'Refusing to replace evidence archive'}
$stream=[IO.File]::Open($zipPath,[IO.FileMode]::CreateNew)
$zip=[IO.Compression.ZipArchive]::new($stream,[IO.Compression.ZipArchiveMode]::Create)
$manifest=try {foreach($entry in $files.GetEnumerator()){
 $file=Get-Item -LiteralPath $entry.Value
 $item=$zip.CreateEntry($entry.Key,[IO.Compression.CompressionLevel]::Optimal)
 $inputStream=[IO.File]::OpenRead($file.FullName);$outputStream=$item.Open()
 try{$inputStream.CopyTo($outputStream)}finally{$inputStream.Dispose();$outputStream.Dispose()}
 [ordered]@{entry=$entry.Key;bytes=$file.Length;sha256=(Get-FileHash -LiteralPath $file.FullName).Hash.ToLowerInvariant()}
}}finally{$zip.Dispose();$stream.Dispose()}
SaveJson 'raw-manifest.json' ([ordered]@{archive='raw-evidence.zip';archive_bytes=(Get-Item -LiteralPath $zipPath).Length;archive_sha256=(Get-FileHash -LiteralPath $zipPath).Hash.ToLowerInvariant();files=@($manifest)})
$changes|ConvertTo-Json
