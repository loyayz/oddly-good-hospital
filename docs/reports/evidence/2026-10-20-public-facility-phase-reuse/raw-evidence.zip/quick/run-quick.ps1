param([string]$Project,[string]$Prefix='after')
$ErrorActionPreference='Stop'
$taskRoot = Split-Path -Parent $PSCommandPath
$repo = [IO.Path]::GetFullPath((Join-Path $taskRoot '../..'))
$engine = 'C:/programs/godot/Godot_v4.7.2-stable_win64_console.exe'
$scenes = @(@{Name='public';Input='public-v6.input.bin';Steps=300},@{Name='gp';Input='gp.input.bin';Steps=80},@{Name='operations';Input='op.input.bin';Steps=40})
foreach ($scene in $scenes) {
    $inputPath = Join-Path $repo ('.cache/task-navigation-20261019/'+$scene.Input)
    $outputPath = Join-Path $taskRoot ($Prefix+'-'+$scene.Name+'.json')
    $logPath = Join-Path $taskRoot ($Prefix+'-'+$scene.Name+'.log')
    if (Test-Path -LiteralPath $logPath) {throw 'Refusing to replace timing log'}
    & $engine --headless --path $Project --script res://tools/performance/representative.gd -- ('--input='+$inputPath) ('--output='+$outputPath) ('--steps='+$scene.Steps) --profile=plain *> $logPath
    $runExit = $LASTEXITCODE
    Get-Content -LiteralPath $logPath -Tail 1
    if ($runExit -ne 0 -or (Select-String -LiteralPath $logPath -Pattern 'SCRIPT ERROR:|ERROR:' -Quiet)) {throw ('Representative failed '+$scene.Name+' exit='+$runExit)}
    $report = Get-Content -Raw -LiteralPath $outputPath | ConvertFrom-Json
    if (-not $report.complete -or -not $report.qualified) {throw ('Unqualified '+$scene.Name)}
    if ($scene.Name -eq 'public' -and @($report.public_checks.PSObject.Properties | Where-Object Value -NE $true).Count -gt 0) {throw 'Public outcome check failed'}
}