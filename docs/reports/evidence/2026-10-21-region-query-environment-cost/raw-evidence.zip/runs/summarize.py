import hashlib
import json
import pathlib
import re
import statistics
import subprocess
import zipfile

REPO = pathlib.Path(r'C:\code\loyayz\oddly-good-hospital')
ROOT = pathlib.Path(__file__).resolve().parent
OUT = REPO / 'docs/reports/evidence/2026-10-21-region-query-environment-cost'
BASE = '87af6a6ad04a8e1eb2b84e8d237af0a9d89d5703'
OUT.mkdir(parents=True, exist_ok=True)


def read(p):
    return json.loads(pathlib.Path(p).read_text(encoding='utf-8-sig'))


def sha(p):
    return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()


def dump(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf8')


def measured(name):
    d = read(ROOT / (name + '.json'))
    assert d['qualified'] and d['complete'] and not d['errors'], name
    assert all(d.get('public_checks', {}).values()), name
    return dict(run=name, metrics=d['metrics'], execution=d['execution'], qualification=d['qualification'],
                final_hash=d['final_binary_sha256'], input_sha256=d['source_input_sha256'],
                work=d['final']['work_ticks_by_kind'], query_counts=d['public']['query_counts'],
                public_work={k: d['public'][k] for k in ['actual_use_ticks', 'queue_actor_ticks', 'actual_exit_then_reuse_count']},
                starts=len(d['public']['actual_use_starts']), completions=len(d['public']['actual_use_completions']),
                operations=d['operations'])


windows = []
for window in ['public360', 'gp80', 'operations40']:
    groups = {}
    for kind, labels in [('controlled_engine', ['ca', 'cb', 'cc', 'cd']),
                         ('default_final', ['fa', 'fb', 'fc', 'fd']),
                         ('invalid_wrapper_affinity', ['pa', 'pb', 'pc', 'pd']),
                         ('withdrawn_door_only', ['a', 'b'])]:
        rows = [measured(x + '-' + window) for x in labels]
        baseline_ids = [0, 3] if len(rows) == 4 else [0]
        after_ids = [1, 2] if len(rows) == 4 else [1]
        before = statistics.mean(rows[i]['metrics']['mean_us'] for i in baseline_ids)
        after = statistics.mean(rows[i]['metrics']['mean_us'] for i in after_ids)
        if kind == 'controlled_engine':
            for r in rows:
                launch = read(ROOT / (r['run'] + '.launch.json'))
                assert launch['actual_mask'] == launch['chosen_mask'] == 1 and launch['child_cpu_ms'] >= 1000
                assert launch['affinity_target'] == 'engine_executable' and launch['exit_code'] == 0
                r['launch'] = launch
        groups[kind] = dict(runs=rows, before_mean_us=before, after_mean_us=after,
                            mean_difference_percent=(after / before - 1) * 100)
    rows = [r for group in groups.values() for r in group['runs']]
    assert len({r['final_hash'] for r in rows}) == 1
    assert len({r['input_sha256'] for r in rows}) == 1
    assert all(r['work'] == rows[0]['work'] and r['public_work'] == rows[0]['public_work'] and
               r['starts'] == rows[0]['starts'] and r['completions'] == rows[0]['completions'] and
               r['operations'] == rows[0]['operations'] for r in rows)
    windows.append(dict(window=window, whole_world_equal=True, groups=groups))
dump('quick-summary.json', dict(baseline=BASE, formal_pass=False, formal_acceptance_paused=True, windows=windows,
     caution='All windows retain 160 actors and the original operations. Controlled engine runs constrain the actual engine executable to one logical processor without changing priority; they are supplementary quick diagnosis, not the default machine or a Release result. Default windows vary substantially. pa/pb/pc/pd and pinned-* constrained only the console launcher, NOT the engine, and are invalid affinity controls. Door-only experiment was withdrawn. Percentiles are not pooled; whole-step effects belong only to plain runs.'))

profiles = []
for prefix in ['before-all', 'after-all', 'pinned-before-all', 'pinned-after-all', 'controlled-before-all', 'controlled-after-all', 'door-all']:
    for window in ['public360', 'gp80', 'operations40']:
        name = prefix + '-' + window
        if not (ROOT / (name + '.json')).exists():
            continue
        d = read(ROOT / (name + '.json'))
        p = d['profile']
        assert d['qualified'] and d['complete'] and not d['errors'] and not p['errors'], name
        assert d['final_binary_sha256'] == read(ROOT / ('ca-' + window + '.json'))['final_binary_sha256']
        indices = {s['tick']: s['index'] for s in d['samples']}
        steps = [dict(index=indices[s['tick']], tick=s['tick'], outer_us=s['outer_elapsed_us'],
                      observer_us=s['observer_handler_us'], stages=s['stages'], calls=s['calls'])
                 for s in p['step_records'] if s['calls']]
        profiles.append(dict(run=name, invalid_affinity_control=prefix.startswith('pinned-'),
                             hash=d['final_binary_sha256'], errors=p['errors'], steps=steps))
dump('function-summary.json', dict(profiles=profiles,
     caution='Instrumentation is diagnostic and perturbs timing. Inclusive time includes child calls; do not add overlapping costs. After source introduces three helpers while preserving every original body. pinned-* is an invalid engine affinity control, retained as ordinary noisy observations.'))

batches = []
for line in (ROOT / 'batches.txt').read_text(encoding='utf8').splitlines():
    if not line.strip():
        continue
    directory = REPO / '.cache/acceptance' / line.strip()
    result = directory / 'acceptance-results.json'
    log = (directory / 'execution.log').read_text(encoding='utf-8-sig')
    declared_results = re.findall(r'^CASE ([A-Z]+-\d+) (PASS|FAIL)', log, re.M)
    batches.append(dict(batch=line.strip(), result=read(result) if result.exists() else None,
                        original_execution_log_case_results=declared_results,
                        timing=read(directory / 'timing-summary.json'), execution=read(directory / 'execution-status.json')))
assert len(batches) == 4
assert len(batches[1]['original_execution_log_case_results']) == 19
assert all(x[1] == 'PASS' for x in batches[1]['original_execution_log_case_results'])
assert batches[-1]['result']['checks'] == 19 and batches[-1]['result']['failed'] == 0 and batches[-1]['result']['completed']
assert not batches[-1]['execution']['script_errors'] and batches[-1]['execution']['test_exit'] == 0
dump('functional-summary.json', dict(batches=batches, formal_pass=False,
     caution='First batch: 18/19 assertions passed; new STAFF-75 room fixture invalid, then repaired legally. Second batch original execution log records all 19 PASS, but process exit leaked 48 objects/14 resources and was NOT clean. Its result JSON was overwritten by subsequent isolation runs in the same frozen project; both original log and later JSON are retained with this distinction. Verbose isolation proved existing OPS-42 fixture held an environment/waiting-life reference cycle. Only that cleanup changed; OPS-42 rerun passed with clean exit. Final independent same 19-case batch froze complete structured details and clean exit without changing production or expanding scope.'))

before = read(ROOT / 'before-project/source-identity.json')
after = read(ROOT / 'after-project/source-identity.json')
rows = [r for r in before['source'] if r['path'].startswith(('game/', 'content/', 'tools/performance/'))]
raw = subprocess.run(['git', 'cat-file', '--batch'], input=''.join(BASE + ':' + r['path'] + '\n' for r in rows).encode(),
                     cwd=REPO, check=True, stdout=subprocess.PIPE).stdout
cursor = 0
for r in rows:
    end = raw.index(b'\n', cursor)
    size = int(raw[cursor:end].split()[-1])
    cursor = end + 1
    blob = raw[cursor:cursor + size]
    cursor += size + 1
    assert hashlib.sha256(blob).hexdigest() == r['sha256'], r['path']
    assert sha(ROOT / 'before-project' / r['path']) == r['sha256'], r['path']
current = [dict(**r, match=sha(REPO / r['path']) == r['sha256'] and sha(ROOT / 'after-project' / r['path']) == r['sha256'])
           for r in after['source'] if r['path'].startswith(('game/', 'content/', 'tools/performance/'))]
assert all(r['match'] for r in current)
binary = {k: before[k] == after[k] for k in ['engine_sha256', 'native_sha256', 'gmp_sha256', 'mpfr_sha256', 'runtime_sha256']}
assert all(binary.values())
assert sha(REPO / 'game/platform/windows/bin/oddly_good_platform.windows.x86_64.dll').upper() == after['native_sha256'].upper()
engine = pathlib.Path('C:/programs/godot/Godot_v4.7.2-stable_win64.exe')
engine_sha = sha(engine)
for prefix in ['ca', 'cb', 'cc', 'cd', 'controlled-before-all', 'controlled-after-all']:
    for window in ['public360', 'gp80', 'operations40']:
        launch = read(ROOT / (prefix + '-' + window + '.launch.json'))
        assert launch['engine_executable_sha256'].lower() == engine_sha
        assert launch['actual_mask'] == 1 and launch['child_cpu_ms'] >= 1000 and launch['exit_code'] == 0
transforms = []
for side in ['before', 'after', 'door']:
    directory = ROOT / (side + '-all-project')
    identity = read(directory / 'all-instance-profile-identity.json')
    plain = ROOT / (side + '-project')
    for r in identity['files']:
        assert sha(plain / r['path']) == r['original_sha256']
        assert sha(directory / '.cache/tail-profile-originals' / r['path']) == r['original_sha256']
        assert sha(directory / r['path']) == r['generated_sha256']
    transforms.append(dict(side=side, files=identity['transformed_file_count'], methods=identity['actual_method_count'], all_originals_match=True))
test_identity = read(REPO / '.cache/acceptance' / batches[-1]['batch'] / 'source-identity.json')
test_rows = [r for r in test_identity['source'] if r['path'].startswith('tests/acceptance/')]
assert test_rows and all(sha(REPO / r['path']) == r['sha256'] for r in test_rows)
test_game = [r for r in test_identity['source'] if r['path'].startswith(('game/', 'content/'))]
assert all(sha(REPO / r['path']) == r['sha256'] for r in test_game)
test_binary = {k: after[k] == test_identity[k] for k in binary}
assert all(test_binary.values())
dump('source-check.json', dict(baseline=BASE, baseline_files=rows, final_files=current, binary_equal=binary,
     native_sha256=after['native_sha256'], console_launcher_sha256=after['engine_sha256'], actual_engine_sha256=engine_sha,
     test_binary_equal=test_binary, transform_originals=transforms, final_test_files=test_rows, test_game_matches=True))

files = []
for p in ROOT.iterdir():
    if p.is_file() and p.suffix in ['.json', '.bin', '.ndjson', '.log', '.py', '.ps1', '.txt', '.gd']:
        files.append(p)
    if p.is_dir() and p.name.endswith('.sources'):
        files.extend(x for x in p.rglob('*') if x.is_file())
for side in ['before', 'after', 'door']:
    directory = ROOT / (side + '-project')
    for name in ['source-identity.json', 'import.log']:
        if (directory / name).exists():
            files.append(directory / name)
    directory = ROOT / (side + '-all-project')
    files.append(directory / 'all-instance-profile-identity.json')
    for r in read(directory / 'all-instance-profile-identity.json')['files']:
        files.extend([directory / r['path'], directory / '.cache/tail-profile-originals' / r['path']])
manifest = []
archive = OUT / 'raw-evidence.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    def add(p, name):
        z.write(p, name)
        manifest.append(dict(path=name, sha256=sha(p), bytes=p.stat().st_size))
    for p in sorted(set(files)):
        add(p, 'runs/' + p.relative_to(ROOT).as_posix())
    for name in ['public-v6.input.bin', 'gp.input.bin', 'op.input.bin']:
        add(REPO / '.cache/task-navigation-20261019' / name, 'inputs/' + name)
    for batch in batches:
        directory = REPO / '.cache/acceptance' / batch['batch']
        for name in ['acceptance-results.json', 'execution.log', 'execution-status.json', 'source-identity.json', 'timing-summary.json', 'import.log']:
            p = directory / name
            if p.exists():
                add(p, 'acceptance/' + batch['batch'] + '/' + name)
    for r in current:
        if r['path'] in ['game/building/hospital_navigation.gd', 'game/building/route_clearance.gd', 'game/life/public_areas.gd', 'game/operations/environment_service.gd']:
            add(REPO / r['path'], 'final-source/' + r['path'])
    for r in test_rows:
        if r['path'].endswith(('environment_source_intersection.gd', 'environment_source_lifecycle.gd', 'navigation_route_subject.gd', 'navigation_unit_wall_cuts.gd', 'public_region_lifecycle.gd', 'public_region_build.gd')):
            add(REPO / r['path'], 'final-source/' + r['path'])
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist()) == len(manifest)
    for r in manifest:
        assert hashlib.sha256(z.read(r['path'])).hexdigest() == r['sha256']
dump('raw-manifest.json', dict(archive='raw-evidence.zip', sha256=sha(archive), bytes=archive.stat().st_size, entries=manifest))
print(json.dumps(dict(archive_entries=len(manifest), archive_bytes=archive.stat().st_size, baseline_files=len(rows), final_files=len(current), test_files=len(test_rows))))
for w in windows:
    for name, g in w['groups'].items():
        print(w['window'], name, g['before_mean_us'], g['after_mean_us'], g['mean_difference_percent'])
