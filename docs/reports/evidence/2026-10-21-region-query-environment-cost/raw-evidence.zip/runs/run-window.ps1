#requires -Version 7.0
param([string]$Project='before-project',[string]$Label='a',[string]$Mode='plain')
$ErrorActionPreference='Stop'
$repo='C:/code/loyayz/oddly-good-hospital'
$root=Join-Path $repo '.cache/region-query-87af6a6-20261021'
$godot='C:/programs/godot/Godot_v4.7.2-stable_win64_console.exe'
foreach($window in @(@{name='public360';input='public-v6.input.bin';steps=360;selected='0,1,27,140'},@{name='gp80';input='gp.input.bin';steps=80;selected='0,27'},@{name='operations40';input='op.input.bin';steps=40;selected='0,1,19,20,21,38,39'})){
    $output=Join-Path $root ($Label+'-'+$window.name+'.json')
    if(Test-Path $output){throw "Evidence exists: $output"}
    $log=[IO.Path]::ChangeExtension($output,'.log')
    $input=Join-Path $repo ('.cache/task-navigation-20261019/'+$window.input)
    $script=if($Mode -eq 'plain'){'representative.gd'}else{'representative_selected.gd'}
    & $godot --headless --path (Join-Path $root $Project) --script ('res://tools/performance/'+$script) -- "--input=$input" "--output=$output" "--steps=$($window.steps)" "--profile=$Mode" "--selected=$($window.selected)" *> $log
    if($LASTEXITCODE -ne 0 -or (Select-String $log -Pattern 'SCRIPT ERROR:|ERROR:' -Quiet)){Get-Content $log -Tail 18;throw "Run failed: $output"}
    $result=Get-Content $output -Raw|ConvertFrom-Json
    if(-not $result.qualified -or -not $result.complete -or $result.errors.Count -gt 0){throw "Unqualified or incomplete: $output"}
    if($result.public_checks -and @($result.public_checks.PSObject.Properties | Where-Object {$_.Value -eq $false}).Count -gt 0){throw "Public check failed: $output"}
    [ordered]@{run=($Label+'-'+$window.name);metrics=$result.metrics;qualified=$result.qualified;hash=$result.final_binary_sha256}|ConvertTo-Json -Depth 4 -Compress
}

