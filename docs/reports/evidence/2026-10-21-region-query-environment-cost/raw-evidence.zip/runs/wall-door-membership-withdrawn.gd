extends RefCounted

const Bulk = preload("res://tests/acceptance/navigation_bulk_build.gd")

func run_case(suite: RefCounted) -> Dictionary:
	var sim: HospitalSimulation = suite._fixture()
	var built: bool = true
	for row: int in 4:
		for column: int in 4:
			var result: CommandResult = suite._command(sim,"build_room",suite._room("wall_bucket_%d_%d"%[row,column],[35+7*column,67+7*row]))
			built = built and result.accepted
	suite._add_actor(sim,"wall_bucket_small","S49",[33,93])
	suite._add_actor(sim,"wall_bucket_wide","S59",[38,93])
	var validation: String = sim.world.validate(suite.content)
	var before: Dictionary = sim.world.freeze()
	var checks: Dictionary = {"sixteen_real_rooms":built and sim.world.facts.rooms.size()==16,"legal_input":validation.is_empty()}
	var rows: Array = []
	for actor_id: String in ["wall_bucket_small","wall_bucket_wide"]:
		var actor: Dictionary = sim.world.facts.actors[actor_id]
		var actual: RouteClearance = RouteClearance.new(sim.space,sim.world,actor,1,[],{},false)
		var original: RouteClearance = Bulk.OriginalClearance.new(sim.space,sim.world,actor,1,[],{},false,actual.source)
		var borrowed: RouteClearance = RouteClearance.new(sim.space,sim.world,actor,1,[],{},true,actual.source,actual)
		var direct: RouteClearance = RouteClearance.new(sim.space,sim.world,actor,1,[],{},true,actual.source)
		var direct_reference: RouteClearance = Bulk.OriginalClearance.new(sim.space,sim.world,actor,1,[],{},true,actual.source)
		var stored: int = 0
		for directions: Dictionary in actual._wall_doors.values():
			for openings: Array in directions.values(): stored += openings.size()
		var open_count: int = 0
		for door: Dictionary in actual._doors:
			if door.ok: open_count += 1
		var candidates: int = 0
		var classified: bool = true
		for wall: Dictionary in actual._walls:
			for door: Dictionary in actual._wall_doors.get(wall.room_id,{}).get(wall.axis,[]):
				candidates += 1
				classified = classified and door.ok and door.room_id==wall.room_id and door.axis==wall.axis
		var compared: int = 0
		var equal: bool = true
		for y: int in range(65,95):
			for x: int in range(33,63):
				for offset: Vector2 in [Vector2.ZERO,Vector2(0.25,0.5)]:
					var from: Vector2 = Vector2(x,y)+offset
					var rect: Rect2 = Rect2(from,Vector2.ONE*actual._size)
					for direction: Vector2i in [Vector2i.ZERO,Vector2i.UP,Vector2i.LEFT,Vector2i.RIGHT,Vector2i.DOWN]:
						var sweep: Rect2 = rect.merge(Rect2(from+Vector2(direction),rect.size))
						compared += 1
						var expected: String = original._wall_reason(sweep)
						equal = equal and actual._wall_reason(sweep)==expected and borrowed._wall_reason(sweep)==expected and direct._wall_reason(sweep)==direct_reference._wall_reason(sweep)
		rows.append({"actor":actor_id,"all_wall_and_door_cuts_equal":equal,"compared_rectangles":compared,"stored_openings":stored,"all_open_doors":open_count,"complete_door_scan_candidates":actual._doors.size()*actual._walls.size(),"classified_candidates":candidates,"one_owned_record_per_opening":stored==open_count,"only_same_room_direction":classified,"borrowed_index_is_same_owner":is_same(actual._wall_doors,borrowed._wall_doors)})
		checks[actor_id] = equal and compared>0 and classified and stored==open_count and candidates<actual._doors.size()*actual._walls.size() and is_same(actual._wall_doors,borrowed._wall_doors)
	checks.facts_and_rng_unchanged = before==sim.world.freeze()
	var result: Dictionary = {"ok":not checks.values().has(false),"checks":checks,"rows":rows,"validation":validation}
	sim.dispose()
	return result
