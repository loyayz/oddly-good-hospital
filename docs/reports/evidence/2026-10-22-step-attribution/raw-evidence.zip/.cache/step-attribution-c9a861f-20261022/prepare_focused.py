from pathlib import Path
import argparse
import hashlib
import json
import shutil

CACHE = Path(__file__).resolve().parent
REPO = CACHE.parents[1]
SOURCE = REPO / '.cache/vacant-queue-fit-50f9e9b-20261022/after-project'
parser = argparse.ArgumentParser()
parser.add_argument('--entry', action='store_true')
args = parser.parse_args()
variant = 'entry' if args.entry else 'focused'
TARGET = CACHE / (variant+'-project')
assert not TARGET.exists(), TARGET
shutil.copytree(SOURCE, TARGET)
path = TARGET / 'tools/performance/step_profile.gd'
original = path.read_bytes()
start = original.index(b'const COMMON_METHODS:')
end = original.index(b'var errors: Array = []')
old = original[start:end]
methods = {
    'space': ['_ensure_actor_index', '_reservation_regions', '_dynamic_clear'],
    'public_areas': ['_decision_signature', '_queue_members', '_queue_fit_current',
                     '_queue_fit_basis', '_queue_fit_clear', '_queue_fit_in_query', 'select'],
    'environment': ['_observe_at', '_coverage', '_coverage_edges'],
    'movement': ['_move_step', '_active_route_clear'],
    'clinic': ['service_candidates'],
}
if args.entry:
    methods = {
        'public_areas': ['select', '_waiting_point', '_entry_landings', '_entry_order',
                         '_entry_geometry_view', 'safe_wait', '_safe_wait_geometry',
                         '_wait_estimate', 'facilities'],
        'point_navigation': ['travel_quote', '_point_route'],
        'space': ['begin_dynamic_route_query', '_ensure_actor_index', '_dynamic_clear'],
        'navigation': ['query_graphs', 'graph'],
    }
assert sum(map(len, methods.values())) == 16
new = ('const COMMON_METHODS: Array[String] = []\nconst HOT_METHODS: Dictionary = '+
       json.dumps(methods, ensure_ascii=False, indent=2)+'\n\n').encode('utf-8')
generated = original[:start]+new+original[end:]
assert generated.replace(new, old, 1) == original
path.write_bytes(generated)
proof = {
    'source_project': str(SOURCE), 'focused_project': str(TARGET),
    'only_modified_source': 'tools/performance/step_profile.gd',
    'before_sha256': hashlib.sha256(original).hexdigest(),
    'after_sha256': hashlib.sha256(generated).hexdigest(),
    'selection_inverse_byte_equal': True,
    'selected_methods': methods, 'selected_method_count': 16,
    'production_bodies_changed': False, 'diagnostic_only': True, 'formal_pass': False,
}
(CACHE/(variant+'-transformation.json')).write_text(json.dumps(proof, ensure_ascii=False, indent=2)+'\n', encoding='utf-8', newline='\n')
print(json.dumps({'project': str(TARGET), 'methods': 16, 'inverse_byte_equal': True}))
