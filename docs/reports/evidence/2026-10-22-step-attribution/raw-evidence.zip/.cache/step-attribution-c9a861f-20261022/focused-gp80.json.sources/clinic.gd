extends "res://game/clinic/clinical_runtime.gd"
var _step_profile_observer: RefCounted

func service_candidates(world: WorldState, visit: Dictionary, kind: String, structural_only: bool = false, reference_schedule: bool = false, selection: Dictionary = {}) -> Array:
	_step_profile_observer.enter_call("clinic.service_candidates")
	var _step_profile_result: Variant = super.service_candidates(world,visit,kind,structural_only,reference_schedule,selection)
	_step_profile_observer.exit_call("clinic.service_candidates")
	return _step_profile_result
