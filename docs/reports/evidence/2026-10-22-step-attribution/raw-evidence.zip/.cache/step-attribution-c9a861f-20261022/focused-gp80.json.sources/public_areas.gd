extends "res://game/life/public_areas.gd"
var _step_profile_observer: RefCounted

func _decision_signature(world: WorldState, intent: Dictionary, definitions: Array, members: Array, extra: Dictionary, route_floors: Array = []) -> Array:
	_step_profile_observer.enter_call("public_areas._decision_signature")
	var _step_profile_result: Variant = super._decision_signature(world,intent,definitions,members,extra,route_floors)
	_step_profile_observer.exit_call("public_areas._decision_signature")
	return _step_profile_result

func select(world: WorldState, actor_id: String, definitions: Array, room_kinds: Array, purpose: String, members: Array = [], maximum_travel_ticks: int = 9223372036854775807, selected_entries: Dictionary = {}) -> Dictionary:
	_step_profile_observer.enter_call("public_areas.select")
	var _step_profile_result: Variant = super.select(world,actor_id,definitions,room_kinds,purpose,members,maximum_travel_ticks,selected_entries)
	_step_profile_observer.exit_call("public_areas.select")
	return _step_profile_result

func _queue_members(world: WorldState) -> Dictionary:
	_step_profile_observer.enter_call("public_areas._queue_members")
	var _step_profile_result: Variant = super._queue_members(world)
	_step_profile_observer.exit_call("public_areas._queue_members")
	return _step_profile_result

func _queue_fit_current(world: WorldState, facility_id: String, ids: Array) -> Dictionary:
	_step_profile_observer.enter_call("public_areas._queue_fit_current")
	var _step_profile_result: Variant = super._queue_fit_current(world,facility_id,ids)
	_step_profile_observer.exit_call("public_areas._queue_fit_current")
	return _step_profile_result

func _queue_fit_basis(world: WorldState, facility_id: String, ids: Array) -> Array:
	_step_profile_observer.enter_call("public_areas._queue_fit_basis")
	var _step_profile_result: Variant = super._queue_fit_basis(world,facility_id,ids)
	_step_profile_observer.exit_call("public_areas._queue_fit_basis")
	return _step_profile_result

func _queue_fit_clear(world: WorldState, facility_id: String, ids: Array, quote: Dictionary) -> bool:
	_step_profile_observer.enter_call("public_areas._queue_fit_clear")
	var _step_profile_result: Variant = super._queue_fit_clear(world,facility_id,ids,quote)
	_step_profile_observer.exit_call("public_areas._queue_fit_clear")
	return _step_profile_result

func _queue_fit_in_query(world: WorldState, facility_id: String, ids: Array) -> Dictionary:
	_step_profile_observer.enter_call("public_areas._queue_fit_in_query")
	var _step_profile_result: Variant = super._queue_fit_in_query(world,facility_id,ids)
	_step_profile_observer.exit_call("public_areas._queue_fit_in_query")
	return _step_profile_result
