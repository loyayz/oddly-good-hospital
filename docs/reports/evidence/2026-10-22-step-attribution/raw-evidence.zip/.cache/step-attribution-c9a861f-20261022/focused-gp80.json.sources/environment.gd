extends "res://game/operations/environment_service.gd"
var _step_profile_observer: RefCounted

func _coverage_edges(world: WorldState, floor_id: int) -> Dictionary:
	_step_profile_observer.enter_call("environment._coverage_edges")
	var _step_profile_result: Variant = super._coverage_edges(world,floor_id)
	_step_profile_observer.exit_call("environment._coverage_edges")
	return _step_profile_result

func _coverage(world: WorldState, floor_id: int, origin: Array, radius: int, noise: bool, edges: Dictionary = {}) -> Dictionary:
	_step_profile_observer.enter_call("environment._coverage")
	var _step_profile_result: Variant = super._coverage(world,floor_id,origin,radius,noise,edges)
	_step_profile_observer.exit_call("environment._coverage")
	return _step_profile_result

func _observe_at(world: WorldState, floor_id: int, cell: Array, actor_id: String, explain: bool, nearby: bool) -> Dictionary:
	_step_profile_observer.enter_call("environment._observe_at")
	var _step_profile_result: Variant = super._observe_at(world,floor_id,cell,actor_id,explain,nearby)
	_step_profile_observer.exit_call("environment._observe_at")
	return _step_profile_result
