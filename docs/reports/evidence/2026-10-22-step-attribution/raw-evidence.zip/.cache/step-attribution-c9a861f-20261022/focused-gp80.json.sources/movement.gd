extends "res://game/building/hospital_movement.gd"
var _step_profile_observer: RefCounted

func _move_step(world: WorldState, actor: Dictionary, movement: Dictionary, segment: Dictionary) -> MotionResult:
	_step_profile_observer.enter_call("movement._move_step")
	var _step_profile_result: Variant = super._move_step(world,actor,movement,segment)
	_step_profile_observer.exit_call("movement._move_step")
	return _step_profile_result

func _active_route_clear(world: WorldState, actor: Dictionary, movement: Dictionary, versions: Dictionary) -> bool:
	_step_profile_observer.enter_call("movement._active_route_clear")
	var _step_profile_result: Variant = super._active_route_clear(world,actor,movement,versions)
	_step_profile_observer.exit_call("movement._active_route_clear")
	return _step_profile_result
