extends "res://game/building/hospital_space.gd"
var _step_profile_observer: RefCounted

func _ensure_actor_index(world: WorldState) -> void:
	_step_profile_observer.enter_call("space._ensure_actor_index")
	super._ensure_actor_index(world)
	_step_profile_observer.exit_call("space._ensure_actor_index")

func _reservation_regions(world: WorldState, floor_id: int, rect: Rect2) -> Array:
	_step_profile_observer.enter_call("space._reservation_regions")
	var _step_profile_result: Variant = super._reservation_regions(world,floor_id,rect)
	_step_profile_observer.exit_call("space._reservation_regions")
	return _step_profile_result

func _dynamic_clear(world: WorldState, actor_id: String, floor_id: int, rect: Rect2, members: Array = []) -> bool:
	_step_profile_observer.enter_call("space._dynamic_clear")
	var _step_profile_result: Variant = super._dynamic_clear(world,actor_id,floor_id,rect,members)
	_step_profile_observer.exit_call("space._dynamic_clear")
	return _step_profile_result
