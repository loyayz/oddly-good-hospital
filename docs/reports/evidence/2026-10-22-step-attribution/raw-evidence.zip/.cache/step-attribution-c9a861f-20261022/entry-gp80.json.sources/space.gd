extends "res://game/building/hospital_space.gd"
var _step_profile_observer: RefCounted

func begin_dynamic_route_query(world: WorldState, refresh_actors: bool = true) -> void:
	_step_profile_observer.enter_call("space.begin_dynamic_route_query")
	super.begin_dynamic_route_query(world,refresh_actors)
	_step_profile_observer.exit_call("space.begin_dynamic_route_query")

func _ensure_actor_index(world: WorldState) -> void:
	_step_profile_observer.enter_call("space._ensure_actor_index")
	super._ensure_actor_index(world)
	_step_profile_observer.exit_call("space._ensure_actor_index")

func _dynamic_clear(world: WorldState, actor_id: String, floor_id: int, rect: Rect2, members: Array = []) -> bool:
	_step_profile_observer.enter_call("space._dynamic_clear")
	var _step_profile_result: Variant = super._dynamic_clear(world,actor_id,floor_id,rect,members)
	_step_profile_observer.exit_call("space._dynamic_clear")
	return _step_profile_result
