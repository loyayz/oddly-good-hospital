extends "res://game/life/public_areas.gd"
var _step_profile_observer: RefCounted

func facilities(world: WorldState, reference: Dictionary, definitions: Array) -> Array:
	_step_profile_observer.enter_call("public_areas.facilities")
	var _step_profile_result: Variant = super.facilities(world,reference,definitions)
	_step_profile_observer.exit_call("public_areas.facilities")
	return _step_profile_result

func select(world: WorldState, actor_id: String, definitions: Array, room_kinds: Array, purpose: String, members: Array = [], maximum_travel_ticks: int = 9223372036854775807, selected_entries: Dictionary = {}) -> Dictionary:
	_step_profile_observer.enter_call("public_areas.select")
	var _step_profile_result: Variant = super.select(world,actor_id,definitions,room_kinds,purpose,members,maximum_travel_ticks,selected_entries)
	_step_profile_observer.exit_call("public_areas.select")
	return _step_profile_result

func _waiting_point(world: WorldState, actor_id: String, reference: Dictionary, maximum_travel_ticks: int) -> Dictionary:
	_step_profile_observer.enter_call("public_areas._waiting_point")
	var _step_profile_result: Variant = super._waiting_point(world,actor_id,reference,maximum_travel_ticks)
	_step_profile_observer.exit_call("public_areas._waiting_point")
	return _step_profile_result

func _entry_order(actor: Dictionary, origin: Vector2, bounds: Dictionary, geometry: Dictionary, maximum_travel_ticks: int) -> Dictionary:
	_step_profile_observer.enter_call("public_areas._entry_order")
	var _step_profile_result: Variant = super._entry_order(actor,origin,bounds,geometry,maximum_travel_ticks)
	_step_profile_observer.exit_call("public_areas._entry_order")
	return _step_profile_result

func _entry_landings(world: WorldState, actor_id: String, floor_id: int) -> Dictionary:
	_step_profile_observer.enter_call("public_areas._entry_landings")
	var _step_profile_result: Variant = super._entry_landings(world,actor_id,floor_id)
	_step_profile_observer.exit_call("public_areas._entry_landings")
	return _step_profile_result

func safe_wait(world: WorldState, actor_id: String, floor_id: int, cell: Array, geometry: Dictionary = {}) -> bool:
	_step_profile_observer.enter_call("public_areas.safe_wait")
	var _step_profile_result: Variant = super.safe_wait(world,actor_id,floor_id,cell,geometry)
	_step_profile_observer.exit_call("public_areas.safe_wait")
	return _step_profile_result

func _safe_wait_geometry(world: WorldState, actor: Dictionary, floor_id: int, origin: Vector2, geometry: RouteClearance, doors: Dictionary = {}) -> bool:
	_step_profile_observer.enter_call("public_areas._safe_wait_geometry")
	var _step_profile_result: Variant = super._safe_wait_geometry(world,actor,floor_id,origin,geometry,doors)
	_step_profile_observer.exit_call("public_areas._safe_wait_geometry")
	return _step_profile_result

func _entry_geometry_view(world: WorldState, actor: Dictionary, area: Dictionary) -> Dictionary:
	_step_profile_observer.enter_call("public_areas._entry_geometry_view")
	var _step_profile_result: Variant = super._entry_geometry_view(world,actor,area)
	_step_profile_observer.exit_call("public_areas._entry_geometry_view")
	return _step_profile_result

func _wait_estimate(world: WorldState, reference: Dictionary, facility_ids: Array, purpose: String) -> int:
	_step_profile_observer.enter_call("public_areas._wait_estimate")
	var _step_profile_result: Variant = super._wait_estimate(world,reference,facility_ids,purpose)
	_step_profile_observer.exit_call("public_areas._wait_estimate")
	return _step_profile_result
