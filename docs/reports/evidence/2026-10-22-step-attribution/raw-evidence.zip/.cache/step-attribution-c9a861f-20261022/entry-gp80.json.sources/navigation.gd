extends "res://game/building/navigation_cache.gd"
var _step_profile_observer: RefCounted

func query_graphs(space: HospitalSpace, world: WorldState, floor_id: int, actor: Dictionary, members: Array, offsets: Dictionary) -> Dictionary:
	_step_profile_observer.enter_call("navigation.query_graphs")
	var _step_profile_result: Variant = super.query_graphs(space,world,floor_id,actor,members,offsets)
	_step_profile_observer.exit_call("navigation.query_graphs")
	return _step_profile_result

func graph(space: HospitalSpace, world: WorldState, floor_id: int, actor: Dictionary, members: Array, offsets: Dictionary) -> FloorNavigation:
	_step_profile_observer.enter_call("navigation.graph")
	var _step_profile_result: Variant = super.graph(space,world,floor_id,actor,members,offsets)
	_step_profile_observer.exit_call("navigation.graph")
	return _step_profile_result
