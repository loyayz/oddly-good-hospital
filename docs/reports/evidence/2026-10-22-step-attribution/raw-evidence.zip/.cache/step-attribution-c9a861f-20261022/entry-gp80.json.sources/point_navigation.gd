extends "res://game/building/hospital_navigation.gd"
var _step_profile_observer: RefCounted

func travel_quote(world: WorldState, actor_id: String, floor_id: int, target: Array) -> Dictionary:
	_step_profile_observer.enter_call("point_navigation.travel_quote")
	var _step_profile_result: Variant = super.travel_quote(world,actor_id,floor_id,target)
	_step_profile_observer.exit_call("point_navigation.travel_quote")
	return _step_profile_result

func _point_route(world: WorldState, actor: Dictionary, source_floor: int, start: Vector2i, target_floor: int, goal: Vector2i, members: Array, offsets: Dictionary, initial_ticks: int, distance_only: bool) -> Dictionary:
	_step_profile_observer.enter_call("point_navigation._point_route")
	var _step_profile_result: Variant = super._point_route(world,actor,source_floor,start,target_floor,goal,members,offsets,initial_ticks,distance_only)
	_step_profile_observer.exit_call("point_navigation._point_route")
	return _step_profile_result
