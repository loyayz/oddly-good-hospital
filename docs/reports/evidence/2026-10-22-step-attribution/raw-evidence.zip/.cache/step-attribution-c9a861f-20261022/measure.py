from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
from pathlib import Path

CACHE = Path(__file__).resolve().parent
REPO = CACHE.parents[1]
PRIOR = REPO / '.cache/vacant-queue-fit-50f9e9b-20261022'
PROJECT = PRIOR / 'after-project'


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def write(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf-8', newline='\n')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--mode', choices=['plain', 'root', 'focused', 'entry'], required=True)
    parser.add_argument('--label', required=True)
    parser.add_argument('--window', choices=['public360', 'gp80'], required=True)
    args = parser.parse_args()
    spec = importlib.util.spec_from_file_location('prior_runner', PRIOR / 'run.py')
    runner = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(runner)
    runner.ROOT = CACHE
    limited = args.mode in ['focused', 'entry']
    if limited:
        PROJECT = CACHE / (args.mode+'-project')
    identity = read(PROJECT / 'source-identity.json')
    rows = identity['source']
    # The selected frozen project has no offline function wrappers or counters.
    assert not (PROJECT / 'all-instance-profile-identity.json').exists()
    assert not (PROJECT / 'query-counter-identity.json').exists()
    for row in rows:
        assert digest(REPO / row['path']) == row['sha256'], row['path']
        if limited and row['path'] == 'tools/performance/step_profile.gd':
            focused = read(CACHE / (args.mode+'-transformation.json'))
            assert digest(PROJECT / row['path']) == focused['after_sha256']
            assert row['sha256'] == focused['before_sha256']
        elif Path(row['path']).suffix in ['.gd', '.json', '.py']:
            assert digest(PROJECT / row['path']) == row['sha256'], row['path']
    filename, steps = runner.WINDOWS[args.window]
    source_input = REPO / '.cache/task-navigation-20261019' / filename
    output = CACHE / (args.label+'-'+args.window+'.json')
    assert not output.exists(), output
    proof = {
        'workspace_commit': 'c9a861fc35e5ac361cd5eae001278f9c07851340',
        'measured_production_commit': identity['head'],
        'project': str(PROJECT),
        'project_identity_sha256': digest(PROJECT / 'source-identity.json'),
        'workspace_source_rows_verified': len(rows),
        'frozen_script_and_data_rows_match_original': True,
        'native_sha256': digest(PROJECT / 'game/platform/windows/bin/oddly_good_platform.windows.x86_64.dll'),
        'input_sha256': digest(source_input),
        'root_markers_only': args.mode == 'root',
        'nested_function_wrappers': limited,
        'limited_observer_selection': args.mode+'-transformation.json' if limited else None,
        'rule_or_input_changes': False,
        'diagnostic_only': True,
        'formal_pass': False,
    }
    write(CACHE / (args.label+'-'+args.window+'.source-check.json'), proof)
    runner.launch([
        '--headless', '--path', PROJECT,
        '--script', 'res://tools/performance/representative.gd', '--',
        '--input='+str(source_input), '--output='+str(output),
        '--steps='+str(steps), '--profile='+('nested' if limited else args.mode),
    ], output)
    result = read(output)
    assert result['complete'] and result['qualified'] and not result['errors']
    reference = read(PRIOR / ('b-'+args.window+'.json'))
    for field in ['qualification', 'public_checks', 'public', 'final', 'operations', 'event_records']:
        if limited and field == 'public':
            actual, expected = dict(result['public']), dict(reference['public'])
            actual.pop('query_counts', None)
            expected.pop('query_counts', None)
            assert actual == expected, field
        else:
            assert result.get(field) == reference.get(field), field
    assert result['final_binary_sha256'] == reference['final_binary_sha256']
    if args.mode == 'root':
        profile = result['profile']
        assert profile['steps'] == steps and profile['step_records_complete']
        assert not profile['nested_calls'] and not profile['errors']
        assert profile['sources']['root_method_preserved']
    if limited:
        profile = result['profile']
        assert profile['steps'] == steps and profile['step_records_complete'] and not profile['errors']
        assert profile['sources']['root_method_preserved']
        configured = read(CACHE/(args.mode+'-transformation.json'))['selected_methods']
        for group, methods in configured.items():
            assert sorted(profile['sources'][group]['methods']) == sorted(methods), group
    print(json.dumps({'run': args.label+'-'+args.window, 'mode': args.mode,
                      'metrics_us': result['metrics'], 'semantics_equal': True}, ensure_ascii=False), flush=True)
