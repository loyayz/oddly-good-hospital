from __future__ import annotations

import hashlib
import json
from pathlib import Path
import zipfile

CACHE = Path(__file__).resolve().parent
REPO = CACHE.parents[1]
OUT = REPO/'docs/reports/evidence/2026-10-22-step-attribution'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def dump(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf-8', newline='\n')


def ms_per_step(rows, count, first=None):
    output = []
    for row in rows:
        item = dict(row)
        for key in ['total_us', 'inclusive_us', 'exclusive_us']:
            if key in item:
                item[key.removesuffix('_us')+'_ms_per_step'] = item[key]/count/1000
        if first is not None:
            item['following_mean_ms'] = (row['total_us']-first.get(row['name'], {}).get('total_us', 0))/(count-1)/1000
        output.append(item)
    return output


if __name__ == '__main__':
    assert not OUT.exists(), OUT
    OUT.mkdir(parents=True)
    cases = [(label, window) for window in ['public360', 'gp80']
             for label in ['plain-before', 'root', 'plain-after', 'focused']]
    cases.append(('entry', 'gp80'))
    runs = []
    members = set()
    for label, window in cases:
        prefix = label+'-'+window
        path = CACHE/(prefix+'.json')
        d = read(path)
        launch = read(CACHE/(prefix+'.launch.json'))
        assert d['complete'] and d['qualified'] and not d['errors']
        assert launch['exit_code'] == 0 and not launch['errors'] and not launch['timed_out']
        ref = read(CACHE/('plain-before-'+window+'.json'))
        assert d['public']['query_counts'] == ref['public']['query_counts']
        assert d['final_binary_sha256'] == ref['final_binary_sha256']
        for field in ['final', 'event_records', 'qualification', 'public_checks', 'operations']:
            assert d.get(field) == ref.get(field), (prefix, field)
        pub, ref_pub = dict(d['public']), dict(ref['public'])
        pub.pop('query_counts', None); ref_pub.pop('query_counts', None)
        assert pub == ref_pub
        row = {
            'run': prefix, 'window': window, 'mode': d['mode'],
            'metrics_us': d['metrics'], 'launch': launch,
            'source_proof': read(CACHE/(prefix+'.source-check.json')),
            'input_sha256': d['source_input_sha256'],
            'final_binary_sha256': d['final_binary_sha256'],
            'actual_160_and_semantics_equal': True,
            'query_counts_equal_plain': True,
            'query_counts': d['public']['query_counts'],
            'top_steps': sorted(d['samples'], key=lambda s:-s['elapsed_us'])[:8],
        }
        if 'profile' in d:
            f = d['profile']; n = d['metrics']['count']
            assert f['steps'] == n and f['complete_steps'] == n and not f['errors']
            assert f['partition_check_us'] == 0 and f['sources']['root_method_preserved']
            assert {v['nonblocking_invocations'] for v in f['step_records']} == {1}
            row['profile_totals'] = {k:f[k] for k in ['profiled_whole_us', 'disjoint_root_stage_us', 'observer_handler_us', 'residual_us', 'partition_check_us']}
            row['root_stages'] = ms_per_step(f['root_stages'], n, f['step_records'][0]['stages'])
            row['functions'] = ms_per_step(f['nested_calls'], n)
            chosen = set([2760,2764,2843] if window=='public360' else [825,851])
            chosen.update(v['tick'] for v in row['top_steps'])
            row['selected_step_records'] = [v for v in f['step_records'] if v.get('tick') in chosen]
            row['root_source_proof'] = f['sources']
            for file in (CACHE/(prefix+'.json.sources')).glob('*.gd'):
                members.add(file)
        for suffix in ['.json', '.json.steps.ndjson', '.launch.json', '.source-check.json', '.stdout.log', '.stderr.log']:
            members.add(CACHE/(prefix+suffix))
        runs.append(row)
    summary = {
        'diagnostic_only': True, 'formal_pass': False,
        'scope': 'Current unchanged production. Attribution and perturbation checks only; no optimization A/B or functional acceptance cases.',
        'production_commit': '8cc12664a69533ecaffa5f41e00a8186bf8bb98c',
        'workspace_commit': 'c9a861fc35e5ac361cd5eae001278f9c07851340',
        'population': {'patients':120,'staff':32,'visitors':8,'floors':4,'rooms':64,'facilities':1336,'step_seconds':0.1},
        'execution_order': ['plain-before-public360','root-public360','plain-after-public360','plain-before-gp80','root-gp80','plain-after-gp80','focused-public360','focused-gp80','entry-gp80'],
        'runs': runs,
        'checks': {'engine_runs':9,'complete_runs':9,'equal_semantics':True,'equal_builtin_query_counts':True,'business_source_changes':False,'new_native_build':False,'case_regression_run':False},
        'interpretation': {
            'root': 'Root markers only. Public whole-step perturbation versus bracketing plain is about +1.6 to +2.0 percent; GP controls show timing variability.',
            'limited_functions': 'Two selections of 16 methods reuse the existing profiler without parameter/result capture. Inclusive rows overlap. Exclusive subtracts only selected descendants and still includes unwrapped methods, engine and native work.',
            'observer': 'Recorded handler bodies do not measure all wrapper/dispatch overhead. Subtracting observer time never reconstructs a plain run.',
            'tail': 'Short GP P99 is the maximum; same-source plain GP851 varies substantially. No timing difference is claimed to be caused by an optimization.',
            'unresolved': 'Exact owner/caller attribution within signatures, per-step CPU scheduling/frequency, and a safe way to share current dynamic dependencies remain unproved.',
        },
        'prior_source_reference': {
            'report': 'docs/reports/2026-10-22-vacant-queue-fit.md',
            'archive': 'docs/reports/evidence/2026-10-22-vacant-queue-fit/raw-evidence.zip',
            'sha256': sha(REPO/'docs/reports/evidence/2026-10-22-vacant-queue-fit/raw-evidence.zip'),
            'note': 'That immutable archive contains the original before/after production snapshots and native DLL used again here. New transformed profiler/source selections and generated wrappers are in this archive.',
        },
    }
    dump(OUT/'summary.json', summary)
    for name in ['measure.py','prepare_focused.py','analyze.py','focused-transformation.json','entry-transformation.json']:
        members.add(CACHE/name)
    members.add(CACHE/'focused-project/source-identity.json')
    members.add(CACHE/'entry-project/source-identity.json')
    members.add(CACHE/'focused-project/tools/performance/step_profile.gd')
    members.add(CACHE/'entry-project/tools/performance/step_profile.gd')
    original = REPO/'.cache/vacant-queue-fit-50f9e9b-20261022/after-project'
    for name in ['source-identity.json','tools/performance/step_profile.gd','tools/performance/representative.gd']:
        members.add(original/name)
    members.add(REPO/'.cache/vacant-queue-fit-50f9e9b-20261022/run.py')
    for name in ['public-v6.input.bin','gp.input.bin']:
        members.add(REPO/'.cache/task-navigation-20261019'/name)
    rows = [{'path':str(f.relative_to(REPO)).replace('\\','/'),'size':f.stat().st_size,'sha256':sha(f)} for f in sorted(members)]
    archive = OUT/'raw-evidence.zip'
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for row in rows: z.write(REPO/row['path'],row['path'])
    with zipfile.ZipFile(archive) as z:
        assert len(z.infolist()) == len(rows)
        for row in rows:
            actual = z.read(row['path'])
            assert len(actual) == row['size'] and hashlib.sha256(actual).hexdigest() == row['sha256']
    dump(OUT/'raw-manifest.json', {'files':rows,'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive),'all_members_reread_verified':True,'diagnostic_only':True,'formal_pass':False})
    print(json.dumps({'files':len(rows),'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive),'runs':9,'semantics_equal':True}))
