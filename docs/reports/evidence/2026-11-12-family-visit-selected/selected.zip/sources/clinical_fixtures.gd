extends RefCounted

const ClinicalStep = preload("res://tests/acceptance/clinical_step.gd")
const CheckpointIdentity = preload("res://tests/acceptance/checkpoint_identity.gd")

var _cache: RefCounted
var _content: HospitalContent
var _simulations: Array[HospitalSimulation] = []
var _snapshots: Dictionary = {}
var _fixture_sequence: int = 0
var _fixture_failures: Array = []
var _building_key: String = ""
var _building_context: Dictionary = {}
var _checkpoint_recipe_cache: Dictionary = {}

func _dispose_simulations() -> void:
	for simulation: HospitalSimulation in _simulations:
		simulation.dispose()
	_simulations.clear()

func _context(surgical: bool = false, c_profile: bool = false, chairs: bool = true, initial_guidance_cell: Array = [], capture_events: bool = false, team_floor: int = 1, or_floor: int = 1, initial_bed_grade: int = 0) -> Dictionary:
	_fixture_sequence += 1
	var world: WorldState = HospitalFactory.create(HospitalSnapshots.uuid(),"临床验收%04d"%_fixture_sequence,true,_content)
	var doctors: Array = []
	for id: String in world.ids("staff"):
		var staff: Dictionary = world.facts.staff[id]
		if staff.role=="doctor": doctors.append(id)
		if staff.role in ["doctor","nurse"]:
			if staff.role=="nurse": staff.base_prepared = false
			staff.personality_id = "DP05"
			staff.schedule = _schedule("outpatient" if staff.role=="doctor" else "work")
	for index: int in doctors.size():
		var doctor: Dictionary = world.facts.staff[doctors[index]]
		if index==0:
			doctor.schedule = _schedule("outpatient",["room_gp"])
			if surgical or c_profile: doctor.abilities.treatment = 2
			if c_profile: doctor.abilities.diagnosis = 2
		elif index==1:
			doctor.schedule = _schedule("outpatient",["room_physical"])
			doctor.abilities.treatment = 2 if c_profile or surgical else 1
		else:
			doctor.schedule = _schedule("rest")
	if c_profile or surgical:
		for definition: Dictionary in _content.catalog.research:
			world.facts.research.append(definition.id)
	if not chairs:
		for id: String in world.ids("facilities"):
			if world.facts.facilities[id].definition_id=="FUR09": world.facts.facilities.erase(id)
	if surgical:
		var top_floor: int=maxi(team_floor,or_floor)
		if top_floor>1:
			world.facts.floors.height_intervals=[{"first":1,"last":top_floor,"height_m":float(_content.balance.floors.clear_height_m)}]
			world.facts.floors.completed_top_floor={HospitalSpace.plot_key([1,2]):top_floor}
			for floor_id: int in range(2,top_floor+1):
				world.facts.floors.overrides[str(floor_id)]={"plots":[[1,2]],"blocked":[],"wall_edges":[],"doors":[],"paths":[]}
			world.facts.connectors["clin_lift"]={"id":"clin_lift","definition_id":"VC02","first_floor":1,"last_floor":top_floor,"cell":[57,66],"footprint":[4,4],"rotation":0,"anchor":[58,70],"repair_cell":[56,67],"floor_id":1,"phase":"idle","riders":[],"remaining_ticks":0,"ticket_next":0,"condition":100.0,"failed":false,"pending_failure":false,"use_receipts":{},"paid_cost":3200,"used":false}
		_add_layout(world,"or_standard","clin_or",[33,65],or_floor)
		_add_layout(world,"ward_two_beds","clin_ward",[45,65])
		_add_worker(world,"clin_surgeon","doctor",[34,75],"surgery",{"diagnosis":1,"treatment":1,"care":0,"surgery":2},"DT02","clin_or")
		_add_worker(world,"clin_anesthesia","doctor",[38,75],"surgery",{"diagnosis":1,"treatment":1,"care":0,"surgery":2},"DT02","clin_or")
		_add_worker(world,"clin_or_nurse","nurse",[42,75],"work",{"diagnosis":1,"treatment":0,"care":1,"surgery":1},"DT01","clin_or")
		world.facts.staff.clin_or_nurse.certificates = ["q_or","q_ward"]
		_add_worker(world,"clin_cover","nurse",[46,72],"work",{"diagnosis":1,"treatment":0,"care":1,"surgery":0},"DT01","clin_ward")
		# Keep the original worker and physical load; the former compulsory
		# round doctor now follows the ordinary office-idle rule.
		_add_worker(world,"clin_round","doctor",[51,72],"outpatient",{"diagnosis":2,"treatment":1,"care":0,"surgery":0})
		if team_floor>1:
			# Declared built hospital and initial spawn, before simulation exists.
			# All subsequent connector travel and gathering remain real work.
			# OR nursing keeps its existing same-floor workbench rule. Move the
			# original public base into this initial floor; do not add a base or
			# prefill preparation. Floor one keeps the original ward workbench.
			world.facts.facilities.nurse_workbench.floor_id = team_floor
			for index: int in 3:
				world.facts.actors[["clin_surgeon","clin_anesthesia","clin_or_nurse"][index]].location = {"kind":"floor","floor_id":team_floor,"cell":[54+index*2,72],"height_m":0.0}
	if initial_bed_grade>0:
		assert(world.sim_tick==0,"Declare initial equipment before its first real step")
		for id: String in world.facility_ids("EQ05"):
			world.facts.facilities[id].grade=initial_bed_grade
			world.facts.facilities[id].upgrade_level=initial_bed_grade
	var simulation: HospitalSimulation = HospitalSimulation.new(world,_content)
	_simulations.append(simulation)
	var c: Dictionary = {"sim":simulation,"world":world,"serial":0,"visit_id":"","doctors":doctors,"started":{},"group_seen":false,"beats":{},"errors":[],"fixture_ready":true}
	c.capture_events = capture_events
	c.event_log = []
	c.nursing_handoff_ticks = {}
	c.nursing_handoff_not_at_base = []
	_command(c,"set_intake_open",{"open":false})
	_command(c,"tutorial_set_enabled",{"enabled":false})
	_command(c,"set_auto_restock",{"enabled":false})
	_fixture_arrival_plan(world)
	_fixture_preflight(c,c_profile,surgical)
	if not initial_guidance_cell.is_empty():
		# Place the desk legally before the first tick or patient arrival. The
		# nurse still starts at the ordinary entrance and walks to the new post.
		var actors_before: Dictionary = world.facts.actors.duplicate(true)
		var initial: bool = world.sim_tick==0 and world.facts.visits.is_empty() and world.facts.floor_guidance.desks.is_empty()
		var moved: CommandResult = _command(c,"build_move",{"target_id":"floor_guidance_desk","floor_id":1,"cell":initial_guidance_cell})
		var unchanged_actors: bool = actors_before==world.facts.actors
		var placement: Dictionary = {"kind":"initial_guidance_desk_placement","before_first_tick":initial,"actors_unchanged":unchanged_actors,"cell":initial_guidance_cell,"command":moved.to_record()}
		print("CASE_INPUT "+JSON.stringify(placement))
		if not initial or not moved.accepted or not unchanged_actors: _fixture_failure(c,placement)
	_tick(c)
	return c

func _fixture_preflight(c: Dictionary, c_profile: bool, surgical: bool) -> void:
	var binding_id: String = "B_S22_D14_M14" if c_profile else "B_S13_D09_M09"
	var disease_id: String = "D14" if c_profile else "D09"
	var binding: Dictionary = _content.definition("treatment_bindings",binding_id)
	var disease: Dictionary = _content.definition("diseases",disease_id)
	var routine: Dictionary = _content.definition("treatment_routines",str(binding.get("routine_id","")))
	var plan: Dictionary = _content.definition("treatment_plans","P_"+disease_id+"_COMMON")
	var missing: Array = []
	if binding.is_empty() or binding.get("disease_id","")!=disease_id or _content.definition("species",str(binding.get("species_id",""))).is_empty(): missing.append("病例、种族或疾病绑定不完整："+binding_id)
	if disease.is_empty() or routine.is_empty() or plan.get("disease_id","")!=disease_id or _content.definition("treatment_protocols",str(plan.get("protocol_id",""))).is_empty(): missing.append("疾病、治疗流程或常规协议定义不完整")
	if routine.get("equipment_id","")!="M09": missing.append("本病例的权威治疗主体不是预期M09")
	if not HospitalResearch.disease_unlocked(c.world,_content,disease_id): missing.append("本病例研究尚未完成："+disease_id)
	var required: Array = ["SE01","FUR02","M09"]
	if surgical: required.append_array(["EQ01","EQ05","SE06"])
	for definition_id: String in required:
		var placed: bool = false
		for facility: Dictionary in c.world.facts.facilities.values():
			if facility.definition_id!=definition_id or bool(facility.failed): continue
			if definition_id!="EQ01" and int(facility.floor_id)!=1: continue
			var room_id: String = str(facility.get("room_id",""))
			if definition_id in ["FUR02","M09","EQ01","EQ05"] and not c.world.facts.rooms.has(room_id): continue
			placed = true
		if not placed: missing.append("缺少实际摆放且有合法房间的设施："+definition_id)
	var research_ids: Array = ["R11"] if c_profile else []
	if surgical: research_ids.append_array(["R33","R34"])
	for research_id: String in research_ids:
		if not research_id in c.world.facts.research: missing.append("缺少正式前置研究："+research_id)
	if surgical:
		var adapter_found: bool = false
		for adapter: Dictionary in _content.catalog.surgical_adapters:
			if adapter.binding_id==binding_id and adapter.plan_id=="P_"+disease_id+"_SURGERY": adapter_found = true
		if not adapter_found: missing.append("缺少本病例的正式手术适配")
	c.fixture_preflight = {"hospital_id":c.world.hospital_id,"binding_id":binding_id,"required_equipment":required,"missing":missing}
	if not missing.is_empty(): _fixture_failure(c,c.fixture_preflight)

func _fixture_failure(c: Dictionary, reason: Dictionary) -> void:
	c.fixture_ready = false
	c.errors.append({"fixture_prerequisite":reason.duplicate(true)})
	_fixture_failures.append(reason.duplicate(true))
	print("CLINICAL FIXTURE FAIL "+JSON.stringify(reason))

func _fixture_arrival_plan(world: WorldState) -> void:
	# Clinical fixtures own their explicit patients; daily capacity is covered by growth.
	var arrivals: Dictionary = world.facts.arrivals
	arrivals.intake_open = false
	var day: int = world.sim_tick/WorldState.TICKS_PER_DAY+1
	if int(arrivals.plan.get("day_index",-1))==day: return
	var zero: Dictionary = {"n":"0","d":"1"}
	arrivals.plan = {"day_index":day,"preset":"normal","scale_numerator":0,
		"shift_capacities":[zero.duplicate(),zero.duplicate(),zero.duplicate()],
		"opportunity_count":0,"shift_opportunity_counts":[0,0,0],"schedule_seed":null,
		"schedule_algorithm":str(_content.balance.arrivals.schedule.algorithm),"next_slot_index":0,
		"held_capacity_fraction":zero.duplicate(),"held_scale_numerator":0}

func _schedule(kind: String, rooms: Array = []) -> Array:
	return [{"kind":kind,"pools":rooms.duplicate(),"locked":false},{"kind":kind,"pools":rooms.duplicate(),"locked":false},{"kind":"rest","pools":[],"locked":false}]

func _add_worker(world: WorldState, id: String, role: String, position: Array, duty: String, abilities: Dictionary, title: String = "DT01", room_id: String = "") -> void:
	HospitalFactory._add_staff(world,id,id,role,position,_content)
	var staff: Dictionary = world.facts.staff[id]
	staff.abilities = abilities.duplicate(true)
	staff.title_id = title if role=="doctor" else ""
	if role=="nurse": staff.base_prepared = false
	staff.personality_id = "DP05"
	staff.schedule = _schedule(duty,[] if room_id.is_empty() else [room_id])
	staff.on_shift = duty!="rest"

func _add_layout(world: WorldState, layout_id: String, room_id: String, origin: Array, floor_id: int = 1) -> void:
	var layout: Dictionary = {}
	for candidate: Dictionary in _content.layouts.layouts:
		if candidate.id==layout_id: layout = candidate
	if layout.is_empty(): return
	HospitalFactory._add_room(world,{"id":room_id,"type":layout.room_type_id,"anchor":origin,"size":layout.size,"floor_id":floor_id,
		"door":{"definition_id":layout.door_id,"offset":layout.door_offset}},_content)
	var bed_index: int = 0
	for index: int in layout.objects.size():
		var item: Dictionary = layout.objects[index]
		var definition: Dictionary = _content.facility_definition(item.definition_id)
		var id: String = room_id+"_"+str(index)
		var cell: Array = [int(origin[0])+int(item.anchor[0]),int(origin[1])+int(item.anchor[1])]
		HospitalFactory._add_facility(world,{"id":id,"definition_id":item.definition_id,"anchor":cell,"size":definition.footprint,"room_id":room_id},_content)
		var facility: Dictionary = world.facts.facilities[id]
		facility.floor_id=floor_id
		if item.definition_id=="EQ01":
			facility.patient_cell = _layout_point(layout,"patient_staging",origin)
			facility.operator_cells = [_layout_point(layout,"surgeon",origin),_layout_point(layout,"anesthetist",origin),_layout_point(layout,"nurse",origin)]
			facility.repair_cell = [int(origin[0])+int(layout.repair_points[0][0]),int(origin[1])+int(layout.repair_points[0][1])]
		elif item.definition_id=="EQ05":
			bed_index += 1
			facility.patient_cell = _layout_point(layout,"patient_staging_"+str(bed_index),origin)
			var care: Array = _layout_point(layout,"care_"+str(bed_index),origin)
			# The second doctor's point remains in the one-cell aisle, inside this ward.
			facility.operator_cells = [care,[int(origin[0])+4,int(origin[1])+(1 if bed_index==1 else 3)]]
			facility.repair_cell = [int(origin[0])+int(layout.repair_points[bed_index-1][0]),int(origin[1])+int(layout.repair_points[bed_index-1][1])]
		elif item.definition_id=="SE06":
			facility.operator_cells = [_layout_point(layout,"nurse_base",origin)]

func _layout_point(layout: Dictionary, kind: String, origin: Array) -> Array:
	for point: Dictionary in layout.service_points:
		if point.kind==kind: return [int(origin[0])+int(point.anchor[0]),int(origin[1])+int(point.anchor[1])]
	return []

func _command(c: Dictionary, kind: String, payload: Dictionary) -> CommandResult:
	c.serial = int(c.serial)+1
	return c.sim.apply(GameCommand.new("clinical_command_"+str(c.serial),c.world.hospital_id,c.world.revision,kind,BusinessPayload.new(payload)))

func _arrive(c: Dictionary, binding: String = "B_S13_D09_M09", plan: String = "P_D09_COMMON", allow_visitors: bool = false) -> bool:
	if not bool(c.get("fixture_ready",true)): return false
	var result: CommandResult = _command(c,"clinical_arrive",{"arrival_key":"patient-"+str(c.serial),"binding_id":binding,"requested_plan_id":plan,"personality_id":"PP01","expression":"clear"})
	if not result.accepted:
		_fixture_failure(c,{"hospital_id":c.world.hospital_id,"binding_id":binding,"formal_arrival_readiness":result.to_record()})
		return false
	c.visit_id = str(result.changed_ids[0])
	if not allow_visitors: _command(c,"clinical_visit_consent",{"visit_id":c.visit_id,"allow":false})
	return true

func _tick(c: Dictionary) -> void:
	if not bool(c.get("fixture_ready",true)): return
	_fixture_arrival_plan(c.world)
	var before_bases: Dictionary = {}
	if c.get("capture_events",false):
		for id: String in c.world.ids("staff"):
			if c.world.facts.staff[id].role=="nurse": before_bases[id] = c.world.facts.staff[id].get("base_task",{}).duplicate(true)
	var result: TickResult = ClinicalStep.step(c.sim) if c.get("clinical_scenario",false) else c.sim.step()
	for id: String in before_bases:
		var before: Dictionary = before_bases[id]
		var after: Dictionary = c.world.facts.staff[id].get("base_task",{})
		var delta: int = 0
		var facility_id: String = str(after.get("facility_id",before.get("facility_id","")))
		if before.is_empty() and not after.is_empty(): delta = 60-int(after.remaining_ticks)
		elif not before.is_empty(): delta = int(before.remaining_ticks)-int(after.get("remaining_ticks",0)) if not after.is_empty() or c.world.facts.staff[id].get("base_prepared",false) else 0
		if delta>0:
			c.nursing_handoff_ticks[id] = int(c.nursing_handoff_ticks.get(id,0))+delta
			var layout: Dictionary = c.sim.space.facility_layout(c.world,facility_id)
			if layout.is_empty() or not c.sim.space.at(c.world,id,int(layout.floor_id),layout.operator_cells[0]): c.nursing_handoff_not_at_base.append({"staff_id":id,"tick":c.world.sim_tick})
	for event: SimEvent in result.facts:
		if c.get("capture_events",false) and event.kind!="tick_completed": c.event_log.append(event.to_record())
		if event.kind=="service_started":
			var kind: String = str(event.details.get("kind",""))
			c.started[kind] = int(c.started.get(kind,0))+1
	for movement: Dictionary in c.world.facts.moves.values():
		if movement.get("members",[]).size()>1: c.group_seen = true
	for session: Dictionary in c.world.facts.sessions.values():
		if session.kind=="surgery": c.beats[int(session.get("clinical_beat",0))] = true

func _until(t, c: Dictionary, condition: Callable, maximum_ticks: int = 2200) -> bool:
	if not bool(c.get("fixture_ready",true)): return false
	for index: int in maximum_ticks:
		if condition.call(): return true
		_tick(c)
		if index%100==99:
			print("CLINICAL_PROGRESS "+JSON.stringify(_state(c)))
			await t.process_frame
	return bool(condition.call())

func _steps(t, c: Dictionary, ticks: int) -> void:
	if not bool(c.get("fixture_ready",true)): return
	for index: int in ticks:
		_tick(c)
		if index%100==99: await t.process_frame

func _visit(c: Dictionary) -> Dictionary:
	return c.world.facts.visits.get(c.visit_id,{})

func _session(c: Dictionary, kind: String) -> Dictionary:
	for value: Dictionary in c.world.facts.sessions.values():
		if value.visit_id==c.visit_id and value.kind==kind: return value
	return {}

func _stay(c: Dictionary) -> Dictionary:
	for value: Dictionary in c.world.facts.ward_stays.values():
		if value.visit_id==c.visit_id: return value
	return {}

func _income(c: Dictionary, component: String = "") -> int:
	var amount: int = 0
	for entry: Dictionary in c.world.facts.ledger.entries.values():
		if bool(entry.settled) and int(entry.amount)>0 and (component.is_empty() or entry.component==component): amount += int(entry.amount)
	return amount

func _units_used(c: Dictionary) -> int:
	var units: int = 0
	for issue: Dictionary in c.world.facts.inventory.issues.values(): units += int(issue.units)
	return units

func _remember(c: Dictionary, key: String) -> void:
	var error: String = c.world.validate(_content)
	if not error.is_empty():
		_fixture_failures.append({"boundary":key,"validation":error})
		return
	var state: Dictionary = {"facts":c.world.freeze(),"visit_id":c.visit_id,"serial":int(c.serial),"doctors":c.doctors.duplicate(),"started":c.started.duplicate(),"group_seen":c.group_seen,"beats":c.beats.duplicate()}
	for field: String in ["queue_gp_session","queue_ready","ward_return","plan_selection","diagnosis_trace","boundary_input","before_bed_arrival","before_admission","clinical_scenario"]:
		if c.has(field): state[field] = c[field]
	_snapshots[key] = state.duplicate(true)
	_building_key = key
	_building_context = c
	if not _cache.publish(key,state): _fixture_failures.append({"boundary":key,"cache_write":false})

func _copy(key: String) -> Dictionary:
	if not _snapshots.has(key): return {}
	var source: Dictionary = _snapshots[key]
	var world: WorldState = WorldState.new(source.facts.duplicate(true))
	var simulation: HospitalSimulation = HospitalSimulation.new(world,_content)
	_simulations.append(simulation)
	var copy: Dictionary = source.duplicate(true)
	copy.erase("facts")
	copy.sim = simulation
	copy.world = world
	copy.errors = []
	return copy

func _checkpoint_recipes() -> Dictionary:
	if not _checkpoint_recipe_cache.is_empty(): return _checkpoint_recipe_cache
	var recipes: Dictionary = {
		"gp_started":{"generator":"_gp_checkpoint","condition":{"phase":"gp"}},
		"c_diagnosed":{"generator":"_diagnosis_state","arguments":[false],"condition":{"diagnosed":true}},
		"surgery_queue":{"generator":"_surgery_queue","arguments":[false],"condition":{"phase":"wait_surgery","stay_phase":"waiting_surgery"}},
		"c_surgery_queue":{"generator":"_surgery_queue","arguments":[true],"condition":{"phase":"wait_surgery","stay_phase":"waiting_surgery"}},
		"outpatient_queue":{"parent":"gp_started","maximum_ticks":2200,"condition":{"phase":"wait_outpatient","preparation":true,"no_attempt":true},"output_flags":{"queue_ready":true}},
		"outpatient_started":{"parent":"outpatient_queue","maximum_ticks":2200,"condition":{"phase":"outpatient"}},
		"surgery_prepared":{"parent":"surgery_queue","maximum_ticks":600,"condition":{"preparation":true}},
		"surgery_setup":{"parent":"surgery_prepared","maximum_ticks":900,"condition":{"preparation":true,"setup_started":true}},
		"surgery_started":{"parent":"surgery_prepared","maximum_ticks":600,"condition":{"phase":"surgery"}},
		"surgery_wake":{"parent":"surgery_started","maximum_ticks":1800,"condition":{"phase":"wake"}},
		"surgery_transfer":{"parent":"surgery_wake","maximum_ticks":200,"condition":{"phase":"transfer"}},
		"ward_entered":{"parent":"surgery_transfer","maximum_ticks":900,"condition":{"phase":"recovery"}},
		"ward_care":{"parent":"ward_entered","maximum_ticks":300,"await_escort":true,"condition":{"session":"care"}},
		"ward_after_care":{"parent":"ward_care","maximum_ticks":350,"condition":{"stay_flag":"care_completed"}},
		"ward_before_settlement":{"parent":"ward_after_care","maximum_ticks":2200,"condition":{"stay_flag":"care_completed","stay_remaining_ticks":1}},
		"ward_settled":{"parent":"ward_before_settlement","maximum_ticks":300,"condition":{"final_result":true}}}
	for recipe: Dictionary in recipes.values(): recipe.methods = ["_ensure_boundary","_boundary_input","_at_boundary"]
	_checkpoint_recipe_cache = recipes
	return recipes

func _checkpoint_dependencies(key: String) -> Dictionary:
	return CheckpointIdentity.describe("res://tests/acceptance/clinical_fixtures.gd",_checkpoint_recipes(),key)

func _gp_checkpoint(t) -> Dictionary:
	var c: Dictionary = _context()
	_seed_stream(c.world,"treatment",false,true,4000,9200)
	if _arrive(c) and await _until(t,c,func()->bool: return _visit(c).get("phase","")=="gp"):
		c.queue_gp_session = _session(c,"gp").duplicate(true)
	return c

func _ensure_boundary(t, key: String) -> bool:
	var recipes: Dictionary = _checkpoint_recipes()
	if not recipes.has(key):
		_fixture_failures.append({"unknown_boundary":key})
		return false
	var cached: Dictionary = _cache.read(key)
	if not cached.is_empty():
		_snapshots[key] = cached
		return true
	var c: Dictionary = {}
	var recipe: Dictionary = recipes[key]
	for ancestor: String in recipe.get("requires",[]):
		if not await _ensure_boundary(t,ancestor): return false
	if recipe.has("generator"):
		var generated: Variant = await callv(recipe.generator,[t]+recipe.get("arguments",[]))
		if generated is Dictionary: c = generated
		if _snapshots.has(key): return true
		if not c.is_empty() and _at_boundary(c,key): _remember(c,key)
	else:
		var parent: String = recipe.parent
		if not await _ensure_boundary(t,parent): return false
		# Keep the real live prefix only until its next named boundary. Frozen
		# nodes remain immutable; disk restores always construct new services.
		c = _building_context if _building_key==parent else _copy(parent)
		_building_key = ""
		_building_context = {}
		if not _boundary_input(c,key): return false
		if recipe.get("await_escort",false):
			var escort: String = str(_stay(c).get("escort_id",""))
			await _until(t,c,func()->bool: return not c.sim.clinic.staff_busy(c.world,escort),180)
		if await _until(t,c,func()->bool: return _at_boundary(c,key),int(recipe.maximum_ticks)):
			for field: String in recipe.get("output_flags",{}): c[field] = recipe.output_flags[field]
			_remember(c,key)
	if not _snapshots.has(key):
		_fixture_failures.append({"missing_boundary":key,"state":_state(c) if not c.is_empty() else {}})
	return _snapshots.has(key)

func _boundary_input(c: Dictionary, key: String) -> bool:
	# These are declared input states for downstream cases. They do not prove
	# earlier travel or elapsed work. CLIN-18/19/20 exercise those actual segments.
	var input: Dictionary = _checkpoint_recipes().get(key,{}).get("input",{})
	if input.get("kind","")=="gathered_surgical_team":
		var preparation: Dictionary = c.world.facts.preparations[c.visit_id]
		var layout: Dictionary = c.sim.space.facility_layout(c.world,preparation.facility_id)
		var positions: Dictionary = {_visit(c).actor_id:layout.patient_cell}
		for index: int in preparation.staff_ids.size(): positions[preparation.staff_ids[index]] = layout.operator_cells[index]
		for id: String in positions:
			c.world.facts.moves.erase(id)
			c.world.facts.actors[id].location = {"kind":"floor","floor_id":int(layout.floor_id),"cell":positions[id].duplicate(),"height_m":0.0}
			c.world.facts.actors[id].posture = "standing"
			c.world.facts.actors[id].erase("support_facility_id")
		c.world.facts.sim_tick = maxi(c.world.sim_tick,int(preparation.deadline_tick)-2)
		preparation.setup_remaining_ticks = 1
		c.boundary_input = {"kind":"gathered_surgical_team","setup_remaining_ticks":1,"prior_travel_and_setup":"input"}
	elif input.get("kind","")=="last_work_tick":
		var session: Dictionary = _session(c,input.service)
		if session.is_empty(): return false
		var delta: int = maxi(0,int(session.remaining_ticks)-1)
		c.world.facts.sim_tick += delta
		session.remaining_ticks = 1
		if session.kind=="surgery": session.clinical_beat = 3
		if session.kind=="care": _stay(c).remaining_ticks = maxi(1,int(_stay(c).remaining_ticks)-delta)
		c.boundary_input = {"kind":"last_work_tick","service":session.kind,"remaining_ticks":1,"prior_work_ticks":"input"}
	elif input.get("kind","")=="last_recovery_tick":
		var stay: Dictionary = _stay(c)
		c.world.facts.sim_tick += maxi(0,int(stay.remaining_ticks)-1)
		stay.remaining_ticks = 1
		c.boundary_input = {"kind":"last_recovery_tick","prior_recovery_ticks":"input"}
	else:
		return true
	_visit(c).last_progress_tick = c.world.sim_tick
	_visit(c).last_service_tick = c.world.sim_tick
	if not _stay(c).is_empty():
		_stay(c).last_progress_tick = c.world.sim_tick
		if _stay(c).has("coverage_segment"): _stay(c).coverage_segment.start_tick = c.world.sim_tick
	c.world.touch()
	var validation: String = c.world.validate(_content)
	print("FIXTURE_INPUT "+JSON.stringify({"for_boundary":key,"input":c.boundary_input,"validation":validation}))
	if not validation.is_empty(): _fixture_failures.append({"boundary_input":key,"validation":validation})
	return validation.is_empty()

func _at_boundary(c: Dictionary, key: String) -> bool:
	var condition: Dictionary = _checkpoint_recipes().get(key,{}).get("condition",{})
	if condition.is_empty(): return false
	if condition.has("phase") and _visit(c).get("phase","")!=condition.phase: return false
	if condition.get("preparation",false) and not c.world.facts.preparations.has(c.visit_id): return false
	if condition.get("setup_started",false) and int(c.world.facts.preparations.get(c.visit_id,{}).get("deadline_tick",-1))<0: return false
	if condition.get("no_attempt",false) and not _visit(c).attempt_ids.is_empty(): return false
	if condition.get("diagnosed",false) and _visit(c).get("diagnosis",{}).get("state","")!="diagnosed": return false
	if condition.has("session") and _session(c,condition.session).is_empty(): return false
	if condition.has("stay_flag") and not bool(_stay(c).get(condition.stay_flag,false)): return false
	if condition.has("stay_phase") and _stay(c).get("phase","")!=condition.stay_phase: return false
	if condition.has("stay_remaining_ticks") and int(_stay(c).get("remaining_ticks",-1))!=int(condition.stay_remaining_ticks): return false
	if condition.get("final_result",false) and _visit(c).get("final_result","").is_empty(): return false
	return true

func _require(t, ids: Array, key: String) -> bool:
	if _snapshots.has(key): return true
	for id: String in ids: t.check(id,false,{"missing_real_business_boundary":key,"fixture_prerequisites":_fixture_failures})
	return false

func _state(c: Dictionary) -> Dictionary:
	var participants: Array = []
	for id: String in c.world.ids("actors"):
		var actor: Dictionary = c.world.facts.actors[id]
		var staff: Dictionary = c.world.facts.staff.get(id,{})
		var move: Dictionary = c.world.facts.moves.get(id,{})
		participants.append({"id":id,"location":actor.location.duplicate(true),"release":staff.get("clinical_release",{}).duplicate(true),"base":staff.get("base_task",{}).duplicate(true),"move":{"target":move.get("target_cell",[]),"cursor":move.get("cursor",-1),"blocked_since":move.get("blocked_since",-1),"yielding":move.get("yielding",false),"pending":move.get("route_pending",false),"next":move.get("path",[]).slice(int(move.get("cursor",0)),int(move.get("cursor",0))+3)}})
	return {"tick":c.world.sim_tick,"visit":_visit(c).duplicate(true),"sessions":c.world.facts.sessions.duplicate(true),"preparations":c.world.facts.preparations.duplicate(true),"stays":c.world.facts.ward_stays.duplicate(true),"participants":participants,"errors":c.errors}

func _seed_stream(world: WorldState, stream: String, first_success: bool, second_success: bool, first_limit: int, second_limit: int) -> bool:
	# Search input seeds, never modify or redraw an already committed Attempt.
	for seed_value: int in range(1,200000):
		var generator: RandomNumberGenerator = RandomNumberGenerator.new()
		generator.seed = seed_value
		var initial: int = generator.state
		var first: int = generator.randi_range(0,9999)
		var second: int = generator.randi_range(0,9999)
		if (first<first_limit)==first_success and (second<second_limit)==second_success:
			world.facts.rng[stream] = {"algorithm":"godot-pcg32-4.7.2","seed_decimal":str(seed_value),"state_decimal":str(initial)}
			return true
	return false

func _commitments(attempts: Dictionary) -> Dictionary:
	var result: Dictionary = {}
	for id: String in attempts:
		var frozen: Dictionary = {}
		for key: String in ["id","visit_id","plan_id","protocol_id","result","probability_bp","start_tick","work_ticks","recovery_ticks","supply_units","cure_fee","facility_fee","ward_fee","ward_fee_quote","staff_ids","effective_level","beat_end_ticks"]:
			frozen[key] = attempts[id].get(key)
		result[id] = frozen
	return result

func _roundtrip(c: Dictionary) -> Dictionary:
	var chunks: Array = []
	var encoder: HospitalJsonStream = HospitalJsonStream.new()
	var encoded: bool = encoder.encode_to(c.world.freeze(),func(_bytes: int)->bool: return true,func(chunk: PackedByteArray)->Dictionary:
		chunks.append(chunk.duplicate())
		return {"ok":true})
	if not encoded: return {"ok":false,"error":encoder.error}
	var cursor: Dictionary = {"index":0}
	var decoder: HospitalJsonStream = HospitalJsonStream.new()
	var decoded: Dictionary = decoder.decode_from(encoder.bytes,encoder.digest,func(_bytes: int)->bool: return true,func()->Dictionary:
		if int(cursor.index)>=chunks.size(): return {"ok":true,"data":PackedByteArray()}
		var chunk: PackedByteArray = chunks[int(cursor.index)]
		cursor.index = int(cursor.index)+1
		return {"ok":true,"data":chunk})
	if not decoded.ok: return {"ok":false,"error":decoded.error}
	var world: WorldState = WorldState.new(decoded.value)
	var reason: String = world.validate(_content)
	if not reason.is_empty(): return {"ok":false,"error":reason,"failure_world":_failure_world("roundtrip",world)}
	var original: Dictionary = c.world.freeze()
	if world.freeze()!=original: return {"ok":false,"error":"流式恢复后的世界与冻结边界不同"}
	var simulation: HospitalSimulation = HospitalSimulation.new(world,_content)
	_simulations.append(simulation)
	c.world = world
	c.sim = simulation
	return {"ok":true,"bytes":encoder.bytes,"sha256":encoder.digest}

func _surgery_queue(t, c_profile: bool = false, allow_visitors: bool = false, or_floor: int = 1, initial_bed_grade: int = 0) -> Dictionary:
	var c: Dictionary=_context(true,c_profile,true,[],false,or_floor,or_floor,initial_bed_grade)
	c.clinical_scenario=true
	c.ward_return={"ok":false,"reason":"ward_base_not_ready"}
	c.plan_selection=CommandResult.new(false,"diagnosis_missing").to_record()
	if c_profile:
		c.world.facts.staff.clin_surgeon.title_id="DT03"
		c.world.facts.staff.clin_surgeon.abilities.surgery=3
		c.world.facts.staff.clin_or_nurse.abilities.surgery=2
	# Nursing setup is an actual prefix before the patient arrives, so waiting
	# for it can never accidentally start this patient's ordinary treatment.
	var nurse_ready: bool=await _until(t,c,func()->bool:return _surgery_staff_ready(c),1200)
	c.ward_return={"ok":nurse_ready,"reason":"" if nurse_ready else "ward_base_not_ready","after":_ward_nurse_return_state(c)}
	if not nurse_ready: return c
	var binding: String="B_S22_D14_M14" if c_profile else "B_S13_D09_M09"
	var plan: String="P_D14_SURGERY" if c_profile else "P_D09_SURGERY"
	_seed_stream(c.world,"treatment",false,true,3200 if c_profile else 4000,9600)
	# Bed/nurse cases use the lawful no-family branch; family scenarios opt in
	# to the two independent hit outcomes and still execute all actual travel.
	_seed_stream(c.world,"arrival",allow_visitors,allow_visitors,8000,3000)
	if not _arrive(c,binding,plan,allow_visitors): return c
	var diagnosed: bool=await _until(t,c,func()->bool:return _visit(c).get("diagnosis",{}).get("state","")=="diagnosed" and str(_visit(c).phase).begins_with("wait_"),3000)
	if not diagnosed:
		c.errors.append({"missing":"completed_diagnosis"})
		return c
	var selected: CommandResult=_command(c,"clinical_select_plan",{"visit_id":c.visit_id,"plan_id":plan})
	c.plan_selection=selected.to_record()
	if not selected.accepted:
		_fixture_failure(c,{"stage":"surgery_plan_selection","selection":selected.to_record(),"diagnosis":_visit(c).diagnosis.duplicate(true)})
		return c
	for index: int in 2200:
		var before: Dictionary=c.world.freeze()
		_tick(c)
		var ward: Dictionary=_stay(c)
		if not c.has("before_bed_arrival") and ward.get("phase","")=="admitting":
			var bed: Dictionary=c.sim.space.facility_layout(c.world,str(ward.bed_id))
			if not c.sim.space.at(c.world,str(_visit(c).actor_id),int(bed.floor_id),bed.patient_cell):
				c.before_bed_arrival={"facts":c.world.freeze(),"visit_id":c.visit_id}
		if ward.has("admitted_tick"):
			c.before_admission={"facts":before,"visit_id":c.visit_id}
			return c
		if index%100==99: await t.process_frame
	c.errors.append({"missing":"actual_admission"})
	return c

func _surgery_staff_ready(c: Dictionary) -> bool:
	var nurse: Dictionary=c.world.facts.staff.clin_or_nurse
	return bool(_ward_nurse_return_state(c).ready) and nurse.on_shift and bool(nurse.get("base_prepared",false)) and nurse.get("base_task",{}).is_empty() and str(nurse.get("life_task",{}).get("phase","idle")) in ["idle","wait_safe"] and not c.world.facts.moves.has("clin_or_nurse") and not c.sim.clinic.staff_busy(c.world,"clin_or_nurse")

func _ward_nurse_return_state(c: Dictionary) -> Dictionary:
	var nurse: Dictionary = c.world.facts.staff.clin_cover
	var location: Dictionary = c.world.facts.actors.clin_cover.location
	var scheduler: HospitalShiftScheduler = c.sim.services.scheduler
	var assignment: Dictionary = scheduler.assignment(c.world,"clin_cover",scheduler.shift_index(c.world))
	var ward_id: String = str(assignment.pools[0]) if assignment.kind=="work" and not assignment.pools.is_empty() else ""
	var ward: Dictionary = c.world.facts.rooms.get(ward_id,{})
	var inside: bool = not ward.is_empty() and location.kind=="floor" and int(location.floor_id)==int(ward.floor_id) and Rect2(float(ward.origin[0]),float(ward.origin[1]),float(ward.size[0]),float(ward.size[1])).has_point(Vector2(float(location.cell[0]),float(location.cell[1])))
	var ready: bool = ward_id=="clin_ward" and nurse.on_shift and bool(nurse.get("base_prepared",false)) and "q_ward" in nurse.certificates and not bool(nurse.get("block_new_work",false)) and nurse.get("base_task",{}).is_empty() and str(nurse.get("life_task",{}).get("phase","idle")) in ["idle","wait_safe"] and not c.world.facts.moves.has("clin_cover") and not c.sim.clinic.staff_busy(c.world,"clin_cover")
	return {"ready":ready,"nurse_id":"clin_cover","ward_id":ward_id,"location":location.duplicate(true),"inside_assigned_ward":inside,"on_shift":nurse.on_shift,"base_prepared":nurse.get("base_prepared",false),"move":c.world.facts.moves.get("clin_cover",{}).duplicate(true),"clinical_release":nurse.get("clinical_release",{}).duplicate(true)}

func _wait_ward_nurse_return(t, c: Dictionary) -> Dictionary:
	var before: Dictionary = _ward_nurse_return_state(c)
	var started_tick: int = c.world.sim_tick
	await _until(t,c,func()->bool:
		if not c.world.facts.attempts.is_empty(): return true
		return bool(_ward_nurse_return_state(c).ready),240)
	var after: Dictionary = _ward_nurse_return_state(c)
	var unstarted: bool = c.world.facts.attempts.is_empty() and _visit(c).get("attempt_ids",[]).is_empty()
	var waiting: bool = _visit(c).get("phase","") in ["wait_outpatient","wait_surgery"]
	var reason: String = ""
	if not unstarted:
		reason = "等待回岗期间已经实际开工，保留原Attempt"
	elif not waiting:
		reason = "病例已离开候治疗边界"
	elif not bool(after.ready):
		reason = "覆盖护士未完成实际回岗"
	return {"ok":reason.is_empty(),"reason":reason,"started_tick":started_tick,"finished_tick":c.world.sim_tick,"no_attempt_started":unstarted,"phase":_visit(c).get("phase",""),"before":before,"after":after}

func _waiting_case(c: Dictionary, position: Array) -> String:
	# A second already-diagnosed queue member is a boundary fixture, not a second flow implementation.
	var source: Dictionary = _visit(c)
	var actor_id: String = c.world.new_id("patient")
	var visit_id: String = c.world.new_id("visit")
	var ticket_id: String = c.world.new_id("ticket")
	var actor: Dictionary = c.world.facts.actors[source.actor_id].duplicate(true)
	actor.id = actor_id
	actor.location = {"kind":"floor","floor_id":1,"cell":position.duplicate(),"height_m":0.0}
	actor.posture = "standing"
	actor.erase("support_facility_id")
	var visit: Dictionary = source.duplicate(true)
	visit.id = visit_id
	visit.actor_id = actor_id
	visit.ticket_id = ticket_id
	visit.arrival_key = "second-prepared-patient"
	visit.phase = "wait_surgery"
	visit.attempt_ids = []
	visit.final_result = ""
	visit.erase("clinical_participants")
	c.world.facts.actors[actor_id] = actor
	c.world.facts.visits[visit_id] = visit
	c.world.facts.tickets[ticket_id] = {"id":ticket_id,"visit_id":visit_id,"kind":"surgery","enqueued_tick":c.world.sim_tick}
	c.world.facts.arrival_receipts[visit.arrival_key] = visit_id
	HospitalLedger.post(c.world,LedgerEntry.new(visit_id,"consultation",20))
	HospitalLedger.post(c.world,LedgerEntry.new(visit_id,"gp",5))
	return visit_id

func _in_stay_ward(c: Dictionary, actor_id: String) -> bool:
	var bed: Dictionary = c.world.facts.facilities.get(str(_stay(c).get("bed_id","")),{})
	var ward: Dictionary = c.world.facts.rooms.get(str(bed.get("room_id","")),{})
	var actor: Dictionary = c.world.facts.actors.get(actor_id,{})
	if ward.is_empty() or actor.is_empty() or actor.location.kind!="floor" or int(actor.location.floor_id)!=int(ward.floor_id): return false
	return Rect2(float(ward.origin[0]),float(ward.origin[1]),float(ward.size[0]),float(ward.size[1])).has_point(Vector2(float(actor.location.cell[0]),float(actor.location.cell[1])))

func _failure_world(case_id: String, world: WorldState) -> Dictionary:
	if world==null: return {"ok":false,"error":"缺少实际模拟世界"}
	var path: String = "res://"+case_id+"-failure-"+HospitalSnapshots.uuid()+".json"
	var encoder: HospitalJsonStream = HospitalJsonStream.new()
	var encoded: bool = encoder.encode(path,world.freeze(),func(_bytes: int)->bool: return true)
	return {"ok":encoded,"path":ProjectSettings.globalize_path(path),"bytes":encoder.bytes,"sha256":encoder.digest,"error":encoder.error,"tick":world.sim_tick}

func _all_rest(world: WorldState, role: String, only_round_qualified: bool = false) -> void:
	for staff: Dictionary in world.facts.staff.values():
		if staff.role!=role: continue
		if only_round_qualified and (int(staff.abilities.diagnosis)<2 or int(staff.abilities.treatment)<1): continue
		staff.schedule = _schedule("rest")

func _visitor(c: Dictionary) -> Dictionary:
	for stay: Dictionary in c.world.facts.visitors.stays.values():
		if stay.visit_id==c.visit_id: return stay
	return {}

func _remove_waiting_chairs(world: WorldState) -> void:
	for id: String in world.ids("facilities"):
		if world.facts.facilities[id].definition_id=="FUR09": world.facts.facilities.erase(id)
	world.touch()

func _diagnosis_state(t, upgraded: bool, initial_guidance_cell: Array = []) -> Dictionary:
	var c: Dictionary=_context(false,true,true,initial_guidance_cell)
	c.clinical_scenario=true
	c.world.facts.staff[c.doctors[0]].abilities.diagnosis=3 if upgraded else 2
	if upgraded: c.world.facts.facilities.gp_station.grade=2
	_seed_stream(c.world,"treatment",false,true,2400 if upgraded else 3200,9200)
	var arrived: bool=_arrive(c,"B_S22_D14_M14","P_D14_COMMON")
	var diagnosed: bool=arrived and await _until(t,c,func()->bool:return _visit(c).get("diagnosis",{}).get("state","")=="diagnosed" and _visit(c).phase=="wait_outpatient",2200)
	if not diagnosed: c.errors.append({"missing":"actual_diagnosis_before_treatment"})
	return c
