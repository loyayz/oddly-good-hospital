"""One serial, bounded affected-contract batch after the native build."""
import argparse
import hashlib
import importlib.util
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / '.cache/query-rect-acceptance01'
BUILD = ROOT / '.cache/query-rect-native-build03/build-identity.json'
CASES = ['PERF-11', 'PERF-12', 'SPACE-53', 'SPACE-57', 'SPACE-61']


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--check-only', action='store_true')
    args = parser.parse_args()
    assert not OUTPUT.exists(), 'Preserve earlier batch evidence'
    build = json.loads(BUILD.read_text(encoding='utf-8-sig'))
    assert build['ok'] and build['environment_probe_exit_code'] == 0, 'Native build has not passed'
    for name, expected in build['source'].items():
        assert digest(ROOT / name) == expected, f'Build source changed: {name}'
    for name, expected in build['new_native'].items():
        assert digest(ROOT / 'game/platform/windows/bin' / name) == expected
    guard_path = ROOT / 'tools/performance/current/prepare_builtin_script_profile.py'
    sys.path.insert(0, str(guard_path.parent))
    spec = importlib.util.spec_from_file_location('qualified_guard', guard_path)
    guard = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(guard)
    command = ['pwsh', '-NoProfile', '-File', str(ROOT / 'tests/run-acceptance.ps1'), '-CaseId', ','.join(CASES)]
    if args.check_only:
        print(json.dumps({'ok': True, 'cases': CASES, 'command': command,
                          'native': build['new_native'], 'output': str(OUTPUT),
                          'engine_started': False, 'created_output': False}))
        return
    process = guard.run_process(command, ROOT, OUTPUT, 900)
    raw = (OUTPUT / 'engine.log').read_text(encoding='utf-8-sig')
    projects = re.findall(r'^ACCEPTANCE_PROJECT=(.+)$', raw, re.MULTILINE)
    assert len(projects) == 1, 'Missing unique acceptance project'
    project = Path(projects[0].strip())
    results = json.loads((project / 'acceptance-results.json').read_text(encoding='utf-8-sig'))
    assert results['completed'] and results['failed'] == 0 and results['checks'] == len(CASES)
    assert set(results['results']) == set(CASES)
    timing = json.loads((project / 'timing-summary.json').read_text(encoding='utf-8-sig'))
    summary = {'ok': True, 'cases': CASES, 'project': str(project), 'process': process,
               'native': build['new_native'], 'timing': timing,
               'result_sha256': digest(project / 'acceptance-results.json')}
    (OUTPUT / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(summary, ensure_ascii=False))


if __name__ == '__main__':
    main()
