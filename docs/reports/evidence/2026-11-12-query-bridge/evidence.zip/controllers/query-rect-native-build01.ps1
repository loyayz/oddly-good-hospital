#requires -Version 7.0
param([switch]$CheckOnly)
$ErrorActionPreference='Stop'
$repo='C:/code/loyayz/oddly-good-hospital'
$target=Join-Path $repo '.cache/query-rect-native-build01'
$batch=Join-Path $repo '.cache/performance160-clinical-family-20261112-candidate03/plain-batch01/status.json'
$godot='C:/programs/godot/Godot_v4.7.2-stable_win64_console.exe'
$zig=Join-Path $repo '.cache/native-math/zig-x86_64-windows-0.15.2/zig.exe'
$compilerCache=Join-Path $repo '.cache/resident-mask-native-20261112-build02'
$native=Join-Path $repo 'game/platform/windows/bin'
$expected=@{
 'oddly_good_platform.windows.x86_64.dll'='89d4e1db54ca8a52ee2ed7da5b5fdcc1917c0667d172ab89d2fe683bc1767af2'
 'libgcc_s_seh-1.dll'='791ebf66e99c7c1b4ed3666468cec45a0172b4c8942ac6c84c3e9cab3e1b5270'
 'libgmp-10.dll'='c2567ccf3f410c3411ba7cd4b7ba14f393a0e70a1d0c0593297df6706b5fba96'
 'libmpfr-6.dll'='b881beb5ed7e3413283ab94f24ab25cd47ed27127774867ae105642ff2fc2e47'
 'libwinpthread-1.dll'='e765ee6109a0080a7c42848911f4349099b3c15aa734d845cb0e438f6f5a91b5'
}
function Hash([string]$Path) { (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant() }
if(Test-Path -LiteralPath $target){throw 'Build output already exists'}
if((Hash $godot)-ne 'c8f0a6bc45a19b33541501e57f6f7cd972ab18453743266339d495cbbe846643'){throw 'Engine identity changed'}
foreach($name in $expected.Keys){if((Hash (Join-Path $native $name))-ne $expected[$name]){throw "Baseline DLL changed: $name"}}
foreach($name in @('zig-global','zig-local')){if(-not(Test-Path -LiteralPath (Join-Path $compilerCache $name) -PathType Container)){throw 'Qualified compiler cache missing'}}
$sources=@{}
$sourcePaths=@(& git -C $repo ls-files -- game/platform/windows tools/build-platform-guard.ps1 tools/build-arrival-math.ps1 tools/build-arrival-discrete.ps1 tools/build-json-stream.ps1 tools/build-backup-zip.ps1)
if($LASTEXITCODE-ne 0){throw 'Cannot enumerate build source'}
foreach($name in $sourcePaths){if($name -match '\.(h|cpp|c|ps1)$'){$sources[$name]=Hash (Join-Path $repo $name)}}
$status=Get-Content -LiteralPath $batch -Raw | ConvertFrom-Json
$identity=[ordered]@{check_only=[bool]$CheckOnly;can_start=($status.state-eq 'complete');source=$sources;old_native=$expected;compiler=$zig;compiler_sha256=(Hash $zig);godot=$godot;godot_sha256=(Hash $godot);reused_compiler_cache=$compilerCache;output=$target}
if($CheckOnly){$identity|ConvertTo-Json -Depth 5;return}
if($status.state-ne 'complete' -or $status.completed-ne 5){throw 'Three plain windows have not released the engine/build slot'}
New-Item -ItemType Directory -Path $target | Out-Null
$environment=@{APPDATA=(Join-Path $target 'runtime/Roaming');LOCALAPPDATA=(Join-Path $target 'runtime/Local');TEMP=(Join-Path $target 'tmp');TMP=(Join-Path $target 'tmp');TMPDIR=(Join-Path $target 'tmp');ZIG_GLOBAL_CACHE_DIR=(Join-Path $compilerCache 'zig-global');ZIG_LOCAL_CACHE_DIR=(Join-Path $compilerCache 'zig-local');OMP_NUM_THREADS='1'}
foreach($name in @('APPDATA','LOCALAPPDATA','TEMP')){New-Item -ItemType Directory -Path $environment[$name] -Force | Out-Null}
foreach($name in $environment.Keys){[Environment]::SetEnvironmentVariable($name,$environment[$name],'Process')}
$backup=Join-Path $target 'old-dlls'
New-Item -ItemType Directory -Path $backup | Out-Null
foreach($name in $expected.Keys){Copy-Item -LiteralPath (Join-Path $native $name) -Destination (Join-Path $backup $name);if((Hash (Join-Path $backup $name))-ne $expected[$name]){throw 'Backup identity mismatch'}}
$identity.check_only=$false
$identity.started_utc=[DateTimeOffset]::UtcNow.ToString('o')
$identity.environment=$environment
$identity.ok=$false
$identity.error=''
$identity|ConvertTo-Json -Depth 6|Set-Content -LiteralPath (Join-Path $target 'build-identity.json') -Encoding utf8NoBOM
$watch=[Diagnostics.Stopwatch]::StartNew()
try {
 & (Join-Path $repo 'tools/build-platform-guard.ps1') -GodotPath $godot *>&1 | Tee-Object -FilePath (Join-Path $target 'build.log')
 foreach($name in $sources.Keys){if((Hash (Join-Path $repo $name))-ne $sources[$name]){throw "Build source changed: $name"}}
 $identity.ok=$true
} catch {$identity.error=$_.Exception.Message;throw} finally {
 $identity.elapsed_ms=$watch.ElapsedMilliseconds
 $identity.ended_utc=[DateTimeOffset]::UtcNow.ToString('o')
 $identity.new_native=@{}
 foreach($name in $expected.Keys){$identity.new_native[$name]=Hash (Join-Path $native $name)}
 $identity|ConvertTo-Json -Depth 6|Set-Content -LiteralPath (Join-Path $target 'build-identity.json') -Encoding utf8NoBOM
}
Write-Output ('QUERY_RECT_NATIVE_BUILD='+$target)
