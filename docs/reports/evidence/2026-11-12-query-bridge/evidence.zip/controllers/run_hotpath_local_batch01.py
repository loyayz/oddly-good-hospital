"""Serial local probes on the already-passed isolated acceptance project."""
import argparse
import hashlib
import importlib.util
import json
import subprocess
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'.cache/hotpath-local-batch01'
ACCEPTANCE=ROOT/'.cache/query-rect-acceptance01/summary.json'
ENGINE=Path('C:/programs/Godot/Godot_v4.7.2-stable_win64_console.exe')
FINAL=ROOT/'.cache/performance160-clinical-family-20261112-mixed-candidate01/qualification-r1/r1.json.final.bin'
FINAL_SHA='0daf82b82da618af8818aed962d5ef2bf9bad1b00be01c4f5a7ce71efb52662e'
MIXED=ROOT/'.cache/performance160-mixed-20261112-toolqualification01/mixed-input01/mixed160.input.bin'
MIXED_SHA='75f5e1d922f39f12382c0ceb74806bda0293251189f68a1ac158842f65fa78ca'

def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path): return json.loads(path.read_text(encoding='utf-8-sig'))
def write(path,value): path.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--check-only',action='store_true');args=parser.parse_args()
    accepted=read(ACCEPTANCE);assert accepted['ok']
    project=Path(accepted['project']);identity=read(project/'source-identity.json')
    assert digest(FINAL)==FINAL_SHA and digest(MIXED)==MIXED_SHA
    source={}
    for row in identity['source']:
        name=row['path']; original=(ROOT/name).read_bytes()
        assert hashlib.sha256(original).hexdigest()==row['sha256'],f'Current source changed: {name}'
        expected=original
        if name=='project.godot':
            old='config/custom_user_dir_name="oddly-good-hospital"'
            text=original.decode('utf-8');assert text.count(old)==1
            expected=text.replace(old,'config/custom_user_dir_name="'+identity['profile']+'"').encode('utf-8')+b'\r\n'
        assert (project/name).read_bytes()==expected,f'Unexpected isolated source: {name}'
        source[name]=digest(project/name)
    for name,expected in accepted['native'].items(): assert digest(project/'game/platform/windows/bin'/name)==expected
    assert digest(ENGINE)==identity['engine_sha256'].lower()
    actual_engine=ENGINE.with_name(ENGINE.name.replace('_console.exe','.exe'))
    assert digest(actual_engine)=='ab1824f85bfd8e0e4128182c000c4003a3e042245b2967848d089b2a04b22424'
    sys.path.insert(0,str(ROOT/'tools/performance/current'))
    spec=importlib.util.spec_from_file_location('qualified_guard',ROOT/'tools/performance/current/prepare_builtin_script_profile.py')
    guard=importlib.util.module_from_spec(spec);spec.loader.exec_module(guard)
    tasks=[
      ('inspect','business_fact_probe.gd',['--inspect','--input='+str(FINAL)],120),
      ('clock','waiting_clock_probe.gd',['--input='+str(FINAL),'--expected-sha='+FINAL_SHA,'--iterations=1000'],180),
      ('shape-counts','traversal_shape_probe.gd',['--input='+str(MIXED),'--expected-sha='+MIXED_SHA,'--mode=counts','--iterations=256'],180),
      ('shape-timing','traversal_shape_probe.gd',['--input='+str(MIXED),'--expected-sha='+MIXED_SHA,'--mode=timing','--iterations=256'],180),
    ]
    assert not BASE.exists(),'Preserve existing output'
    if args.check_only:
        print(json.dumps({'ok':True,'source_count':len(source),'project':str(project),'native':accepted['native'],
                          'tasks':[t[0] for t in tasks]+['spatial-capture','spatial-replay'],
                          'engine_started':False,'created_output':False}));return
    BASE.mkdir()
    write(BASE/'protocol.json',{'source':source,'native':accepted['native'],'engine':str(ENGINE),'engine_sha256':digest(ENGINE),
                              'actual_engine':str(actual_engine),'actual_engine_sha256':digest(actual_engine),
                              'acceptance':str(ACCEPTANCE),'input':str(MIXED),'input_sha256':MIXED_SHA,
                              'final':str(FINAL),'final_sha256':FINAL_SHA,'controller_sha256':digest(Path(__file__))})
    rows=[]
    def run(name,script,options,timeout):
        capturing='--mode=capture' in options
        output=BASE/name/('requests.bin' if capturing else 'result.json')
        report=Path(str(output)+'.summary.json') if capturing else output
        command=[str(ENGINE),'--headless','--path',str(project),'--script','res://tools/performance/current/'+script,'--',*options,'--output='+str(output)]
        write(BASE/'status.json',{'state':'running','task':name,'completed':len(rows)})
        print(json.dumps({'start':name}),flush=True)
        process=guard.run_process(command,project,BASE/name,timeout)
        value=read(report)
        assert value.get('ok',value.get('complete',False)),f'Probe failure: {name}'
        assert not value.get('errors',[]),f'Probe errors: {name}'
        rows.append({'task':name,'process':process,'output':str(report),'sha256':digest(report)})
        write(BASE/'summary.json',{'complete':False,'tasks':rows})
        print(json.dumps({'finished':name,'wall_seconds':process['process_wall_seconds']}),flush=True)
        return value
    try:
        for task in tasks: run(*task)
        body=project/'game/building/body_index.gd';body_sha=digest(body)
        preparer=ROOT/'tools/performance/current/prepare_spatial_query_capture.py'
        record=BASE/'capture-overlay.json'
        installed=False
        try:
            command=[sys.executable,'-X','utf8','-B',str(preparer),'install','--project',str(project),'--record',str(record),'--expected-body-sha',body_sha]
            result=subprocess.run(command,cwd=ROOT,capture_output=True,text=True,encoding='utf-8',timeout=30)
            write(BASE/'capture-install.json',{'command':command,'returncode':result.returncode,'stdout':result.stdout,'stderr':result.stderr})
            assert result.returncode==0,'Capture installation failed'
            installed=True
            capture=run('spatial-capture','spatial_query_probe.gd',['--mode=capture','--input='+str(FINAL),'--expected-sha='+FINAL_SHA],180)
        finally:
            if installed:
                command=[sys.executable,'-X','utf8','-B',str(preparer),'restore','--project',str(project),'--record',str(record)]
                result=subprocess.run(command,cwd=ROOT,capture_output=True,text=True,encoding='utf-8',timeout=30)
                write(BASE/'capture-restore.json',{'command':command,'returncode':result.returncode,'stdout':result.stdout,'stderr':result.stderr})
                assert result.returncode==0 and digest(body)==body_sha,'Capture restoration failed'
        stream=Path(capture['stream']);stream_sha=digest(stream)
        assert stream_sha==capture['stream_sha256']
        run('spatial-replay','spatial_query_probe.gd',['--mode=replay','--input='+str(stream),'--expected-sha='+stream_sha,'--iterations=100'],180)
        for name,expected in source.items(): assert digest(project/name)==expected,f'Probe source changed: {name}'
        for name,expected in accepted['native'].items(): assert digest(project/'game/platform/windows/bin'/name)==expected
        assert digest(FINAL)==FINAL_SHA and digest(MIXED)==MIXED_SHA
        write(BASE/'summary.json',{'complete':True,'tasks':rows,'source_native_inputs_unchanged':True,
                                   'scope':'Local operation evidence and retained-world inspection; not full CPU qualification.'})
        write(BASE/'status.json',{'state':'complete','completed':len(rows)})
    except BaseException as error:
        write(BASE/'status.json',{'state':'stopped_on_error','completed':len(rows),'error_type':type(error).__name__,'error':str(error)})
        raise

if __name__=='__main__': main()
