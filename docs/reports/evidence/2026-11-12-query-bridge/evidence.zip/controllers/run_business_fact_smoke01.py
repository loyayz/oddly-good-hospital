"""Two real steps only; validate the history diagnostic without long sampling."""
import argparse, hashlib, importlib.util, json, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'.cache/business-fact-smoke01'
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--check-only',action='store_true');args=parser.parse_args()
    local=read(ROOT/'.cache/hotpath-local-batch01/summary.json');assert local['complete'] and local['source_native_inputs_unchanged']
    protocol=read(ROOT/'.cache/hotpath-local-batch01/protocol.json')
    accepted=read(ROOT/'.cache/query-rect-acceptance01/summary.json');project=Path(accepted['project'])
    for name,expected in protocol['source'].items(): assert sha(project/name)==expected,name
    for name,expected in protocol['native'].items(): assert sha(project/'game/platform/windows/bin'/name)==expected,name
    assert sha(Path(protocol['engine']))==protocol['engine_sha256']
    assert sha(Path(protocol['actual_engine']))==protocol['actual_engine_sha256']
    source=Path(protocol['input']);assert sha(source)==protocol['input_sha256']
    assert not BASE.exists(),'Preserve prior results'
    output=BASE/'result.json'
    command=[protocol['engine'],'--headless','--path',str(project),'--script','res://tools/performance/current/business_fact_probe.gd','--','--smoke','--input='+str(source),'--output='+str(output)]
    if args.check_only: print(json.dumps({'ok':True,'steps':2,'prefix':0,'command':command,'engine_started':False}));return
    sys.path.insert(0,str(ROOT/'tools/performance/current'))
    spec=importlib.util.spec_from_file_location('guard',ROOT/'tools/performance/current/prepare_builtin_script_profile.py')
    guard=importlib.util.module_from_spec(spec);spec.loader.exec_module(guard)
    process=guard.run_process(command,project,BASE,120)
    result=read(output)
    assert result['complete'] and result['all_completed_steps']==2 and result['requested_prefix_steps']==0 and result['requested_sample_steps']==2 and result['errors']==[]
    assert result['final_sha256']=='21aff2546935022312333b67605680c491292575aaa845b07733db993a415a51'
    contract=subprocess.run([sys.executable,'-X','utf8','-B',str(ROOT/'tools/performance/current/business_fact_contract.py'),'--result',str(output)],cwd=ROOT,capture_output=True,text=True,encoding='utf-8',timeout=30)
    (BASE/'offline-contract.json').write_text(json.dumps({'returncode':contract.returncode,'stdout':contract.stdout,'stderr':contract.stderr},ensure_ascii=False,indent=2),encoding='utf-8')
    assert contract.returncode==0,'Offline smoke contract failed'
    summary={'ok':True,'steps':2,'process':process,'result_sha256':sha(output),'final_sha256':result['final_sha256'],'coverage_pass':result['sample_business']['comprehensive']['coverage_pass'],'scope':'Two-step diagnostic correctness only; full history, performance and coverage qualification are unverified.'}
    (BASE/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(summary))
if __name__=='__main__':main()
