from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import shutil
import subprocess
import sys
import time

sys.dont_write_bytecode = True
REPO = Path(__file__).resolve().parent.parent
ROOT = REPO / '.cache/queue-signature-26bcc0f-20261023'
PRIOR = REPO / '.cache/waiting-phase-f4207fb-20261023'
BASE = ROOT / 'baseline-project'
read = lambda p: json.loads(Path(p).read_text(encoding='utf-8-sig'))
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()

def write(path, value):
    path = Path(path)
    assert not path.exists(), path
    path.write_bytes((json.dumps(value, ensure_ascii=False, indent=2)+'\n').encode('utf-8'))

def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result

def check_sources(project):
    return [dict(path=x['path'], sha256=sha(project/x['path'])) for x in read(ROOT/'baseline-identity.json')['sources']]

def prepare():
    started = time.perf_counter()
    ROOT.mkdir(exist_ok=True)
    assert not BASE.exists()
    previous = read(PRIOR/'reverse-identity.json')
    shutil.copytree(PRIOR/'reverse-project', BASE)
    sources = []
    for row in previous['sources']:
        relative = row['path']
        assert sha(BASE/relative) == row['sha256'], relative
        if relative not in ['project.godot','export_presets.cfg']:
            assert sha(BASE/relative) == sha(REPO/relative), relative
        sources.append(dict(path=relative, sha256=sha(BASE/relative)))
    tests = []
    for relative in subprocess.check_output(['git','ls-files','tests'],cwd=REPO,text=True).splitlines():
        source = REPO/relative
        if source.is_file():
            shutil.copy2(source, BASE/relative)
            tests.append(dict(path=relative, sha256=sha(BASE/relative)))
    identity = dict(source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip(),
        sources=sources, tests=tests, preparation_wall_ms=(time.perf_counter()-started)*1000,
        prior_identity_sha256=sha(PRIOR/'reverse-identity.json'),diagnostic_only=True,formal_pass=False,
        runtime_caches_restored=False,engine_started=False)
    write(ROOT/'baseline-identity.json', identity)
    probe = ROOT/'probe-project'
    shutil.copytree(BASE, probe)
    relative = 'game/life/public_areas.gd'
    original = (probe/relative).read_bytes().decode('utf-8')
    instrument = module(REPO/'.cache/waiting_probe_f4207fb.py', 'old_inline')
    # Keep the proven return instrumentation; add the missing route/queue split.
    generated, patch = instrument.instrument_method(original, '_decision_signature', 'public_areas.gd._decision_signature', [850,866,2759,2763,2878])
    anchor = '\tvar queue_key: String = JSON.stringify([intent.public_purpose,reference],"",true,true)'
    assert generated.count(anchor)==1
    mark = instrument.marks('signature.route_sources', '\t').replace('_waiting_probe_started','_waiting_probe_part')
    mark += '\tif _waiting_probe_part>0: _waiting_probe_part = Time.get_ticks_usec()\n'
    generated = generated.replace(anchor,mark+anchor)
    generated = generated.replace('"signature.route_queue"','"signature.queue"')
    (probe/relative).write_bytes(generated.encode('utf-8'))
    write(ROOT/'probe-identity.json',dict(sources=check_sources(probe),original_sha256=hashlib.sha256(original.encode()).hexdigest(),
        generated_sha256=sha(probe/relative),patch=patch,extra_mark=mark,diagnostic_only=True,formal_pass=False))
    print(json.dumps(dict(prepared=str(ROOT),sources=len(sources),tests=len(tests))),flush=True)

def after(label):
    target = ROOT/(label+'-project')
    assert not target.exists()
    shutil.copytree(BASE,target)
    changes=[]
    for row in read(ROOT/'baseline-identity.json')['sources']:
        relative=row['path']
        if relative in ['project.godot','export_presets.cfg']: continue
        if sha(REPO/relative)!=row['sha256']:
            shutil.copy2(REPO/relative,target/relative)
            changes.append(relative)
    tests=[]
    for relative in subprocess.check_output(['git','ls-files','tests'],cwd=REPO,text=True).splitlines():
        if (REPO/relative).is_file():
            shutil.copy2(REPO/relative,target/relative)
            tests.append(dict(path=relative,sha256=sha(target/relative)))
    write(ROOT/(label+'-identity.json'),dict(sources=check_sources(target),tests=tests,changes=changes,diagnostic_only=True,formal_pass=False))
    print(json.dumps(dict(prepared=str(target),changes=changes)),flush=True)

def finalprobe():
    project=ROOT/'finalprobe-project'
    assert not project.exists()
    shutil.copytree(ROOT/'final-project',project)
    relative='game/life/public_areas.gd'
    original=(project/relative).read_bytes().decode('utf-8')
    instrument=module(REPO/'.cache/waiting_probe_f4207fb.py','old_inline_final')
    generated,patch=instrument.instrument_method(original,'_decision_signature','public_areas.gd._decision_signature',[850,866,2759,2763,2878])
    anchor='\tvar queue_key: String = JSON.stringify([intent.public_purpose,reference],"",true,true)'
    assert generated.count(anchor)==1
    mark=instrument.marks('signature.route_sources','\t').replace('_waiting_probe_started','_waiting_probe_part')
    mark+='\tif _waiting_probe_part>0: _waiting_probe_part = Time.get_ticks_usec()\n'
    generated=generated.replace(anchor,mark+anchor).replace('"signature.route_queue"','"signature.queue"')
    (project/relative).write_bytes(generated.encode('utf-8'))
    write(ROOT/'finalprobe-identity.json',dict(sources=check_sources(project),patch=patch,extra_mark=mark,diagnostic_only=True,formal_pass=False))
    print(json.dumps(dict(prepared=str(project))),flush=True)

def clinicprobe():
    project=ROOT/'clinicprobe-project'
    assert not project.exists()
    shutil.copytree(BASE,project)
    relative='game/clinic/clinical_runtime.gd'
    original=(project/relative).read_bytes().decode('utf-8')
    source=original
    instrument=module(REPO/'.cache/waiting_probe_f4207fb.py','clinic_inline')
    patches=[]
    for name in ['_build_availability','_facility_busy','_staff_busy','_service_qualified','_can_start','_schedule_allows']:
        source,patch=instrument.instrument_method(source,name,'clinical_runtime.gd.'+name,[850,866,2759,2763,2878])
        patches.append(patch)
    (project/relative).write_bytes(source.encode('utf-8'))
    restored=source
    for patch in reversed(patches):restored=restored.replace(patch['generated'],patch['original'],1)
    assert restored==original
    write(ROOT/'clinicprobe-identity.json',dict(sources=check_sources(project),patches=patches,inverse_equal=True,diagnostic_only=True,formal_pass=False))
    print(json.dumps(dict(prepared=str(project))),flush=True)

def clinicparentprobe():
    project=ROOT/'clinicparentprobe-project'
    assert not project.exists()
    shutil.copytree(BASE,project)
    instrument=module(REPO/'.cache/waiting_probe_f4207fb.py','clinic_parent_inline')
    patches=[]
    for relative,names in {
        'game/clinic/clinical_runtime.gd':['_dispatch_service','service_candidates','_gather_assigned','_dispatch_clinical_releases'],
        'game/operations/department_service.gd':['route_patient','readiness'],
        'game/clinic/hospital_visitors.gd':['dispatch'],
    }.items():
        original=(project/relative).read_bytes().decode('utf-8')
        source=original.replace('func()->Dictionary: return','func()->Dictionary:return')
        changes=[]
        for name in names:
            source,patch=instrument.instrument_method(source,name,relative.rsplit('/',1)[-1]+'.'+name,[850,866,2759,2763,2878])
            changes.append(patch)
        (project/relative).write_bytes(source.encode('utf-8'))
        restored=source
        for patch in reversed(changes):restored=restored.replace(patch['generated'],patch['original'],1)
        assert restored==original.replace('func()->Dictionary: return','func()->Dictionary:return')
        patches.append(dict(path=relative,changes=changes,lambda_spacing_only=True,inverse_equal=True))
    write(ROOT/'clinicparentprobe-identity.json',dict(sources=check_sources(project),patches=patches,diagnostic_only=True,formal_pass=False))
    print(json.dumps(dict(prepared=str(project))),flush=True)

def measure(args):
    project=ROOT/(args.variant+'-project')
    identity=read(ROOT/(args.variant+'-identity.json'))
    for row in identity['sources']:
        assert sha(project/row['path'])==row['sha256'],row['path']
    launch=module(REPO/'.cache/wait-signature-031e1f7-20261022/run.py','launcher')
    launch.ROOT=ROOT
    if args.window=='functional':
        prefix=ROOT/args.label
        launch.launch(['--headless','--path',project,'--script','res://tests/acceptance/runner.gd','--','staff',
            '--case=STAFF-48','--case=STAFF-57','--case=STAFF-69','--case=STAFF-71'],prefix)
        actual=read(project/'acceptance-results.json')
        write(ROOT/(args.label+'.acceptance-results.json'),actual)
        print(json.dumps(dict(checks=actual['checks'],failed=actual['failed'],results={k:dict(passed=v['passed'],elapsed_ms=v['elapsed_ms'],setup_ms=v['setup_ms']) for k,v in actual['results'].items()})),flush=True)
        assert actual['completed'] and actual['checks']==4 and actual['failed']==0
        return
    filename,steps=launch.WINDOWS[args.window]
    source_input=REPO/'.cache/task-navigation-20261019'/filename
    output=ROOT/(args.label+'-'+args.window+'.json')
    assert not output.exists()
    is_probe=args.variant.endswith('probe')
    write(output.with_suffix('.source-check.json'),dict(actual_sources=identity['sources'],input_sha256=sha(source_input),
        runner_sha256=sha(project/'tools/performance/representative_worker.gd'),diagnostic_only=True,formal_pass=False,
        runtime_caches_restored=False,steps=steps,profile='root' if is_probe else 'plain'))
    launch.launch(['--headless','--path',project,'--script','res://tools/performance/representative_worker.gd','--',
        '--input='+str(source_input),'--output='+str(output),'--steps='+str(steps),'--profile='+('root' if is_probe else 'plain')],output)
    actual=read(output)
    expected=read(PRIOR/('r2-'+args.window+'.json'))
    checks=dict(complete=actual['complete'],qualified=actual['qualified'],errors_empty=not actual['errors'])
    for key in ['source_input_sha256','initial','final','qualification','operations','event_records','final_binary_sha256']:
        checks[key]=actual.get(key)==expected.get(key)
    ap,bp=actual['public'].copy(),expected['public'].copy()
    ac,bc=ap.pop('query_counts'),bp.pop('query_counts')
    checks['public_business']=ap==bp
    differences={k:dict(actual=ac.get(k),expected=bc.get(k)) for k in ac.keys()|bc.keys() if ac.get(k)!=bc.get(k)}
    queue_work={'public_queue_fit_hits','public_queue_fit_builds','public_wait_dependency_rectangles','facility_environment_hits',
        'reservation_candidate_queries','public_wait_dependency_batches','public_wait_rechecks',
        'public_wait_environment_match_hits','public_facility_candidates','public_wait_hits'} if args.variant in ['priorwaiters','final','finalprobe','final2','occupied','occupiedfinal','occupiedprobe','occupiedcountprobe'] else set()
    checks['all_original_counts_equal_except_declared_queue_work']=all(k.startswith(('diag_wait/','public_wait_queue_')) or k in queue_work for k in differences)
    checks['all_non_timing_samples']=[{k:v for k,v in x.items() if k!='elapsed_us'} for x in actual['samples']]==[{k:v for k,v in x.items() if k!='elapsed_us'} for x in expected['samples']]
    worker=actual['worker_sample']
    checks['default_workers_complete']=worker['batches']==steps and worker['processed']==worker['consumed'] and worker['failed_batches']==0
    probes={k:v for k,v in ac.items() if k.startswith('diag_wait/')}
    selected=[]
    if is_probe:
        checks['all_stage_records']=actual['profile']['steps']==steps and actual['profile']['step_records_complete'] and not actual['profile']['errors']
        selected=[x for x in actual['profile']['step_records'] if x['tick'] in [851,867,2760,2764,2879]]
    write(output.with_suffix('.semantic-check.json'),dict(passed=all(checks.values()),checks=checks,metrics=actual['metrics'],probes=probes,
        selected_stages=selected,all_query_count_differences=differences,reference_sha256=sha(PRIOR/('r2-'+args.window+'.json'))))
    print(json.dumps(dict(output=str(output),metrics=actual['metrics'],checks=checks,probes=probes,
        new_counts={k:v for k,v in ac.items() if k.startswith('public_wait_queue_')})),flush=True)
    assert all(checks.values())

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('action',choices=['prepare','after','finalprobe','clinicprobe','clinicparentprobe','measure'])
    parser.add_argument('--variant',default='baseline')
    parser.add_argument('--label',default='a1')
    parser.add_argument('--window',default='gp80')
    args=parser.parse_args()
    if args.action=='prepare':prepare()
    elif args.action=='after':after(args.variant)
    elif args.action=='finalprobe':finalprobe()
    elif args.action=='clinicprobe':clinicprobe()
    elif args.action=='clinicparentprobe':clinicparentprobe()
    else:measure(args)
