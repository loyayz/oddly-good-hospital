from __future__ import annotations
import argparse, datetime, hashlib, importlib.util, json, os, pathlib, shutil, subprocess, time

ROOT = pathlib.Path(__file__).resolve().parent
REPO = ROOT.parents[1]
ENGINE = REPO / '.cache/ordinary-tail-2d65f93-20261022/engine/Godot_v4.7.2-stable_win64.exe'
WINDOWS = {'public360': ('public-v6.input.bin', 360), 'gp80': ('gp.input.bin', 80), 'operations40': ('op.input.bin', 40)}

def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def read(p): return json.loads(pathlib.Path(p).read_text(encoding='utf-8-sig'))
def dump(p, x): pathlib.Path(p).write_bytes((json.dumps(x, indent=2, ensure_ascii=False)+'\n').encode('utf-8'))

def launch(arguments, prefix, timeout=120):
    prefix = pathlib.Path(prefix)
    receipt = prefix.with_suffix('.launch.json')
    assert not receipt.exists(), receipt
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    before = time.perf_counter()
    with prefix.with_suffix('.stdout.log').open('wb') as out, prefix.with_suffix('.stderr.log').open('wb') as err:
        environment = os.environ.copy()
        for key in ('APPDATA','LOCALAPPDATA'):
            path=ROOT/'isolated-user'/key; path.mkdir(parents=True,exist_ok=True); environment[key]=str(path)
        child = subprocess.Popen([str(ENGINE), *map(str,arguments)], cwd=REPO, stdout=out, stderr=err, env=environment, creationflags=subprocess.CREATE_NO_WINDOW)
        timed_out = False
        try: code = child.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
            subprocess.run(['taskkill','/PID',str(child.pid),'/T','/F'], capture_output=True)
            code = child.wait()
        # Keep actual Windows process CPU separately from launcher wall time.
        import ctypes
        values = [ctypes.c_ulonglong() for _ in range(4)]
        ok = ctypes.windll.kernel32.GetProcessTimes(ctypes.c_void_p(int(child._handle)), *(ctypes.byref(v) for v in values))
        cpu_ms = (values[2].value + values[3].value) / 10000 if ok else None
    log_errors = []
    for suffix in ('.stdout.log','.stderr.log'):
        log_errors.extend(line for line in prefix.with_suffix(suffix).read_text(encoding='utf-8',errors='replace').splitlines() if 'SCRIPT ERROR:' in line or 'ERROR:' in line)
    record = dict(engine=str(ENGINE), engine_sha256=sha(ENGINE), self_contained=True, isolated_appdata=environment['APPDATA'], isolated_localappdata=environment['LOCALAPPDATA'], pid=child.pid, arguments=list(map(str,arguments)), started_at_utc=started, ended_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), wall_ms=(time.perf_counter()-before)*1000, child_cpu_ms=cpu_ms, exit_code=code, timed_out=timed_out, errors=log_errors, affinity_changed=False, priority_changed=False, diagnostic_only=True, formal_pass=False)
    dump(receipt, record)
    if code or timed_out or log_errors: raise RuntimeError(str(receipt)+': '+str(log_errors[:4]))
    return record

def instrument(source, target):
    assert not target.exists()
    shutil.copytree(source,target)
    path = source/'tools/performance/instrument_all_instances.py'
    spec = importlib.util.spec_from_file_location('instrument',path)
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    extra = {
        'public_areas': ['_facility_members','_fit_key','_body_key','_candidate_regions','_derive_floor','_decision_view','_region_basis','_wait_door_view','_facility_environment','_environment_sample_indices','_environment_matches','_queue_fit_current','_queue_fit_basis','_queue_fit_clear','_actor_index_scope'],
        'point_navigation': ['_source_quote','_prepare_route_subject','_connector_preparation','_connector_edges','ready_waiting_cost_field'],
        'navigation': ['_envelope','_traversal_shape','_graph_key','_distance_destination','ready_structural_field'],
        'environment': ['_prepare_facility_sources','_build_facility_sources','_prepare_actor_sources','_prepare_sample_sources','_sample_records','_has_sample','_wall_edge','_wall_between'],
        'clinic': ['_facility_busy','_staff_busy','_gathering_visit'],
        'movement': ['_courtesy_clearance'],
        'departments': ['ensure','_track_phase','_update_cause_clocks'],
    }
    for group, methods in extra.items(): module.EXTRA.setdefault(group,[]).extend(methods)
    result=module.instrument(target); result['extra_methods']=extra
    dump(target/'all-instance-profile-identity.json', result)
    print(json.dumps(dict(project=str(target), files=len(result['files']), methods=result['actual_method_count'])),flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser(); parser.add_argument('action'); parser.add_argument('--project',default='before-project'); parser.add_argument('--label',default='a'); parser.add_argument('--mode',default='plain'); parser.add_argument('--windows',default=','.join(WINDOWS)); parser.add_argument('--selected',default='0,1,27,67,69,140,194,219,279'); args=parser.parse_args()
    project=ROOT/args.project
    if args.action=='portable':
        ENGINE.parent.mkdir(exist_ok=True)
        for name in ('Godot_v4.7.2-stable_win64.exe','Godot_v4.7.2-stable_win64_console.exe'):
            source=pathlib.Path('C:/programs/godot')/name; target=ENGINE.parent/name
            assert not target.exists(); shutil.copy2(source,target); assert sha(source)==sha(target)
        (ENGINE.parent/'_sc_').touch()
        print(sha(ENGINE))
    elif args.action=='import':
        print(json.dumps(launch(['--headless','--editor','--path',project,'--import','--quit'],ROOT/args.label),ensure_ascii=False))
    elif args.action=='instrument': instrument(project,ROOT/args.label)
    elif args.action=='window':
        for window in args.windows.split(','):
            filename,steps=WINDOWS[window]; output=ROOT/f'{args.label}-{window}.json'; assert not output.exists()
            script='representative.gd' if args.mode in ('plain','root') else 'representative_selected.gd'
            launch(['--headless','--path',project,'--script','res://tools/performance/'+script,'--','--input='+str(REPO/'.cache/task-navigation-20261019'/filename),'--output='+str(output),'--steps='+str(steps),'--profile='+args.mode,'--selected='+args.selected],output)
            result=read(output); assert result['complete'] and result['qualified'] and not result['errors'],output
            print(json.dumps(dict(run=args.label+'-'+window,metrics=result['metrics'],hash=result['final_binary_sha256'])),flush=True)
