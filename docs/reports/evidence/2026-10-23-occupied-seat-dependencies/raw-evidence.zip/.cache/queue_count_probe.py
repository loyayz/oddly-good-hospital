from pathlib import Path
import importlib.util
import json
import shutil
from types import SimpleNamespace

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('queue_count_round',HERE/'queue_signature_round.py')
round=importlib.util.module_from_spec(spec)
spec.loader.exec_module(round)
ROOT=round.ROOT
for variant,parent in [('baselinecountprobe','baselineprobe'),('occupiedcountprobe','occupiedprobe')]:
    project=ROOT/(variant+'-project')
    assert not project.exists()
    shutil.copytree(ROOT/(parent+'-project'),project)
    relative='game/life/public_areas.gd'
    original=(project/relative).read_bytes().decode('utf-8')
    source=original.replace('if _waiting_probe_started>0: _waiting_probe_queue_rows += 1','_waiting_probe_queue_rows += 1')
    anchor='\tvar _waiting_probe_return_1: Variant = records'
    extra=('\tspace.query_counts["diag_wait/all/signature.queue_rows"] = int(space.query_counts.get("diag_wait/all/signature.queue_rows",0))+_waiting_probe_queue_rows\n'
        '\tspace.query_counts["diag_wait/all/signature.calls"] = int(space.query_counts.get("diag_wait/all/signature.calls",0))+1\n')
    assert source.count(anchor)==1
    source=source.replace(anchor,extra+anchor)
    (project/relative).write_bytes(source.encode('utf-8'))
    round.write(ROOT/(variant+'-identity.json'),dict(sources=round.check_sources(project),parent_identity_sha256=round.sha(ROOT/(parent+'-identity.json')),
        changed_source=dict(path=relative,original=original,generated=source),diagnostic_only=True,formal_pass=False))
    print(json.dumps(dict(prepared=variant)),flush=True)
    round.measure(SimpleNamespace(variant=variant,label='total-'+variant,window='gp80'))
