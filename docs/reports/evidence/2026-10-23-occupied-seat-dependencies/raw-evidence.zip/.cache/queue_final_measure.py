from pathlib import Path
import importlib.util
from types import SimpleNamespace

path=Path(__file__).with_name('queue_signature_round.py')
spec=importlib.util.spec_from_file_location('queue_round_final',path)
round=importlib.util.module_from_spec(spec)
spec.loader.exec_module(round)
for variant,label,window in [
    ('baseline','a5','gp80'),
    ('occupiedfinal','e3','gp80'),
    ('baseline','a6','gp80'),
    ('baseline','a3','public360'),
    ('occupiedfinal','e1','public360'),
    ('baseline','a4','public360'),
    ('baseline','a1','operations40'),
    ('occupiedfinal','e1','operations40'),
]:
    round.measure(SimpleNamespace(variant=variant,label=label,window=window))
