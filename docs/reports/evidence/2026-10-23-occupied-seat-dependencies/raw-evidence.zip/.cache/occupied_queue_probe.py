from pathlib import Path
import importlib.util
import json
import re
import shutil
from types import SimpleNamespace

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('queue_probe_round',HERE/'queue_signature_round.py')
round=importlib.util.module_from_spec(spec)
spec.loader.exec_module(round)
ROOT=round.ROOT
TICKS=[850,866,2759,2763,2878]

def mark(label,indent='\t'):
    return (indent+'if _waiting_probe_started>0:\n'
        +indent+'\tvar _waiting_probe_finished: int = Time.get_ticks_usec()\n'
        +indent+'\tvar _waiting_probe_key: String = "diag_wait/"+str(world.sim_tick+1)+"/"+'+json.dumps(label)+'\n'
        +indent+'\tspace.query_counts[_waiting_probe_key+"/us"] = int(space.query_counts.get(_waiting_probe_key+"/us",0))+_waiting_probe_finished-_waiting_probe_started\n'
        +indent+'\tspace.query_counts[_waiting_probe_key+"/calls"] = int(space.query_counts.get(_waiting_probe_key+"/calls",0))+1\n')

def instrument(source,name,label):
    start=source.index('func '+name+'(')
    end_match=re.search(r'\n(?:static )?func ',source[start+6:])
    end=start+6+end_match.start()+1 if end_match else len(source)
    original=source[start:end]
    lines=original.splitlines(keepends=True)
    generated=[lines[0],'\tvar _waiting_probe_started: int = Time.get_ticks_usec() if world.sim_tick in '+str(TICKS)+' else 0\n']
    ordinal=0
    for raw in lines[1:]:
        stripped=raw.lstrip('\t').rstrip('\r\n')
        indent=raw[:len(raw)-len(raw.lstrip('\t'))]
        expression=None
        if stripped.startswith(('if ','elif ')) and ': return' in stripped:
            condition,expression=stripped.split(': return',1)
            generated.append(indent+condition+':\n')
            indent+='\t'
        elif stripped=='return':expression=''
        elif stripped.startswith('return '):expression=stripped[len('return '):]
        else:
            generated.append(raw)
            continue
        expression=expression.strip()
        if expression:
            ordinal+=1
            variable='_waiting_probe_return_'+str(ordinal)
            # Evaluate the original return expression before stopping the clock.
            generated.append(indent+'var '+variable+': Variant = '+expression+'\n')
            generated.append(mark(label,indent))
            generated.append(indent+'return '+variable+'\n')
        else:
            generated.append(mark(label,indent))
            generated.append(indent+'return\n')
    generated.append(mark(label))
    changed=''.join(generated)
    if name=='_decision_signature':
        changed=changed.replace('\tvar view: Dictionary = _decision_view(world)','\tvar _waiting_probe_part: int = _waiting_probe_started\n\tvar _waiting_probe_queue_rows: int = 0\n\tvar view: Dictionary = _decision_view(world)',1)
        queue_anchor='\tvar queue_key:' if '\tvar queue_key:' in changed else '\tvar queue: Array'
        for anchor,part in [
            ('\tvar route_dependent: bool =','setup'),('\tvar reach: float =','facilities'),
            ('\tif route_dependent:\n','dynamic'),(queue_anchor,'route_sources'),
            ('\tvar sorted_ids: Array = other_ids.keys()','queue'),
            ('\trecords.append_array(_environment_samples','other_bodies'),
            ('\tvar _waiting_probe_return_','environment')]:
            offset=changed.index(anchor)
            boundary=mark('signature.'+part).replace('_waiting_probe_started','_waiting_probe_part')
            boundary+='\tif _waiting_probe_part>0: _waiting_probe_part = Time.get_ticks_usec()\n'
            changed=changed[:offset]+boundary+changed[offset:]
        changed=changed.replace('\t\tvar queue_bodies: Array = []','\t\tif _waiting_probe_started>0: _waiting_probe_queue_rows += 1\n\t\tvar queue_bodies: Array = []',1)
        anchor='\tvar _waiting_probe_return_1: Variant = records'
        count=('\tif _waiting_probe_started>0:\n'
            '\t\tvar _waiting_probe_row_key: String = "diag_wait/"+str(world.sim_tick+1)+"/signature.queue_rows"\n'
            '\t\tspace.query_counts[_waiting_probe_row_key] = int(space.query_counts.get(_waiting_probe_row_key,0))+_waiting_probe_queue_rows\n')
        assert changed.count(anchor)==1
        changed=changed.replace(anchor,count+anchor,1)
    return source[:start]+changed+source[end:],dict(method=name,label=label,original=original,generated=changed)

for variant,parent in [('baselineprobe','baseline'),('occupiedprobe','occupiedfinal')]:
    project=ROOT/(variant+'-project')
    assert not project.exists()
    shutil.copytree(ROOT/(parent+'-project'),project)
    patches=[]
    for relative,names in {
        'game/life/public_areas.gd':['_decision_signature'],
        'game/clinic/clinical_runtime.gd':['_dispatch_service','service_candidates','_gather_assigned','_build_availability','_can_start'],
        'game/clinic/hospital_visitors.gd':['dispatch'],
    }.items():
        original=(project/relative).read_bytes().decode('utf-8')
        source=original
        changes=[]
        for name in names:
            source,patch=instrument(source,name,relative.rsplit('/',1)[-1]+'.'+name)
            changes.append(patch)
        (project/relative).write_bytes(source.encode('utf-8'))
        restored=source
        for patch in reversed(changes):restored=restored.replace(patch['generated'],patch['original'],1)
        assert restored==original
        patches.append(dict(path=relative,replacements=changes,inverse_equal=True))
    round.write(ROOT/(variant+'-identity.json'),dict(sources=round.check_sources(project),patches=patches,
        return_expressions_evaluated_before_clock_stop=True,diagnostic_only=True,formal_pass=False))
    print(json.dumps(dict(prepared=variant)),flush=True)

for variant,label,window in [('baselineprobe','beforeprobe02','gp80'),('occupiedprobe','afterprobe02','gp80'),('occupiedprobe','afterprobe02','public360')]:
    round.measure(SimpleNamespace(variant=variant,label=label,window=window))
