from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import re
import shutil
import subprocess
import time

REPO = Path(__file__).resolve().parent.parent
ROOT = REPO / '.cache/waiting-phase-f4207fb-20261023'
BASE = REPO / '.cache/worker-production-20261023/production-project'
PROBE = ROOT / 'probe-project-03'
PREPARATION = ROOT / 'preparation-03.json'
AFTER = ROOT / 'after-project'
REVERSE = ROOT / 'reverse-project'
IDENTITY = REPO / '.cache/worker-production-20261023/production-source-identity.json'
read = lambda p: json.loads(Path(p).read_text(encoding='utf-8-sig'))
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()

def write(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')

def module(path):
    spec = importlib.util.spec_from_file_location('waiting_launcher', path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result

def marks(label, indent):
    key = json.dumps(label)
    return (indent+'if _waiting_probe_started>0:\n'+indent+'\tvar _waiting_probe_finished: int = Time.get_ticks_usec()\n'
        +indent+'\tvar _waiting_probe_key: String = "diag_wait/"+str(world.sim_tick+1)+"/"+'+key+'\n'
        +indent+'\tspace.query_counts[_waiting_probe_key+"/us"] = int(space.query_counts.get(_waiting_probe_key+"/us",0))+_waiting_probe_finished-_waiting_probe_started\n'
        +indent+'\tspace.query_counts[_waiting_probe_key+"/calls"] = int(space.query_counts.get(_waiting_probe_key+"/calls",0))+1\n')

def instrument_method(source, name, label, ticks):
    needle = 'func '+name+'('
    start = source.index(needle)
    assert start==0 or source[start-1]=='\n'
    next_method = re.search(r'\n(?:static )?func ', source[start+len(needle):])
    end = start+len(needle)+next_method.start()+1 if next_method else len(source)
    original = source[start:end]
    lines = original.splitlines(keepends=True)
    assert lines[0].rstrip().endswith(':')
    generated = [lines[0], '\tvar _waiting_probe_started: int = Time.get_ticks_usec() if world.sim_tick in '+str(ticks)+' else 0\n']
    for raw in lines[1:]:
        line = raw.rstrip('\r\n')
        stripped = line.lstrip('\t')
        indent = line[:len(line)-len(stripped)]
        if name=='select' and len(indent)>1:
            # The filter lambda owns its own return statements.
            generated.append(raw)
            continue
        if ': return' in stripped and not stripped.startswith('#'):
            condition, expression = stripped.split(': return', 1)
            generated += [indent+condition+':\n', marks(label, indent+'\t'), indent+'\treturn'+expression+'\n']
        elif stripped=='return' or stripped.startswith('return '):
            generated += [marks(label, indent), raw]
        else:
            generated.append(raw)
    # Methods without an explicit final return still record their fall-through.
    last = next(x.strip() for x in reversed(lines) if x.strip() and not x.lstrip().startswith('#'))
    if not last.startswith('return'):
        generated.append(marks(label, '\t'))
    changed = ''.join(generated)
    if name=='_decision_signature':
        changed = changed.replace('\tvar view: Dictionary = _decision_view(world)', '\tvar _waiting_probe_part: int = _waiting_probe_started\n\tvar view: Dictionary = _decision_view(world)',1)
        boundaries = [
            ('\tvar route_dependent: bool =', 'setup'),
            ('\tvar reach: float =', 'facilities'),
            ('\tif route_dependent:\n', 'dynamic'),
            ('\tvar sorted_ids: Array = other_ids.keys()', 'route_queue'),
            ('\trecords.append_array(_environment_samples', 'other_bodies'),
            ('\tif _waiting_probe_started>0:', 'environment'),
        ]
        # The last boundary is the original final-return bookend.
        for anchor,part in boundaries:
            offset = changed.index(anchor)
            mark = marks('signature.'+part,'\t').replace('_waiting_probe_started','_waiting_probe_part')
            mark += '\tif _waiting_probe_part>0: _waiting_probe_part = Time.get_ticks_usec()\n'
            changed = changed[:offset]+mark+changed[offset:]
    assert changed!=original
    return source[:start]+changed+source[end:], dict(method=name,label=label,original=original,generated=changed)

def verify(project, changes):
    checked = []
    for row in read(IDENTITY)['production_sources']:
        relative = row['path']
        assert sha(BASE/relative)==row['sha256'], relative
        if relative not in ['project.godot','export_presets.cfg','game/life/public_areas.gd','game/building/hospital_navigation.gd','game/building/navigation_cache.gd']:
            assert sha(REPO/relative)==row['sha256'], relative
        if relative not in changes:
            assert sha(project/relative)==row['sha256'], relative
        checked.append(dict(path=relative,sha256=sha(project/relative)))
    native = 'game/platform/windows/bin/oddly_good_platform.windows.x86_64.dll'
    assert sha(project/native)==sha(BASE/native)==sha(REPO/native)
    return checked

def prepare_after():
    started = time.perf_counter()
    assert not AFTER.exists()
    shutil.copytree(BASE,AFTER)
    relative = 'game/life/public_areas.gd'
    shutil.copy2(REPO/relative,AFTER/relative)
    checked = verify(AFTER,{relative})
    assert sha(AFTER/relative)!=sha(BASE/relative)
    write(ROOT/'after-identity.json',dict(source_commit='f4207fb8d829ad833a744dbd08629563f9f8c8fa',sources=checked,
        changed_production_sources=[dict(path=relative,before_sha256=sha(BASE/relative),after_sha256=sha(AFTER/relative))],
        preparation_wall_ms=(time.perf_counter()-started)*1000,diagnostic_only=True,formal_pass=False))
    print(json.dumps(dict(prepared=str(AFTER),sources=len(checked),changed_sources=[relative])),flush=True)

def prepare_reverse():
    started = time.perf_counter()
    assert not REVERSE.exists()
    shutil.copytree(BASE,REVERSE)
    relatives = ['game/building/navigation_cache.gd','game/building/hospital_navigation.gd']
    for relative in relatives: shutil.copy2(REPO/relative,REVERSE/relative)
    checked = verify(REVERSE,set(relatives))
    tests = []
    for relative in subprocess.check_output(['git','ls-files','tests'],cwd=REPO,text=True).splitlines():
        source = REPO/relative
        if not source.is_file(): continue
        target = REVERSE/relative
        target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(source,target)
        tests.append(dict(path=relative,sha256=sha(target)))
    write(ROOT/'reverse-identity.json',dict(source_commit='f4207fb8d829ad833a744dbd08629563f9f8c8fa',sources=checked,actual_tests=tests,
        changed_production_sources=[dict(path=x,before_sha256=sha(BASE/x),after_sha256=sha(REVERSE/x)) for x in relatives],
        preparation_wall_ms=(time.perf_counter()-started)*1000,diagnostic_only=True,formal_pass=False))
    print(json.dumps(dict(prepared=str(REVERSE),sources=len(checked),tests=len(tests),changed_sources=relatives)),flush=True)

def functional():
    identity = read(ROOT/'reverse-identity.json')
    for row in identity['sources']+identity['actual_tests']:
        assert sha(REVERSE/row['path'])==row['sha256'],row['path']
        if row['path'] not in ['project.godot','export_presets.cfg']: assert sha(REPO/row['path'])==row['sha256'],row['path']
    launch = module(REPO/'.cache/wait-signature-031e1f7-20261022/run.py')
    launch.ROOT = ROOT
    prefix = ROOT/'reverse-functional-04'
    launch.launch(['--headless','--path',REVERSE,'--script','res://tests/acceptance/runner.gd','--','space','staff','--case=SPACE-51','--case=STAFF-57','--case=STAFF-61'],prefix)
    actual = read(REVERSE/'acceptance-results.json')
    write(ROOT/'reverse-functional-04.acceptance-results.json',actual)
    assert actual['completed'] and actual['checks']==3 and actual['failed']==0
    assert sorted(actual['results'])==['SPACE-51','STAFF-57','STAFF-61']
    print(json.dumps(dict(checks=actual['checks'],failed=actual['failed'],cases={k:dict(passed=v['passed'],elapsed_ms=v['elapsed_ms'],setup_ms=v['setup_ms']) for k,v in actual['results'].items()})),flush=True)

def prepare():
    started = time.perf_counter()
    assert not PROBE.exists()
    ROOT.mkdir(exist_ok=True)
    shutil.copytree(BASE, PROBE)
    public = read(REPO/'.cache/worker-production-20261023/b3-public360.json')
    ordered = sorted(public['samples'],key=lambda x:x['elapsed_us'])
    selected = [851,867,ordered[(len(ordered)-1)//2]['tick'],ordered[356]['tick']]
    ticks = sorted({x-1 for x in selected})
    methods = {
      'game/life/waiting_life.gd': ['_dispatch_public_seat','_dispatch_public_need','seat_candidates','_manual_seat_quote'],
      'game/life/public_areas.gd': ['select','_waiting_point','_entry_landings','_entry_geometry_view','_decision_signature','_queue_fit_current'],
    }
    patches = []
    for relative,names in methods.items():
        original = (PROBE/relative).read_bytes().decode('utf-8')
        source = original
        replacements = []
        for name in names:
            source, patch = instrument_method(source,name,relative.rsplit('/',1)[-1]+'.'+name,ticks)
            replacements.append(patch)
        restored = source
        for patch in reversed(replacements):
            assert restored.count(patch['generated'])==1
            restored = restored.replace(patch['generated'],patch['original'],1)
        assert restored==original
        (PROBE/relative).write_bytes(source.encode('utf-8'))
        patches.append(dict(path=relative,before_sha256=hashlib.sha256(original.encode()).hexdigest(),after_sha256=sha(PROBE/relative),inverse_equal=True,replacements=replacements))
    checked = verify(PROBE,set(methods))
    write(PREPARATION,dict(diagnostic_only=True,formal_pass=False,selected_result_ticks=selected,condition_world_ticks=ticks,
        source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip(),sources=checked,patches=patches,
        preparation_wall_ms=(time.perf_counter()-started)*1000,workload_changed=False,runtime_caches_restored=False))
    print(json.dumps(dict(prepared=str(PROBE),selected_result_ticks=selected,methods=sum(map(len,methods.values())))),flush=True)

def measure(args):
    prepared = read(PREPARATION)
    project = REVERSE if args.mode=='reverse' else AFTER if args.mode=='after' else BASE if args.mode=='plain' else PROBE
    changes = {'game/building/navigation_cache.gd','game/building/hospital_navigation.gd'} if args.mode=='reverse' else {'game/life/public_areas.gd'} if args.mode=='after' else set() if args.mode=='plain' else {x['path'] for x in prepared['patches']}
    checked = verify(project,changes)
    if args.mode=='after':
        for row in read(ROOT/'after-identity.json')['sources']:
            assert sha(AFTER/row['path'])==row['sha256'],row['path']
            if row['path'] not in ['project.godot','export_presets.cfg']:
                assert sha(REPO/row['path'])==row['sha256'],row['path']
    if args.mode=='reverse':
        for row in read(ROOT/'reverse-identity.json')['sources']:
            assert sha(REVERSE/row['path'])==row['sha256'],row['path']
            if row['path'] not in ['project.godot','export_presets.cfg']: assert sha(REPO/row['path'])==row['sha256'],row['path']
    for patch in prepared['patches']:
        if args.mode=='probe': assert sha(project/patch['path'])==patch['after_sha256']
    launch = module(REPO/'.cache/wait-signature-031e1f7-20261022/run.py')
    launch.ROOT = ROOT
    filename,steps = launch.WINDOWS[args.window]
    source_input = REPO/'.cache/task-navigation-20261019'/filename
    output = ROOT/(args.label+'-'+args.window+'.json')
    if args.action=='measure':
        assert not output.exists()
        write(output.with_suffix('.source-check.json'),dict(actual_sources_checked=checked,input_sha256=sha(source_input),diagnostic_only=True,
            formal_pass=False,mode=args.mode,source_commit=prepared['source_commit'],inline_proof_sha256=sha(PREPARATION)))
        launch.launch(['--headless','--path',project,'--script','res://tools/performance/representative_worker.gd','--',
            '--input='+str(source_input),'--output='+str(output),'--steps='+str(steps),'--profile='+('root' if args.mode=='probe' else 'plain')],output)
    else:
        receipt = read(output.with_suffix('.launch.json'))
        assert output.exists() and receipt['exit_code']==0 and not receipt['errors'] and not receipt['timed_out']
    actual = read(output)
    expected = read(REPO/'.cache/worker-production-20261023'/('b3-'+args.window+'.json'))
    checks = dict(complete=actual['complete'],qualified=actual['qualified'],errors_empty=not actual['errors'])
    for key in ['source_input_sha256','initial','final','qualification','operations','event_records','final_binary_sha256']:
        checks[key] = actual.get(key)==expected.get(key)
    a,b = actual['public'].copy(),expected['public'].copy()
    ac,bc = a.pop('query_counts'),b.pop('query_counts')
    checks['public_business'] = a==b
    differences = {k:dict(actual=ac.get(k),expected=bc.get(k)) for k in ac.keys()|bc.keys() if ac.get(k)!=bc.get(k)}
    allowed = {'distance_field_builds','distance_field_hits','static_path_builds','static_path_hits','structural_reverse_field_lookups','structural_reverse_field_hits'} if args.mode=='reverse' else set()
    checks['all_original_counts_equal_except_declared_field_work'] = all(k.startswith('diag_wait/') or k in allowed for k in differences)
    checks['all_non_timing_samples'] = [{k:v for k,v in x.items() if k!='elapsed_us'} for x in actual['samples']]==[{k:v for k,v in x.items() if k!='elapsed_us'} for x in expected['samples']]
    worker = actual['worker_sample']
    checks['default_workers_complete'] = worker['batches']==steps and worker['processed']==worker['consumed'] and worker['failed_batches']==0
    probes = {k:v for k,v in ac.items() if k.startswith('diag_wait/')}
    stages = []
    if args.mode=='probe':
        checks['all_stage_records'] = actual['profile']['steps']==steps and actual['profile']['step_records_complete'] and not actual['profile']['errors']
        for row in actual['profile']['step_records']:
            if row['tick'] in prepared['selected_result_ticks']:
                stages.append(dict(tick=row['tick'],whole_us=row['outer_elapsed_us'],waiting=row['stages']['dispatch.waiting']))
    summary = dict(diagnostic_only=True,formal_pass=False,passed=all(checks.values()),checks=checks,metrics=actual['metrics'],probes=probes,selected_stages=stages,all_query_count_differences=differences)
    write(output.with_suffix('.semantic-check.json'),summary)
    print(json.dumps(summary),flush=True)
    assert all(checks.values())

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('action',choices=['prepare','prepare_after','prepare_reverse','functional','measure','summarize'])
    parser.add_argument('--mode',choices=['plain','probe','after','reverse'])
    parser.add_argument('--window',choices=['public360','gp80','operations40'])
    parser.add_argument('--label')
    args=parser.parse_args()
    if args.action=='prepare': prepare()
    elif args.action=='prepare_after': prepare_after()
    elif args.action=='prepare_reverse': prepare_reverse()
    elif args.action=='functional': functional()
    else: measure(args)
