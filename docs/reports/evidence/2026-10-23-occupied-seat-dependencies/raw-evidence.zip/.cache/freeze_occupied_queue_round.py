from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import zipfile

REPO=Path(__file__).resolve().parent.parent
ROOT=REPO/'.cache/queue-signature-26bcc0f-20261023'
OUT=REPO/'docs/reports/evidence/2026-10-23-occupied-seat-dependencies'
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
digest=lambda b:hashlib.sha256(b).hexdigest()
sha=lambda p:digest(Path(p).read_bytes())
relative=lambda p:str(Path(p).relative_to(REPO)).replace('\\','/')
def write(path,value):Path(path).write_bytes((json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))

assert not OUT.exists()
prior=REPO/'docs/reports/evidence/2026-10-23-waiting-cost-and-reverse-field/raw-evidence.zip'
assert sha(prior)=='ce6c05503116937dc1225150ac05b4b1899280ddd23588f973234f97685a8016'
identity=read(ROOT/'occupiedfinal-identity.json')
baseline=read(ROOT/'baseline-identity.json')
for row in baseline['sources']:
    assert sha(ROOT/'baseline-project'/row['path'])==row['sha256'],row['path']
for row in identity['sources']:
    path=row['path']
    assert sha(ROOT/'occupiedfinal-project'/path)==row['sha256'],path
    if path not in ['project.godot','export_presets.cfg']:assert sha(REPO/path)==row['sha256'],path
documentation_changes=[]
for row in identity['tests']:
    path=row['path']
    assert sha(ROOT/'occupiedfinal-project'/path)==row['sha256'],path
    if sha(REPO/path)!=row['sha256']:
        assert path=='tests/acceptance/staff.md',path
        documentation_changes.append(dict(path=path,measured_sha256=row['sha256'],delivery_sha256=sha(REPO/path),documentation_only=True))

allowed={'public_queue_fit_hits','public_queue_fit_builds','public_wait_dependency_rectangles','facility_environment_hits',
    'reservation_candidate_queries','public_wait_dependency_batches','public_wait_rechecks',
    'public_wait_environment_match_hits','public_facility_candidates','public_wait_hits'}
runs={}
intervals=[]
for receipt_path in sorted(ROOT.glob('*.launch.json')):
    receipt=read(receipt_path)
    name=receipt_path.name.removesuffix('.launch.json')
    intervals.append((receipt['started_at_utc'],receipt['ended_at_utc'],name))
    result_path=ROOT/(name+'.json')
    if not result_path.exists():continue
    result=read(result_path)
    if 'metrics' not in result or 'samples' not in result:continue
    assert receipt['exit_code']==0 and not receipt['errors'] and not receipt['timed_out'],name
    assert result['complete'] and result['qualified'] and not result['errors'],name
    window=next(x for x in ['public360','gp80','operations40'] if name.endswith(x))
    expected=read(REPO/'.cache/waiting-phase-f4207fb-20261023'/('r2-'+window+'.json'))
    for key in ['source_input_sha256','initial','final','qualification','operations','event_records','final_binary_sha256']:
        assert result.get(key)==expected.get(key),(name,key)
    assert len(result['samples'])==result['requested_steps']
    assert all(x['present']==160 and x['complete'] for x in result['samples'])
    assert [{k:v for k,v in x.items() if k!='elapsed_us'} for x in result['samples']]==[{k:v for k,v in x.items() if k!='elapsed_us'} for x in expected['samples']],name
    ap,bp=result['public'].copy(),expected['public'].copy()
    ac,bc=ap.pop('query_counts'),bp.pop('query_counts')
    assert ap==bp,name
    differences={k:dict(actual=ac.get(k),baseline=bc.get(k)) for k in ac.keys()|bc.keys() if ac.get(k)!=bc.get(k)}
    assert all(k in allowed or k.startswith(('diag_wait/','public_wait_queue_')) for k in differences),name
    for key,row in differences.items():
        if key in allowed:
            if key=='public_wait_hits':assert row['actual']>=row['baseline'],(name,key)
            else:assert row['actual']<=row['baseline'],(name,key)
    worker=result['worker_sample']
    assert worker['batches']==result['requested_steps'] and worker['processed']==worker['consumed'] and worker['failed_batches']==0,name
    if result.get('profile'):
        profile=result['profile']
        assert profile['steps']==result['requested_steps'] and profile['step_records_complete'] and not profile['errors'],name
    source_check=read(ROOT/(name+'.source-check.json'))
    arguments=receipt['arguments']
    project=Path(arguments[arguments.index('--path')+1])
    variant=project.name.removesuffix('-project')
    source_identity=read(ROOT/(variant+'-identity.json'))
    assert source_identity['sources']==source_check['actual_sources'],name
    for row in source_identity['sources']:assert sha(project/row['path'])==row['sha256'],(name,row['path'])
    original_validation=read(ROOT/(name+'.semantic-check.json'))
    assert sha(ROOT/(name+'.json.final.bin'))==result['final_binary_sha256'],name
    runs[name]=dict(variant=variant,profile='root' if variant.endswith('probe') else 'plain',metrics_us=result['metrics'],steps=len(result['samples']),
        business_events_rng_non_time_samples_equal=True,qualified_160_every_step=True,query_count_differences=differences,
        query_counts={k:v for k,v in ac.items() if not k.startswith('diag_wait/')},
        diagnostic_counts={k:v for k,v in ac.items() if k.startswith('diag_wait/')},
        original_aggregation_passed=original_validation['passed'],independent_revalidation_passed=True,
        process_cpu_ms=receipt['child_cpu_ms'],launch_wall_ms=receipt['wall_ms'],
        input_sha256=result['source_input_sha256'],final_binary_sha256=result['final_binary_sha256'])

intervals.sort()
for first,second in zip(intervals,intervals[1:]):assert first[1]<=second[0],('overlapping engines',first,second)
cases=read(ROOT/'functional03.acceptance-results.json')
assert cases['completed'] and cases['checks']==4 and cases['failed']==0
assert sorted(cases['results'])==['STAFF-48','STAFF-57','STAFF-69','STAFF-71']
guard=cases['results']['STAFF-69']['details']['occupied_seat_queue_dependencies']
assert guard['ok'] and guard['new_unoccupied_candidate_restores_complete_original_queue']

members={}
def add(path,name=None):
    path=Path(path)
    if not path.is_file():return
    name=name or relative(path)
    data=path.read_bytes()
    if name in members:assert members[name]==data,name
    members[name]=data

for path in ROOT.iterdir():
    if path.is_file() and not path.name.endswith('.final.bin'):add(path)
for path in ROOT.glob('*.sources/*.gd'):add(path)
aliases=[]
for project in sorted(ROOT.glob('*-project')):
    for source in ['game/life/public_areas.gd','game/clinic/clinical_runtime.gd','game/clinic/hospital_visitors.gd','game/operations/department_service.gd','tests/acceptance/public_phase_use.gd']:
        path=project/source
        if not path.exists():continue
        member='source-blobs/'+sha(path)+'.gd'
        add(path,member)
        aliases.append(dict(original=relative(path),member=member,sha256=sha(path)))
for path in ROOT.glob('*.json.final.bin'):
    member='final-states/'+sha(path)+'.bin'
    add(path,member)
    aliases.append(dict(original=relative(path),member=member,sha256=sha(path)))
for source in ['game/life/public_areas.gd','tests/acceptance/public_phase_use.gd','tests/acceptance/staff.md','docs/specs/26-10/2026-10-18-public-facility-area-use.md']:
    add(REPO/source,'delivery-source/'+source)
for name in ['public-v6.input.bin','gp.input.bin','op.input.bin']:add(REPO/'.cache/task-navigation-20261019'/name)
for name in ['queue_signature_round.py','queue_final_measure.py','occupied_queue_probe.py','queue_count_probe.py','waiting_probe_f4207fb.py']:
    add(REPO/'.cache'/name)
add(REPO/'.cache/wait-signature-031e1f7-20261022/run.py')
add(Path(__file__))
add(ROOT/'occupiedfinal-project/tools/performance/representative_worker.gd','runner-source/representative_worker.gd')

notes=dict(
    nonmeasurement_tool_failures=['Read-only CIM battery query unavailable in the execution environment; current power state remains unverified.',
        'One Python read-only display used the Windows default GBK encoding and failed; subsequent display explicitly used UTF-8.'],
    original_aggregation_failures={k:'Engine window completed and business matched, but the original count equality/whitelist was too strict. Raw failed aggregation retained; independent per-counter revalidation above passed.' for k,v in runs.items() if not v['original_aggregation_passed']},
    discarded_short_function_timings='clinicprobe01 and clinicparent01 insert clocks before evaluating return expressions. Return-expression work is excluded for affected methods; these short-method timings are not used for cost claims. Corrected beforeprobe02/afterprobe02 and total-* evaluate expressions first.',
    rejected_variants=['bodyrows: per-actor validation cache, no established whole-step gain','priorwaiters/final/final2: earlier-seat-claimant filtering, no established whole-step gain and public P99 regressed'],
    selected_tick_limit='Uninstrumented root records still cover complete windows; conditional function timers cover only declared selected ticks. Nested intervals overlap.',
    environment_limit='Identical source controls range widely, including adjacent low-duration windows. Runtime cause was not established. No affinity, priority, population, dt, polling, budget or business threshold was changed.')
members['tool-and-interpretation-notes.json']=(json.dumps(notes,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
OUT.mkdir(parents=True)
archive=OUT/'raw-evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=7) as target:
    for name,data in sorted(members.items()):target.writestr(name,data)
member_rows=[dict(path=name,size=len(data),sha256=digest(data)) for name,data in sorted(members.items())]
with zipfile.ZipFile(archive) as target:
    assert sorted(target.namelist())==[x['path'] for x in member_rows]
    for row in member_rows:
        data=target.read(row['path'])
        assert len(data)==row['size'] and digest(data)==row['sha256'],row['path']
manifest=dict(schema_version=1,archive=relative(archive),size=archive.stat().st_size,sha256=sha(archive),members=member_rows,
    aliases=aliases,external_baseline=dict(path=relative(prior),sha256=sha(prior),verified=True),
    source_identity=identity,baseline_identity=baseline,documentation_only_after_measurement=documentation_changes,
    no_engine_overlap=True,engine_intervals=intervals)
write(OUT/'raw-manifest.json',manifest)
summary=dict(schema_version=1,generated_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    baseline_commit=baseline['source_commit'],diagnostic_only=True,formal_pass=False,
    fixed_load=dict(actors=160,patients=120,staff=32,visitors=8,floors=4,rooms=64,facilities=1336,tick_seconds=0.1),
    successful_engine_windows=len(runs),measured_steps=sum(x['steps'] for x in runs.values()),runs=runs,
    functional=dict(checks=cases['checks'],failed=cases['failed'],cases={k:dict(passed=v['passed'],body_ms=v['body_ms'],setup_ms=v['setup_ms']) for k,v in cases['results'].items()},occupied_queue_boundary=guard),
    notes=notes,raw_archive=dict(path=relative(archive),sha256=sha(archive),size=archive.stat().st_size,members=len(member_rows)),
    production_files_verified=len(identity['sources']),test_files_verified=len(identity['tests']))
write(OUT/'summary.json',summary)
print(json.dumps(dict(windows=len(runs),steps=summary['measured_steps'],archive=summary['raw_archive'],cases=summary['functional']['cases'],failed_original_aggregations=list(notes['original_aggregation_failures']))),flush=True)
