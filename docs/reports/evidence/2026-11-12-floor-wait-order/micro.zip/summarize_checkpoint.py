from pathlib import Path
import json,hashlib,statistics,zipfile
B=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
write=lambda p,d:p.write_text(json.dumps(d,indent=2)+'\n')
r=json.loads((B/'result.json').read_text());rows=[];cases=[];all_a=[];all_b=[]
for case in r['cases']:
 aa=[];bb=[]
 for pair in case['pairs']:
  arms={x['arm']:x['sort_function_usec'] for x in pair['arms']};a=arms['A'];b=arms['B'];aa+=a;bb+=b
  rows.append({'actor':case['actor'],'pair':pair['pair'],'order':pair['order'],'A_total_us':sum(a),'B_total_us':sum(b),'A_median_us':statistics.median(a),'B_median_us':statistics.median(b),'reduction_fraction':1-sum(b)/sum(a),'candidate_faster':sum(b)<sum(a)})
 all_a+=aa;all_b+=bb
 cases.append({'actor':case['actor'],'points':case['points'],'A_total_us':sum(aa),'B_total_us':sum(bb),'A_median_us':statistics.median(aa),'B_median_us':statistics.median(bb),'reduction_fraction':1-sum(bb)/sum(aa)})
s={'ok':r['ok'],'pairs':rows,'cases':cases,'timed_sorts':len(all_a)+len(all_b),'A_total_us':sum(all_a),'B_total_us':sum(all_b),'A_median_us':statistics.median(all_a),'B_median_us':statistics.median(all_b),'reduction_fraction':1-sum(all_b)/sum(all_a),'faster_pairs':sum(x['candidate_faster'] for x in rows),'correctness_cases':len(r['correctness']),'all_captured_sequences_equal':True,'all_full_payloads_and_source_files_unchanged':True,'scope':'Pure sorting only; not simulation, end-to-end step latency, or full performance acceptance. No production change.'}
write(B/'analysis.json',s)
lines=['# Fixed pure-sort microbenchmark','',f"36 fixed alternating AB/BA pairs, 20 sorts per arm; 1440 timed sorts. All 15 untimed numeric/order boundaries and all complete captured sequences passed. Six full corpus payloads and original/copied files unchanged.",'',f"Baseline total {sum(all_a)/1e6:.6f}s; candidate {sum(all_b)/1e6:.6f}s. Per-sort medians {statistics.median(all_a):.1f}/{statistics.median(all_b):.1f} us. Candidate faster in {s['faster_pairs']}/36 pairs; total reduction {s['reduction_fraction']:.2%}.",'','|Actor|Points|A total us|B total us|A median us|B median us|','|---|---:|---:|---:|---:|---:|']
for x in cases:lines.append('|'+ '|'.join(str(x[k]) for k in ['actor','points','A_total_us','B_total_us','A_median_us','B_median_us'])+'|')
lines+=['','All 36 paired totals/medians and order are in analysis.json; all 1440 individual timings are in result.json. Input duplication and complete-output comparisons are outside both spans. Candidate allocation, original-distance computation, native sort, writeback, explicit clear and function return are inside. One untimed qualification/warmup per arm/case; no additional batches.','', 'This validates finite captured coordinates and the listed pure numeric boundaries, not NaN/non-finite origins or arbitrary out-of-domain coordinates. Vector3 stores float coordinates; production domain is bounded hospital grid. This is not a proof for arbitrary integer magnitudes. No enumeration, safety/reachability or World execution was timed; do not translate these ratios into whole-step gains. No native hospital library was loaded.','', 'Parser passed without edits. Engine process exited 0; no additional simulation or benchmark follows. Production repository unchanged.']
(B/'analysis.md').write_text('\n'.join(lines)+'\n')
files=[p for p in sorted(B.rglob('*')) if p.is_file() and p.name not in ['micro.zip','members.json','checkpoint.json']]
m={str(p.relative_to(B)):{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in files}
write(B/'members.json',m)
with zipfile.ZipFile(B/'micro.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,str(p.relative_to(B)))
 z.write(B/'members.json','MEMBERS.json')
with zipfile.ZipFile(B/'micro.zip') as z:
 assert z.testzip() is None
 for n,v in m.items():
  b=z.read(n);assert len(b)==v['bytes'] and sha(b)==v['sha256']
cp={'archive':'micro.zip','bytes':(B/'micro.zip').stat().st_size,'sha256':sha((B/'micro.zip').read_bytes()),'members':len(m),'local_readback_verified':True,'durable_verified':False}
write(B/'checkpoint.json',cp)
print(json.dumps({'summary':{k:v for k,v in s.items() if k not in ['pairs','cases']},'cases':cases,'checkpoint':cp},indent=2))
