from pathlib import Path
import sys,json,hashlib,shutil,traceback
B=Path(__file__).resolve().parent;ROOT=B.parent
sys.path.insert(0,str(ROOT/'movement-stage-recovery-20261112'));import full_narrow_v1 as h
c=h.c;g=h.g
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
write=lambda p,d:Path(p).write_text(json.dumps(d,indent=2)+'\n')
p=json.loads((B/'plan.json').read_text());prep=json.loads((B/'preparation-check.json').read_text())
for n,v in prep['files_sha256'].items():assert sha(B/n)==v,n
assert sha(B/'plan.json')=='22c20259c4bdc3d221a497873ad5dab5ab5946399a63afe7634ec5ee6bcd8d74'
assert sha(p['engine'])==p['engine_sha256']
source=ROOT/'oddly-good-hospital-cloud-recovery-20261112/game/life/public_areas.gd'
assert sha(source)==p['production_source_sha256']
s=source.read_text();a=s.index('\tpoints.sort_custom(',s.index('func floor_waiting_point('));z=s.index('\n\tfor point: Vector2i in points:',a)
assert s[a:z] in (B/'project/order.gd').read_text()
for e in p['corpus']:assert sha(e['path'])==sha(e['source'])==e['sha256']
receipt=ROOT/'waiting-fallback-breakdown-20261112/breakdown.durable-receipt.json';shutil.copy2(receipt,B/receipt.name)
shutil.copy2(source,B/'public_areas.production.gd');shutil.copy2(ROOT/'root-stage-recovery-20261112/linux_guard_v2.py',B/'linux_guard_v2.py')
write(B/'identity.json',{'engine_sha256':sha(p['engine']),'guard_sha256':sha(B/'linux_guard_v2.py'),'plan_sha256':sha(B/'plan.json'),'source_sha256':sha(source),'input_sha256':[e['sha256'] for e in p['corpus']],'pure_project_no_native_loaded':True})
c.idle();g.PROJECT=B/'project';g.LIBRARY_PATH=str(ROOT/'cloud-validation-recovery-20261112/cache/prefix/lib')
write(B/'host-before.json',h.host())
try:
 g.run([p['engine'],'--headless','--path',str(B/'project'),'--script','res://run.gd','--check-only'],B/'parser-01',timeout=60)
 c.idle()
 g.run(p['prepared_command'],B/'micro-01',timeout=180,allowed_exits=(0,1))
finally:write(B/'host-after.json',h.host())
r=json.loads((B/'result.json').read_text());assert r['ok'] and not r['errors']
assert len(r['correctness'])==15 and all(x['ok'] for x in r['correctness'])
assert r['total_pairs']==36 and r['timed_sorts']==1440
for case in r['cases']:
 assert case['complete_captured_order_equal'] and case['source_and_full_payload_unchanged']
 assert len(case['pairs'])==6
 for i,pair in enumerate(case['pairs']):
  assert pair['order']==(['A','B'] if i%2==0 else ['B','A'])
  for arm in pair['arms']:assert arm['all_outputs_exact'] and len(arm['sort_function_usec'])==20
for e in p['corpus']:assert sha(e['path'])==sha(e['source'])==e['sha256']
c.idle();print('FIXED_BATCH_VERIFIED')
