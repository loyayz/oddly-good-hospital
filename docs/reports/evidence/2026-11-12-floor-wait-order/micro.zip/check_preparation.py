from pathlib import Path
import hashlib,json
b=Path(__file__).resolve().parent
p=json.loads((b/'plan.json').read_text())
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
source=Path('/workspace/scratch/6962cc21ddf3/oddly-good-hospital-cloud-recovery-20261112/game/life/public_areas.gd').read_text()
a=source.index('\tpoints.sort_custom(',source.index('func floor_waiting_point('));z=source.index('\n\tfor point: Vector2i in points:',a)
order=(b/'project/order.gd').read_text();assert source[a:z] in order
assert p['total_pairs']==36 and p['total_timed_sorts']==1440 and p['arm_order']==['AB','BA']*3
assert len(p['corpus'])==6
for f in p['corpus']:assert sha(f['path'])==sha(f['source'])==f['sha256']
runner=(b/'project/run.gd').read_text()
for forbidden in ['HospitalSimulation.new','WorldState.new','request_move(','.safe_wait(','.can_reach(']:assert forbidden not in runner+order
assert 'decorated.clear()' in order and 'decorated.sort()' in order
assert order.count('origin.distance_squared_to(Vector2(point))')==1
assert 'const PAIRS: int=6' in runner and 'const REPEATS: int=20' in runner
assert 'FileAccess.READ' in runner and 'snapshot==var_to_bytes(d)' in runner
assert sha(p['engine'])==p['engine_sha256']
files={str(f.relative_to(b)):sha(f) for f in sorted(b.rglob('*')) if f.is_file() and f.name!='preparation-check.json'}
report={'ok':True,'validation':'Python static assertions only; NOT Godot parse/runtime validation','no_engine_parser_or_benchmark_started':True,'files_sha256':files}
(b/'preparation-check.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'ok':True,'files':len(files),'order_sha256':sha(b/'project/order.gd'),'runner_sha256':sha(b/'project/run.gd'),'plan_sha256':sha(b/'plan.json')}))
