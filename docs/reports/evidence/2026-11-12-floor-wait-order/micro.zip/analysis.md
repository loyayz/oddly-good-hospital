# Fixed pure-sort microbenchmark

36 fixed alternating AB/BA pairs, 20 sorts per arm; 1440 timed sorts. All 15 untimed numeric/order boundaries and all complete captured sequences passed. Six full corpus payloads and original/copied files unchanged.

Baseline total 14.652447s; candidate 2.020679s. Per-sort medians 19897.5/2699.0 us. Candidate faster in 36/36 pairs; total reduction 86.21%.

|Actor|Points|A total us|B total us|A median us|B median us|
|---|---:|---:|---:|---:|---:|
|bench_patient_0003|8256|2586016|322083|21135.0|2640.5|
|bench_patient_0011|8256|2392376|339122|18155.0|2562.0|
|bench_patient_0012|8320|2411124|335553|19680.0|2732.5|
|bench_patient_0026|8320|2558864|345805|21011.5|2815.0|
|bench_patient_0027|8256|2345764|338975|19385.5|2738.0|
|bench_patient_0059|8256|2358303|339141|19019.0|2707.0|

All 36 paired totals/medians and order are in analysis.json; all 1440 individual timings are in result.json. Input duplication and complete-output comparisons are outside both spans. Candidate allocation, original-distance computation, native sort, writeback, explicit clear and function return are inside. One untimed qualification/warmup per arm/case; no additional batches.

This validates finite captured coordinates and the listed pure numeric boundaries, not NaN/non-finite origins or arbitrary out-of-domain coordinates. Vector3 stores float coordinates; production domain is bounded hospital grid. This is not a proof for arbitrary integer magnitudes. No enumeration, safety/reachability or World execution was timed; do not translate these ratios into whole-step gains. No native hospital library was loaded.

Parser passed without edits. Engine process exited 0; no additional simulation or benchmark follows. Production repository unchanged.
