extends RefCounted

func baseline(points: Array, origin: Vector2) -> void:
	points.sort_custom(func(a: Vector2i,b: Vector2i)->bool:
		var da: float=origin.distance_squared_to(Vector2(a))
		var db: float=origin.distance_squared_to(Vector2(b))
		return da<db if da!=db else a.y<b.y if a.y!=b.y else a.x<b.x)

func candidate(points: Array, origin: Vector2) -> void:
	var decorated: Array[Vector3]=[]
	for point: Vector2i in points:
		var distance: float=origin.distance_squared_to(Vector2(point))
		decorated.append(Vector3(distance,point.y,point.x))
	decorated.sort()
	for i: int in decorated.size():
		points[i]=Vector2i(int(decorated[i].z),int(decorated[i].y))
	# Release the temporary Variant array inside the measured function.
	decorated.clear()
