extends SceneTree
const Order=preload("res://order.gd")
const PAIRS: int=6
const REPEATS: int=20
var sorter: RefCounted=Order.new()
var errors: Array=[]

func _initialize() -> void:
	call_deferred("_run")

func _expect(ok: bool, label: String) -> void:
	if not ok: errors.append(label)

func _pure_case(label: String, original: Array, origin: Vector2, literal: Array=[]) -> Dictionary:
	var before: Array=original.duplicate()
	var a: Array=original.duplicate()
	var b: Array=original.duplicate()
	sorter.baseline(a,origin)
	sorter.candidate(b,origin)
	var ok: bool=a==b and original==before
	if not literal.is_empty(): ok=ok and a==literal
	_expect(ok,"pure:"+label)
	return {"case":label,"ok":ok,"origin":[origin.x,origin.y],"input":original,"expected":a,"candidate":b}

func _correctness() -> Array:
	var rows: Array=[]
	rows.append(_pure_case("empty",[],Vector2.ZERO))
	rows.append(_pure_case("single",[Vector2i(95,95)],Vector2(40,71)))
	rows.append(_pure_case("duplicates",[Vector2i(31,32),Vector2i(31,32),Vector2i(32,31),Vector2i(32,31)],Vector2(31.5,31.5)))
	rows.append(_pure_case("literal_integer_y_x_ties",[Vector2i(41,40),Vector2i(40,41),Vector2i(40,39),Vector2i(39,40)],Vector2(40,40),[Vector2i(40,39),Vector2i(39,40),Vector2i(41,40),Vector2i(40,41)]))
	rows.append(_pure_case("literal_half_grid_ties",[Vector2i(32,32),Vector2i(31,32),Vector2i(32,31),Vector2i(31,31)],Vector2(31.5,31.5),[Vector2i(31,31),Vector2i(32,31),Vector2i(31,32),Vector2i(32,32)]))
	var grid: Array=[]
	for y: int in [0,31,32,40,41,63,64,70,71,95]:
		for x: int in [0,31,32,39,40,41,63,64,95]: grid.append(Vector2i(x,y))
	grid.reverse()
	for origin: Vector2 in [Vector2(40,70),Vector2(40.5,70.5),Vector2(40.000003814697265625,70.00000762939453125),Vector2(39.999996185302734375,69.99999237060546875),Vector2(63.5,63.5),Vector2(95,95),Vector2(1.0e12,1.0e12),Vector2(-1.0e12,-1.0e12),Vector2(-0.5,32.5),Vector2(1.0e12,-1.0e12)]:
		rows.append(_pure_case("numeric_domain_"+str(rows.size()),grid,origin))
	return rows

func _arm(arm: String, original: Array, origin: Vector2, expected: Array) -> Dictionary:
	var samples: Array=[]
	var all_equal: bool=true
	for repeat: int in REPEATS:
		# Both arms duplicate the same original input outside the measured span.
		var points: Array=original.duplicate()
		var elapsed: int=0
		if arm=="A":
			var started: int=Time.get_ticks_usec()
			sorter.baseline(points,origin)
			elapsed=Time.get_ticks_usec()-started
		else:
			var started: int=Time.get_ticks_usec()
			sorter.candidate(points,origin)
			elapsed=Time.get_ticks_usec()-started
		# All comparison, result retention and final output-array release are outside.
		all_equal=all_equal and points==expected
		samples.append(elapsed)
	_expect(all_equal,"timed:"+arm)
	return {"arm":arm,"repeat_count":REPEATS,"sort_function_usec":samples,"all_outputs_exact":all_equal}

func _run() -> void:
	var args: PackedStringArray=OS.get_cmdline_user_args()
	if args.size()!=3:
		push_error("Expected corpus manifest, output, and explicit RUN_APPROVED token")
		quit(2);return
	if args[2]!="RUN_APPROVED": quit(2);return
	var manifest: Dictionary=JSON.parse_string(FileAccess.get_file_as_string(args[0]))
	_expect(manifest.corpus.size()==6,"six sealed inputs")
	var correctness: Array=_correctness()
	var cases: Array=[]
	for entry: Dictionary in manifest.corpus:
		var before_sha: String=FileAccess.get_sha256(entry.path)
		_expect(before_sha==entry.sha256,"input identity:"+entry.path)
		if before_sha!=entry.sha256: continue
		var f: FileAccess=FileAccess.open(entry.path,FileAccess.READ)
		var d: Dictionary=f.get_var(false)
		f.close()
		# No WorldState or Simulation is constructed. Facts remain untouched.
		var snapshot: PackedByteArray=var_to_bytes(d)
		var original: Array=d.points_before
		var expected: Array=d.points_after
		var origin: Vector2=Vector2(float(d.origin[0]),float(d.origin[1]))
		var typed: bool=true
		for point: Variant in original: typed=typed and typeof(point)==TYPE_VECTOR2I
		for point: Variant in expected: typed=typed and typeof(point)==TYPE_VECTOR2I
		_expect(typed and original.size()==expected.size(),"typed complete corpus:"+d.actor_id)
		# Untimed qualification/warmup: one complete call for each arm.
		var a: Array=original.duplicate()
		var c: Array=original.duplicate()
		sorter.baseline(a,origin);sorter.candidate(c,origin)
		_expect(a==expected and c==expected,"captured order:"+d.actor_id)
		var pairs: Array=[]
		for pair: int in PAIRS:
			var order: Array=["A","B"] if pair%2==0 else ["B","A"]
			var arms: Array=[]
			for arm: String in order: arms.append(_arm(arm,original,origin,expected))
			pairs.append({"pair":pair+1,"order":order,"arms":arms})
		var unchanged: bool=snapshot==var_to_bytes(d) and before_sha==FileAccess.get_sha256(entry.path) and before_sha==FileAccess.get_sha256(entry.source)
		_expect(unchanged,"source/full payload unchanged:"+d.actor_id)
		cases.append({"actor":d.actor_id,"points":original.size(),"origin":[origin.x,origin.y],"pairs":pairs,"complete_captured_order_equal":a==expected and c==expected,"source_and_full_payload_unchanged":unchanged,"input_sha256":before_sha})
	var result: Dictionary={"ok":errors.is_empty() and cases.size()==6,"engine":Engine.get_version_info(),"fixed_pairs_per_case":PAIRS,"fixed_repeats_per_arm":REPEATS,"total_pairs":cases.size()*PAIRS,"timed_sorts":cases.size()*PAIRS*2*REPEATS,"correctness":correctness,"cases":cases,"errors":errors,"scope":"Pure computation only. Complete original sort vs Vector3 decoration/native Array.sort/restore lifecycle. No simulation, enumeration, safety, reachability, or overall performance acceptance."}
	var out: FileAccess=FileAccess.open(args[1],FileAccess.WRITE)
	out.store_string(JSON.stringify(result,"\t"));out.close()
	print("FLOOR_ORDER_MICRO "+str(result.ok))
	quit(0 if result.ok else 1)
