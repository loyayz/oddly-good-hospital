from pathlib import Path
import json,hashlib,re,subprocess
root=Path('/workspace/scratch/6962cc21ddf3');r=root/'oddly-good-hospital-cloud-recovery-20261112';b=root/'floor-wait-order-selected-20261112';b.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
uid={str(p.relative_to(r)):sha(p) for p in r.rglob('*.uid') if '.git' not in p.parts};(b/'uid-before.json').write_text(json.dumps(uid,indent=2))
report=r/'docs/reports/2026-11-12-floor-wait-order.md'
with report.open('a') as f:f.write('''\n## 排序整合：实施前范围与选例\n\n本次只将已测排序接入 floor_waiting_point，完整枚举、公共点定义、原 Vector2 距离、y/x 平局、safe_wait && can_reach 的顺序及短路、同层返回位置全部保留；不加缓存、不改 native。实际交接是到期且当前占地不安全的 fallback_travel；原期限、票号、移动所有者、真实安全到达后80 tick 使用不变。依据公共设施规格148–156/164及医院日常§17。\n\n选例：最终生产排序 helper 的15个纯边界与6份captured全序；同一正式 floor_waiting_point 对照原比较器，核完整序列、实际安全/可达调用轨迹、首个通过与只读World/RNG，包含冷World/facts替换/公共房间/派生上层边界；STAFF-74门及连接锚点真实撤离、存档恢复和80tick，并观察 floor_waiting_point 实际命中；只调用 safe_fallback_before_busy_waypoint 的两种所有权边界，不运行完整arrival专题。已有micro测量只在整合helper与已测候选体逐字一致时复用，不重跑micro或历史性能窗口。先parser/diffcheck，再选例；失败保留原日志。\n''')
p=r/'game/life/public_areas.gd';old=p.read_text();(b/'public_areas.before.gd').write_text(old)
a=old.index('\tpoints.sort_custom(',old.index('func floor_waiting_point('));z=old.index('\n\tfor point: Vector2i in points:',a);comparator=old[a:z]
measured=(root/'floor-wait-order-candidate-20261112/project/order.gd').read_text();body=measured.split('func candidate(points: Array, origin: Vector2) -> void:\n',1)[1]
helper='''# Complete public candidates have exact integer coordinates in 0..95.
# Keep the original Vector2 distance precision and literal y/x tie order.
func _sort_floor_waiting_points(points: Array, origin: Vector2) -> void:
'''+body+'\n'
new=old[:a]+'\t_sort_floor_waiting_points(points,origin)'+old[z:];idx=new.index('func room_exit_point(');new=new[:idx]+helper+new[idx:];p.write_text(new)
assert new.split('func _sort_floor_waiting_points(points: Array, origin: Vector2) -> void:\n')[1].split('\nfunc room_exit_point')[0]==body+'\n'
# Tests run real production path; reference overrides only its sort helper.
s='''extends SceneTree
const Phase=preload("res://tests/acceptance/public_phase_use.gd")
const Boundary=preload("res://tests/acceptance/public_arrival_boundaries.gd")
class TraceSpace extends HospitalSpace:
	var events: Array=[]
	func can_reach(world: WorldState, actor_id: String, floor_id: int, target: Array, members: Array=[], offsets: Dictionary={}, ignore_people: bool=false) -> bool:
		var result: bool=super.can_reach(world,actor_id,floor_id,target,members,offsets,ignore_people)
		events.append({"kind":"reach","cell":target.duplicate(),"result":result})
		return result
class TraceAreas extends HospitalPublicAreas:
	var before: Array=[]
	var after: Array=[]
	func _sort_floor_waiting_points(points: Array, origin: Vector2) -> void:
		before=points.duplicate()
		super._sort_floor_waiting_points(points,origin)
		after=points.duplicate()
	func safe_wait(world: WorldState, actor_id: String, floor_id: int, cell: Array, geometry: Dictionary={}) -> bool:
		var result: bool=super.safe_wait(world,actor_id,floor_id,cell,geometry)
		space.events.append({"kind":"safe","cell":cell.duplicate(),"result":result})
		return result
class ReferenceAreas extends TraceAreas:
	func _sort_floor_waiting_points(points: Array, origin: Vector2) -> void:
		before=points.duplicate()
BASELINE
		after=points.duplicate()
class SortAdapter extends RefCounted:
	var areas: HospitalPublicAreas
	func baseline(points: Array, origin: Vector2) -> void:
BASELINE
	func candidate(points: Array, origin: Vector2) -> void:
		areas._sort_floor_waiting_points(points,origin)
class CountAreas extends HospitalPublicAreas:
	static var calls: int=0
	func floor_waiting_point(world: WorldState, actor_id: String) -> Dictionary:
		calls+=1
		return super.floor_waiting_point(world,actor_id)
class CountPhase extends Phase:
	func _areas(staff: Dictionary={}) -> Dictionary:
		var x: Dictionary=super._areas(staff)
		x.space.public_areas=CountAreas.new(x.space)
		return x
var content: HospitalContent
var sorter: RefCounted
var errors: Array=[]
var checks: Array=[]
func _initialize() -> void: call_deferred("_run")
func _expect(ok: bool, label: String) -> void:
	if not ok: errors.append(label)
func check(id: String, passed: bool, details: Variant=null) -> void:
	checks.append({"case":id,"ok":passed,"details":details})
	_expect(passed,id)
PURE
func _trace_valid(points: Array, events: Array, result: Dictionary, floor_id: int) -> bool:
	var index: int=0
	var reach: bool=false
	var success: bool=false
	for event: Dictionary in events:
		if success or index>=points.size(): return false
		var point: Vector2i=points[index]
		if event.cell!=[point.x,point.y] or event.kind!=("reach" if reach else "safe"): return false
		if reach:
			success=event.result;reach=false
			if not success: index+=1
		elif event.result: reach=true
		else: index+=1
	if reach: return false
	return result=={"floor_id":floor_id,"cell":[points[index].x,points[index].y]} if success else result.is_empty() and index==points.size()
func _query(label: String, world: WorldState, actor: String, actual: TraceSpace, reference: TraceSpace) -> Dictionary:
	actual.events.clear();reference.events.clear()
	actual.public_areas.before=[];actual.public_areas.after=[]
	reference.public_areas.before=[];reference.public_areas.after=[]
	var frozen: Dictionary=world.freeze()
	var validation: String=world.validate(content)
	var a: Dictionary=actual.public_areas.floor_waiting_point(world,actor)
	var mid: bool=world.freeze()==frozen
	var b: Dictionary=reference.public_areas.floor_waiting_point(world,actor)
	var same: bool=actual.public_areas.before==reference.public_areas.before and actual.public_areas.after==reference.public_areas.after and actual.events==reference.events and a==b
	var short_circuit: bool=_trace_valid(actual.public_areas.after,actual.events,a,int(world.facts.actors[actor].location.floor_id))
	var row: Dictionary={"case":label,"ok":validation.is_empty() and same and short_circuit and mid and world.freeze()==frozen,"validation":validation,"full_order_and_call_trace_equal":same,"short_circuit":short_circuit,"world_rng_unchanged":mid and world.freeze()==frozen,"count":actual.public_areas.after.size(),"events":actual.events.duplicate(true),"returned":a}
	_expect(row.ok,label)
	return row
func _inputs(manifest: Dictionary, sequence_only: bool) -> Array:
	var rows: Array=[]
	var actual:=TraceSpace.new(content);actual.public_areas=TraceAreas.new(actual)
	var reference:=TraceSpace.new(content);reference.public_areas=ReferenceAreas.new(reference)
	var adapter:=SortAdapter.new();adapter.areas=actual.public_areas;sorter=adapter
	if sequence_only: rows.append_array(_correctness())
	for entry: Dictionary in manifest.corpus:
		_expect(FileAccess.get_sha256(entry.path)==entry.sha256,"corpus hash")
		var f:=FileAccess.open(entry.path,FileAccess.READ);var d: Dictionary=f.get_var(false);f.close()
		var original: PackedByteArray=var_to_bytes(d)
		if sequence_only:
			var points: Array=d.points_before.duplicate()
			actual.public_areas._sort_floor_waiting_points(points,Vector2(float(d.origin[0]),float(d.origin[1])))
			var ok: bool=points==d.points_after
			_expect(ok,"captured:"+d.actor_id);rows.append({"case":d.actor_id,"ok":ok,"points":points.size()})
		else:
			var world:=WorldState.new(d.facts.duplicate(true))
			rows.append(_query(d.actor_id,world,d.actor_id,actual,reference))
			if rows.size()==1:
				var cold:=WorldState.new(world.freeze())
				rows.append(_query("cold_world",cold,d.actor_id,actual,reference))
				cold.facts=cold.freeze().duplicate(true)
				rows.append(_query("replaced_facts",cold,d.actor_id,actual,reference))
		_expect(original==var_to_bytes(d) and FileAccess.get_sha256(entry.path)==entry.sha256,"corpus unchanged")
	return rows
func _fixture_queries() -> Array:
	var fixture:=Phase.new();fixture._content=content
	var x: Dictionary=fixture._areas()
	var visit: Dictionary=fixture._visit(x,"public_order",[38,90])
	var a:=TraceSpace.new(content);a.public_areas=TraceAreas.new(a)
	var b:=TraceSpace.new(content);b.public_areas=ReferenceAreas.new(b)
	var rows: Array=[_query("room_public_before",x.world,visit.actor_id,a,b)]
	x.world.facts.rooms.west.kind="office";x.world.touch()
	rows.append(_query("room_public_to_private",x.world,visit.actor_id,a,b))
	x.world.facts.rooms.west.kind="rest";x.world.touch()
	rows.append(_query("room_public_restored",x.world,visit.actor_id,a,b))
	# Existing complete upper-floor ownership facts are supplied by captured
	# inputs; assert those inputs exercise derived floor_plots in the report.
	x.a.dispose()
	return rows
func _run() -> void:
	var args:=OS.get_cmdline_user_args();content=HospitalContent.new()
	var mode: String=args[0];var rows: Array=[]
	if mode in ["sequence","query"]:
		var manifest: Dictionary=JSON.parse_string(FileAccess.get_file_as_string(args[2]))
		rows=_inputs(manifest,mode=="sequence")
		if mode=="query":rows.append_array(_fixture_queries())
	elif mode=="flow":
		var phase:=CountPhase.new();phase._content=content;phase._case_74(self)
		check("STAFF-74-floor-fallback-hit",CountAreas.calls>0,{"calls":CountAreas.calls})
		var boundary:=Boundary.new();boundary._content=content
		var row: Dictionary=boundary._fallback_waypoint();rows.append(row);_expect(row.ok,row.case)
		rows.append_array(checks)
	else:errors.append("unknown mode")
	var out:=FileAccess.open(args[1],FileAccess.WRITE)
	out.store_string(JSON.stringify({"ok":errors.is_empty(),"mode":mode,"rows":rows,"errors":errors},"\\t"));out.close()
	print("FLOOR_WAIT_ORDER "+mode+" "+str(errors.is_empty()))
	quit(0 if errors.is_empty() else 1)
'''
s=s.replace('BASELINE','\n'.join('\t'+line for line in comparator.splitlines()))
micro=(root/'floor-wait-order-candidate-20261112/project/run.gd').read_text();pure=micro[micro.index('func _pure_case('):micro.index('func _arm(')];s=s.replace('PURE',pure)
(r/'tests/acceptance/run_floor_wait_order.gd').write_text(s)
(b/'integration-identity.json').write_text(json.dumps({'production_before_sha256':hashlib.sha256(old.encode()).hexdigest(),'production_after_sha256':sha(p),'measured_candidate_sha256':sha(root/'floor-wait-order-candidate-20261112/project/order.gd'),'helper_body_exact':True,'test_sha256':sha(r/'tests/acceptance/run_floor_wait_order.gd'),'uid_count':len(uid)},indent=2))
print('prepared',b)
