from pathlib import Path
p=Path('oddly-good-hospital-cloud-recovery-20261112/tests/acceptance/run_fallback_safe_arrival.gd');s=p.read_text();Path('fallback-safe-arrival-20261112/runner-flow03.gd').write_bytes(p.read_bytes())
s=s.replace('ticket_before.erase("pause_reasons");ticket_after.erase("pause_reasons")','var expected_pause: Dictionary=ticket_before.pause_reasons.duplicate(true)\n\t\t\tif not foreign:expected_pause.erase("need_service")\n\t\t\tvar pause_exact: bool=ticket_after.pause_reasons==expected_pause\n\t\t\tticket_before.erase("pause_reasons");ticket_after.erase("pause_reasons")').replace('"valid_final":x.world.validate','"only_own_pause_released":pause_exact,"valid_final":x.world.validate')
insert='''class SupportGuard extends "res://tests/acceptance/arrival_entry_ownership_edges.gd":
	var observations: Array=[]
	var output_dir: String
	func _edge_tick(x: Dictionary, ids: Array) -> String:
		for actor_id: String in ids:
			var movement: Dictionary=x.world.facts.moves.get(actor_id,{})
			if movement.is_empty():continue
			var actor: Dictionary=x.world.facts.actors[actor_id]
			var cursor: int=int(movement.cursor)
			var support: bool=cursor>=0 and cursor<movement.path.size() and movement.path[cursor].kind=="support_exit"
			if actor.get("posture","")!="lying" and not support:continue
			# Direct helper permission probe, not a fabricated life-service flow.
			# The real support journey is unchanged except this saved ownership tag.
			var had: bool=movement.has("waiting_need_id")
			var old: Variant=movement.get("waiting_need_id")
			movement.waiting_need_id="guard-probe"
			var validation: String=x.world.validate(_content)
			var before: Dictionary=x.world.freeze()
			var denied: bool=not x.l._try_finish_fallback_travel(x.world,actor_id,"guard-probe")
			if observations.is_empty():
				var f:=FileAccess.open(output_dir+"/support-preWorld.bin",FileAccess.WRITE);f.store_var(before,false);f.close()
			observations.append({"lying":actor.posture=="lying","support_exit":support,"denied":denied,"unchanged":before==x.world.freeze(),"validation":validation})
			if had:movement.waiting_need_id=old
			else:movement.erase("waiting_need_id")
		return super._edge_tick(x,ids)

func _guard_cases(directory: String) -> Array:
	var support:=SupportGuard.new();support._content=content;support.output_dir=directory
	var support_result: Dictionary=support._support_departure()
	check("REAL-SUPPORT-GUARD",support_result.ok and not support.observations.is_empty() and support.observations.any(func(row:Dictionary)->bool:return row.support_exit) and support.observations.all(func(row:Dictionary)->bool:return row.denied and row.unchanged and row.validation.is_empty()),{"journey":support_result,"probes":support.observations})
	var suite=preload("res://tests/acceptance/space.gd").new();suite.content=content
	var sim: HospitalSimulation=suite._fixture()
	suite._add_actor(sim,"leader","S49",[54,80]);suite._add_actor(sim,"follower","S49",[52,80])
	var form: Dictionary=ConvoyTrail.formation(sim.space,sim.world,"leader",["leader","follower"],Vector2.RIGHT)
	for id: String in ["leader","follower"]:
		sim.world.facts.actors[id].location.cell=form.targets[id];sim.space.sync_actor(sim.world,id)
	var reason: String=sim.space.request_group_move(sim.world,"leader",["leader","follower"],{},1,[58,80])
	var movement: Dictionary=sim.world.facts.moves.get("leader",{})
	movement.waiting_need_id="guard-probe"
	var before: Dictionary=sim.world.freeze()
	var validation: String=sim.world.validate(content)
	var life:=HospitalWaitingLife.new(content,sim.space)
	var refused: bool=not life._try_finish_fallback_travel(sim.world,"leader","guard-probe")
	var f:=FileAccess.open(directory+"/convoy-preWorld.bin",FileAccess.WRITE);f.store_var(before,false);f.close()
	check("OFFICIAL-CONVOY-MEMBERS-GUARD",reason.is_empty() and validation.is_empty() and movement.has("convoy") and movement.members.size()==2 and refused and sim.world.freeze()==before,{"validation":validation,"request":reason,"members":movement.get("members",[]),"convoy":movement.has("convoy"),"denied":refused,"unchanged":sim.world.freeze()==before})
	sim.dispose()
	return checks

'''
s=s.replace('func _run() -> void:',insert+'func _run() -> void:').replace('elif mode=="staff74":','elif mode=="guards":rows=_guard_cases(args[1].get_base_dir())\n\telif mode=="staff74":');p.write_bytes(s.encode())
