from pathlib import Path
import hashlib,json
root=Path('/workspace/scratch/6962cc21ddf3');r=root/'oddly-good-hospital-cloud-recovery-20261112';b=root/'fallback-safe-arrival-20261112';b.mkdir(exist_ok=False)
p=r/'game/life/waiting_life.gd';(b/'waiting_life.before.gd').write_bytes(p.read_bytes())
(b/'uid-before.json').write_text(json.dumps({str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in r.rglob('*.uid')},indent=2))
(r/'docs/reports/2026-11-12-fallback-safe-arrival.md').write_text('''# 随身兜底真实安全到场\n\n## 变更前规则、交接及选例\n- public-facility-area-use:150 明确：沿本任务真实地面行程到任一合法安全占地即可结束移动，不必到预选整数终点，也不要求设施区域成员。其他任务、实际绕行、承托退出及多人行程不得借此取消。\n- 仅 waiting_life fallback 私有结束逻辑去除区域 contains 门槛；保留原任务、detour/convoy/member、floor/lying、当前floor段检查，以及原 cancel_ground_move全部保护；实际完整身体 safe_wait 不变。共享 owns_arrival / try_finish_arrival 不变。\n- 选本任务安全中途 current_area 空场景与 foreign owner：合法正式生活需要和本need请求，逐步到达前不工作，原时钟/票序不重置，恢复后真实到场及80tick效果。远目标是fixture明确请求，不声称自然选点。保留原失败和本轮 baseline。\n- 选最小合法 guard 边界覆盖拒绝路径；选 STAFF-74 门/连接真实撤离恢复；共享区域到场仍需 contains 的直接边界。不会扩展全专题、性能或 waypoint其他问题。\n- 保存完整合法原始 preWorld、日志/命令/exit/耗时和UID。施工/上下楼不是本批范围。\n''')
s=p.read_text();old='''\t\t\tvar local: Dictionary = space.public_areas.current_area(world,visit.actor_id)
\t\t\tif not space.public_areas.try_finish_arrival(world,visit.actor_id,local,"waiting_need_id",need.id):''';assert old in s;s=s.replace(old,'''\t\t\tif not _try_finish_fallback_travel(world,visit.actor_id,need.id):''')
mark='func _start_fallback(world: WorldState, visit: Dictionary, need: Dictionary) -> void:'
helper='''# Portable fallback owns safety, not arrival in a facility area.
func _try_finish_fallback_travel(world: WorldState, actor_id: String, need_id: String) -> bool:
	var movement: Dictionary = world.facts.moves.get(actor_id,{})
	if movement.is_empty() or movement.get("waiting_need_id","")!=need_id or movement.has("detour") or movement.has("convoy") or movement.get("members",[actor_id])!=[actor_id]: return false
	var actor: Dictionary = world.facts.actors[actor_id]
	if actor.location.kind!="floor" or actor.get("posture","standing")=="lying": return false
	var cursor: int = int(movement.get("cursor",0))
	var path: Array = movement.get("path",[])
	if cursor>=0 and cursor<path.size() and path[cursor].kind!="floor": return false
	return space.public_areas.safe_wait(world,actor_id,int(actor.location.floor_id),actor.location.cell) and space.cancel_ground_move(world,actor_id)

''';assert mark in s;p.write_bytes(s.replace(mark,helper+mark).encode())
run=(root/'derived-public-point-20261112/run_case.py').read_text().replace("'game/building/room_use.gd'","'game/life/waiting_life.gd'").replace('run_derived_public_point.gd','run_fallback_safe_arrival.gd');(b/'run_case.py').write_text(run)
