from pathlib import Path
import sys,traceback
B=Path(__file__).resolve().parent;root=B.parent;R=root/'oddly-good-hospital-cloud-recovery-20261112';sys.path.insert(0,str(root/'movement-stage-recovery-20261112'));import full_narrow_v1 as h
c=h.c;g=h.g;cfg=c.read(root/'root-stage-recovery-20261112/config.json');c.verify(cfg);c.idle();g.PROJECT=R;g.LIBRARY_PATH=cfg['library_path'];mode,runid=sys.argv[1:];out=B/runid;out.mkdir(exist_ok=False)
c.write(out/'identity.json',{'runtime':cfg,'mode':mode,'source':c.sha(R/'game/life/waiting_life.gd'),'test':c.sha(R/'tests/acceptance/run_fallback_safe_arrival.gd')})
cmd=[cfg['engine'],'--headless','--path',str(R),'--script','res://tests/acceptance/run_fallback_safe_arrival.gd']
if mode=='parse':cmd+=['--check-only']
else:cmd+=['--',mode,str(out/'result.json'),str(root/'floor-wait-order-candidate-20261112/plan.json')]
c.write(out/'host-before.json',h.host())
try:g.run(cmd,out/'engine',timeout=240,allowed_exits=(0,1))
except BaseException:c.write(out/'error.json',{'traceback':traceback.format_exc()});raise
finally:c.write(out/'host-after.json',h.host())
print(mode,c.read(out/'engine/process.json')['returncode'])
