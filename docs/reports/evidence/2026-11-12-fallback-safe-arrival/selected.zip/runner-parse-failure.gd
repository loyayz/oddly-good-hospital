extends "res://tests/acceptance/run_floor_wait_order.gd"

class SafetyFlow extends CurrentBoundary:
	func run(directory: String) -> Dictionary:
		var rows: Array=[]
		for foreign: bool in [false,true]:
			var x: Dictionary=_areas()
			_facility(x,"toilet","FUR07",[39,68],"west")
			var visit: Dictionary=_visit(x,"safe_waypoint",[37,78])
			var actor: Dictionary=x.world.facts.actors[visit.actor_id]
			var blocker: Dictionary=actor.duplicate(true)
			blocker.id="waypoint_blocker";blocker.name="waypoint_blocker";blocker.location.cell=[42,90]
			x.world.facts.actors[blocker.id]=blocker;x.space.sync_actor(x.world,blocker.id);x.world.touch(false)
			x.l._begin_need(x.world,visit)
			var need: Dictionary=x.world.facts.waiting_life.needs[visit.id]
			var start: int=need.started_tick
			var ticket_id: String=visit.ticket_id
			var ticket_before: Dictionary=x.world.facts.tickets[ticket_id].duplicate(true)
			var anger: float=visit.anger
			x.world.facts.sim_tick=start+451
			x.l._dispatch_need(x.world,visit,need)
			var pending: bool=need.phase=="fallback_travel" and need.remaining_ticks==0
			var reason: String=x.l._request_need_move(x.world,need,actor.id,1,[42,90])
			if foreign:x.world.facts.moves[actor.id].waiting_need_id="another_task"
			var initial: String=x.world.validate(_content)
			var f:=FileAccess.open(directory+("/foreign" if foreign else "/owned")+"-preWorld.bin",FileAccess.WRITE)
			f.store_var(x.world.freeze(),false);f.close()
			var steps: int=0
			var zero_before: bool=true
			var restored: bool=false
			var reached: bool=false
			var shared_rejected: bool=false
			var owner_result: bool=false
			var saved_need_id: String=need.id
			for i: int in 100:
				x.world.facts.sim_tick+=1
				var safe: bool=x.space.public_areas.safe_wait(x.world,actor.id,1,actor.location.cell)
				if safe:
					reached=steps>0 and actor.location.cell!=[42,90] and x.space.public_areas.current_area(x.world,actor.id).is_empty()
					var frozen: Dictionary=x.world.freeze()
					shared_rejected=not x.space.public_areas.try_finish_arrival(x.world,actor.id,{},"waiting_need_id",need.id) and x.world.freeze()==frozen
					x.l._dispatch_need(x.world,visit,need)
					owner_result=(need.phase=="fallback_travel" and need.remaining_ticks==0 and x.world.freeze()==frozen) if foreign else (need.phase=="fallback" and need.remaining_ticks==80 and not x.world.facts.moves.has(actor.id))
					break
				x.l._dispatch_need(x.world,visit,need)
				zero_before=zero_before and need.phase=="fallback_travel" and need.remaining_ticks==0 and visit.anger==anger and need.started_tick==start
				x.space.advance(x.world);x.world.touch(false);steps+=1
				if steps==5:
					var snapshot: Dictionary=x.world.freeze()
					var save:=FileAccess.open(directory+("/foreign" if foreign else "/owned")+"-inflight.bin",FileAccess.WRITE);save.store_var(snapshot,false);save.close()
					x=_restore(x);visit=x.world.facts.visits[visit.id];need=x.world.facts.waiting_life.needs[visit.id];actor=x.world.facts.actors[visit.actor_id]
					restored=x.world.freeze()==snapshot and need.started_tick==start and need.id==saved_need_id
			var at_arrival: Array=actor.location.cell.duplicate()
			var eighty: bool=foreign
			if not foreign and owner_result:
				_tick_waiting(x,79)
				var before_last: bool=need.phase=="fallback" and need.remaining_ticks==1 and visit.anger==anger
				_tick_waiting(x)
				eighty=before_last and need.phase=="returning" and is_equal_approx(float(visit.anger),anger+float(_content.balance.amenity_flow.fallback_anger))
			var checks: Dictionary={"legal_preWorld":initial.is_empty(),"real_pending_owned_request":pending and reason.is_empty(),"no_early_work":zero_before,"safe_midway_without_area":reached,"shared_area_contract_unchanged":shared_rejected,"owner_correct":owner_result,"restored_exactly":restored,"real_80_ticks":eighty,"original_need_clock_ticket":need.started_tick==start and need.id==saved_need_id and visit.ticket_id==ticket_id and x.world.facts.tickets[ticket_id]==ticket_before,"valid_final":x.world.validate(_content).is_empty()}
			rows.append({"foreign":foreign,"ok":checks.values().all(func(v:Variant)->bool:return v==true),"checks":checks,"steps":steps,"arrival":at_arrival,"phase":need.phase,"remaining_ticks":need.remaining_ticks,"validation":initial})
			x.a.dispose()
		return {"ok":rows.all(func(row:Dictionary)->bool:return row.ok),"rows":rows}

func _run() -> void:
	var args:=OS.get_cmdline_user_args();content=HospitalContent.new()
	var mode: String=args[0];var rows: Array=[]
	if mode=="flow":
		var flow:=SafetyFlow.new();flow._content=content
		var result: Dictionary=flow.run(args[1].get_base_dir());rows=result.rows;_expect(result.ok,"safe-midway")
	elif mode=="staff74":
		var phase:=CountPhase.new();phase._content=content;phase._case_74(self);rows=checks
	else:errors.append("unknown mode")
	var out:=FileAccess.open(args[1],FileAccess.WRITE);out.store_string(JSON.stringify({"ok":errors.is_empty(),"rows":rows,"errors":errors},"\t"));out.close()
	quit(0 if errors.is_empty() else 1)
