import hashlib,json,pathlib,re,subprocess,zipfile
repo=pathlib.Path(r'C:\code\loyayz\oddly-good-hospital')
root=repo/'docs/reports/evidence/2026-10-21-navigation-batch-costs'
read=lambda path:json.loads(path.read_text(encoding='utf-8-sig'))
check=read(root/'source-check.json');rows=check['final_files']+check['final_test_files']
raw=subprocess.check_output(['git','cat-file','--batch'],input=''.join(':'+r['path']+'\n' for r in rows).encode(),cwd=repo)
cursor=0;exceptions=[]
for row in rows:
 end=raw.index(b'\n',cursor);size=int(raw[cursor:end].split()[-1]);cursor=end+1
 blob=raw[cursor:cursor+size];cursor+=size+1
 if hashlib.sha256(blob).hexdigest()!=row['sha256']:
  assert row['path']=='tests/acceptance/zip_library_boundaries.gd',row['path']
  assert blob.replace(b'\r\n',b'\n')==(repo/row['path']).read_bytes().replace(b'\r\n',b'\n')
  assert not subprocess.check_output(['git','diff','HEAD','--',row['path']],cwd=repo)
  exceptions.append(row['path'])
report=repo/'docs/reports/2026-10-21-navigation-batch-costs.md'
links=re.findall(r'\]\((evidence/[^)]+)\)',report.read_text(encoding='utf8'))
assert len(links)==6 and all((report.parent/link).is_file() for link in links)
manifest=read(root/'raw-manifest.json');archive=root/manifest['archive']
assert hashlib.sha256(archive.read_bytes()).hexdigest()==manifest['sha256']
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(manifest['entries'])
 for row in manifest['entries']:assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256']
functional=read(root/'functional-summary.json');batches=functional['batches']
assert [(x['result']['checks'],x['result']['failed']) for x in batches]==[(18,3),(3,1),(1,0)]
passed={k for batch in batches for k,v in batch['result']['results'].items() if v['passed']}
assert len(passed)==18
assert all(not b['execution']['script_errors'] for b in batches)
staged=subprocess.check_output(['git','diff','--cached','--name-only'],cwd=repo,text=True).splitlines()
assert len(staged)==24 and not any(p.endswith('.dll') for p in staged)
print(json.dumps(dict(staged_files=len(staged),verified_game_and_test_files=len(rows),unchanged_crlf_exceptions=exceptions,raw_entries=len(manifest['entries']),final_affected_cases=len(passed),formal_acceptance_paused=True)))
