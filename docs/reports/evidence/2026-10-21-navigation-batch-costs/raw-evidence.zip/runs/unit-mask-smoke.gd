extends SceneTree

func _initialize() -> void:
	var door: Dictionary = {"cell":[40,70],"span":1,"axis":"x","room_id":"smoke_room"}
	var source: Dictionary = {"layout":{"plots":[[1,2]],"blocked":[],"doors":[door]},"rooms":{"smoke_room":{"origin":[40,70],"size":[4,4]}},"facilities":{},"connectors":{},"height":3.2}
	var quoted: Dictionary = {"original":Rect2(40,70,1,1),"opening":Rect2(40,70,1,1),"ok":true,"reason":"","room_id":"smoke_room","axis":"x"}
	var result: Dictionary = PlatformArrivalMath.unit_static_masks({"source":source,"doors":[quoted],"height_ok":true})
	var ready: bool = result.get("ready",false)
	var valid: bool = ready and result.present.size()==9216 and result.enabled.size()==9216 and result.edges.size()==9216 and result.ids.size()==1024 and result.enabled[70*96+40]==1 and (int(result.edges[69*96+40])&8)!=0
	print("UNIT_MASK_RECT2_SMOKE="+JSON.stringify({"ok":valid,"ready":ready,"complete_masks":result.get("present",PackedByteArray()).size(),"actual_door_rect_conversion":true}))
	quit(0 if valid else 1)
