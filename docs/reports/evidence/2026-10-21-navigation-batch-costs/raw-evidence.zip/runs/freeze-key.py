import hashlib,json,pathlib,shutil,uuid
repo=pathlib.Path(r'C:\code\loyayz\oddly-good-hospital')
root=pathlib.Path(__file__).resolve().parent
source=root/'before-project';target=root/'key-project'
assert not target.exists()
shutil.copytree(source,target)
identity=json.loads((source/'source-identity.json').read_text(encoding='utf-8-sig'))
changes=['game/building/hospital_navigation.gd','game/building/navigation_cache.gd']
for relative in changes:
 shutil.copyfile(repo/relative,target/relative)
 for row in identity['source']:
  if row['path']==relative:row['sha256']=hashlib.sha256((target/relative).read_bytes()).hexdigest()
profile='OddlyGoodHospital KeyIntermediate '+uuid.uuid4().hex
project=(target/'project.godot').read_text(encoding='utf-8-sig')
project=project.replace(identity['profile'],profile)
(target/'project.godot').write_text(project,encoding='utf8')
identity.update(project=str(target),profile=profile,working_changes=changes,derived_from=str(source),diagnostic_only=True)
(target/'source-identity.json').write_text(json.dumps(identity,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps(dict(project=str(target),changes=changes)))
