import hashlib,json,pathlib,statistics,subprocess,zipfile
REPO=pathlib.Path(r'C:\code\loyayz\oddly-good-hospital')
ROOT=pathlib.Path(__file__).resolve().parent
OUT=REPO/'docs/reports/evidence/2026-10-21-navigation-batch-costs'
BASE='899df400cbc056c9ab54f0f2d1ba8aa517a3e31c'
OUT.mkdir(parents=True,exist_ok=True)
def read(p):return json.loads(pathlib.Path(p).read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def dump(name,value):(OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def measured(name):
 d=read(ROOT/(name+'.json'))
 assert d['complete'] and d['qualified'] and not d['errors'],name
 assert all(d['qualification'].values()) and all(d.get('public_checks',{}).values())
 assert all(s['complete'] and s['present']==160 for s in d['samples'])
 return dict(run=name,metrics=d['metrics'],execution=d['execution'],launch=read(ROOT/(name+'.launch.json')),qualification=d['qualification'],final_hash=d['final_binary_sha256'],input_sha256=d['source_input_sha256'],work=d['final']['work_ticks_by_kind'],query_counts=d['public']['query_counts'],public_work={k:d['public'][k] for k in ['actual_use_ticks','queue_actor_ticks','actual_exit_then_reuse_count']},starts=len(d['public']['actual_use_starts']),completions=len(d['public']['actual_use_completions']),operations=d['operations'])
windows=[]
for window in ['public360','gp80','operations40']:
 rows=[measured(x+'-'+window) for x in ['a','b','c','d']]
 middle=measured('key-'+window)
 assert len({r['final_hash'] for r in rows+[middle]})==1
 assert len({r['input_sha256'] for r in rows+[middle]})==1
 assert all(all(r[k]==rows[0][k] for k in ['work','public_work','starts','completions','operations']) for r in rows+[middle])
 before=statistics.mean(rows[i]['metrics']['mean_us'] for i in [0,3]);after=statistics.mean(rows[i]['metrics']['mean_us'] for i in [1,2])
 windows.append(dict(window=window,runs=rows,key_only_intermediate=middle,whole_world_equal=True,before_mean_us=before,after_mean_us=after,mean_reduction_percent=(1-after/before)*100))
dump('quick-summary.json',dict(baseline=BASE,formal_pass=False,formal_acceptance_paused=True,windows=windows,caution='Plain A/B/B/A independent windows. Same 160 actors and complete work, default affinity and priority. Key-only intermediate retained even where no benefit/regression. Each window percentile remains separate; not pooled formal acceptance.'))
profiles=[]
for side in ['before','after']:
 for window in ['public360','gp80','operations40']:
  name=side+'-all-'+window;d=read(ROOT/(name+'.json'));p=d['profile']
  assert d['complete'] and d['qualified'] and not d['errors'] and not p['errors']
  assert d['final_binary_sha256']==read(ROOT/('a-'+window+'.json'))['final_binary_sha256']
  indices={s['tick']:s['index'] for s in d['samples']}
  steps=[dict(index=indices[s['tick']],tick=s['tick'],outer_us=s['outer_elapsed_us'],observer_us=s['observer_handler_us'],stages=s['stages'],calls=s['calls']) for s in p['step_records'] if s['calls']]
  profiles.append(dict(run=name,hash=d['final_binary_sha256'],errors=p['errors'],steps=steps,query_counts=d['public']['query_counts']))
dump('function-summary.json',dict(profiles=profiles,caution='All-instance wrappers preserve original bodies and perturb timings. Inclusive values contain child values; do not sum overlapping calls. Whole-step changes use plain windows.'))
batches=[]
for line in (ROOT/'batches.txt').read_text(encoding='utf8').splitlines():
 if not line.strip():continue
 directory=REPO/'.cache/acceptance'/line.strip()
 batches.append(dict(batch=line.strip(),result=read(directory/'acceptance-results.json'),timing=read(directory/'timing-summary.json'),execution=read(directory/'execution-status.json')))
assert batches
assert batches[-1]['result']['completed'] and batches[-1]['result']['failed']==0
assert batches[-1]['execution']['test_exit']==0 and not batches[-1]['execution']['script_errors']
dump('functional-summary.json',dict(batches=batches,formal_pass=False,caution='Only explicitly selected affected cases were executed. Initial failures and affected reruns remain in order. Functional passing is not formal performance acceptance.'))
before=read(ROOT/'before-project/source-identity.json');after=read(ROOT/'after-project/source-identity.json')
prefixes=('game/','content/','tools/performance/')
rows=[r for r in before['source'] if r['path'].startswith(prefixes)]
raw=subprocess.run(['git','cat-file','--batch'],input=''.join(BASE+':'+r['path']+'\n' for r in rows).encode(),cwd=REPO,check=True,stdout=subprocess.PIPE).stdout
cursor=0
for r in rows:
 end=raw.index(b'\n',cursor);size=int(raw[cursor:end].split()[-1]);cursor=end+1;blob=raw[cursor:cursor+size];cursor+=size+1
 assert hashlib.sha256(blob).hexdigest()==r['sha256'],r['path']
 assert sha(ROOT/'before-project'/r['path'])==r['sha256'],r['path']
current=[dict(**r,match=sha(REPO/r['path'])==r['sha256'] and sha(ROOT/'after-project'/r['path'])==r['sha256']) for r in after['source'] if r['path'].startswith(prefixes)]
assert all(r['match'] for r in current)
binary={k:before[k]==after[k] for k in ['engine_sha256','native_sha256','gmp_sha256','mpfr_sha256','runtime_sha256']}
assert all(v for k,v in binary.items() if k!='native_sha256') and not binary['native_sha256']
assert sha(REPO/'game/platform/windows/bin/oddly_good_platform.windows.x86_64.dll').upper()==after['native_sha256'].upper()
transforms=[]
for side in ['before','after']:
 directory=ROOT/(side+'-all-project');identity=read(directory/'all-instance-profile-identity.json')
 for r in identity['files']:
  assert sha(ROOT/(side+'-project')/r['path'])==r['original_sha256']
  assert sha(directory/'.cache/tail-profile-originals'/r['path'])==r['original_sha256']
  assert sha(directory/r['path'])==r['generated_sha256']
 transforms.append(dict(side=side,files=identity['transformed_file_count'],methods=identity['actual_method_count'],all_originals_match=True))
test_identity=read(REPO/'.cache/acceptance'/batches[-1]['batch']/'source-identity.json')
test_rows=[r for r in test_identity['source'] if r['path'].startswith('tests/acceptance/')]
assert all(sha(REPO/r['path'])==r['sha256'] for r in test_rows)
assert all(sha(REPO/r['path'])==r['sha256'] for r in test_identity['source'] if r['path'].startswith(('game/','content/')))
test_binary={k:after[k]==test_identity[k] for k in binary};assert all(test_binary.values())
engines={measured(x+'-'+w)['launch']['engine_executable_sha256'] for x in ['a','b','c','d','key'] for w in ['public360','gp80','operations40']};assert len(engines)==1
dump('source-check.json',dict(baseline=BASE,baseline_files=rows,final_files=current,binary_equal=binary,before_native=before['native_sha256'],after_native=after['native_sha256'],actual_engine_sha256=next(iter(engines)),test_binary_equal=test_binary,transform_originals=transforms,final_test_files=test_rows,test_game_matches=True))
files=[]
for p in ROOT.iterdir():
 if p.is_file() and p.suffix in ['.json','.bin','.ndjson','.log','.py','.ps1','.txt','.gd']:files.append(p)
for side in ['before','after','key']:
 directory=ROOT/(side+'-project')
 files.append(directory/'source-identity.json')
 files.extend(directory.glob('*.log'))
 if side=='key':continue
 directory=ROOT/(side+'-all-project');files.append(directory/'all-instance-profile-identity.json');files.extend(directory.glob('*.log'))
 for r in read(directory/'all-instance-profile-identity.json')['files']:files.extend([directory/r['path'],directory/'.cache/tail-profile-originals'/r['path']])
failed=ROOT/'failed-native-project'
files.append(failed/'source-identity.json')
files.extend(failed.glob('*.log'))
for name in ['game/platform/windows/platform_arrivals.cpp','game/platform/windows/platform_unit_static_masks.h','game/building/route_clearance.gd','game/building/floor_navigation.gd']:
 files.append(failed/name)
manifest=[];archive=OUT/'raw-evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 def add(p,name):
  z.write(p,name);manifest.append(dict(path=name,sha256=sha(p),bytes=p.stat().st_size))
 for p in sorted(set(files)):add(p,'runs/'+p.relative_to(ROOT).as_posix())
 for name in ['public-v6.input.bin','gp.input.bin','op.input.bin']:add(REPO/'.cache/task-navigation-20261019'/name,'inputs/'+name)
 for b in batches:
  directory=REPO/'.cache/acceptance'/b['batch']
  for name in ['acceptance-results.json','execution.log','execution-status.json','source-identity.json','timing-summary.json','import.log']:
   if (directory/name).exists():add(directory/name,'acceptance/'+b['batch']+'/'+name)
  for name in ['navigation_key_scope.gd','navigation_unit_static_masks.gd','public_wait_environment_matches.gd','public_waiting_cost_field.gd']:
   add(directory/'tests/acceptance'/name,'acceptance/'+b['batch']+'/executed-tests/'+name)
 changed=subprocess.run(['git','diff','--name-only','HEAD'],cwd=REPO,check=True,stdout=subprocess.PIPE).stdout.decode().splitlines()
 changed+=subprocess.run(['git','ls-files','--others','--exclude-standard'],cwd=REPO,check=True,stdout=subprocess.PIPE).stdout.decode().splitlines()
 for name in sorted(set(changed)):
  if name.startswith(('game/','tests/acceptance/','tools/build-')):add(REPO/name,'final-source/'+name)
 add(REPO/'.cache/platform-guard/abi/platform_guard_abi.h','build/platform_guard_abi.h')
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(manifest)
 for r in manifest:assert hashlib.sha256(z.read(r['path'])).hexdigest()==r['sha256']
dump('raw-manifest.json',dict(archive=archive.name,sha256=sha(archive),bytes=archive.stat().st_size,entries=manifest))
print(json.dumps(dict(archive_entries=len(manifest),archive_bytes=archive.stat().st_size,baseline_files=len(rows),final_files=len(current),test_files=len(test_rows))))
for w in windows:print(w['window'],w['before_mean_us'],w['after_mean_us'],w['mean_reduction_percent'])
