# Cloud worker288 / cleaner0028 departure boundary

Exactly six production0.1s steps, tick7642→7648, from complete input fb4dce11b37978f555437a1abe896d5475efb21431aa38b74ed0f188a13af9a8. No horizon extension, gameplay edits, tests or broad replay. Original requests/jobs/local ownership are not changed by observer code.

Plain and observer final binaries (complete World/RNG/ordered events) match exactly:477372219729a259f451b0db95968ff098a3d6c924ac8ca125b855f2b21b6306. This is cloud-vs-cloud qualification, not Windows equivalence.

Actual MotionResults:
-7642: cleaner0028 moves east0.199997;288 attempts south0.200001 but is body-blocked by0028.
-7643 and7644:0028 continues east;288's southward attempts succeed0.200001 each.288 actually reaches[86,44.4000015258789]. This proves that the previous moving blocker clears and288 resumes.
-7645:0028 completes east leg at[87,44.5999984741211];288 is now actually body-blocked by nurse0025.
-7646–7647:0028 turns north and moves, ending[87,44.1999969482422];288's southward attempts remain actually body-blocked by0025. No static, reservation or door blocker in these MotionResults.
-All six actual patient0111 alight attempts remain current-body blocked by288. No alight commit; patient remains on trip147. Neither288 nor226 arrival is claimed.

288 retains request4024/job287, current cursor0 and local target[86,46], corner[87,46], rejoin[87,44], original4F[75,6] goal. Cleaner0028 retains request7081 and4F[46,82] goal. New blocker0025 is a nurse with request7553, original2F[30.5,58.7333335876465] goal; final position[85.6000061035156,44.9999961853027], local target[85,44.9999961853027]. It moved5 of the6 steps and last moved west at7647. Existing actual body/sweep safety still decides contention; a new defect or starvation is not established.

Design01-simulation lines115–117 requires preservation of effective departures and original-route ownership while checking each actual step. The known0028 departure boundary is resolved positively. Next possible discriminating boundary is0025's actual departure/contact clearance, but no further run is performed or assumed authorized.

Runtime/guard identities, isolated per-run HOME/XDG/TMPDIR, pinned4.7.2 Linux engine/native, OMP1 and app policy with4 environmental tasks are recorded in execution-identity.json/process.json and inherited preparation evidence. Guard owns and reaps each process; no concurrent engines. Plain9.046s/observer8.637s wall including startup are diagnostic, not performance evidence.

All2047 inventoried source/runtime files restored and hash-verified after hooks. Checkout not instrumented; no Windows access, commit or push. Final continuation plain6/result.json.final.bin at7648; SHA above. Evidence archive excludes runtime/project/profile duplication and includes exact input/finals, traces, overlays, guard, identities and logs.
