from pathlib import Path
import sys
project=Path(__file__).parent/"project"
sys.path.insert(0,str(project/"tools/performance/current"))
import prepare_transport_trace as overlay
patches={
 'game/building/hospital_transit.gd':overlay.transit_patch(project/'game/building/hospital_transit.gd'),
 'game/building/hospital_movement.gd':overlay.movement_patch(project/'game/building/hospital_movement.gd'),
}
p=patches['game/building/hospital_transit.gd']
marker='\tvar at_entry: bool=_at_landing(space,world,connection,movement,segment)\n'
p.replace(marker,marker+'\tif actor.id in ["maintenance_contractor_00000288","bench_staff_0028"]: _TransportDiagnostic._record(world,"worker_begin",{"actor":_TransportDiagnostic._actor(world,actor.id),"at_entry":at_entry,"connection":_TransportDiagnostic._connection(connection)})\n')
marker='\tif not at_entry and not _landing_in_use(connection,int(segment.from)):\n\t\tspace.movement._queue_route(world,movement,true)\n'
p.replace(marker,'\tif not at_entry and not _landing_in_use(connection,int(segment.from)):\n\t\tif actor.id in ["maintenance_contractor_00000288","bench_staff_0028"]: _TransportDiagnostic._record(world,"worker_queue_landing_recovery",{"actor":_TransportDiagnostic._actor(world,actor.id)})\n\t\tspace.movement._queue_route(world,movement,true)\n')

p=patches['game/building/hospital_movement.gd']
for name,args,kind in [('_local_resume','world,actor,movement','bool'),('_local_collision','world,actor,movement,contact','void'),('_local_try_return','world,actor,movement,advance,blocked_motion','bool'),('_local_choose_options','world,actor,movement,motion,fixed','bool'),('_move_step','world,actor,movement,segment','MotionResult')]:
 before='\tvar _capture: bool=actor.id in ["maintenance_contractor_00000288","bench_staff_0028"]\n\tvar _before: Dictionary=_TransportDiagnostic._actor(world,actor.id) if _capture else {}\n'
 details='{"function":"'+name+'","before":_before,"after":_TransportDiagnostic._actor(world,actor.id)'
 if kind=='bool':details+=',"result":_trace_value'
 if name=='_local_try_return':details+=',"advance":advance,"blocked_motion":[blocked_motion.x,blocked_motion.y]'
 if name in ['_move_step','_local_collision']:
  value='_trace_value' if name=='_move_step' else 'contact'
  details+=',"requested":['+value+'.requested_motion.x,'+value+'.requested_motion.y],"actual":['+value+'.actual_motion.x,'+value+'.actual_motion.y],"body_ids":'+value+'.blocker_actor_ids.duplicate(),"reservation_ids":'+value+'.reservation_ids.duplicate(),"static_reason":'+value+'.static_reason,"door_id":'+value+'.door_id'
 if name in ['_move_step','_local_collision']:
  details+=',"blocker_owners":'+value+'.blocker_actor_ids.map(func(id: String)->Dictionary:return _TransportDiagnostic._actor(world,id))'
 details+='}'
 after='\tif _capture: _TransportDiagnostic._record(world,"worker_pair_actual_call",'+details+')\n'
 p.wrap(name,args,before,after,kind)
p=overlay.Patch(project/'game/building/hospital_space.gd')
p.replace('class_name HospitalSpace\nextends RefCounted\n','class_name HospitalSpace\nextends RefCounted\n'+overlay.PREFIX)
import re
match=re.search(r'^func _dynamic_clear\([^\n]*\)[^\n]*:\n[\s\S]*?(?=^func |\Z)',p.text,re.M);body=match[0];new=body
for oldline,newline in [
 ('\t\tif rect.intersects(region.rect,false):\n\t\t\treturn false','\t\tif rect.intersects(region.rect,false):\n\t\t\tif actor_id=="bench_patient_0111": _TransportDiagnostic._record(world,"actual_dynamic_reject",{"branch":"reservation","reservation_id":region.reservation_id})\n\t\t\treturn false'),
 ('\t\tif _actor_index.intersects(floor_id,rect,actor_id,ignored):\n\t\t\treturn false','\t\tif _actor_index.intersects(floor_id,rect,actor_id,ignored):\n\t\t\tif actor_id=="bench_patient_0111": _TransportDiagnostic._record(world,"actual_dynamic_reject",{"branch":"current_body_index","rect":_TransportDiagnostic._raw_rect(rect)})\n\t\t\treturn false'),
 ('\tif movement._sweep_index.intersects(floor_id,rect,actor_id,members):\n\t\treturn false','\tif movement._sweep_index.intersects(floor_id,rect,actor_id,members):\n\t\tif actor_id=="bench_patient_0111": _TransportDiagnostic._record(world,"actual_dynamic_reject",{"branch":"accepted_sweep"})\n\t\treturn false')]:
 assert new.count(oldline)==1
 new=new.replace(oldline,newline)
p.replace(body,new)
patches['game/building/hospital_space.gd']=p

p=overlay.Patch(project/'tools/performance/current/plain_v4.gd')
p.replace('extends SceneTree\n','extends SceneTree\n'+overlay.PREFIX)
p.replace('\tvar initial: Dictionary = snapshot(world)\n','\t_TransportDiagnostic.prepare(world,content)\n\tvar initial: Dictionary = snapshot(world)\n')
p.replace('\tvar attribution: Dictionary = profiler.report() if profile_stages else {}\n','\t_TransportDiagnostic.finish(output+".transport.json",world)\n\twrite_json(output+".maintenance.json",world.facts.maintenance)\n\twrite_json(output+".moves.json",world.facts.moves)\n\tvar attribution: Dictionary = profiler.report() if profile_stages else {}\n')
patches['tools/performance/current/plain_v4.gd']=p
