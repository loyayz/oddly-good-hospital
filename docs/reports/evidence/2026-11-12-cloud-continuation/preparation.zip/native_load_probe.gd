extends SceneTree

func _initialize() -> void:
	var extension_path := "res://game/platform/windows/oddly_good_platform.gdextension"
	var status := GDExtensionManager.load_extension(extension_path)
	var classes := {}
	var ok := status == GDExtensionManager.LOAD_STATUS_OK or status == GDExtensionManager.LOAD_STATUS_ALREADY_LOADED
	for class_name_to_check in ["PlatformSessionGuard", "PlatformThreadPolicy", "PlatformJsonNumbers", "PlatformArrivalMath"]:
		var present := ClassDB.class_exists(class_name_to_check)
		classes[class_name_to_check] = present
		ok = ok and present
	print(JSON.stringify({"ok": ok, "extension_load_status": status, "classes": classes, "engine": Engine.get_version_info()}))
	quit(0 if ok else 1)
