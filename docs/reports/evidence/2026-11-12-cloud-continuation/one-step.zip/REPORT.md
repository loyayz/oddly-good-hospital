# Cloud worker288 one-step boundary

Read-only production diagnosis on e232c42389e614cf13d305c4376d59892c4aa0c3. No business source edits, tests, full replay, or Windows execution.

Input tick7641: input59570f.bin, SHA59570f0a9f59bfb5bdf5f5f88531a461c226cef43268ae130cbea581e718d1ba. Exactly one full production0.1s step per fresh plain/observer process, app main-thread policy,4 environmental tasks,OMP_NUM_THREADS1. Complete final binary World/RNG/ordered events equal, tick7642 SHAfb4dce11b37978f555437a1abe896d5475efb21431aa38b74ed0f188a13af9a8. This qualifies cloud observer against cloud plain, not platform equality against Windows.

Actual branches at7641:
- Patient0111 alight attempt rejects in current_body_index, independently identified actual body288.
- Worker288 _local_resume returns true with target[86,46], corner[87,46], rejoin[87,44] and cursor0 retained.
- Its actual _move_step requests[0,0.200000762939453], produces[0,0], identifies bench_staff_0028. Static reason and door empty, reservation IDs empty.
- That cleaner already actually moved east this step from[86,44.5999984741211] to[86.1999969482422,44.5999984741211], toward local target[87,44.5999984741211]; request7081 and original4F[46,82] goal retained.
- _local_collision leaves288 local connector/corners, original request4024, job287 and4F[75,6] goal unchanged. No _local_try_return or _local_choose_options calls for288 observed in this step. The exact internal early-return line inside collision was not instrumented and is not claimed.

Conclusion: current real contention with a moving blocker, not the prior zero-vector/completed-original-point defect. No new requirement violation or starvation established. Design01-simulation lines115–117 preserve effective departing local motion, require real body/sweep checks and original-route arrival, and prohibit priority/teleport shortcuts. Source hospital_movement.gd1361–1388 and1243 onward distinguishes local continuation and collision courtesy. There is no justification to modify these rules from this one-step evidence.

Smallest next discriminating boundary, if separately authorized: observe whether staff0028's effective eastward departure clears288's next actual step, then whether patient0111 can alight. Stop on that clearance/contact transition; do not infer a deadlock or stack blind windows. No further run performed.

Runtime: official4.7.2 Linux engine SHA8d106cbe6144c2dc7e881d61d2429c1a8a76e6b22ef48bd5e48dcf934953f71e; native SHA3e97c961acf01e178046efc14b5dff786a83b4e91f09638528ccf531b248d379; pinned MPFR library path recorded in process.json. Imported assets/cache copied from qualified preparation. Generated uid sidecars separately inventoried. HOME/XDG/TMPDIR isolated per run. Guard proof is a harmless Python sleep timeout/reap, not gameplay. Plain9.230s/observer9.001s wall including startup, not performance measurements.

All2047 inventoried source/runtime files restored and verified after instrumentation. Final continuation: plain1/result.json.final.bin. No commits/push. Checkout untouched by this investigation.
