import argparse
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tools/performance/current'))
from prepare_builtin_script_profile import run_process

read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
parser = argparse.ArgumentParser()
parser.add_argument('--project', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--check-only', action='store_true')
args = parser.parse_args()
project, output = args.project.resolve(), args.output.resolve()
assert project.is_relative_to(ROOT / '.cache/acceptance')
assert output.is_relative_to(ROOT / '.cache') and not output.exists()
metadata = read(project / 'source-identity.json')
source = {r['path']: r['sha256'] for r in metadata['source']}
original_configuration = (ROOT / 'project.godot').read_bytes()
assert hashlib.sha256(original_configuration).hexdigest() == source['project.godot']
profile_anchor = 'config/custom_user_dir_name="oddly-good-hospital"'
configuration = original_configuration.decode('utf-8-sig')
assert configuration.count(profile_anchor) == 1
expected_configuration = configuration.replace(profile_anchor, 'config/custom_user_dir_name="' + metadata['profile'] + '"', 1).encode('utf-8') + b'\r\n'
assert (project / 'project.godot').read_bytes() == expected_configuration, 'Only the standard acceptance profile rewrite is allowed'
profile_transform = {'before_sha256': source['project.godot'], 'after_sha256': sha(project / 'project.godot'), 'profile': metadata['profile'], 'basis': 'tests/run-acceptance.ps1 profile replacement plus Set-Content CRLF'}
source['project.godot'] = profile_transform['after_sha256']
assert all(sha(project / path) == value for path, value in source.items())
assert metadata['native_sha256'].lower() == sha(project / 'game/platform/windows/bin/oddly_good_platform.windows.x86_64.dll') == '89d4e1db54ca8a52ee2ed7da5b5fdcc1917c0667d172ab89d2fe683bc1767af2'
native = read(ROOT / '.cache/resident-mask-final-identity.json')['native']
assert all(sha(project / 'game/platform/windows/bin' / name) == value for name, value in native.items())
engine = metadata['engine']
assert sha(Path(engine)) == metadata['engine_sha256'].lower()
v3 = ROOT / '.cache/performance160-clinical-family-20261112-v3-candidate02/qualification-r1/r1.json.final.bin'
mixed = ROOT / '.cache/performance160-clinical-family-20261112-mixed-candidate01/qualification-r1/r1.json.final.bin'
samples = [
    ('v3-body', 'individual_body_probe.gd', v3, '0afa344f973e4ce8b12ce46a034f3dc754f43e42e446938e94f4ed47163aaf74', 1000),
    ('mixed-body', 'individual_body_probe.gd', mixed, '0daf82b82da618af8818aed962d5ef2bf9bad1b00be01c4f5a7ce71efb52662e', 1000),
    ('mixed-navigation', 'navigation_source_probe.gd', mixed, '0daf82b82da618af8818aed962d5ef2bf9bad1b00be01c4f5a7ce71efb52662e', 10000),
]
assert all(sha(input_path) == digest for _, _, input_path, digest, _ in samples)
if args.check_only:
    print(json.dumps({'preflight': True, 'engine_started': False, 'source_files': len(source), 'exact_profile_transform': profile_transform, 'native': native}))
    sys.exit(0)
output.mkdir()
records = []
for name, script, input_path, digest, iterations in samples:
    folder = output / name
    result = folder / 'result.json'
    assert sha(input_path) == digest
    command = [engine, '--headless', '--path', str(project), '--script', 'res://tools/performance/current/' + script, '--', '--input=' + str(input_path), '--expected-sha=' + digest, '--output=' + str(result), '--iterations=' + str(iterations)]
    process = run_process(command, project, folder, 180)
    data = read(result)
    assert data['ok'] and not data['errors']
    assert sha(input_path) == digest
    records.append({'sample': name, 'process': process, 'result': str(result), 'result_sha256': sha(result)})
assert all(sha(project / path) == value for path, value in source.items())
(output / 'summary.json').write_text(json.dumps({'ok': True, 'project': str(project), 'source_identity_sha256': sha(project / 'source-identity.json'), 'project_profile_transform': profile_transform, 'records': records}, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({'ok': True, 'summary': str(output / 'summary.json')}))
