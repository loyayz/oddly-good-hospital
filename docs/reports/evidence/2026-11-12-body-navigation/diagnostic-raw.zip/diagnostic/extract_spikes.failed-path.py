"""One offline read of existing stage records; no engine or instrumentation."""
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[3]
FOLDER = Path(__file__).resolve().parent
PLAIN = ROOT / "performance160-clinical-family-20261112-mixed-candidate01/qualification-r1"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def load_steps(path):
    data = path.read_bytes()
    rows = [json.loads(line) for line in data.splitlines()]
    completed = {row["sample"]["index"]: row["sample"] for row in rows if row["kind"] == "complete"}
    assert len(completed) == 7000 and set(completed) == set(range(7000))
    return completed, {"path": str(path), "bytes": len(data), "sha256": sha(data)}


def main():
    stage_path = FOLDER / "scripts/result.json.stages.json"
    raw = stage_path.read_bytes()
    stage_identity = {"path": str(stage_path), "bytes": len(raw), "sha256": sha(raw)}
    report = json.loads(raw)
    del raw
    records = report["step_records"]
    assert len(records) == 6000 and report["complete_steps"] == 6000 and not report["errors"]
    measured, measured_identity = load_steps(FOLDER / "scripts/result.json.steps.ndjson")
    plain, plain_identity = load_steps(PLAIN / "r1.json.steps.ndjson")
    top = sorted(range(6000), key=lambda index: (-records[index]["outer_elapsed_us"], index))[:5]
    selected = list(dict.fromkeys([0] + top))
    result = []
    for position in selected:
        row = records[position]
        index = position + 1000
        driver, comparison = measured[index], plain[index]
        assert row["tick"] == driver["tick"] == comparison["tick"] == 633 + index + 1
        assert row["outer_elapsed_us"] == driver["elapsed_us"] and row["complete"]
        phases = {name: entry["total_us"] for name, entry in row["stages"].items()}
        assert sum(phases.values()) == row["root_stage_us"]
        partition = row["outer_elapsed_us"] - row["root_stage_us"] - row["observer_handler_us"] - row["residual_us"]
        assert partition == 0
        top_roots = sorted(phases.items(), key=lambda pair: (-pair[1], pair[0]))[:8]
        iteration_us = measured[index + 1]["wall_start_us"] - driver["wall_start_us"] if index < 6999 else None
        plain_iteration_us = plain[index + 1]["wall_start_us"] - comparison["wall_start_us"] if index < 6999 else None
        result.append({"index": index, "tick": row["tick"], "sample_position": position,
                       "max_rank": top.index(position) + 1 if position in top else None,
                       "step_us": row["outer_elapsed_us"], "iteration_us": iteration_us,
                       "outside_step_us": iteration_us - row["outer_elapsed_us"] if iteration_us else None,
                       "plain_step_us": comparison["elapsed_us"], "plain_iteration_us": plain_iteration_us,
                       "root_us": row["root_stage_us"], "marker_handler_us": row["observer_handler_us"],
                       "residual_us": row["residual_us"], "partition_check_us": partition,
                       "nonblocking_invocations": row["nonblocking_invocations"], "root_marker_calls": row["root_marker_calls"],
                       "commands_drain_us": phases["commands.drain"], "movement_space_us": phases["movement.space"],
                       "top_roots_us": top_roots,
                       "other_roots_us": sum(phases.values()) - sum(value for _, value in top_roots)})
    identity_path = FOLDER.parent / "project/builtin-script-profile-identity.json"
    identity_bytes = identity_path.read_bytes()
    identity = json.loads(identity_bytes)
    source_paths = ["tools/performance/current/plain_v4.gd", "tools/performance/step_profile.gd",
                    "tools/performance/current/comprehensive_operations.gd", "game/sim/simulation.gd"]
    source = {path: sha((FOLDER.parent / "project" / path).read_bytes()) for path in source_paths}
    plain_result = json.loads((PLAIN / "r1.json").read_bytes())
    commands = plain_result["sample_business"]["comprehensive"]["sample"]["commands"]
    output = {"scope": "Existing B02 7b2a735 + 89d / mixed 75f5 builtin diagnostic only; no rerun, no causal inference from flat totals.",
              "unit": "microseconds", "baseline_commit": identity["base_commit"], "input_sha256": identity["input_sha256"],
              "world_events_sha256": "0daf82b82da618af8818aed962d5ef2bf9bad1b00be01c4f5a7ce71efb52662e",
              "record_schema": list(records[0]), "selected_steps": result,
              "sample_command_receipts": {name: value.get("kind") for name, value in commands.items()},
              "raw": {"stages": stage_identity, "diagnostic_steps": measured_identity, "plain_steps": plain_identity},
              "code_sha256": source, "extraction_sha256": sha(Path(__file__).read_bytes()),
              "identity_sha256": sha(identity_bytes),
              "limits": ["step_us is Simulation.step elapsed including internal waits. root + marker_handler + residual exactly partitions it.",
                         "iteration_us is the next original driver iteration start minus this start: it includes command enqueue/previews, capture, stage handlers, observe, copies, JSON/flush and loop work. It is not observer-only time.",
                         "First sample iteration additionally includes scripts-profiler activation and sample-boundary setup before sample_wall_start.",
                         "Top eight root phases are explicit; other_roots_us retains every remaining phase in the partition.",
                         "No root timer separately measures individual command, building suboperation or source/cache rebuild. Their individual duration and cold-cache attribution remain unknown.",
                         "Diagnostic timings are perturbed; matched plain values establish only the corresponding measured step/iteration, not an identical phase split."]}
    destination = FOLDER / "spikes.json"
    assert not destination.exists()
    destination.write_text(json.dumps(output, ensure_ascii=False, separators=(",", ":")) + "\n", encoding="utf-8")
    print(json.dumps({"output": str(destination), "bytes": destination.stat().st_size,
                      "sha256": sha(destination.read_bytes()), "selected_steps": result,
                      "command_receipts": output["sample_command_receipts"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
