from pathlib import Path
import sys,shutil,subprocess,json,math,hashlib
repo=Path(r'C:\Users\cong\dot-work\oddly-good-hospital-handoff-20261112'); old=Path(r'C:\Users\cong\dot-work\ogh-full-mixed-20261112');root=Path(r'C:\Users\cong\dot-work\ogh-recovery-full-20261112');root.mkdir(exist_ok=False);project=root/'project'
sys.path.insert(0,str(repo/'tools/performance/current'))
from prepare_builtin_script_profile import digest,read,write,run_process,native_identity,engine_identity
from campaign160 import target_checks
shutil.copytree(old/'project',project)
paths=subprocess.check_output(['git','-C',str(repo),'ls-files'],text=True).splitlines()
for x in ['tests/acceptance/transit_busy_recovery.gd','tests/acceptance/transit_busy_recovery.md']:paths.append(x)
for x in paths:
 (project/x).parent.mkdir(parents=True,exist_ok=True);shutil.copy2(repo/x,project/x)
assert digest(project/'game/building/hospital_transit.gd')=='2ead5adfdcd4be9c2530a0b3f6a20ba4bdf11b64616b4457a540a3b643489d73'
assert digest(project/'game/building/hospital_movement.gd')=='fd9d720d6c7688eff475bb15968c64a3e4fcdeb0a2acb8878c00619e1e556ca4'
input_path=root/'mixed160.input.bin';shutil.copy2(old/'mixed160.input.bin',input_path);assert digest(input_path)=='75f5e1d922f39f12382c0ceb74806bda0293251189f68a1ac158842f65fa78ca'
engine=Path(r'C:\programs\Godot\Godot_v4.7.2-stable_win64_console.exe')
identity={'source':{x:digest(project/x) for x in paths},'native':native_identity(project),'engine':engine_identity(engine),'input_sha256':digest(input_path),'git_base':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'working_tree_production_patch':subprocess.check_output(['git','-C',str(repo),'diff','--','game/building/hospital_transit.gd'],text=True,encoding='utf-8'),'reused_imports':str(old/'project/.godot')}
write(root/'identity-before.json',identity);write(project/'source-inventory.json',paths)
shutil.copy2(project/'game/building/hospital_transit.gd',root/'hospital_transit.gd')
out=root/'plain-r1';result=out/'result.json'
command=[str(engine),'--headless','--path',str(project),'--script','res://tools/performance/current/plain_v4.gd','--',f'--input={input_path}',f'--output={result}','--prefix-steps=1000','--steps=6000','--observed-floor=1','--main-thread-policy=app','--worker-tasks=4','--expected-scenario=mixed160-clinical-ops-v1','--require-coverage']
print('START POST-FIX FULL PLAIN',flush=True);process=run_process(command,project,out,2400,(0,1));print('END POST-FIX FULL PLAIN',flush=True)
d=read(result);c=d['sample_business']['comprehensive'];checks={}
checks['complete_window']=d['all_completed_steps']==7000 and d['metrics']['count']==6000 and d['initial']['tick']==633 and d['final']['tick']==7633
checks['source_unchanged']={x:digest(project/x) for x in paths}==identity['source']
checks['runtime_unchanged']=native_identity(project)==identity['native'] and engine_identity(engine)==identity['engine']
checks['input_unchanged']=digest(input_path)==identity['input_sha256']==d['source_input_sha256']
checks['final_sha_verified']=digest(Path(str(result)+'.final.bin'))==d['final_sha256']
rows=[json.loads(x) for x in Path(str(result)+'.steps.ndjson').read_text().splitlines()];a=[x['sample'] for x in rows if x['kind']=='complete'];b=[x for x in rows if x['kind']=='enter']
checks['ordered_step_records']=len(a)==len(b)==7000 and [x['index'] for x in a]==[x['index'] for x in b]==list(range(7000)) and [x['tick'] for x in a]==list(range(634,7634))
sorted_us=sorted(x['elapsed_us'] for x in a[1000:]);checks['percentiles_recomputed']=d['metrics']['p95_us']==sorted_us[5699] and d['metrics']['p99_us']==sorted_us[5939] and d['metrics']['max_us']==max(sorted_us)
e=read(Path(str(result)+'.execution.json'));checks['policy']=e['main_thread_policy']['applied'] and e['worker_tasks']==4 and not e['profile_stages'] and not e['worker_samples']['diagnostics_enabled']
checks['coverage_rows']=all(v['covered']==(v['actual']>=v['lower_bound']) for v in c['coverage'].values()) and set(c['uncovered'])=={k for k,v in c['coverage'].items() if not v['covered']}
assert all(checks.values()),checks
s={'integrity_checks':checks,'complete':d['complete'],'errors':d['errors'],'coverage_pass':c['coverage_pass'],'invariant_failure_counts':c['invariant_failure_counts'],'observer_errors':c['errors'],'coverage':c['coverage'],'uncovered':c['uncovered'],'metrics':d['metrics'],'prefix_wall_us':d['prefix_wall_us'],'all_wall_us':d['all_wall_us'],'process':process,'cpu_checks':target_checks(d['metrics'],read(project/'docs/data/balance.json')['performance_targets']['metrics']),'sample_work':c['sample']['work'],'sample_events':c['sample']['events'],'final_sha256':d['final_sha256'],'final_population':d['final']['population'],'source_identity_sha256':digest(root/'identity-before.json')}
write(root/'summary.json',s);print(json.dumps({k:s[k] for k in ['complete','errors','uncovered','invariant_failure_counts','metrics','sample_work','final_sha256']},ensure_ascii=False),flush=True)
