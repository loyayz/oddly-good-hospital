extends SceneTree
func _initialize() -> void:
	var f: FileAccess=FileAccess.open(OS.get_environment("OGH_FINAL_INPUT"),FileAccess.READ)
	var e: Dictionary=f.get_var(false);f.close()
	var d: Dictionary={"maintenance":e.facts.maintenance,"connectors":e.facts.connectors,"actors":{},"moves":{},"events":e.events,"ledger":e.facts.ledger}
	for id: String in e.facts.maintenance.contractors:
		d.actors[id]=e.facts.actors.get(id,{})
		d.moves[id]=e.facts.moves.get(id,{})
	var o: FileAccess=FileAccess.open(OS.get_environment("OGH_FINAL_OUTPUT"),FileAccess.WRITE)
	o.store_string(JSON.stringify(d,"\t"));o.close();quit(0)
