#requires -Version 7.0
$ErrorActionPreference='Stop'
$project=$PSScriptRoot
$identity=Get-Content -LiteralPath (Join-Path $project 'snapshot-prepare-identity.json') -Raw | ConvertFrom-Json
function Invoke-SnapshotProbe([object]$Run,[string]$Name) {
    $log=Join-Path $project ($Name+'.log')
    $statusPath=Join-Path $project ($Name+'.status.json')
    if((Test-Path -LiteralPath $log) -or (Test-Path -LiteralPath $statusPath)) {throw "Preserve previous evidence: $Name"}
    $start=[Diagnostics.ProcessStartInfo]::new($identity.engine)
    $start.UseShellExecute=$false
    $start.CreateNoWindow=$true
    $start.RedirectStandardOutput=$true
    $start.RedirectStandardError=$true
    foreach($property in $Run.environment.PSObject.Properties) {$start.Environment[$property.Name]=$property.Value}
    foreach($argument in $Run.arguments) {$start.ArgumentList.Add($argument)}
    $process=[Diagnostics.Process]::new()
    $process.StartInfo=$start
    $clock=[Diagnostics.Stopwatch]::StartNew()
    $writer=[IO.StreamWriter]::new($log,$false,[Text.UTF8Encoding]::new($false))
    $fatal=$false
    try {
        $null=$process.Start()
        $stdout=$process.StandardOutput.ReadLineAsync()
        $stderr=$process.StandardError.ReadLineAsync()
        $outEnded=$false
        $errEnded=$false
        while(-not $process.HasExited -or -not $outEnded -or -not $errEnded) {
            foreach($stream in @('out','err')) {
                $task=if($stream -eq 'out'){$stdout}else{$stderr}
                if($task.IsCompleted) {
                    $line=$task.GetAwaiter().GetResult()
                    if($null -eq $line) {if($stream -eq 'out'){$outEnded=$true}else{$errEnded=$true}}
                    else {
                        $writer.WriteLine($line)
                        $writer.Flush()
                        if($line -match 'SCRIPT ERROR:|Parse Error:|ERROR:') {$fatal=$true;if(-not $process.HasExited){$process.Kill($true)}}
                        if($stream -eq 'out'){$stdout=$process.StandardOutput.ReadLineAsync()}else{$stderr=$process.StandardError.ReadLineAsync()}
                    }
                }
            }
            if($clock.Elapsed.TotalSeconds -gt 300 -and -not $process.HasExited) {$fatal=$true;$process.Kill($true)}
            Start-Sleep -Milliseconds 10
        }
        $process.WaitForExit()
        $status=[ordered]@{name=$Name;exit=$process.ExitCode;fatal=$fatal;elapsed_ms=$clock.ElapsedMilliseconds;arguments=$Run.arguments;environment=$Run.environment;log=$log}
        $status|ConvertTo-Json -Depth 5 |Set-Content -LiteralPath $statusPath -Encoding utf8NoBOM
        if($fatal -or $process.ExitCode -ne 0){Get-Content -LiteralPath $log -Tail 30;throw "Snapshot probe failed: $Name"}
        if($Run.repeat -gt 0) {
            $result=Get-Content -LiteralPath $Run.output -Raw|ConvertFrom-Json
            if(-not $result.complete -or -not $result.ok -or $result.input_sha256 -ne $identity.input_sha256) {throw "Incomplete or failed fixed result: $Name"}
            foreach($check in $result.checks.PSObject.Properties){if($check.Value -ne $true){throw "Business check failed: $Name/$($check.Name)"}}
        }
        if($Name -eq 'estimate-contract') {
            $result=Get-Content -LiteralPath $Run.output -Raw|ConvertFrom-Json
            if(-not $result.complete -or -not $result.ok){throw 'Estimate contract failed'}
            foreach($check in $result.checks.PSObject.Properties){if($check.Value -ne $true){throw "Estimate check failed: $($check.Name)"}}
        }
        Write-Output ($Name+' '+$status.elapsed_ms+'ms PASS')
    } finally {$writer.Dispose();$process.Dispose()}
}
Invoke-SnapshotProbe $identity.import 'import'
Invoke-SnapshotProbe $identity.contract 'estimate-contract'
foreach($run in $identity.runs){Invoke-SnapshotProbe $run ('r'+$run.repeat)}
Write-Output ('SNAPSHOT_PROBE_COMPLETE='+$project)
