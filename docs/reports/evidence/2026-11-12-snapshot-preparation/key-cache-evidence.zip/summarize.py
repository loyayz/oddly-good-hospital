import hashlib
import json
from pathlib import Path
import statistics

root = Path(__file__).resolve().parent
def read(name):
    return json.loads((root / name).read_text(encoding='utf-8-sig'))
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
identity = read('snapshot-prepare-identity.json')
assert all(digest(root / path) == sha for path, sha in identity['source'].items())
assert digest(Path(identity['input'])) == identity['input_sha256']
assert digest(Path(identity['original_input'])) == identity['input_sha256']
assert all(digest(Path(path)) == sha for path, sha in identity['engine_executables'].items())
assert all(digest(root / 'game/platform/windows/bin' / name) == sha for name, sha in identity['native'].items())
status = [read(name + '.status.json') for name in ['import','r1','r2','r3']]
assert all(row['exit'] == 0 and not row['fatal'] for row in status)
results = [read(f'snapshot-prepare-r{repeat}.json') for repeat in range(1,4)]
assert all(row['complete'] and row['ok'] and all(value is True for value in row['checks'].values()) for row in results)
assert len(set(row['data_directory'] for row in results)) == 3
assert len(results[0]['failures']) == 3 and all(row['ok'] for row in results[0]['failures'])
assert all(row['facts'] == results[0]['facts'] for row in results)
assert all(row['main_thread_policy'] == results[0]['main_thread_policy'] for row in results)
timings = {}
def add(label, values):
    timings[label] = {'samples_usec': values, 'mean_usec': statistics.mean(values), 'median_usec': statistics.median(values)}
for phase in ['preparation_usec','begin_return_usec','after_begin_to_idle_usec','begin_through_idle_usec','restore_validation_usec']:
    add(phase,[row[phase] for row in results])
for scope, names in [('synchronous',['validate','estimate','budget','request','content_identity','freeze','thread_start']),('background',['legacy_import','database_prepare','encode_and_chunk_writes','manifest','read_back_validate','commit_close','final_load_validate','cleanup'])]:
    add(scope + '.total_usec',[row[scope]['total_usec'] for row in results])
    for name in names:
        assert all(row[scope][name]['calls'] == 1 for row in results)
        add(scope + '.' + name,[row[scope][name]['elapsed_usec'] for row in results])
add('synchronous.request_excluding_content_identity',[row['synchronous']['request']['elapsed_usec']-row['synchronous']['content_identity']['elapsed_usec'] for row in results])
result = {'complete':True,'ok':True,'scope':'Instrumented real Snapshot preparation and worker operations, with three independent fresh libraries and the unchanged complete160 input. Times include diagnostic call overhead. Nested request/content identity values must not be added; background read-back/final-load durations include decode and full validation. Not complete-save or game CPU qualification.','input_sha256':identity['input_sha256'],'identity_sha256':digest(root/'snapshot-prepare-identity.json'),'source_restoration_byte_exact':identity['snapshot']['whole_file_and_method_bodies_restore_exactly'],'all_source_hashes_still_match':True,'engine_status':status,'checks_per_repeat':[len(row['checks']) for row in results],'facts':results[0]['facts'],'failures':results[0]['failures'],'profiles':[row['data_directory'] for row in results],'main_thread_policy':results[0]['main_thread_policy'],'estimated_bytes':[row['synchronous']['estimated_bytes'] for row in results],'timings':timings,'raw_sha256':{f'snapshot-prepare-r{i+1}.json':digest(root/f'snapshot-prepare-r{i+1}.json') for i in range(3)}}
(root/'summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'complete':True,'groups':len(timings),'checks_per_repeat':result['checks_per_repeat'],'summary_sha256':digest(root/'summary.json')}))
