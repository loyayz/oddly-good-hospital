"""Insert reversible local spans into the frozen all-instance project only.

This program never starts Godot and never rewrites production or tools files.
Run without arguments once to prepare; --verify checks the exact inverse later.
"""

from __future__ import annotations

import hashlib
import json
import pathlib
import re
import shutil
import sys


ROOT = pathlib.Path(__file__).resolve().parent
SOURCE = ROOT / "after-all-project"
TARGET = ROOT / "segments-complete-project"
PROOF = ROOT / "segments-complete-proof"
RELATIVE = "game/life/public_areas.gd"
SPACE_RELATIVE = "game/building/hospital_space.gd"
MANIFEST_NAME = "signature-segments-identity.json"
ALL_IDENTITY = "all-instance-profile-identity.json"
OBSERVER = "_local_segment_observer"
META = "oddly_good_tail_profile_observer_v1"


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def dump(path: pathlib.Path, value: object) -> None:
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf8")


def method_span(source: str, name: str) -> tuple[int, int]:
    headers = list(re.finditer(r"(?m)^(?:static )?func ([A-Za-z_][A-Za-z_0-9]*)\(", source))
    matches = [index for index, match in enumerate(headers) if match.group(1) == name]
    assert len(matches) == 1, (name, matches)
    number = matches[0]
    return headers[number].start(), headers[number + 1].start() if number + 1 < len(headers) else len(source)


def method_bytes(source: str, name: str) -> bytes:
    start, finish = method_span(source, name)
    return source[start:finish].encode("utf8")


def marker(operation: str, entering: bool, indent: int = 1) -> str:
    action = "enter_instance" if entering else "exit_instance"
    arguments = "get_instance_id(),{}" if entering else "null"
    return "\t" * indent + f'if {OBSERVER}!=null: {OBSERVER}.{action}("{operation}",{arguments})\n'


def project_files(project: pathlib.Path) -> dict[str, str]:
    # Runtime import caches are deliberately outside the frozen source proof.
    return {
        path.relative_to(project).as_posix(): digest(path.read_bytes())
        for path in sorted(project.rglob("*"))
        if path.is_file()
        and path.relative_to(project).parts[0] not in {".godot", ".cache"}
        and path.relative_to(project).as_posix() not in {"import.log", ALL_IDENTITY, MANIFEST_NAME}
    }


def prepare() -> None:
    assert SOURCE.is_dir(), SOURCE
    assert not TARGET.exists(), f"Refusing to replace existing project: {TARGET}"
    assert not PROOF.exists(), f"Refusing to replace existing proof: {PROOF}"
    original = (SOURCE / RELATIVE).read_bytes()
    source = original.decode("utf8")
    assert "\r" not in source, "Frozen source uses unexpected line endings"
    assert "OGH_LOCAL_SEGMENT_INSERT" not in source
    insertions: list[dict[str, object]] = []

    def before(method: str, anchor: str, content: str) -> None:
        start, finish = method_span(source, method)
        body = source[start:finish]
        assert body.count(anchor) == 1, (method, anchor, body.count(anchor))
        offset = start + body.index(anchor)
        number = len(insertions) + 1
        chunk = f"# OGH_LOCAL_SEGMENT_INSERT_{number:02d}_BEGIN\n" + content + f"# OGH_LOCAL_SEGMENT_INSERT_{number:02d}_END\n"
        insertions.append({"number": number, "method": method, "before_original_line": source.count("\n", 0, offset) + 1, "original_character_offset": offset, "chunk": chunk, "chunk_sha256": digest(chunk.encode("utf8"))})

    observer = f'\tvar {OBSERVER}: Variant = Engine.get_meta(&"{META}") if Engine.has_meta(&"{META}") else null\n'
    signature = "_tail_profile_original__decision_signature"
    signature_operations = ["public_areas.signature_facility_points", "public_areas.signature_queue_rows", "public_areas.signature_other_environment"]
    before(signature, "\tvar view: Dictionary = _decision_view(world)\n", observer)
    before(signature, "\tvar points: Array = []\n", marker(signature_operations[0], True))
    before(signature, '\tvar queue_key: String = JSON.stringify([intent.public_purpose,reference],"",true,true)\n', marker(signature_operations[0], False) + marker(signature_operations[1], True))
    before(signature, "\tvar sorted_ids: Array = other_ids.keys()\n", marker(signature_operations[1], False) + marker(signature_operations[2], True))
    before(signature, "\treturn records\n", marker(signature_operations[2], False))

    derive = "_tail_profile_original__derive_floor"
    derive_operations = ["public_areas.derive_zone_setup", "public_areas.derive_erase", "public_areas.derive_seed_order", "public_areas.derive_component_bfs", "public_areas.derive_component_geometry", "public_areas.derive_component_by_cell", "public_areas.derive_facility_bind"]
    before(derive, '\tvar result: Dictionary = {"regions":[],"by_cell":{},"by_facility":{}}\n', observer)
    before(derive, "\tvar zones: Dictionary = {}\n", marker(derive_operations[0], True))
    before(derive, "\tvar free: Dictionary = zones.duplicate()\n", marker(derive_operations[0], False) + marker(derive_operations[1], True))
    before(derive, "\t# Row-major IDs use the engine's integer sort while retaining the same\n", marker(derive_operations[1], False) + marker(derive_operations[2], True))
    before(derive, "\tvar seen: Dictionary = {}\n", marker(derive_operations[2], False))
    before(derive, "\t\tvar cells: Dictionary = {start:true}\n", marker(derive_operations[3], True, 2))
    before(derive, '\t\tvar geometry: String = JSON.stringify(pending,"",true,true).sha256_text()\n', marker(derive_operations[3], False, 2) + marker(derive_operations[4], True, 2))
    before(derive, "\t\tfor point: Vector2i in cells: result.by_cell[_key(floor_id,point)] = region\n", marker(derive_operations[4], False, 2) + marker(derive_operations[5], True, 2))
    before(derive, "\tfor facility: Dictionary in facilities:\n\t\tvar actual: Dictionary = facility.layout\n", marker(derive_operations[5], False, 2) + marker(derive_operations[6], True))
    before(derive, "\treturn result\n", marker(derive_operations[6], False))

    assert len({entry["original_character_offset"] for entry in insertions}) == len(insertions)
    changed = source
    for entry in sorted(insertions, key=lambda item: int(item["original_character_offset"]), reverse=True):
        offset = int(entry["original_character_offset"])
        changed = changed[:offset] + str(entry["chunk"]) + changed[offset:]
    reconstructed = inverse(changed, insertions).encode("utf8")
    assert reconstructed == original, "Inverse must restore every original byte"
    wrappers = ["_decision_signature", "_derive_floor"]
    wrapper_proof = {name: {"parent_sha256": digest(method_bytes(source, name)), "generated_sha256": digest(method_bytes(changed, name)), "unchanged": method_bytes(source, name) == method_bytes(changed, name)} for name in wrappers}
    assert all(row["unchanged"] for row in wrapper_proof.values())
    assert changed.count(f'enter_instance("{signature_operations[0]}"') == 1
    assert changed.count('enter_instance("public_areas._decision_signature"') == 1
    assert changed.count('enter_instance("public_areas._derive_floor"') == 1

    # One rebuild span covers the real not-shared clear/reinsert branch, with
    # no per-actor observer wrapper. All original fast returns precede it.
    space_original = (SOURCE / SPACE_RELATIVE).read_bytes()
    space_source = space_original.decode("utf8")
    actor_method = "_tail_profile_original__ensure_actor_index"
    actor_start, actor_finish = method_span(space_source, actor_method)
    actor_body = space_source[actor_start:actor_finish]
    actor_operation = "actor_index.rebuild"
    actor_insertions: list[dict[str, object]] = []
    for number, anchor, after, content in [
        (1, "\tif world!=_indexed_world:\n", False,
         f"\tvar {OBSERVER}: Variant = null\n\tif not shared:\n\t\t{OBSERVER} = Engine.get_meta(&\"{META}\") if Engine.has_meta(&\"{META}\") else null\n" + marker(actor_operation, True, 2)),
        (2, "\t\t\t_sync_actor(world,id,false)\n", True, marker(actor_operation, False)),
    ]:
        assert actor_body.count(anchor) == 1, (anchor, actor_body.count(anchor))
        offset = actor_start + actor_body.index(anchor) + (len(anchor) if after else 0)
        chunk = f"# OGH_LOCAL_ACTOR_INSERT_{number:02d}_BEGIN\n" + content + f"# OGH_LOCAL_ACTOR_INSERT_{number:02d}_END\n"
        actor_insertions.append({"number": number, "method": actor_method, "original_character_offset": offset, "chunk": chunk, "chunk_sha256": digest(chunk.encode("utf8"))})
    space_changed = space_source
    for entry in sorted(actor_insertions, key=lambda item: int(item["original_character_offset"]), reverse=True):
        offset = int(entry["original_character_offset"])
        space_changed = space_changed[:offset] + str(entry["chunk"]) + space_changed[offset:]
    space_reconstructed = inverse(space_changed, actor_insertions).encode("utf8")
    assert space_reconstructed == space_original
    assert method_bytes(space_source, "_ensure_actor_index") == method_bytes(space_changed, "_ensure_actor_index")

    parent_tree = project_files(SOURCE)
    parent_identity_bytes = (SOURCE / ALL_IDENTITY).read_bytes()
    parent_identity = json.loads(parent_identity_bytes)
    shutil.copytree(SOURCE, TARGET)
    PROOF.mkdir()
    (PROOF / "public_areas.original-all-wrapper.gd.txt").write_bytes(original)
    (PROOF / "public_areas.inverse-reconstructed.gd.txt").write_bytes(reconstructed)
    (PROOF / "hospital_space.original-all-wrapper.gd.txt").write_bytes(space_original)
    (PROOF / "hospital_space.inverse-reconstructed.gd.txt").write_bytes(space_reconstructed)
    (PROOF / "parent-all-instance-profile-identity.json").write_bytes(parent_identity_bytes)
    (TARGET / RELATIVE).write_bytes(changed.encode("utf8"))
    (TARGET / SPACE_RELATIVE).write_bytes(space_changed.encode("utf8"))
    generated_tree = project_files(TARGET)
    assert set(parent_tree) == set(generated_tree)
    differences = [path for path in parent_tree if parent_tree[path] != generated_tree[path]]
    assert sorted(differences) == sorted([RELATIVE, SPACE_RELATIVE]), differences
    manifest = {
        "schema_version": 1,
        "diagnostic_only": True,
        "formal_acceptance_paused": True,
        "parent_project": str(SOURCE),
        "generated_project": str(TARGET),
        "parent_frozen_source_identity_sha256": digest((SOURCE / "source-identity.json").read_bytes()),
        "parent_all_instance_identity_sha256": digest(parent_identity_bytes),
        "transformer_sha256": digest(pathlib.Path(__file__).read_bytes()),
        "engine_metadata_key": META,
        "source_file": RELATIVE,
        "original_complete_source_sha256": digest(original),
        "generated_complete_source_sha256": digest(changed.encode("utf8")),
        "inverse_complete_source_sha256": digest(reconstructed),
        "inverse_byte_equal": True,
        "original_statement_order_preserved": True,
        "original_lines_removed_or_rewritten": 0,
        "outer_wrappers": wrapper_proof,
        "new_wrappers": 0,
        "new_local_operation_count": len(signature_operations + derive_operations) + 1,
        "signature_operations": signature_operations,
        "derive_operations": derive_operations,
        "actor_operations": [actor_operation],
        "additional_sources": [{
            "source_file": SPACE_RELATIVE,
            "original_complete_source_sha256": digest(space_original),
            "generated_complete_source_sha256": digest(space_changed.encode("utf8")),
            "inverse_complete_source_sha256": digest(space_reconstructed),
            "inverse_byte_equal": True,
            "original_lines_removed_or_rewritten": 0,
            "outer_wrapper": "_ensure_actor_index",
            "outer_wrapper_sha256": digest(method_bytes(space_source, "_ensure_actor_index")),
            "outer_wrapper_unchanged": True,
            "insertions": actor_insertions,
        }],
        "insertions": insertions,
        "frozen_project_file_count": len(parent_tree),
        "original_project_files": parent_tree,
        "changed_parent_project_files": differences,
        "excluded_runtime_paths": [".godot/", ".cache/", "import.log"],
        "interpretation": {
            "local_spans": "Disjoint siblings within their existing timed original function. Component spans repeat once per new component, never once per cell.",
            "derive_unsegmented": "Result initialization, seen initialization, seed decoding and already-seen checks between components remain in the original derive_floor exclusive remainder.",
            "signature_unsegmented": "Original decision_view, requested actor bodies, common header and connection basis remain before the first local span.",
            "actor_rebuild": "Counts only the real not-shared rebuild branch: shapes/index clearing, world binding, build counter and all world.ids(actors) syncs. Existing fast returns and shared projections do not enter it.",
            "observer_handlers": "Existing enter_instance/exit_instance observer handler time is removed through _observer_us. Existing nested view/region/navigation/entry timings remain active.",
            "instrumentation_residual": "Engine metadata reads, guards, call dispatch and timer overhead are not fully isolatable. Local or parent exclusive values are diagnostic spans, not certified exclusive business time.",
            "comparison": "Compare with the existing same frozen after-all-project selected windows. No plain run or formal acceptance claim is introduced.",
        },
    }
    dump(TARGET / MANIFEST_NAME, manifest)
    identity = json.loads(parent_identity_bytes)
    identity["parent_all_instance_identity_sha256"] = digest(parent_identity_bytes)
    identity["original_method_bodies_preserved"] = False
    identity["original_business_statement_order_preserved"] = True
    identity["original_method_bodies_recoverable_by_local_inverse"] = True
    identity["local_segments"] = {
        "identity_path": "res://" + MANIFEST_NAME,
        "identity_sha256": digest((TARGET / MANIFEST_NAME).read_bytes()),
        "transformer_sha256": manifest["transformer_sha256"],
        "source_files": [RELATIVE, SPACE_RELATIVE],
        "original_complete_source_sha256": manifest["original_complete_source_sha256"],
        "generated_complete_source_sha256": manifest["generated_complete_source_sha256"],
        "inverse_complete_source_sha256": manifest["inverse_complete_source_sha256"],
        "inverse_byte_equal": True,
        "outer_wrappers_unchanged": True,
        "new_wrappers": 0,
        "operations": signature_operations + derive_operations + [actor_operation],
        "additional_sources": [{key: value for key, value in entry.items() if key != "insertions"} for entry in manifest["additional_sources"]],
        "instrumentation_residual_is_not_business_exclusive_time": True,
    }
    for entry in identity["files"]:
        if entry["path"] == RELATIVE:
            assert entry["generated_sha256"] == digest(original)
            entry["parent_all_wrapper_sha256"] = entry["generated_sha256"]
            entry["generated_sha256"] = manifest["generated_complete_source_sha256"]
            entry["local_inverse_all_wrapper_sha256"] = digest(reconstructed)
        elif entry["path"] == SPACE_RELATIVE:
            assert entry["generated_sha256"] == digest(space_original)
            entry["parent_all_wrapper_sha256"] = entry["generated_sha256"]
            entry["generated_sha256"] = digest(space_changed.encode("utf8"))
            entry["local_inverse_all_wrapper_sha256"] = digest(space_reconstructed)
    dump(TARGET / ALL_IDENTITY, identity)
    dump(PROOF / "preparation-receipt.json", {"project": str(TARGET), "manifest_sha256": digest((TARGET / MANIFEST_NAME).read_bytes()), "all_instance_identity_sha256": digest((TARGET / ALL_IDENTITY).read_bytes()), "original_complete_source_sha256": digest(original), "generated_complete_source_sha256": digest(changed.encode("utf8")), "inverse_complete_source_sha256": digest(reconstructed), "new_wrappers": 0, "godot_started": False})
    verify()


def inverse(source: str, insertions: list[dict[str, object]]) -> str:
    for entry in reversed(insertions):
        chunk = str(entry["chunk"])
        assert digest(chunk.encode("utf8")) == entry["chunk_sha256"]
        assert source.count(chunk) == 1, entry["number"]
        source = source.replace(chunk, "", 1)
    return source


def verify() -> None:
    manifest = json.loads((TARGET / MANIFEST_NAME).read_bytes())
    receipt = json.loads((PROOF / "preparation-receipt.json").read_bytes())
    assert digest(pathlib.Path(__file__).read_bytes()) == manifest["transformer_sha256"]
    assert digest((TARGET / MANIFEST_NAME).read_bytes()) == receipt["manifest_sha256"]
    assert digest((TARGET / ALL_IDENTITY).read_bytes()) == receipt["all_instance_identity_sha256"]
    assert digest((SOURCE / ALL_IDENTITY).read_bytes()) == manifest["parent_all_instance_identity_sha256"]
    original = (PROOF / "public_areas.original-all-wrapper.gd.txt").read_bytes()
    generated = (TARGET / RELATIVE).read_bytes()
    reconstructed = inverse(generated.decode("utf8"), manifest["insertions"]).encode("utf8")
    assert original == reconstructed == (SOURCE / RELATIVE).read_bytes()
    assert original == (PROOF / "public_areas.inverse-reconstructed.gd.txt").read_bytes()
    assert digest(original) == manifest["original_complete_source_sha256"]
    assert digest(generated) == manifest["generated_complete_source_sha256"]
    for name in manifest["outer_wrappers"]:
        assert method_bytes(generated.decode("utf8"), name) == method_bytes(original.decode("utf8"), name)
    for entry in manifest["additional_sources"]:
        extra_original = (PROOF / "hospital_space.original-all-wrapper.gd.txt").read_bytes()
        extra_generated = (TARGET / entry["source_file"]).read_bytes()
        extra_reconstructed = inverse(extra_generated.decode("utf8"), entry["insertions"]).encode("utf8")
        assert extra_original == extra_reconstructed == (SOURCE / entry["source_file"]).read_bytes()
        assert extra_original == (PROOF / "hospital_space.inverse-reconstructed.gd.txt").read_bytes()
        assert digest(extra_original) == entry["original_complete_source_sha256"]
        assert digest(extra_generated) == entry["generated_complete_source_sha256"]
        assert method_bytes(extra_generated.decode("utf8"), entry["outer_wrapper"]) == method_bytes(extra_original.decode("utf8"), entry["outer_wrapper"])
    parent_tree = manifest["original_project_files"]
    assert project_files(SOURCE) == parent_tree
    current_tree = project_files(TARGET)
    assert set(current_tree) == set(parent_tree)
    assert sorted(path for path in parent_tree if parent_tree[path] != current_tree[path]) == sorted([RELATIVE, SPACE_RELATIVE])
    print(json.dumps({"prepared_project": str(TARGET), "inverse_byte_equal": True, "unchanged_outer_wrappers": True, "local_operations": manifest["new_local_operation_count"], "parent_stable_files": manifest["frozen_project_file_count"], "changed_source_files": [RELATIVE, SPACE_RELATIVE], "original_source_sha256": digest(original), "instrumented_source_sha256": digest(generated), "manifest_sha256": receipt["manifest_sha256"], "all_instance_identity_sha256": receipt["all_instance_identity_sha256"], "godot_started": False}, ensure_ascii=False))


if __name__ == "__main__":
    if sys.argv[1:] == ["--verify"]:
        verify()
    elif not sys.argv[1:]:
        prepare()
    else:
        raise SystemExit("Usage: prepare-segments.py [--verify]")
