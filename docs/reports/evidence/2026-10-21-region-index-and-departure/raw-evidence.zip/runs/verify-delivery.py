"""Verify staged report/evidence after summarize.py and report authoring."""
from __future__ import annotations

import argparse
import hashlib
import json
import pathlib
import re
import subprocess
import zipfile

REPO = pathlib.Path(r"C:\code\loyayz\oddly-good-hospital")
OUT = REPO / "docs/reports/evidence/2026-10-21-region-index-and-departure"
DEFAULT_REPORT = REPO / "docs/reports/2026-10-21-region-index-and-departure.md"
CRLF_EXCEPTION = "tests/acceptance/zip_library_boundaries.gd"


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def digest(data):
    return hashlib.sha256(data).hexdigest()


def git_output(*arguments, text=False, data=None):
    return subprocess.check_output(["git", *arguments], cwd=REPO, text=text, input=data)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--report", type=pathlib.Path, default=DEFAULT_REPORT)
    report = parser.parse_args().report.resolve()
    source = read(OUT / "source-check.json")
    rows = source["final_files"] + source["final_test_files"]
    queries = "".join(":" + row["path"] + "\n" for row in rows).encode()
    raw = git_output("cat-file", "--batch", data=queries)
    cursor, exceptions = 0, []
    for row in rows:
        end = raw.index(b"\n", cursor)
        header = raw[cursor:end].split()
        assert len(header) == 3 and header[1] == b"blob", (row["path"], header)
        size = int(header[2])
        cursor = end + 1
        blob = raw[cursor:cursor + size]
        cursor += size + 1
        current = (REPO / row["path"]).read_bytes()
        assert digest(current) == row["sha256"], row["path"]
        if digest(blob) != row["sha256"]:
            assert row["path"] == CRLF_EXCEPTION, row["path"]
            assert blob.replace(b"\r\n", b"\n") == current.replace(b"\r\n", b"\n")
            assert not git_output("diff", "HEAD", "--", row["path"]), row["path"]
            exceptions.append(row["path"])
    assert cursor == len(raw)
    assert source["test_file_count"] == len(source["executed_test_files"])
    assert source["delivery_test_file_count"] == len(source["final_test_files"])
    assert all(source["binary_equal"].values()) and all(source["test_binary_equal"].values())
    assert source["before_native"] == source["after_native"]

    assert report.is_file(), report
    links = re.findall(r"\]\((evidence/[^)]+)\)", report.read_text(encoding="utf8"))
    assert links and all((report.parent / link).is_file() for link in links), links
    required = {"quick-summary.json", "function-summary.json", "functional-summary.json", "source-check.json", "raw-manifest.json", "raw-evidence.zip"}
    assert required <= {pathlib.Path(link).name for link in links}
    quick = read(OUT / "quick-summary.json")
    functional = read(OUT / "functional-summary.json")
    functions = read(OUT / "function-summary.json")
    assert quick["formal_pass"] is False and quick["formal_acceptance_paused"] is True
    assert functional["formal_pass"] is False and functional["formal_acceptance_paused"] is True
    batches = functional["batches"]
    assert len(batches) == 1
    passed = {case for batch in batches for case, value in batch["result"]["results"].items() if value["passed"]}
    assert passed == set(functional["affected_cases"])
    for batch in batches:
        assert batch["result"]["completed"] and batch["result"]["failed"] == 0
        assert not batch["execution"]["script_errors"] and batch["execution"]["test_exit"] == 0
    for wrapper in functions["transform_originals"]:
        assert wrapper["all_original_bodies_and_generated_wrappers_equal"]
    for segment in functions["local_segment_inverses"]:
        assert segment["complete_inverse_byte_equal"] and "actor_index.rebuild" in segment["operations"]

    manifest = read(OUT / "raw-manifest.json")
    archive = OUT / manifest["archive"]
    assert digest(archive.read_bytes()) == manifest["sha256"] and archive.stat().st_size == manifest["bytes"]
    with zipfile.ZipFile(archive) as container:
        assert len(container.namelist()) == len(set(container.namelist())) == len(manifest["entries"])
        for row in manifest["entries"]:
            blob = container.read(row["path"])
            assert digest(blob) == row["sha256"] and len(blob) == row["bytes"], row["path"]
    staged = git_output("diff", "--cached", "--name-only", text=True).splitlines()
    assert staged and not any(path.lower().endswith(".dll") for path in staged)
    required_staged = {report.relative_to(REPO).as_posix()}
    required_staged.update((OUT / name).relative_to(REPO).as_posix() for name in required)
    required_staged.update(row["path"] for row in source["changed_production_files"])
    required_staged.update(row["path"] for row in source["final_test_files"])
    assert required_staged <= set(staged), sorted(required_staged - set(staged))
    # Verify every staged report/evidence byte, not just path presence. The
    # count is derived from the actual index rather than a fixed batch size.
    for relative in staged:
        if relative.startswith("docs/reports/"):
            assert git_output("show", ":" + relative) == (REPO / relative).read_bytes(), relative
    assert not git_output("diff", "--check") and not git_output("diff", "--cached", "--check")
    print(json.dumps({"staged_files": len(staged), "verified_game_and_test_files": len(rows), "unchanged_crlf_exceptions": exceptions, "report_links": len(links), "raw_entries": len(manifest["entries"]), "final_affected_cases": len(passed), "formal_acceptance_paused": True}))


if __name__ == "__main__":
    main()
