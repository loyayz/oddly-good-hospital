#requires -Version 7.0
param([string]$Project='before-project',[string]$Label='a',[string]$Mode='plain')
$ErrorActionPreference='Stop'
$repo='C:/code/loyayz/oddly-good-hospital'
$root=Join-Path $repo '.cache/region-components-5b87657-20261021'
$godot='C:/programs/godot/Godot_v4.7.2-stable_win64.exe'
foreach($window in @(@{name='public360';input='public-v6.input.bin';steps=360;selected='0,1,27,140'},@{name='gp80';input='gp.input.bin';steps=80;selected='0,1,3,4,15,27,28,39,79'},@{name='operations40';input='op.input.bin';steps=40;selected='0,1,19,20,21,38,39'})){
    $output=Join-Path $root ($Label+'-'+$window.name+'.json')
    if(Test-Path -LiteralPath $output){throw "Evidence exists: $output"}
    $stdout=[IO.Path]::ChangeExtension($output,'.stdout.log')
    $stderr=[IO.Path]::ChangeExtension($output,'.stderr.log')
    $script=if($Mode -eq 'plain'){'representative.gd'}else{'representative_selected.gd'}
    $arguments=@('--headless','--path',(Join-Path $root $Project),'--script',('res://tools/performance/'+$script),'--',
        ('--input='+ (Join-Path $repo ('.cache/task-navigation-20261019/'+$window.input))),('--output='+$output),
        ('--steps='+$window.steps),('--profile='+$Mode),('--selected='+$window.selected))
    $started=[DateTimeOffset]::UtcNow
    $child=Start-Process -FilePath $godot -ArgumentList $arguments -PassThru -WindowStyle Hidden -RedirectStandardOutput $stdout -RedirectStandardError $stderr
    $child.WaitForExit()
    $child.Refresh()
    [ordered]@{diagnostic_only=$true;formal_acceptance_paused=$true;started_at_utc=$started;ended_at_utc=[DateTimeOffset]::UtcNow;affinity_changed=$false;priority_changed=$false;arguments=$arguments;exit_code=$child.ExitCode;child_cpu_ms=$child.TotalProcessorTime.TotalMilliseconds;engine_executable_sha256=(Get-FileHash -LiteralPath $godot).Hash}|ConvertTo-Json -Depth 5|Set-Content -LiteralPath ([IO.Path]::ChangeExtension($output,'.launch.json')) -Encoding utf8NoBOM
    if($child.ExitCode -ne 0 -or @(Select-String -LiteralPath $stdout,$stderr -Pattern 'SCRIPT ERROR:|ERROR:').Count -gt 0){Get-Content -LiteralPath $stdout,$stderr -Tail 15;throw "Quick run failed: $output"}
    $result=Get-Content -LiteralPath $output -Raw|ConvertFrom-Json
    if(-not $result.complete -or -not $result.qualified -or $result.errors.Count -gt 0){throw "Incomplete or invalid: $output"}
    [ordered]@{run=($Label+'-'+$window.name);metrics=$result.metrics;hash=$result.final_binary_sha256}|ConvertTo-Json -Depth 4 -Compress
}
