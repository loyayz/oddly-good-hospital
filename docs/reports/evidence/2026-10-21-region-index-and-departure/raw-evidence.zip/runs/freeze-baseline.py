import hashlib,json,pathlib,shutil,subprocess,uuid
repo=pathlib.Path(r'C:\code\loyayz\oddly-good-hospital')
root=pathlib.Path(__file__).resolve().parent
source=repo/'.cache/inner-query-899df40-20261021/after-project'
target=root/'before-project'
identity=json.loads((source/'source-identity.json').read_text(encoding='utf-8-sig'))
base='5b876579b40c2a02f8baa16de3373ed981a85f8f'
rows=[r for r in identity['source'] if r['path'].startswith(('game/','content/','tools/performance/'))]
raw=subprocess.run(['git','cat-file','--batch'],input=''.join(base+':'+r['path']+'\n' for r in rows).encode(),cwd=repo,check=True,stdout=subprocess.PIPE).stdout
cursor=0
for r in rows:
 end=raw.index(b'\n',cursor);size=int(raw[cursor:end].split()[-1]);cursor=end+1;blob=raw[cursor:cursor+size];cursor+=size+1
 assert hashlib.sha256(blob).hexdigest()==r['sha256']
 assert hashlib.sha256((source/r['path']).read_bytes()).hexdigest()==r['sha256']
assert not target.exists()
shutil.copytree(source,target)
profile='OddlyGoodHospital Performance '+uuid.uuid4().hex
p=target/'project.godot';p.write_text(p.read_text(encoding='utf-8-sig').replace(identity['profile'],profile),encoding='utf8')
identity.update(head=base,project=str(target),profile=profile,baseline_git_files_verified=len(rows),copied_from=str(source))
(target/'source-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf8')
print('frozen baseline',len(rows))
