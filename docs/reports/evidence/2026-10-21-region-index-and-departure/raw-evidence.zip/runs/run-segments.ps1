#requires -Version 7.0
param([string]$Label='segments-all')
$ErrorActionPreference='Stop'
$root=Split-Path -Parent $PSCommandPath
& python (Join-Path $root 'prepare-segments.py') --verify
if($LASTEXITCODE -ne 0){throw 'Frozen local segment inverse verification failed'}
# This launcher is intentionally not called by the preparation script.
# The existing driver serializes the same three selected all-instance windows.
& pwsh -NoProfile -File (Join-Path $root 'run-window.ps1') -Project 'segments-complete-project' -Label $Label -Mode 'all'
if($LASTEXITCODE -ne 0){throw "Selected segment diagnostic failed: $LASTEXITCODE"}
