"""Package this frozen quick comparison; never start an engine or alter sources."""
from __future__ import annotations

import hashlib
import importlib.util
import json
import pathlib
import statistics
import subprocess
import sys
import zipfile

REPO = pathlib.Path(r"C:\code\loyayz\oddly-good-hospital")
ROOT = pathlib.Path(__file__).resolve().parent
PREVIOUS = REPO / ".cache/inner-query-899df40-20261021"
OUT = REPO / "docs/reports/evidence/2026-10-21-region-index-and-departure"
BASE = "5b876579b40c2a02f8baa16de3373ed981a85f8f"
BATCH = "03c7b0d84a9442709966d9af12da2dfb"
PREFIXES = ("game/", "content/", "tools/performance/")
WINDOWS = {"public360": (360, "public-v6.input.bin"), "gp80": (80, "gp.input.bin"), "operations40": (40, "op.input.bin")}
INPUTS = REPO / ".cache/task-navigation-20261019"
BINARY_KEYS = ("engine_sha256", "native_sha256", "gmp_sha256", "mpfr_sha256", "runtime_sha256")
EXPECTED_NATIVE = "c7a0604fd2fcc9ccf60c0f60ad2d62bfe299b7f5c017041c23b381f3c0582991"
REQUIRED_CASES = {"STAFF-69", "STAFF-70", "STAFF-71", "STAFF-72", "STAFF-75", "SPACE-51"}
DELIVERY_TEST_PATHS = {"tests/acceptance/manual_seat_departure_scope.gd", "tests/acceptance/space.gd", "tests/acceptance/public_region_build.gd", "tests/acceptance/public_region_lifecycle.gd", "tests/acceptance/public_region_refresh_and_doors.gd"}
SEGMENT_IDENTITY = "signature-segments-identity.json"
ALL_IDENTITY = "all-instance-profile-identity.json"
sys.dont_write_bytecode = True


def read(path):
    return json.loads(pathlib.Path(path).read_text(encoding="utf-8-sig"))


def digest(data):
    return hashlib.sha256(data).hexdigest()


def sha(path):
    return digest(pathlib.Path(path).read_bytes())


def dump(name, value):
    (OUT / name).write_bytes((json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf8"))


def git_blobs(expressions):
    raw = subprocess.check_output(["git", "cat-file", "--batch"], input="".join(x + "\n" for x in expressions).encode(), cwd=REPO)
    cursor = 0
    for expression in expressions:
        end = raw.index(b"\n", cursor)
        header = raw[cursor:end].split()
        assert len(header) == 3 and header[1] == b"blob", (expression, header)
        size = int(header[2])
        cursor = end + 1
        yield raw[cursor:cursor + size]
        cursor += size + 1
    assert cursor == len(raw)


def measured(directory, label, window, side):
    path = directory / f"{label}-{window}.json"
    data = read(path)
    launch = read(directory / f"{label}-{window}.launch.json")
    steps, input_name = WINDOWS[window]
    assert data["complete"] and data["qualified"] and not data["errors"], path
    assert data["formal_pass"] is False and data["formal_acceptance_paused"] is True
    assert data["requested_steps"] == steps and len(data["samples"]) == steps
    assert data["metrics"]["count"] == steps
    assert all(data["qualification"].values()) and all(data.get("public_checks", {}).values())
    assert all(s["complete"] and s["present"] == 160 for s in data["samples"])
    depth_samples = [s for s in data["samples"] if "route_query_depth" in s]
    assert all(s["route_query_depth"] == 0 for s in depth_samples), path
    if label.startswith("segments"):
        assert len(depth_samples) == steps, (path, "selected observer must record every query depth")
    query_depth_evidence = {
        "recorded_sample_count": len(depth_samples), "missing_sample_count": steps - len(depth_samples),
        "all_recorded_zero": True if depth_samples else None,
        "scope": "selected observer records per-step query depth; plain runner has no such observation",
    }
    assert data["initial"]["present"] == data["final"]["present"] == 160
    assert data["initial"]["validation"] == data["final"]["validation"] == ""
    assert not data["public"]["errors"]
    assert sha(path.with_name(path.name + ".final.bin")) == data["final_binary_sha256"]
    assert sha(INPUTS / input_name) == data["source_input_sha256"]
    assert launch["exit_code"] == 0 and not launch["affinity_changed"] and not launch["priority_changed"]
    for suffix in ("stdout.log", "stderr.log"):
        text = (directory / f"{label}-{window}.{suffix}").read_text(encoding="utf-8-sig")
        assert "SCRIPT ERROR:" not in text and "ERROR:" not in text, (path, suffix)
    public_keys = ("actual_use_ticks", "queue_actor_ticks", "actual_exit_then_reuse_count", "actual_use_starts", "actual_use_completions", "area_arrivals", "fallback_starts")
    return {
        "run": f"{side}-{label}-{window}" if label.startswith("segments") else f"{label}-{window}",
        "side": side, "source_result": str(path), "source_result_sha256": sha(path),
        "metrics": data["metrics"], "execution": data["execution"], "launch": launch,
        "qualification": data["qualification"], "final_hash": data["final_binary_sha256"],
        "input_sha256": data["source_input_sha256"], "work": data["final"]["work_ticks_by_kind"],
        "query_counts": data["public"]["query_counts"],
        "public_work": {k: data["public"][k] for k in public_keys}, "operations": data["operations"],
        "all_steps_complete_with_160_actors": True,
        "query_scope_depth_evidence": query_depth_evidence,
    }, data


def same_work(rows):
    fields = ("final_hash", "input_sha256", "work", "public_work", "operations")
    assert all(all(row[key] == rows[0][key] for key in fields) for row in rows), [r["run"] for r in rows]


def load_transformer(directory, name):
    path = directory / "tools/performance/instrument_all_instances.py"
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module, path


def wrapper_proof(side, directory, plain):
    identity = read(directory / ALL_IDENTITY)
    transformer, path = load_transformer(directory, "frozen_wrappers_" + side)
    assert sha(path) == identity["transformer_sha256"]
    assert identity["original_method_bodies_preserved"]
    files = []
    for row in identity["files"]:
        original = (directory / ".cache/tail-profile-originals" / row["path"]).read_bytes()
        generated = (directory / row["path"]).read_bytes()
        assert digest(original) == row["original_sha256"] == row["reconstructed_original_sha256"]
        assert sha(plain / row["path"]) == row["original_sha256"]
        assert digest(generated) == row["generated_sha256"]
        methods = {entry["method"] for entry in row["methods"]}
        group = row["methods"][0]["operation"].split(".", 1)[0]
        rebuilt, records = transformer.transform(original.decode("utf8"), group, methods, bool(identity["decision_ledger"]))
        assert rebuilt.encode("utf8") == generated and records == row["methods"], row["path"]
        files.append({"path": row["path"], "original_sha256": digest(original), "generated_sha256": digest(generated), "methods": len(methods), "reconstructed_and_regenerated_byte_equal": True})
    assert len(files) == identity["transformed_file_count"] == 25
    assert sum(r["methods"] for r in files) == identity["actual_method_count"] == 309
    return {"side": side, "parent_project": str(directory), "identity_sha256": sha(directory / ALL_IDENTITY), "files": files, "transformed_file_count": len(files), "actual_method_count": sum(r["methods"] for r in files), "all_original_bodies_and_generated_wrappers_equal": True}


def segment_proof(side, directory):
    target = directory / "segments-complete-project"
    proof = directory / "segments-complete-proof"
    parent = directory / "after-all-project"
    identity = read(target / SEGMENT_IDENTITY)
    receipt = read(proof / "preparation-receipt.json")
    assert identity["inverse_byte_equal"] and identity["original_statement_order_preserved"]
    assert identity["original_lines_removed_or_rewritten"] == identity["new_wrappers"] == 0
    operations = identity["signature_operations"] + identity["derive_operations"] + identity["actor_operations"]
    assert len(operations) == len(set(operations)) == identity["new_local_operation_count"] == 11
    assert "actor_index.rebuild" in operations
    assert sha(target / SEGMENT_IDENTITY) == receipt["manifest_sha256"]
    assert sha(target / ALL_IDENTITY) == receipt["all_instance_identity_sha256"]
    assert sha(parent / ALL_IDENTITY) == identity["parent_all_instance_identity_sha256"]
    assert sha(proof / "parent-all-instance-profile-identity.json") == identity["parent_all_instance_identity_sha256"]
    sources = [{**identity, "stem": "public_areas"}] + [{**entry, "stem": "hospital_space"} for entry in identity["additional_sources"]]
    checked = []
    for row in sources:
        generated = (target / row["source_file"]).read_bytes()
        text = generated.decode("utf8")
        for insertion in reversed(row["insertions"]):
            chunk = insertion["chunk"]
            assert digest(chunk.encode()) == insertion["chunk_sha256"] and text.count(chunk) == 1
            text = text.replace(chunk, "", 1)
        original = (parent / row["source_file"]).read_bytes()
        assert text.encode("utf8") == original
        assert original == (proof / (row["stem"] + ".original-all-wrapper.gd.txt")).read_bytes()
        assert original == (proof / (row["stem"] + ".inverse-reconstructed.gd.txt")).read_bytes()
        assert digest(original) == row["original_complete_source_sha256"] == row["inverse_complete_source_sha256"]
        assert digest(generated) == row["generated_complete_source_sha256"]
        checked.append({"path": row["source_file"], "original_sha256": digest(original), "generated_sha256": digest(generated), "inverse_byte_equal": True})
    all_identity = read(target / ALL_IDENTITY)
    for row in all_identity["files"]:
        assert sha(target / row["path"]) == row["generated_sha256"], row["path"]
    return {"side": side, "source_root": str(directory), "identity_sha256": sha(target / SEGMENT_IDENTITY), "all_identity_sha256": sha(target / ALL_IDENTITY), "new_wrappers": 0, "operations": operations, "new_local_operation_count": len(operations), "modified_files": checked, "complete_inverse_byte_equal": True}


def binary_proof(identity, project):
    base = project / "game/platform/windows/bin"
    assert sha(base / "oddly_good_platform.windows.x86_64.dll") == identity["native_sha256"].lower()
    assert sha(base / "libgmp-10.dll") == identity["gmp_sha256"].lower()
    assert sha(base / "libmpfr-6.dll") == identity["mpfr_sha256"].lower()
    for name, expected in identity["runtime_sha256"].items():
        assert sha(base / name) == expected.lower(), (project, name)


def archive_evidence(batches, wrapper_directories, test_rows, changed_production):
    files = {}

    def add(path, name):
        path = pathlib.Path(path)
        assert path.is_file(), path
        assert name not in files or files[name] == path, name
        files[name] = path

    def local_runs(directory, prefix, all_runs):
        for path in directory.iterdir():
            if path.is_file() and path.suffix in {".json", ".bin", ".ndjson", ".log", ".py", ".ps1", ".txt", ".gd"}:
                if all_runs or path.name.startswith("segments-all-") or path.name in {"prepare-all.py", "prepare-segments.py", "run-segments.ps1"}:
                    add(path, prefix + path.name)
            elif path.is_dir() and path.name.startswith("segments-all-") and path.name.endswith(".json.sources"):
                for item in path.rglob("*"):
                    if item.is_file(): add(item, prefix + item.relative_to(directory).as_posix())

    local_runs(ROOT, "runs/", True)
    local_runs(PREVIOUS, "baseline-segments/", False)
    for side in ("before", "after"):
        plain = ROOT / (side + "-project")
        add(plain / "source-identity.json", "runs/" + side + "-project/source-identity.json")
        for path in plain.glob("*.log"): add(path, "runs/" + side + "-project/" + path.name)
    for side, directory in wrapper_directories.items():
        prefix = side + "-instrumentation/"
        all_project = directory / "after-all-project"
        for name in (ALL_IDENTITY, "source-identity.json"):
            add(all_project / name, prefix + "parent-all-project/" + name)
        for row in read(all_project / ALL_IDENTITY)["files"]:
            for relative in (row["path"], ".cache/tail-profile-originals/" + row["path"]):
                add(all_project / relative, prefix + "parent-all-project/" + relative)
        for path in all_project.glob("*.log"): add(path, prefix + "parent-all-project/" + path.name)
        for path in (directory / "segments-complete-proof").rglob("*"):
            if path.is_file(): add(path, prefix + "segments-complete-proof/" + path.relative_to(directory / "segments-complete-proof").as_posix())
        target = directory / "segments-complete-project"
        for name in (ALL_IDENTITY, SEGMENT_IDENTITY, "source-identity.json"):
            add(target / name, prefix + "segments-complete-project/" + name)
        for relative in ("game/life/public_areas.gd", "game/building/hospital_space.gd"):
            add(target / relative, prefix + "segments-complete-project/" + relative)
        for path in target.glob("*.log"): add(path, prefix + "segments-complete-project/" + path.name)
    for window, (_, name) in WINDOWS.items(): add(INPUTS / name, "inputs/" + name)
    for batch in batches:
        directory = REPO / ".cache/acceptance" / batch["batch"]
        prefix = "acceptance/" + batch["batch"] + "/"
        for path in directory.iterdir():
            if path.is_file() and path.suffix in {".json", ".log"}: add(path, prefix + path.name)
        for row in test_rows: add(directory / row["path"], prefix + "executed-source/" + row["path"])
    for row in changed_production: add(REPO / row["path"], "final-source/" + row["path"])
    manifest = []
    archive = OUT / "raw-evidence.zip"
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as container:
        for name, path in sorted(files.items()):
            container.write(path, name)
            manifest.append({"path": name, "sha256": sha(path), "bytes": path.stat().st_size})
    with zipfile.ZipFile(archive) as container:
        assert len(container.namelist()) == len(set(container.namelist())) == len(manifest)
        for row in manifest:
            blob = container.read(row["path"])
            assert digest(blob) == row["sha256"] and len(blob) == row["bytes"], row["path"]
    dump("raw-manifest.json", {"archive": archive.name, "sha256": sha(archive), "bytes": archive.stat().st_size, "entries": manifest, "every_entry_sha256_verified": True})
    return manifest, archive.stat().st_size


def main():
    before = read(ROOT / "before-project/source-identity.json")
    after = read(ROOT / "after-project/source-identity.json")
    baseline_rows = [r for r in before["source"] if r["path"].startswith(PREFIXES)]
    final_rows = [r for r in after["source"] if r["path"].startswith(PREFIXES)]
    assert len(baseline_rows) == len(final_rows) == 442
    assert {r["path"] for r in baseline_rows} == {r["path"] for r in final_rows}
    for row, blob in zip(baseline_rows, git_blobs([BASE + ":" + r["path"] for r in baseline_rows])):
        assert digest(blob) == row["sha256"] == sha(ROOT / "before-project" / row["path"]), row["path"]
    current = [{**r, "match": sha(REPO / r["path"]) == r["sha256"] == sha(ROOT / "after-project" / r["path"])} for r in final_rows]
    assert all(r["match"] for r in current)
    old_hashes = {r["path"]: r["sha256"] for r in baseline_rows}
    changed_production = [r for r in current if old_hashes[r["path"]] != r["sha256"]]
    binary_equal = {key: before[key] == after[key] for key in BINARY_KEYS}
    assert all(binary_equal.values()) and before["native_sha256"].lower() == EXPECTED_NATIVE
    for identity, project in ((before, ROOT / "before-project"), (after, ROOT / "after-project"), (after, REPO)):
        binary_proof(identity, project)
    console_engine = pathlib.Path(before["engine"])
    assert sha(console_engine) == before["engine_sha256"].lower()
    gui_engine = console_engine.with_name(console_engine.name.replace("_console", ""))

    windows, profiles, launches = [], [], []
    for window in WINDOWS:
        rows = [measured(ROOT, label, window, "before" if label in {"a", "d"} else "after")[0] for label in ("a", "b", "c", "d")]
        same_work(rows)
        before_mean = statistics.mean(rows[i]["metrics"]["mean_us"] for i in (0, 3))
        after_mean = statistics.mean(rows[i]["metrics"]["mean_us"] for i in (1, 2))
        windows.append({"window": window, "runs": rows, "whole_world_equal": True, "before_mean_us": before_mean, "after_mean_us": after_mean, "mean_reduction_percent": (1 - after_mean / before_mean) * 100})
        launches.extend(row["launch"] for row in rows)
        for side, directory in (("before", PREVIOUS), ("after", ROOT)):
            row, data = measured(directory, "segments-all", window, side)
            same_work([rows[0], row])
            profile = data["profile"]
            assert not profile["errors"] and profile["step_records_complete"] and profile["incomplete_steps"] == 0
            indices = {sample["tick"]: sample["index"] for sample in data["samples"]}
            steps = [{"index": indices[s["tick"]], "tick": s["tick"], "outer_us": s["outer_elapsed_us"], "observer_us": s["observer_handler_us"], "stages": s["stages"], "calls": s["calls"], "local_segments": {k: v for k, v in s["calls"].items() if k.startswith("actor_index.") or k.startswith("public_areas.signature_") or k.startswith("public_areas.derive_")}} for s in profile["step_records"] if s["calls"]]
            assert steps
            profiles.append({**row, "errors": profile["errors"], "steps": steps, "raw_profile_retained": True, "real_rebuild_operation": "actor_index.rebuild"})
            launches.append(row["launch"])
    engines = {row["engine_executable_sha256"].lower() for row in launches}
    assert engines == {sha(gui_engine)}

    directory = REPO / ".cache/acceptance" / BATCH
    result = read(directory / "acceptance-results.json")
    execution = read(directory / "execution-status.json")
    assert result["completed"] and result["failed"] == 0
    assert set(result["requested_cases"]) == REQUIRED_CASES == set(result["results"])
    assert result["checks"] == result["declared"] == len(REQUIRED_CASES)
    assert all(item["passed"] for item in result["results"].values())
    assert execution["import_exit"] == execution["test_exit"] == 0 and not execution["script_errors"]
    batches = [{"batch": BATCH, "result": result, "timing": read(directory / "timing-summary.json"), "execution": execution}]
    test_identity = read(directory / "source-identity.json")
    test_rows = [r for r in test_identity["source"] if r["path"].startswith("tests/acceptance/")]
    assert test_rows and any(r["path"].endswith("manual_seat_departure_scope.gd") for r in test_rows)
    for row in test_rows:
        assert sha(directory / row["path"]) == row["sha256"], row["path"]
    # Later work may add an unrelated STAFF-57 helper or hook. Retain the
    # complete executed snapshot, but only these five second-batch test edits
    # are claimed as byte-identical delivery sources for this evidence.
    delivery_tests = [r for r in test_rows if r["path"] in DELIVERY_TEST_PATHS]
    assert {r["path"] for r in delivery_tests} == DELIVERY_TEST_PATHS
    for row in delivery_tests:
        assert sha(REPO / row["path"]) == row["sha256"], row["path"]
    current_test_observations = [{"path": r["path"], "matches_executed_snapshot": (REPO / r["path"]).is_file() and sha(REPO / r["path"]) == r["sha256"]} for r in test_rows]
    test_game = [r for r in test_identity["source"] if r["path"].startswith(("game/", "content/"))]
    for row in test_game:
        assert sha(REPO / row["path"]) == sha(directory / row["path"]) == row["sha256"], row["path"]
    test_binary_equal = {key: after[key] == test_identity[key] for key in BINARY_KEYS}
    assert all(test_binary_equal.values())
    binary_proof(test_identity, directory)
    wrapper_directories = {"before": PREVIOUS, "after": ROOT}
    wrapper_checks = [wrapper_proof(side, parent / "after-all-project", ROOT / (side + "-project")) for side, parent in wrapper_directories.items()]
    segment_checks = [segment_proof(side, parent) for side, parent in wrapper_directories.items()]
    OUT.mkdir(parents=True, exist_ok=True)
    dump("quick-summary.json", {"baseline": BASE, "diagnostic_only": True, "formal_pass": False, "formal_acceptance_paused": True, "execution_order": ["a:before", "b:after", "c:after", "d:before"], "windows": windows, "caution": "Plain A/B/B/A independent fixed legal 160-person windows. Percentiles are not pooled. No intermediate variant and no native binary change. Ordinary editor headless debug diagnostics are not Release acceptance."})
    dump("function-summary.json", {"baseline": BASE, "profiles": profiles, "transform_originals": wrapper_checks, "local_segment_inverses": segment_checks, "caution": "Before profiles are retained from the previous root's segments-all runs, not labeled as new after results. Parent 309 wrappers and 11 reversible local segments perturb time. Real actor_index.rebuild counts are separate from _ensure_actor_index entrance counts. Inclusive parents contain children and cannot be added to infer plain whole-step gains."})
    dump("functional-summary.json", {"batches": batches, "affected_cases": sorted(REQUIRED_CASES), "all_selected_affected_cases_passed": True, "formal_pass": False, "formal_acceptance_paused": True, "caution": "One batch, six selected affected cases. No full topic or formal performance acceptance claim."})
    dump("source-check.json", {"baseline": BASE, "baseline_files": baseline_rows, "final_files": current, "changed_production_files": changed_production, "binary_equal": binary_equal, "before_native": before["native_sha256"], "after_native": after["native_sha256"], "actual_engine_sha256": next(iter(engines)), "actual_engine_path": str(gui_engine), "console_engine_sha256": sha(console_engine), "test_binary_equal": test_binary_equal, "transform_originals": wrapper_checks, "local_segment_inverses": segment_checks, "executed_test_files": test_rows, "test_file_count": len(test_rows), "final_test_files": delivery_tests, "delivery_test_file_count": len(delivery_tests), "current_test_snapshot_observations": current_test_observations, "test_snapshot_boundary": "All executed acceptance test bytes are frozen and archived. Only final_test_files are second-batch changed delivery tests. Later unrelated test additions or hooks are not claimed as executed by this batch.", "test_game_matches": True, "complete_results_and_every_sample_validated": True})
    entries, archive_bytes = archive_evidence(batches, wrapper_directories, test_rows, changed_production)
    print(json.dumps({"archive_entries": len(entries), "archive_bytes": archive_bytes, "baseline_files": len(baseline_rows), "final_files": len(current), "test_files": len(test_rows), "affected_cases": len(REQUIRED_CASES), "formal_acceptance_paused": True}))
    for window in windows:
        print(window["window"], window["before_mean_us"], window["after_mean_us"], window["mean_reduction_percent"])


if __name__ == "__main__":
    main()
