import hashlib
import json
import re
import statistics
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SCRATCH = Path(__file__).resolve().parent

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def save(name, value):
    (SCRATCH / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

quick = {'diagnostic_only': True, 'formal_pass': False, 'formal_acceptance_paused': True, 'runs': {}}
for version, project, prefix in [('before', 'before-project', 'before'), ('after', 'after-project', 'after'), ('second', 'final-project', 'final'), ('third', 'verified-project', 'verified'), ('final', 'complete-project', 'complete')]:
    identity = SCRATCH / project / 'source-identity.json'
    if not identity.exists():
        continue
    source = read(identity)
    for scene in ['public', 'gp', 'operations']:
        path = SCRATCH / f'{prefix}-{scene}.json'
        if not path.exists():
            continue
        value = read(path)
        quick['runs'][f'{version}-{scene}'] = {
            'head': source['head'], 'native_sha256': source['native_sha256'],
            'final_binary_sha256': value.get('final_binary_sha256'),
            'input_sha256': value['source_input_sha256'], 'metrics': value['metrics'],
            'complete': value['complete'], 'qualified': value['qualified'],
            'qualification': value['qualification'], 'errors': value['errors'],
            'public_checks': value.get('public_checks', {}),
            'query_counts': value.get('public', {}).get('query_counts', {}),
            'present_min': value['final']['minimum_present'], 'present_max': value['final']['maximum_present'],
            'same_actor_ids': value['final']['same_actor_ids'],
            'clinical_work_ticks': value['final'].get('work_ticks_by_kind', {}),
            'execution': value['execution'], 'artifact': path.name,
        }
quick['same_final_binary_by_scene'] = {scene: len({row['final_binary_sha256'] for name,row in quick['runs'].items() if name.endswith('-'+scene)})==1 for scene in ['public','gp','operations']}
save('quick-summary.json', quick)

micro = {'diagnostic_only': True, 'formal_pass': False, 'versions': {}}
for version in ['before', 'after']:
    library = read(SCRATCH / f'{version}-library.json')
    algorithm = read(SCRATCH / f'{version}-algorithm.json')
    rounds = [op for op in library['operations'] if op['operation'] == 'json_world_roundtrip']
    infos = [op for op in library['operations'] if op['operation'] == 'real_database_file_info']
    micro['versions'][version] = {
        'library_ok': library['ok'], 'algorithm_ok': algorithm['ok'],
        'input_sha256': library['input_sha256'], 'json_bytes': rounds[0]['bytes'], 'json_sha256': rounds[0]['sha256'],
        'encode_median_us': statistics.median(op['encode_us'] for op in rounds),
        'decode_median_us': statistics.median(op['decode_us'] for op in rounds),
        'file_info_median_us': statistics.median(op['elapsed_us'] for op in infos),
        'database_bytes': infos[0]['result']['bytes'],
        'io': {op['operation']: op['elapsed_us'] for op in library['operations'] if op['operation'] in ['real_sqlite_save', 'real_backup_export', 'real_backup_import']},
        'matching_median_us': {row['pattern']: statistics.median(row['samples_us']) for row in algorithm['matching']},
        'shape_median_us': {str(row['size']): statistics.median(row['samples_us']) for row in algorithm['shapes']},
    }
save('micro-summary.json', micro)

batches, latest = [], {}
for logname in ['nav-functional-1.log', 'library-functional-1.log', 'nav-functional-2.log'] + [f'functional-{n}.log' for n in range(3,15)]:
    log = SCRATCH / logname
    if not log.exists():
        continue
    found = re.search(r'ACCEPTANCE_PROJECT=(.+)', log.read_text(encoding='utf-8-sig'))
    if not found:
        continue
    project = Path(found.group(1).strip())
    entry = {'log': logname, 'project_id': project.name}
    for filename in ['timing-summary.json', 'execution-status.json']:
        if (project / filename).exists():
            entry[filename] = read(project / filename)
    if (project / 'acceptance-results.json').exists():
        results = read(project / 'acceptance-results.json')
        entry.update({k: results.get(k) for k in ['completed', 'declared', 'checks', 'failed', 'elapsed_ms', 'requested_cases']})
        for case, row in results['results'].items():
            latest[case] = {'passed': row['passed'], 'project_id': project.name, 'log': logname, 'requirement': row['requirement']}
    batches.append(entry)
save('functional-summary.json', {'batches': batches, 'latest_per_case': dict(sorted(latest.items())), 'latest_unique_cases': len(latest), 'latest_passed': sum(row['passed'] for row in latest.values()), 'scope': 'Selected affected functional cases only; no full-suite or formal-performance claim.'})

profiles = {}
for name in ['before-public-root20', 'before-continuation-root20', 'complete-public-root80']:
    path = SCRATCH / f'{name}.json'
    if path.exists():
        value = read(path)
        profiles[name] = {k: value.get(k) for k in ['complete', 'qualified', 'qualification', 'metrics', 'source_input_sha256']}
        profiles[name]['profile'] = {k: value.get('profile', {}).get(k) for k in ['root_stages', 'profiled_whole_us', 'observer_handler_us', 'residual_us', 'errors', 'sources']}
        if name == 'complete-public-root80':
            plain_rows = read(SCRATCH / 'complete-public.json')['samples'][:80]
            profiled_rows = value['samples']
            same_sample_facts = len(plain_rows) == len(profiled_rows) and all(
                {k:v for k,v in left.items() if k!='elapsed_us'} == {k:v for k,v in right.items() if k!='elapsed_us'}
                for left,right in zip(plain_rows,profiled_rows)
            )
            profiles[name]['plain_same_input_prefix'] = {
                'steps': len(plain_rows),
                'elapsed_us': sum(row['elapsed_us'] for row in plain_rows),
                'same_recorded_sample_facts': same_sample_facts,
                'comparison': 'Elapsed-time perturbation only; no saved plain step-80 final world and no claim of final-world equality at that boundary.'
            }
save('phase-summary.json', profiles)
print(json.dumps({'quick_runs': len(quick['runs']), 'unique_cases': len(latest), 'passed': sum(row['passed'] for row in latest.values())}))
