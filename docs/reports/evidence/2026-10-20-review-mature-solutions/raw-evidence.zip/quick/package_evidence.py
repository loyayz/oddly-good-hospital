import hashlib
import json
import re
import shutil
import subprocess
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SCRATCH = Path(__file__).resolve().parent
DEST = ROOT / 'docs/reports/evidence/2026-10-20-review-mature-solutions'
DEST.mkdir(parents=True, exist_ok=True)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

entries = {}
def add(path, name):
    if path.is_file():
        entries[name] = path

# Authored summaries only. The shared review HTML and extracted answers are
# intentionally excluded; the report contains an independently worded matrix.
for path in SCRATCH.iterdir():
    if path.is_file() and (path.suffix in ['.json', '.log', '.ndjson', '.bin'] or path.name in ['route-cost-consumers.md','library_probe.gd','algorithm_probe.gd','continuation_input.gd','index_probe.gd','summarize.py','write_report.py','package_evidence.py']):
        add(path, 'quick/' + path.name)
    if path.is_dir() and path.name.endswith('.sources'):
        for source in path.rglob('*'):
            add(source, 'quick/' + source.relative_to(SCRATCH).as_posix())

identities = {}
for project in ['before-project', 'after-project', 'final-project', 'verified-project', 'complete-project']:
    identity = SCRATCH / project / 'source-identity.json'
    identities[project] = read(identity)
    add(identity, f'sources/{project}/source-identity.json')
    add(identity.parent / 'import.log', f'sources/{project}/import.log')

for log in SCRATCH.glob('*functional-*.log'):
    found = re.search(r'ACCEPTANCE_PROJECT=(.+)', log.read_text(encoding='utf-8-sig'))
    if not found:
        continue
    project = Path(found.group(1).strip())
    for name in ['source-identity.json','fixture-config.json','import.log','execution.log','execution-status.json','acceptance-results.json','timing-summary.json']:
        add(project / name, f'functional/{project.name}/{name}')

inputs = ROOT / '.cache/task-navigation-20261019'
for name in ['public-v6.input.bin','gp.input.bin','op.input.bin']:
    add(inputs / name, 'inputs/' + name)
    add(inputs / (name + '.provenance.json'), 'inputs/' + name + '.provenance.json')
for name in ['rebase_input.gd','rebase-public-v6.log','rebase-gp.log','rebase-op.log']:
    add(inputs / name, 'inputs/' + name)

delivery = {'implementation_head': identities['complete-project']['head'], 'native_sha256': identities['complete-project']['native_sha256'], 'compared_game_files': [], 'all_match': True, 'functional_final_source_match': True}
for row in identities['complete-project']['source']:
    if not row['path'].startswith('game/'):
        continue
    actual = ROOT / row['path']
    equal = actual.is_file() and sha(actual) == row['sha256']
    blob = subprocess.run(['git','show',delivery['implementation_head']+':'+row['path']],cwd=ROOT,capture_output=True,check=True).stdout
    blob_equal = hashlib.sha256(blob).hexdigest() == row['sha256']
    delivery['compared_game_files'].append({'path':row['path'],'sha256':row['sha256'],'workspace_matches_frozen':equal,'git_blob_matches_frozen':blob_equal})
    delivery['all_match'] &= equal and blob_equal
if not delivery['all_match']:
    raise RuntimeError('Measured game source differs from delivery')
latest_functional = read(SCRATCH / 'functional-summary.json')['latest_per_case']['SPACE-55']['project_id']
functional_source = read(ROOT / '.cache/acceptance' / latest_functional / 'source-identity.json')
functional_by_path = {row['path']:row['sha256'] for row in functional_source['source']}
delivery['functional_final_source_match'] = all(functional_by_path.get(row['path'])==row['sha256'] for row in identities['complete-project']['source'] if row['path'].startswith('game/'))
if not delivery['functional_final_source_match']:
    raise RuntimeError('Final functional and performance game sources differ')
save(SCRATCH / 'delivery-source-check.json', delivery)
add(SCRATCH / 'delivery-source-check.json', 'quick/delivery-source-check.json')

commands = {'scope':'Quick diagnosis only; formal performance acceptance paused.', 'build':['pwsh','-File','tools/build-platform-guard.ps1'], 'functional_final':['pwsh','-File','tests/run-acceptance.ps1','-CaseId','SPACE-55,STAFF-41,STAFF-42,STAFF-52'], 'ordinary':[]}
for version, project, prefix in [('before','before-project','before'),('after','after-project','after'),('second','final-project','final'),('third','verified-project','verified'),('final','complete-project','complete')]:
    for scene, filename, steps in [('public','public-v6.input.bin',300),('gp','gp.input.bin',80),('operations','op.input.bin',40)]:
        commands['ordinary'].append({'version':version,'scene':scene,'head':identities[project]['head'],'args':[identities[project]['engine'],'--headless','--path',str(SCRATCH/project),'--script','res://tools/performance/representative.gd','--','--input='+str(inputs/filename),'--output='+str(SCRATCH/f'{prefix}-{scene}.json'),'--steps='+str(steps),'--profile=plain']})
commands['final_root_diagnostic'] = [identities['complete-project']['engine'],'--headless','--path',str(SCRATCH/'complete-project'),'--script','res://tools/performance/representative.gd','--','--input='+str(inputs/'public-v6.input.bin'),'--output='+str(SCRATCH/'complete-public-root80.json'),'--steps=80','--profile=root']
save(DEST / 'commands.json', commands)
for name in ['quick-summary.json','functional-summary.json','micro-summary.json','phase-summary.json','delivery-source-check.json']:
    shutil.copyfile(SCRATCH / name, DEST / name)
shutil.copyfile(SCRATCH / 'route-cost-consumers.md', DEST / 'route-cost-consumers.md')
for project, identity in identities.items():
    save(DEST / f'{project}-identity.json', {key:value for key,value in identity.items() if key!='source'})

archive = DEST / 'raw-evidence.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as output:
    for name, path in sorted(entries.items()):
        output.write(path, name)
manifest = [{'entry':name,'bytes':path.stat().st_size,'sha256':sha(path)} for name,path in sorted(entries.items())]
save(DEST / 'raw-manifest.json', {'entries':manifest,'archive':{'name':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive)}})
with zipfile.ZipFile(archive) as check:
    assert check.testzip() is None
    assert len(check.infolist()) == len(manifest)
    for row in manifest:
        assert hashlib.sha256(check.read(row['entry'])).hexdigest()==row['sha256']

(DEST / 'README.md').write_text('''# 评审修复与成熟实现替换证据

正式性能验收暂停；全部性能数字为固定输入快速诊断。

- [整步汇总](quick-summary.json)：五个实现版本、三个相同160人场景、资格、时间、工作量。
- [选例汇总](functional-summary.json)：批次、前提、准备／测试耗时、失败及最新逐项结果。
- [子操作汇总](micro-summary.json)：JSON、真实SQLite／备份和合成算法；不代替整步。
- [阶段汇总](phase-summary.json)：最终80步覆盖实际诊疗的根阶段诊断，以及早期诊断的资格限制；基线后续20步没有实际临床工时，资格为false。
- [交付来源核验](delivery-source-check.json)：最终测量游戏文件逐项对比冻结提交及最终功能回归来源。
- [命令](commands.json)、五份工程身份、[原始归档](raw-evidence.zip)、[逐文件SHA256清单](raw-manifest.json)。

归档保留本轮原始失败及无收益结果。第三方评审完整原文、玩家资料、导入缓存、编译库和完整隔离工程不在归档中。JSON库子操作在2cfa8db测量，最终提交没有修改其实现；构建SHA差异来自新增距离场API，不能把子操作数字当作最终普通整步的组成时间。
''', encoding='utf-8')
print(json.dumps({'entries':len(manifest),'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive),'game_files_compared':len(delivery['compared_game_files']),'source_match':delivery['all_match']}))
