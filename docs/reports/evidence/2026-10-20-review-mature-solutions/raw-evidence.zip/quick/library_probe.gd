extends SceneTree

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var args: PackedStringArray = OS.get_cmdline_user_args()
	var input: String = args[0]
	var output: String = args[1]
	var file: FileAccess = FileAccess.open(input,FileAccess.READ)
	var payload: Dictionary = file.get_var()
	file.close()
	var content: HospitalContent = HospitalContent.new()
	var world: WorldState = WorldState.new(payload.facts)
	var facts: Dictionary = world.freeze()
	var report: Dictionary = {"diagnostic_only":true,"formal_pass":false,"input_sha256":FileAccess.get_sha256(input),"present":world.present_actor_count(),"validation":world.validate(content),"operations":[],"ok":true}
	var budget: Callable = func(_bytes: int)->bool: return true
	var path: String = "user://review-world.json"
	for iteration: int in 3:
		var codec: HospitalJsonStream = HospitalJsonStream.new()
		var started: int = Time.get_ticks_usec()
		var encoded: bool = codec.encode(path,facts,budget)
		var encode_us: int = Time.get_ticks_usec()-started
		started = Time.get_ticks_usec()
		var decoded: Dictionary = codec.decode(path,codec.bytes,codec.digest,budget) if encoded else {"ok":false,"error":codec.error}
		var decode_us: int = Time.get_ticks_usec()-started
		var equal: bool = decoded.ok and decoded.value==facts
		report.operations.append({"iteration":iteration,"operation":"json_world_roundtrip","encode_us":encode_us,"decode_us":decode_us,"bytes":codec.bytes,"sha256":codec.digest,"ok":equal,"error":decoded.get("error","")})
		report.ok = report.ok and equal
	var guard: RefCounted = ClassDB.instantiate("PlatformSessionGuard")
	var acquired: Dictionary = guard.call("acquire")
	if acquired.ok:
		var store: HospitalSnapshots = HospitalSnapshots.new(content,guard)
		var started: int = Time.get_ticks_usec()
		var begin: Dictionary = store.begin(world,"review-library-probe")
		var receipt: Dictionary = store.wait_for_idle() if begin.ok else begin
		report.operations.append({"operation":"real_sqlite_save","elapsed_us":Time.get_ticks_usec()-started,"ok":receipt.ok,"error":receipt.get("error","")})
		report.ok = report.ok and receipt.ok
		if receipt.ok:
			var library: HospitalLibrary = HospitalLibrary.new(content,store)
			var zip: HospitalBackupZip = HospitalBackupZip.new()
			var dbpath: String = HospitalSnapshots.ROOT.path_join(world.hospital_id).path_join(HospitalSnapshots.DATABASE_NAME)
			for iteration: int in 3:
				started = Time.get_ticks_usec()
				var info: Dictionary = zip.file_info(dbpath,budget)
				report.operations.append({"iteration":iteration,"operation":"real_database_file_info","elapsed_us":Time.get_ticks_usec()-started,"result":info})
				report.ok = report.ok and info.ok
			started = Time.get_ticks_usec()
			var exported: Dictionary = library.export_backup(world.hospital_id,receipt.snapshot_id,"user://review.oghbackup")
			report.operations.append({"operation":"real_backup_export","elapsed_us":Time.get_ticks_usec()-started,"ok":exported.ok,"error":exported.get("error","")})
			report.ok = report.ok and exported.ok
			if exported.ok:
				started = Time.get_ticks_usec()
				var imported: Dictionary = library.import_backup("user://review.oghbackup")
				report.operations.append({"operation":"real_backup_import","elapsed_us":Time.get_ticks_usec()-started,"ok":imported.ok,"error":imported.get("error","")})
				report.ok = report.ok and imported.ok
		guard.call("release")
	else:
		report.ok = false
		report.guard = acquired
	var result_file: FileAccess = FileAccess.open(output,FileAccess.WRITE)
	result_file.store_string(JSON.stringify(report,"\t"))
	result_file.close()
	quit(0 if report.ok else 1)
