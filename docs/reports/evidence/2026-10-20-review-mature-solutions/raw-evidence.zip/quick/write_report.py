import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SCRATCH = Path(__file__).resolve().parent
REPORT = ROOT / 'docs/reports/2026-10-20-review-mature-solutions.md'

def read(name):
    return json.loads((SCRATCH / name).read_text(encoding='utf-8-sig'))

quick_summary = read('quick-summary.json')
quick = quick_summary['runs']
micro = read('micro-summary.json')['versions']
functional = read('functional-summary.json')
phase = read('phase-summary.json')['complete-public-root80']
final_head = quick['final-public']['head']
text = (SCRATCH / 'resolution-draft.md').read_text(encoding='utf-8-sig')
text = text.replace('dev 第六轮评审与成熟实现替换', 'dev 评审修复、移动碰撞与成熟实现替换')
text = text.replace('评审源：https://chatgpt.com/share/6ad70e7a-7df8-83e9-9401-80e2bffab446 。', '评审源：[源码评审](https://chatgpt.com/share/6ad70e7a-7df8-83e9-9401-80e2bffab446)。')
text = text.replace('楼层版本和共享连接状态复核', '静态楼层版本和共享连接状态复核；预约占用与授权不再触发静态整路重校验')
text = text.replace('按身体token、成员与偏移', '按路线自身保存的真实身体数值、姿态、成员与偏移')
text = text.replace('实际移动才生成路径', '实际移动及需要路线占地的安全见证才生成路径')
locations = {
    'R1': '`hospital_movement.gd::request_group_move`',
    'R2': '`hospital_navigation.gd::_route_result/_floor_route`、`floor_navigation.gd::find_path`及全部52处直接消费者',
    'R3': '`hospital_movement.gd::_active_route_clear`、`navigation_cache.gd::floor_static_version`',
    'R4': '`hospital_movement.gd::_dispatch_routes`及原生`PlatformRouteQueue`',
    'R5': '`hospital_space.gd::_build_reservation_view/_index_reservation`及预约释放边界',
    'R6': '`hospital_navigation.gd::_point_route/_point_edges`、`hospital_transit.gd::_routing_candidates`',
    'R7': '`hospital_movement.gd::_yield/_yield_idle_staff/_staff_has_movement_responsibility`',
    'R8': '`hospital_movement.gd::_reserve_doors`、`hospital_space.gd`门候选索引',
    'R9': '`hospital_movement.gd::_movement_clear`、`hospital_space.gd::_unit_step_dynamic_clear`',
    'R10': '`navigation_cache.gd::_trim`及图／查询触碰入口',
}
for code, location in locations.items():
    text = text.replace(f'| {code} | ', f'| {code} | {location}：')
text = text.replace('按几何身份缓存楼层连接、停层和节点声明；', '按几何身份缓存楼层连接、停层和节点声明，在已知同步投影边界继承相同结构；')
text = text.replace('## 成熟方案替换与保留理由', 'R2所有完整路线消费者的字段与处理理由见[逐处审查表](evidence/2026-10-20-review-mature-solutions/route-cost-consumers.md)。保留路径的实际移动、动态绕行和准备点让路见证也逐项列出。\n\n## 成熟方案替换与保留理由')
text = text.replace('| 建造连通及孔洞检查 |', '| 重复端点距离场 | Boost.Graph breadth_first_search | 删除两处脚本BFS，借用同一FloorNavigation的四位出边掩码；保留12次命中门槛、有向边、预约及UP/LEFT/RIGHT/DOWN顺序，失败回AStar2D；每图新增9216字节计入原缓存预算 |\n| 建造连通及孔洞检查 |')
text = text.replace('当前采用成熟AStar2D及按包络、权限和几何身份缓存的路线；前者会计算未访问连接，后者在只需少量目标时遍历整层。没有为这项选项引入另一套网格搜索及重复几何权威。', '当前采用AStar2D点到点搜索，达到原12次端点命中门槛才由Boost BFS建立距离场，共用同一图的边。预先计算全部组合会计算未访问连接，每次全层搜索在少量目标时会扩大工作量；未采用取消摊销门槛的做法。')

def ms(value):
    return f'{value / 1000:.2f}'

sections = '''### 固定来源与计时边界

最终实现冻结为 `FINAL_HEAD`，初版替换为 `2cfa8db352a55debe559fa94391949bb616f6798`，第二次补充为 `7f140e8ce0a32496fb9d7b1ea932d0d9abd5a54f`，第三次补充为 `b17f3f1384a3349dfb3cb15df5faa295b00a687a`，基线为 `f9dec5b23d87f492fbc4c588a543427a109a93a0`。五者使用同一Godot 4.7.2 `ed1daf0bf`、Windows、Intel Core Ultra 5 125H；三个场景前后读取同一份输入文件，不重建或削减负载。各自从冷服务缓存启动，普通整步依次执行，计时期间没有并行构建、其他测量或代理测试。

每个场景始终保持120病人、32员工、8普通访客，共160个相同身份的在院人物；64房间、1336设施和原业务规则保留。公共场景输入SHA256为 `1d83a8834528fd2f6c53dff06f6ec150c9e598eed675fc37521ab7e45fcadb10`。原始输入、来源链、操作配置和逐步输出均归档。

计时为headless编辑器/debug引擎中的普通 `HospitalSimulation.step()`，原生后端O2编译。包括真实诊疗、排队和移动；不包括GameSession后台完整742病例容量准备、渲染及持久化IO。不能换算为正式Release帧率。普通整步、插桩阶段和IO微测量分别报告。

### 普通整步：最终对照及失败的中间结果

单位ms；p99在80步与40步窗口中接近或等于最大值，样本不足以估计长期尾分布。following为剔除首步后的均值。

| 场景／版本 | 步数 | 均值 | following均值 | p50 | p95 | p99 | 最大值 | 冷首步 | 合法场景资格 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
'''
for scene, label in [('public', '公共设施'), ('gp', 'GP'), ('operations', '运营')]:
    for version, name in [('before', '基线'), ('after', '初版2cfa8db'), ('second', '第二次7f140e8'), ('third', '第三次b17f3f1'), ('final', '最终'+final_head[:7])]:
        row = quick[f'{version}-{scene}']
        m = row['metrics']
        values = [m[key] for key in ['mean_us', 'following_mean_us', 'p50_us', 'p95_us', 'p99_us', 'max_us', 'cold_first_us']]
        sections += f"| {label}／{name} | {m['count']} | " + ' | '.join(ms(v) for v in values) + f" | {'通过' if row['qualified'] else '未通过'} |\n"
sections += '\n'
for scene, label in [('public', '公共设施'), ('gp', 'GP'), ('operations', '运营')]:
    before = quick[f'before-{scene}']['metrics']['mean_us']
    after = quick[f'final-{scene}']['metrics']['mean_us']
    sections += f"{label}最终整步均值相对基线变化 **{(after / before - 1) * 100:+.1f}%**。"
sections += '''这是单次固定窗口观察值，没有逐建议消融实验，不能给每项修改分摊独立收益。功能正确性修改、库维护收益与实测性能收益不混写。

最终公共最大单步仍由11.62s退化到20.83s；GP最大值由26.17s降到21.86s，仍有严重长尾。运营均值79.22→151.03ms（+90.6%），剔除冷首步后42.99→76.33ms（+77.6%），属于实测退化，不能宣称本轮整体性能达标。五个版本每个场景的最终世界二进制SHA256各自一致，这是额外观察到的事实一致性；正确性仍由当前设计和独立边界断言定义，不以旧输出为规则。

初版公共场景均值由979.52ms退化至1377.00ms，最大值由11.62s增加至20.06s；运营也退化。第二次虽把拓扑构建4627次降为6次，公共均值996.79ms仍没有快过基线，整路复核及路径物化几乎未降。第三次将复核降为339次、路径物化降为18729格，但公共均值反而为1440.57ms，仍没有整步收益。三组原始失败／无收益结果均保留。

沿实际计数及调用链补齐：静态路线不再沿用含动态占用的版本，也不依赖会被报价投影索引清空的身体token；37处纯成本／布尔旅程调用与2处纯层内计算改用成本契约，真正移动与见证保留路径。最后发现候诊返程、设施往返和员工候选报价仍为一个假定人物位置重建全院身体索引。该结构成本链完全不读人物索引，最终版移除这三处无用同步与私有动态查询，同时保留实际适配安全预检及真实移动碰撞。8361065是初版路径物化格子总数，含确实需要的出口见证，不能全部算成无用格子。`can_reach`在初版已经使用成本模式，不能把它记成后来发现的新收益。

### 工作量证据与逐建议的测量边界

以下为同一公共场景300步的模拟主Space计数，不汇总临时独立Space。计数引入前标为“未计数”，不以零冒充；已引入但未触发的稀疏事件显示0。

| 计数／对应建议 | 基线 | 初版 | 第二次 | 第三次 | 最终 |
| --- | ---: | ---: | ---: | ---: | ---: |
'''
count_rows = [
    ('floor_route_builds', '楼层路线查询 R2/R6'),
    ('static_path_builds', '实际AStar构建 R2/R6'),
    ('static_path_hits', '静态路径复用 R6'),
    ('materialized_floor_cells', '物化脚本路径格子 R2'),
    ('route_checks', '活跃路线轻量检查 R3'),
    ('route_revalidations', '剩余静态整路复核 R3'),
    ('route_revalidation_unvalidated', '尚无成功证明而复核 R3'),
    ('route_revalidation_body', '真实身体变化触发复核 R3'),
    ('route_revalidation_formation', '成员／偏移变化触发复核 R3'),
    ('route_revalidation_floor', '静态楼层变化触发复核 R3'),
    ('route_revalidation_connection', '连接变化触发复核 R3'),
    ('connector_topology_builds', '连接拓扑构建 R6'),
    ('connector_node_declarations', '连接节点声明 R6'),
    ('connector_topology_inherits', '同步投影拓扑继承 R6'),
    ('route_dispatch_restores', '冷恢复调度队列 R4'),
    ('route_dispatch_scans', '调度出堆 R4'),
    ('route_dispatches', '实际调度路线 R4'),
    ('reservation_index_builds', '预约索引重建 R5'),
    ('reservation_index_updates', '预约索引增量更新 R5'),
    ('movement_candidates', '身体候选 R7/R9'),
    ('door_candidates', '门候选 R8'),
    ('reservation_candidate_queries', '预约候选查询 R9'),
    ('yield_attempts', '让行决策 R7'),
    ('yield_candidates', '让行候选 R7'),
    ('distance_field_builds', 'Boost距离场构建'),
    ('distance_field_failures', '距离场失败回退'),
    ('actor_index_builds', '主Space人物索引全量重建 R2'),
    ('actor_index_actor_visits', '这些重建实际扫描人物 R2'),
    ('cache_query_clears', '缓存预算清理查询 R10'),
    ('cache_graph_evictions', '缓存预算驱逐图 R10'),
]
for key, label in count_rows:
    values = []
    for version in ['before','after','second','third','final']:
        counts = quick[f'{version}-public']['query_counts']
        introduced = (key.startswith('route_revalidation_') and version in ['third','final'] or key.startswith('distance_field_') and version in ['second','third','final'] or key.startswith('cache_') and version!='before')
        values.append(str(counts.get(key,0 if introduced else '未计数')))
    sections += f'| {label} | ' + ' | '.join(values) + ' |\n'
sections += '''
R1以目标生效、非法目标原子拒绝及真实到场验证正确性，不宣称独立加速。R2～R9的工作量变化与整步数据一起使用，不能以候选数或命中数代替时间。复核原因仅在实际整路复核时计数；未证明路线只记unvalidated，已证明路线同次可有多个变化原因，原因总和不要求等于复核总数。R10没有单独构造缓存压力性能场景，LRU淘汰正确性由预算清空／恢复边界覆盖；不宣称其实际内存或速度已达标。

### JSON、备份及算法子操作

这组对子操作的实际计时使用基线及初版2cfa8db；最终补充未改变对应JSON、ZIP、个人床匹配或建造组件实现，复用这份证据。各3次JSON／file_info取中位数；真实保存、导出、导入各1次。JSON为同一份956307字节世界，前后SHA256同为 `77d8f3d0e82b201309fbf111dfb8661eed7ecade6bf07597ecaebb8f1cdea3fc`，完整事实往返相等。真实SQLite数据库均1007616字节，保存点身份和创建时间不同，数据库文件哈希不要求相同。

| 子操作 | 修改前ms | 修改后ms | 说明 |
| --- | ---: | ---: | --- |
'''
for key, label, note in [('encode_median_us','JSON编码','3次中位数'),('decode_median_us','JSON解码','3次中位数'),('file_info_median_us','真实数据库CRC及SHA','3次中位数')]:
    sections += f"| {label} | {ms(micro['before'][key])} | {ms(micro['after'][key])} | {note} |\n"
for key, label in [('real_sqlite_save','真实SQLite保存'),('real_backup_export','真实备份导出'),('real_backup_import','真实备份导入')]:
    sections += f"| {label} | {ms(micro['before']['io'][key])} | {ms(micro['after']['io'][key])} | 单次真实管线 |\n"
for key, label in [('dense_32','32员工／32床稠密匹配'),('chain_32','32员工链式匹配'),('scarce_16','32员工／16床缺床匹配')]:
    sections += f"| {label} | {ms(micro['before']['matching_median_us'][key])} | {ms(micro['after']['matching_median_us'][key])} | 合成算法输入，10次中位数 |\n"
for key in ['24','96']:
    sections += f"| {key}×{key}建造形状 | {ms(micro['before']['shape_median_us'][key])} | {ms(micro['after']['shape_median_us'][key])} | 合法矩形，3次中位数 |\n"
sections += '''
JSON及真实备份明显受益；稠密／链式匹配及形状检查没有性能收益，明确保留退化值。匹配仍保最大覆盖和医院的优先顺序，组件仍保连通与孔洞规则；采用成熟实现的理由是删除重复通用算法并集中维护，不将这些结果描述为加速。合成算法时间不能外推为160人整步收益。旧报告中“JSON小数由MPFR解码”的表述不准确：该桥接一直使用Windows UCRT `_strtod_l`，本轮没有改变小数语义。

### 功能回归与失败记录

'''
sections += f"当前最新有效证据共 **{functional['latest_unique_cases']}项选定用例，{functional['latest_passed']}项通过**。\n\n"
sections += '、'.join(functional['latest_per_case']) + '。\n\n'
sections += '''本轮只选择变化的事实与交接：移动目标／排队／同组与安全离位、几何／预约／权限投影、个人床优先匹配、建造连通、结构容量可达性及JSON／备份失败原子性。接口含义未变的库结果复用已有选例证据；新增静态版本、投影拓扑及距离场在最终补充上重测。批次、前置状态来源、准备与测试时间、逐项结果及源码身份见functional-summary.json与原始归档，不将重复执行累计成更多用例。

原始失败均保留：

- 原生依赖接入曾出现Boost头文件、minizip配置、图适配类型歧义与未使用接口的编译错误，修复后统一构建通过。
- 第一批导航用例暴露缓存占位值类型错误；JSON／ZIP用例暴露负零、EOF空哈希块及严格EOCD定位问题，均已修复。
- 一次导入发生新脚本／旧DLL不匹配；此后冻结源码和DLL后再统一准备，不以该导入认定功能通过。
- 新移动回归暴露旧waiting_reason未清理，已修复；另有测试StringName键、等待边界前提及二进制32位位置舍入的断言问题，分别纠正输入／前提／数值误差范围，游戏速度、步长和性能阈值未变。
- 最终补充首批14项中12项断言通过、2项因测试接口失配失败；整批有脚本错误，不认定整批通过。更新受影响的签名、直接距离场调用和删去失效的旧计时钩子，重跑4项全部通过。没有借机重构验证工具。
- 后续17项代表批次发现旧门计时接口、碰撞测试调用归属未同步；修正后重跑受影响项。OPS-44另把出口临时有人当成结构无路，与任务／寻路／移动规格§3相反，现同时断言结构路线可出发、实际出口扫掠仍受阻；该项重跑通过。所有业务规则均以当前规格为依据，未靠旧内核输出定义正确答案。
- 额外的160人空座报价子测量，给定人物及目标被真实身体阻挡，随后对该人物也未找到满足前提的空座，保留两次失败；没有换走阻挡者或改成全空设施。该子测量不给前后加速结论，索引取消由独立边界断言及完整300步的实际计数／计时验证。
- 个别混合批次退出出现ObjectDB／Resource未释放警告；最终4项重跑无该警告。这不是全游戏内存无增长证明，正式内存与稳定性仍未执行。

'''

sections += '''### 最终阶段诊断与剩余瓶颈

最终80步从同一公共输入开始，覆盖真实诊疗、公共设施和高成本操作；160人身份始终不变，世界合法、实际临床工时及所有本窗口适用的资格检查通过。普通整步与根阶段插桩分别执行，以下只说明时间落在哪个阶段，不给每项库替换分摊收益。

| 根阶段 | 调用次数 | 总计ms | 占插桩整步 | 单次最大ms |
| --- | ---: | ---: | ---: | ---: |
'''
for row in phase['profile']['root_stages'][:6]:
    sections += f"| `{row['name']}` | {row['calls']} | {ms(row['total_us'])} | {row['profiled_whole_share']*100:.2f}% | {ms(row['max_us'])} |\n"
prefix = phase['plain_same_input_prefix']
profile_us = phase['profile']['profiled_whole_us']
sections += f'''
插桩整步合计{ms(profile_us)}ms，同输入普通300步的前80步合计{ms(prefix['elapsed_us'])}ms，差异{(profile_us/prefix['elapsed_us']-1)*100:+.2f}%；已记录的逐步人数、移动、会话与生命周期事件字段一致。没有保存普通第80步的最终世界，因此不声称该边界完整事实逐字段相等。观察器开销{ms(phase['profile']['observer_handler_us'])}ms，根阶段之外残差{ms(phase['profile']['residual_us'])}ms；整段墙钟扰动不能仅用观察器回调耗时扣除。

第28次执行（index=27，完成tick=2651）耗时20.406s，其中`dispatch.waiting`为20.320s，约99.58%；同输入普通窗口最大值20.833s也发生在这个边界。当前主要时间落在候诊／公共设施任务调度，不能继续笼统归咎于每步移动碰撞：本80步的`movement.space`只占3.58%。这份根阶段证据尚未细分该调度内的设施适配、安全出口见证、报价投影与路线搜索各占多少，也没有解释运营退化的独立耗时来源；不能把剩余时间全部写成A*耗时。后续若继续优化，应先在这个实际边界细分调用，保留合法排队和完整安全预检，不再由辅助函数变快推断整步达标。

早期公共前20步也包含实际临床工作，但主要覆盖冷启动，`dispatch.waiting`占61.96%，不能代表后半段尾延迟。另从基线真实300步后的完整世界构造20步后续诊断，只替换观察元数据，世界事实逐字节不变、始终160人且世界合法；该窗口没有实际临床工时，资格为false，保留退出失败与完整阶段记录，仅用于公共设施／移动诊断，不能当作合格临床性能验证。所有阶段占比均以对应插桩整步为分母。

10类源码问题已落实对应修复及相关回归；7项具体替代选项的取舍有独立理由。运营退化、公共／GP长尾和正式验收仍是未解决事项。成熟库替换没有自动解决所有性能问题。
'''

text = text.replace('待最终选例及同源快速窗口完成后填入原始结果。失败结果保留，不以修改后的结果覆盖。', sections)
text = text.replace('FINAL_HEAD', final_head)
intro = '''本轮10类代码建议均采纳并修复，另落实工作量／阶段测量建议；54项选定相关用例的最新证据通过。同一合法160人快速窗口中，公共整步均值979.52→828.12ms（减少15.5%），GP 1071.32→574.43ms（减少46.4%），运营79.22→151.03ms（增加90.6%）。公共最大单步11.62→20.83s，不能认定性能验收通过。根阶段诊断将20秒长尾定位到候诊／公共设施任务调度，内部细分与运营退化归因仍未完成。

'''
text = text.replace('## 评审逐项处理', intro+'## 评审逐项处理')
text += '''
## 交付证据

[证据目录](evidence/2026-10-20-review-mature-solutions/README.md)提供机器可读汇总、来源身份、原始归档及SHA256清单。归档包含原始失败、逐步计时、固定合法输入、真实最终世界、选例结果和本轮诊断脚本；不包含完整第三方评审原文、玩家医院、引擎导入缓存或编译库二进制。

原生最终构建SHA256为 `6bed87c44e561939b18f11dc37c8747c5dea88fbd7947f71f601c7df2ccc236d`，15609856字节。Boost 1.92.0-4、RapidJSON固定提交、minizip-ng 4.2.2与zlib 1.3.2的源码包SHA和许可证交付路径记录在构建日志／脚本；没有引入运行时联网依赖。

选型接口依据：[Boost BFS](https://www.boost.org/doc/libs/latest/libs/graph/doc/html/graph/algorithms/traversal/breadth_first_search.html)、[Boost Dijkstra](https://www.boost.org/doc/libs/latest/libs/graph/doc/html/graph/algorithms/shortest_paths/dijkstra_shortest_paths.html)、[Godot PhysicsServer2D](https://docs.godotengine.org/en/4.7/classes/class_physicsserver2d.html)、[Box2D距离及形状扫掠](https://box2d.org/documentation/group__distance.html)。接口能否直接替代以游戏的双移动／可变包络与严格接触规则核实，通用库名称不构成性能验收结果。
'''
REPORT.parent.mkdir(parents=True, exist_ok=True)
REPORT.write_text(text, encoding='utf-8')
print(REPORT)
