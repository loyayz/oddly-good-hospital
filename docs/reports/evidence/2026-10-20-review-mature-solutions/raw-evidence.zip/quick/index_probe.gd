extends SceneTree

class CountedSpace extends HospitalSpace:
	var sync_visits: Dictionary = {}
	func _sync_actor(world: WorldState, id: String) -> void:
		var owner: int = world.get_instance_id()
		sync_visits[owner] = int(sync_visits.get(owner,0))+1
		super._sync_actor(world,id)
	func sync_total() -> int:
		var total: int = 0
		for count: int in sync_visits.values(): total += count
		return total

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var args: PackedStringArray = OS.get_cmdline_user_args()
	var source: FileAccess = FileAccess.open(args[0],FileAccess.READ)
	var payload: Dictionary = source.get_var()
	source.close()
	var content: HospitalContent = HospitalContent.new()
	var world: WorldState = WorldState.new(payload.facts)
	var facts: Dictionary = world.freeze()
	var space: CountedSpace = CountedSpace.new(content)
	var life: HospitalWaitingLife = HospitalWaitingLife.new(content,space)
	var report: Dictionary = {"diagnostic_only":true,"formal_pass":false,"input_sha256":FileAccess.get_sha256(args[0]),"present":world.present_actor_count(),"validation":world.validate(content),"samples":[],"ok":true}
	var visit_id: String = args[2] if args.size()>2 else "bench_visit_0024"
	var facility_id: String = args[3] if args.size()>3 else ""
	if facility_id.is_empty():
		for id: String in world.ids("facilities"):
			if life._public_seat(world,world.facts.facilities[id]) and life._facility_quote(world,world.facts.visits[visit_id],id).get("ok",false):
				facility_id = id
				break
	if facility_id.is_empty():
		push_error("No legal free seat quote in the unchanged world")
		quit(1)
		return
	report.visit_id = visit_id
	report.facility_id = facility_id
	for iteration: int in 3:
		# A real caller has a current source-world index. Its preparation is
		# outside this facility quote; no actor or facility fact is changed.
		space.begin_dynamic_route_query(world)
		var initial_visits: int = space.sync_total()
		var source_visits: int = int(space.sync_visits.get(world.get_instance_id(),0))
		var started: int = Time.get_ticks_usec()
		var quote: Dictionary = life._facility_quote(world,world.facts.visits[visit_id],facility_id)
		var elapsed: int = Time.get_ticks_usec()-started
		var all_delta: int = space.sync_total()-initial_visits
		var source_delta: int = int(space.sync_visits.get(world.get_instance_id(),0))-source_visits
		space.end_route_query()
		var readonly: bool = facts==world.freeze()
		report.samples.append({"iteration":iteration,"elapsed_us":elapsed,"actor_sync_visits":all_delta,"source_actor_sync_visits":source_delta,"projection_actor_sync_visits":all_delta-source_delta,"quote":quote,"facts_unchanged":readonly})
		report.ok = report.ok and quote.get("ok",false) and readonly
	var output: FileAccess = FileAccess.open(args[1],FileAccess.WRITE)
	output.store_string(JSON.stringify(report,"\t"))
	output.close()
	quit(0 if report.ok else 1)
