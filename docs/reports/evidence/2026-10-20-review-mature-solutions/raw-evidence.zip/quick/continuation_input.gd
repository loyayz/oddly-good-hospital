extends SceneTree

func _initialize() -> void:
	var args: PackedStringArray = OS.get_cmdline_user_args()
	var source: FileAccess = FileAccess.open(args[0],FileAccess.READ)
	var payload: Dictionary = source.get_var()
	source.close()
	var completed: FileAccess = FileAccess.open(args[1],FileAccess.READ)
	var final: Dictionary = completed.get_var()
	completed.close()
	var content: HospitalContent = HospitalContent.new()
	var world: WorldState = WorldState.new(final.facts)
	var validation: String = world.validate(content)
	if not validation.is_empty() or world.present_actor_count()!=160:
		push_error("Invalid actual continuation: "+validation)
		quit(1)
		return
	payload.facts = final.facts
	# Reset observer metadata only. All world facts come from 300 actual steps.
	payload.representative_clinical = {"metadata":{"continuation":{"source_final_sha256":FileAccess.get_sha256(args[1]),"actual_steps":300}}}
	var output: FileAccess = FileAccess.open(args[2],FileAccess.WRITE)
	output.store_var(payload)
	output.close()
	print(JSON.stringify({"source_final_sha256":FileAccess.get_sha256(args[1]),"output_sha256":FileAccess.get_sha256(args[2]),"present":world.present_actor_count(),"validation":validation,"facts_unchanged":var_to_bytes(payload.facts)==var_to_bytes(final.facts)}))
	quit()
