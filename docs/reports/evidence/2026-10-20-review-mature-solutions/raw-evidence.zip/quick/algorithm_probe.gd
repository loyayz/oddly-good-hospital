extends SceneTree

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var report: Dictionary = {"diagnostic_only":true,"formal_pass":false,"ok":true,"matching":[],"shapes":[]}
	var staff: Array = []
	for n: int in 32: staff.append("staff_%02d"%n)
	for pattern: String in ["dense_32","chain_32","scarce_16"]:
		var candidates: Dictionary = {}
		for n: int in 32:
			candidates[staff[n]] = []
			for bed: int in (16 if pattern=="scarce_16" else 32):
				if pattern=="chain_32" and bed!=n and bed!=(n+1)%32: continue
				candidates[staff[n]].append({"bed_id":"bed_%02d"%bed,"travel_ticks":absi(n-bed)*10+bed})
		var samples: Array = []
		var expected: Dictionary = {}
		var stable: bool = true
		for iteration: int in 10:
			var started: int = Time.get_ticks_usec()
			var result: Dictionary = HospitalPersonalBedMatching.solve(staff,candidates)
			samples.append(Time.get_ticks_usec()-started)
			if iteration==0: expected = result
			stable = stable and result==expected
		var covered: bool = expected.size()==(16 if pattern=="scarce_16" else 32)
		report.matching.append({"pattern":pattern,"samples_us":samples,"owners":expected,"stable":stable,"expected_coverage":covered})
		report.ok = report.ok and stable and covered
	for size: int in [24,96]:
		var samples: Array = []
		var ok: bool = true
		for iteration: int in 3:
			var started: int = Time.get_ticks_usec()
			var result: Dictionary = BuildGeometry.shape({"origin":[0,0],"size":[size,size]},[3,3])
			samples.append(Time.get_ticks_usec()-started)
			ok = ok and result.ok and result.cells.size()==size*size
		report.shapes.append({"size":size,"samples_us":samples,"ok":ok})
		report.ok = report.ok and ok
	var file: FileAccess = FileAccess.open(OS.get_cmdline_user_args()[0],FileAccess.WRITE)
	file.store_string(JSON.stringify(report,"\t"))
	file.close()
	quit(0 if report.ok else 1)
