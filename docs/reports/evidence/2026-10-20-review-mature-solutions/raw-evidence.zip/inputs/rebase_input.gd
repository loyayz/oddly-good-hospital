extends SceneTree
func _initialize() -> void:
	var options: Dictionary = {}
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--") and "=" in arg: options[arg.trim_prefix("--").get_slice("=",0)] = arg.substr(arg.find("=")+1)
	var source: FileAccess = FileAccess.open(options.input,FileAccess.READ)
	var input: Dictionary = source.get_var()
	source.close()
	var content: HospitalContent = HospitalContent.new()
	var facts_sha: String = _sha(var_to_bytes(input.facts))
	var world: WorldState = WorldState.new(input.facts)
	var reason: String = world.validate(content)
	var fixed: bool = true
	for id: String in world.facts.adaptations:
		var reservation: Dictionary = world.facts.adaptations[id]
		if reservation.kind!="facility": continue
		var facility: Dictionary = world.facts.facilities[id]
		var definition: Dictionary = content.facility_definition(facility.definition_id)
		var profile: Dictionary = content.definition("facility_fit_profiles",str(definition.get("fit_profile_id","")))
		if profile.get("extent_rule","")!="max_base_and_reclined_body": fixed = fixed and reservation.footprint==facility.footprint
	var report: Dictionary = {"source":options.input,"source_sha256":FileAccess.get_sha256(options.input),"previous_content_fingerprint":input.content_fingerprint,"new_content_fingerprint":content.content_fingerprint,"facts_sha256":facts_sha,"facts_unchanged":facts_sha==_sha(var_to_bytes(world.freeze())),"validation":reason,"all_nonstretching_facility_footprints_fixed":fixed,"present":world.present_actor_count()}
	var ok: bool = content.error.is_empty() and reason.is_empty() and report.facts_unchanged and fixed and report.present==160
	if ok:
		input.content_fingerprint = content.content_fingerprint
		input.content_rebase = report
		var target: FileAccess = FileAccess.open(options.output,FileAccess.WRITE)
		target.store_var(input)
		target.close()
	var record: FileAccess = FileAccess.open(str(options.output)+".provenance.json",FileAccess.WRITE)
	record.store_string(JSON.stringify(report,"\t"))
	record.close()
	print("INPUT_IDENTITY="+JSON.stringify(report))
	quit(0 if ok else 1)
func _sha(bytes: PackedByteArray) -> String:
	var hash: HashingContext = HashingContext.new()
	hash.start(HashingContext.HASH_SHA256)
	hash.update(bytes)
	return hash.finish().hex_encode()
