from pathlib import Path
import sys,json,hashlib
base=Path('C:/Users/cong/dot-work/ogh-worker-handoff-20261112');base.mkdir(exist_ok=False)
old=Path('C:/Users/cong/dot-work/ogh-fixed-boundary-20261112');project=old/'.cache/boundary-project'
sys.path.insert(0,str(old/'tools/performance/current'))
import prepare_builtin_script_profile as guard
import prepare_transport_trace as overlay
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
meta=json.loads((old/'input-identity.json').read_text());inp=old/'plain8/result.json.final.bin'
assert sha(inp)=='4de4fc8af69271b1374fd9be4dcc1bbce93265598c900654ade65065dc30638f'
for rel,digest in meta['source'].items(): assert sha(project/rel)==digest,rel
steps=64
command=lambda out:[meta['engine'],'--headless','--path',str(project),'--script','res://tools/performance/current/plain_v4.gd','--','--input='+str(inp),'--output='+str(out),'--steps='+str(steps),'--prefix-steps=0','--worker-tasks=4','--main-thread-policy=app']
print('Plain bounded 64 steps',flush=True)
guard.run_process(command(base/'plain64/result.json'),project,base/'plain64',180)
patches={
 'game/building/hospital_transit.gd':overlay.transit_patch(project/'game/building/hospital_transit.gd'),
 'game/building/hospital_movement.gd':overlay.movement_patch(project/'game/building/hospital_movement.gd'),
}
p=patches['game/building/hospital_transit.gd']
marker='\tvar at_entry: bool=_at_landing(space,world,connection,movement,segment)\n'
p.replace(marker,marker+'\tif actor.id in ["maintenance_contractor_00000238","maintenance_contractor_00000239"]: _TransportDiagnostic._record(world,"worker_begin",{"actor":_TransportDiagnostic._actor(world,actor.id),"at_entry":at_entry,"connection":_TransportDiagnostic._connection(connection)})\n')
marker='\tif not at_entry:\n\t\tspace.movement._queue_route(world,movement,true)\n'
p.replace(marker,'\tif not at_entry:\n\t\tif actor.id in ["maintenance_contractor_00000238","maintenance_contractor_00000239"]: _TransportDiagnostic._record(world,"worker_queue_landing_recovery",{"actor":_TransportDiagnostic._actor(world,actor.id)})\n\t\tspace.movement._queue_route(world,movement,true)\n')
p=overlay.Patch(project/'tools/performance/current/plain_v4.gd')
p.replace('extends SceneTree\n','extends SceneTree\n'+overlay.PREFIX)
p.replace('\tvar initial: Dictionary = snapshot(world)\n','\t_TransportDiagnostic.prepare(world,content)\n\tvar initial: Dictionary = snapshot(world)\n')
p.replace('\tvar attribution: Dictionary = profiler.report() if profile_stages else {}\n','\t_TransportDiagnostic.finish(output+".transport.json",world)\n\twrite_json(output+".maintenance.json",world.facts.maintenance)\n\tvar attribution: Dictionary = profiler.report() if profile_stages else {}\n')
patches['tools/performance/current/plain_v4.gd']=p
manifest={rel:p.checked() for rel,p in patches.items()}
(base/'overlay.json').write_text(json.dumps(manifest,indent=2))
try:
 for p in patches.values():p.path.write_bytes(p.text.encode())
 print('Observed bounded 64 steps',flush=True)
 guard.run_process(command(base/'trace64/result.json'),project,base/'trace64',180)
 a=json.loads((base/'plain64/result.json').read_text());b=json.loads((base/'trace64/result.json').read_text())
 assert a['complete'] and b['complete'] and a['all_completed_steps']==64 and a['final_sha256']==b['final_sha256']
 (base/'comparison.json').write_text(json.dumps({'complete_world_rng_ordered_events_equal':True,'final_sha256':a['final_sha256'],'input_sha256':sha(inp),'steps':steps},indent=2))
 print('World RNG ordered events equal',flush=True)
finally:
 for p in patches.values():p.path.write_bytes(p.original)
 for rel,digest in meta['source'].items():assert sha(project/rel)==digest,rel
 print('Production sources fully restored',flush=True)
